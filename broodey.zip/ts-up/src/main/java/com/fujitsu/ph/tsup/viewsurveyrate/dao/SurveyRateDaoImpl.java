//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : SurveyRateDaoImpl                                                                                                                                                               
// Class Name   : SurveyRateDaoImpl.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.01    | 2021/08/16 | WS)E.Juan             | New Creation        
// 0.02    | 2021/10/12 | WS)MI.Aguinaldo       | Added findSurveyResponses        
// 0.03    | 2021/10/27 | WS)L.Celoso           | Added findSurveyResponses using course schedule ID
//==================================================================================================     
package com.fujitsu.ph.tsup.viewsurveyrate.dao;


import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.viewsurveyrate.domain.SurveyRateForm;
    
    
@Repository
public class SurveyRateDaoImpl implements SurveyRateDao {
    
    @Autowired
    private NamedParameterJdbcTemplate template;
    
    /**
     * display all the survey result that has the same course title, Instructor name, and course date time
     * @param courseTitle, InstructorName, courseDateTime
     * @return SurveyRateForm
     */

    @Override
    public Set<SurveyRateForm> findSurvey(String courseTitle,String InstructorName,ZonedDateTime courseDateTime) {
        String sql= "SELECT * from survey_form WHERE coursetitle = :c_title AND instructorname = :c_insname AND coursedatetime = :c_coursedatetime";
                 
                  

                  
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("c_title", courseTitle)
                .addValue("c_insname", InstructorName)
                .addValue("c_coursedatetime",courseDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());
        
        List<SurveyRateForm> surveyRateForm = template.query(sql, namedParameters, new SurveyRateRowMapper());
        Set<SurveyRateForm> setSurveyRateForm = new HashSet<SurveyRateForm>(surveyRateForm);
        return setSurveyRateForm;
    }

    /**
     * Find survey responses.
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return Set<SurveyResponse>
     */
    @Override
    public Set<SurveyResponse> findSurveyResponses(String courseTitle, String instructorName,
            ZonedDateTime courseDateTime) {
        String sql = "SELECT * " +
                    "FROM survey_form " +
                    "WHERE coursetitle = :c_title " +
                    "AND instructorname = :c_insname "+
                    "AND coursedatetime = :c_coursedatetime";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("c_title", courseTitle)
                .addValue("c_insname", instructorName)
                .addValue("c_coursedatetime",courseDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());
        
        List<SurveyResponse> surveyRateForm = template.query(sql, namedParameters, new SurveyResponseRowMapper());
        
        return surveyRateForm.isEmpty() ? Collections.emptySet() : new HashSet<>(surveyRateForm);
    }

    /**
     * Find survey responses.
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return Set<SurveyResponse>
     */
    @Override
    public Set<SurveyResponse> findSurveyResponses(Long courseScheduleId) {
        String sql = "SELECT * " +
                    "FROM survey_form " +
                    "WHERE course_schedule_id = :courseScheduleId";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("courseScheduleId", courseScheduleId);
        
        List<SurveyResponse> surveyRateForm = template.query(sql, namedParameters, new SurveyResponseRowMapper());
        
        return surveyRateForm.isEmpty() ? Collections.emptySet() : new HashSet<>(surveyRateForm);
    }


    
    
}

/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.importing.web;

import static com.fujitsu.ph.tsup.importing.service.ImportingDataServiceImpl.EXISTING_DATA;
import static com.fujitsu.ph.tsup.importing.service.ImportingDataServiceImpl.NEW_DATA;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.category.service.CourseCategoryManagementService;
import com.fujitsu.ph.tsup.exception.ImportDataException;
import com.fujitsu.ph.tsup.importing.model.ImportingDataForm;
import com.fujitsu.ph.tsup.importing.model.SabaDTO;
import com.fujitsu.ph.tsup.importing.service.ImportingDataService;

// =======================================================
// Project Name: Data Upload
// Class Name: DataUploadController.java
//
// <<Modification History>>
// Version | Date | Updated by | Content
// --------+------------+-------------------+---------------
// 0.01 | 23/06/2021 | WS) m.yanoyan    | Created
// 0.02 | 07/09/2021 | WS) mi.aguinaldo | Update
// 0.03 | 2021/09/28 | WS) j.lugtu      | Removed CSV methods
// 0.04 | 2021/10/14 | WS) j.lugtu      | Updated method for trainee info import
// 0.05 | 2021/10/14 | WS) j.lazo       | Added processing via importData
// 0.06 | 2021/10/27 | WS) j.lazo       | Added imported course count checking
// =======================================================

@Controller
@RequestMapping("/dataUpload")
public class DataUploadController {
    private static final String SUCCESS_MSG_MODAL_ATTRIBUTE = "successMsg";
    private static final String ERROR_MSG_MODAL_ATTRIBUTE = "errorMsg";
    private static final String SUCCESS_COURSE_INFO_MODAL_ATTRIBUTE = "courseInfo";

    private static final Logger LOGGER = LoggerFactory.getLogger(DataUploadController.class);

    private List<SabaDTO> dtoHolder;

    @Autowired
    private ImportingDataService importingDataService;

    @Autowired
    private CourseCategoryManagementService courseCategoryManagementService;

    @GetMapping("/load")
    public String load(Model model) {
        ImportingDataForm dataForm = new ImportingDataForm();

        model.addAttribute("importingDataForm", dataForm);
        return "data-upload/uploadCSVData";
    }

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("multipartFile") MultipartFile file, Model model) {

        List<SabaDTO> dtos = new ArrayList<>();
        List<String> traineeInfoEmails = new ArrayList<String>();

        ImportingDataForm dataForm = new ImportingDataForm();

        List<CourseCategory> courseCategoryList = courseCategoryManagementService.findAllCourseCategory()
                .stream().collect(Collectors.toList());
        try {

            if (importingDataService.hasExcelFormat(file)) {
                dtos = importingDataService.excellToSabaDTOs(file);
                traineeInfoEmails = importingDataService.extractTraineeInfoEmail(file);

                int nonExistingUsers = importingDataService.getNumberOfNewUsers(traineeInfoEmails);

                if (nonExistingUsers == 0) {
                    Map<String, List<SabaDTO>> segregatedExistingAndNewOfCourses = importingDataService
                            .segregateExistingAndNewOfCourses(dtos);

                    List<SabaDTO> existingData = segregatedExistingAndNewOfCourses.get(EXISTING_DATA);

                    importingDataService.updateCoursesWithoutCourseCode(existingData);
                    dtoHolder = dtos;
                    List<SabaDTO> newData = segregatedExistingAndNewOfCourses.get(NEW_DATA);

                    dataForm.setSabaDTOs(newData);
                    dataForm.setImportedData(dtos.size());

                    String msgString = "You have successfully imported " + newData.size()
                            + " Member Course Information";

                    //if there are no new courses, skip import of course category from continue-importing POST.
                    if (newData.size() == 0) {
                        importingDataService.importData(dtoHolder);
                    }

                    model.addAttribute(SUCCESS_MSG_MODAL_ATTRIBUTE, msgString);
                } else {
                    throw new ImportDataException("Failed to update course. There are " + nonExistingUsers
                            + " unregistered users in the system from the file.");
                }
            }

        } catch (RuntimeException e) {
            LOGGER.error(e.getMessage(), e);
            model.addAttribute(ERROR_MSG_MODAL_ATTRIBUTE, e.getMessage());
        }

        model.addAttribute("importingDataForm", dataForm);
        model.addAttribute("courseCategory", courseCategoryList);
        return "data-upload/uploadFragment :: upload";
    }

    @PostMapping("/continue-importing")
    public String continueImporting(@ModelAttribute ImportingDataForm dataForm,
            RedirectAttributes redirectAttributes) {

        try {
            int totalCategoryCreated = importingDataService.createCourseCategories(dataForm.getSabaDTOs());

            int totalCourseCreated = importingDataService.createCourses(dataForm.getSabaDTOs());

            StringBuilder courseInfoSb = new StringBuilder("You have successfully imported the following:  ");
            courseInfoSb.append(totalCourseCreated + " new Course ");
            if (totalCategoryCreated > 0) {
                courseInfoSb.append(", ");
                courseInfoSb.append(totalCategoryCreated + " new Course Category");
            }

            importingDataService.importData(dtoHolder);

            redirectAttributes.addFlashAttribute(SUCCESS_COURSE_INFO_MODAL_ATTRIBUTE, courseInfoSb.toString());

            redirectAttributes.addFlashAttribute(SUCCESS_MSG_MODAL_ATTRIBUTE, "You have successfully imported "
                    + dataForm.getImportedData() + " Member Course Information.");

        } catch (RuntimeException e) {
            LOGGER.error(e.getMessage(), e);
            redirectAttributes.addAttribute(ERROR_MSG_MODAL_ATTRIBUTE, e.getMessage());
            return "redirect:/dataUpload/load#uploadFailModal";
        }

        return "redirect:/dataUpload/load#uploadSuccessModal";
    }
}

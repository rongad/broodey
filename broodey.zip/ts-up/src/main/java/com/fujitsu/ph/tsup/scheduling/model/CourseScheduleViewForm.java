package com.fujitsu.ph.tsup.scheduling.model;

import java.util.Objects;

//=======================================================
//$Id: PR02$
//Project Name: Training Sign Up
//Class Name: CourseScheduleViewForm.java
//
//<<Modification History>>
//Version | Date       | Updated by        | Content
//--------+------------+-------------------+---------------
//0.01    | 06/22/2020 | WS) J.Macabugao   | New Creation
//0.02    | 07/07/2021 | WS) J.Atendido    | Added required columns for View/Edit Datatable
//0.03    | 7/29/2021  | WS) J.Atendido    | Added column for total enrolled participants
//0.03    | 08/05/2021 | WS) MI.Aguinaldo  | Added a new constructor
//0.04    | 09/07/2021 | WS) L.Celoso      | Added Course Category
//=======================================================

/**
* <pre>
* It is a JavaBean for CourseScheduleViewForm
* <pre>
* @version 0.03
* @author j.macabugao
* @author j.atendido
*
*/

import java.util.Set;
import java.util.stream.Collectors;

import com.fujitsu.ph.tsup.scheduling.domain.CourseSchedule;
import com.fujitsu.ph.tsup.scheduling.domain.CourseScheduleDetail;

public class CourseScheduleViewForm {

    /**
     * Course Schedule Id
     */
    private Long id;

    /**
     * Course Id
     */
    private Long courseId;

    /**
     * Course Name
     */
    private String courseName;

    /**
     * Instructor Id
     */
    private Long instructorId;

    /**
     * Instructor Name(LASTNAME, FIRSTNAME)
     */
    private String instructorName;

    /**
     * Participants
     */
    private int participants;

    /**
     * Set of course schedule details
     */
    private Set<CourseScheduleDetailForm> courseScheduleDetails;

    /**
     * Minimum Allowed Participants
     */
    private Integer minAllowed;

    /**
     * Maximum Allowed Participants
     */
    private Integer maxAllowed;


    /**
     * Total Number of Participants
     */
    private Integer totalEnrolled;
    

    /**
     * Venue Name
     */
    private String venueName;
    
    /**
     * Course Category
     */
    private String courseCategory;
	/**
     * Mandatory Type
     */
    private String mandatoryType;
    
    /**
     * Mandatory
     */
    private String mandatory;
    
    public CourseScheduleViewForm() {
    }
    
    public CourseScheduleViewForm(CourseSchedule courseSchedule) {
	Objects.requireNonNull(courseSchedule, "CourseSchedule must not be null");
	Objects.requireNonNull(courseSchedule.getCourseScheduleDetail());
	
	this.id = courseSchedule.getId();
	this.courseId = courseSchedule.getCourseId();
	this.courseName = courseSchedule.getCourseName();
	this.courseCategory = courseSchedule.getCourseCategory();
	this.instructorId = courseSchedule.getInstructorId();
	this.instructorName = courseSchedule.getInstructorFullName();
	this.minAllowed = courseSchedule.getMinRequired();
	this.maxAllowed = courseSchedule.getMaxAllowed();
	this.venueName = courseSchedule.getVenueName();
	this.totalEnrolled = courseSchedule.getTotalParticipants();
	this.mandatory = courseSchedule.getMandatory();
	this.mandatoryType = courseSchedule.getMandatoryType();
	
	Set<CourseScheduleDetail> courseSchedDetails = courseSchedule.getCourseScheduleDetail();
	
	Set<CourseScheduleDetailForm> corsSchedDetailFormSet = courseSchedDetails.stream()
										 .map(csd -> new CourseScheduleDetailForm(
											 csd))
										 .collect(Collectors.toSet());
	this.courseScheduleDetails = corsSchedDetailFormSet;
	
    }

    public Long getId() {
	return id;
    }

    public void setId(Long id) {
	this.id = id;
    }

    public Long getCourseId() {
	return courseId;
    }

    public void setCourseId(Long courseId) {
	this.courseId = courseId;
    }

    public String getCourseName() {
	return courseName;
    }

    public void setCourseName(String courseName) {
	this.courseName = courseName;
    }

    public Long getInstructorId() {
	return instructorId;
    }

    public void setInstructorId(Long instructorId) {
	this.instructorId = instructorId;
    }

    public String getInstructorName() {
	return instructorName;
    }

    public void setInstructorName(String instructorName) {
	this.instructorName = instructorName;
    }

    public int getParticipants() {
	return participants;
    }

    public void setParticipants(int participants) {
	this.participants = participants;
    }

    public Set<CourseScheduleDetailForm> getCourseScheduleDetails() {
	return courseScheduleDetails;
    }

    public void setCourseScheduleDetails(Set<CourseScheduleDetailForm> courseScheduleDetails) {
	this.courseScheduleDetails = courseScheduleDetails;
    }

    public Integer getMinAllowed() {
	return minAllowed;
    }

    public void setMinAllowed(Integer minAllowed) {
	this.minAllowed = minAllowed;
    }

    public Integer getMaxAllowed() {
	return maxAllowed;
    }

    public void setMaxAllowed(Integer maxAllowed) {
	this.maxAllowed = maxAllowed;
    }

    public Integer getTotalEnrolled() {
        return totalEnrolled;
    }

    public void setTotalEnrolled(Integer totalEnrolled) {
        this.totalEnrolled = totalEnrolled;
    }

    public String getVenueName() {
	return venueName;
    }

    public void setVenueName(String venueName) {
	this.venueName = venueName;
    }
    
	public String getCourseCategory() {
		return courseCategory;
	}

	public void setCourseCategory(String courseCategory) {
		this.courseCategory = courseCategory;
	}

	public String getMandatoryType() {
		return mandatoryType;
	}

	public void setMandatoryType(String mandatoryType) {
		this.mandatoryType = mandatoryType;
	}

	public String getMandatory() {
		return mandatory;
	}

	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}

    @Override
    public String toString() {
		return "CourseScheduleViewForm [id=" + id + ", courseId=" + courseId + ", courseName=" + courseName
				+ ", instructorId=" + instructorId + ", instructorName=" + instructorName + ", participants="
				+ participants + ", courseScheduleDetails=" + courseScheduleDetails + ", venue=" + venueName
				+ ", minAllowed=" + minAllowed + ", maxAllowed=" + maxAllowed + ", totalEnrolled=" + totalEnrolled
				+ " , courseCategory=" + courseCategory + ", mandatory=" + mandatory + ", mandatoryType="
				+ mandatoryType + "]"; 
    }

}
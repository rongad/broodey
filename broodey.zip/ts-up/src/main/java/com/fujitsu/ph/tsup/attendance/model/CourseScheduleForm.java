package com.fujitsu.ph.tsup.attendance.model;


//==================================================================================================
//$Id:PR03$
//Project Name :Training Sign Up
//System Name  :Attendance process
//Class Name   :CourseScheduleForm.java
//
//<<Modification History>>
//Version | Date       | Updated By                             | Content
//--------+------------+----------------------------------------+-----------------------------------
//0.01    | 06/23/2020 |  WS) J. Iwarat                         | New Creation
//0.02    | 07/16/2020 |  WS) J. Iwarat                         | Update
//0.03    | 08/26/2020 |  WS) K.Abad WS) J.Iwarat WS) R.Ramos   | Update
//0.04    | 08/13/2021 |  WS) R.Gaquit						    | Update
//0.05    | 08/17/2021 |  WS) R.Gaquit						    | Update
//==================================================================================================
/**
 * <pre>
 * JavaBean for CourseScheduleForm
 * In this Class,Instances or fields of the List of the data for the initial setting of the data base 
 * 
 * <pre>
 * 
 * @version 0.05
 * @author k.abad
 * @author j.iwarat
 * @author r.ramos
 * @author r.gaquit
 */
public class CourseScheduleForm implements Comparable<CourseScheduleForm>{

    /**
     * Course Schedule Id
     */
    private Long id;

    /**
     * Course Id
     */
    private Long courseId;

    /**
     * Course Name
     */
    private String courseName;

    /**
     * Instructor Id
     */
    private Long instructorId;

    /**
     * Instructor Name(LASTNAME, FIRSTNAME)
     */
    private String instructorName;

    /**
     * Venue Id
     */
    private Long venueId;

    /**
     * Venue Name
     */
    private String venueName;
    
    /**
     * Mandatory Type
     */
    private String mandatoryType; //added 08/13/2021
    
    /**
     * Mandatory
     */
    private String mandatory; //added 08/13/2021
    
    /**
     * Set of course schedule details
     */
    private CourseScheduleDetailForm courseScheduleDetails;

    /**
     * Minimum number of participants
     */
    private int minRequired;

    /**
     * Maximum number of participants
     */
    private int maxAllowed;

    /**
     * Total Number of Participants currently enrolled
     */
    private int totalParticipants;
    
    //pagination code ============
    /** Current Page in pagination*/
    private String currentPage;
    //pagination code end=========

    /**
     * @return
     */
    public Long getId() {
        return id;
    }    

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return
     */
    public Long getCourseId() {
        return courseId;
    }

    /**
     * @param courseId
     */
    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    /**
     * @return
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * @param courseName
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    /**
     * @return
     */
    public Long getInstructorId() {
        return instructorId;
    }

    /**
     * @param instructorId
     */
    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    /**
     * @return
     */
    public String getInstructorName() {
        return instructorName;
    }

    /**
     * @param instructorName
     */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    /**
     * @return
     */
    public Long getVenueId() {
        return venueId;
    }

    /**
     * @param venueId
     */
    public void setVenueId(Long venueId) {
        this.venueId = venueId;
    }

    /**
     * @return
     */
    public String getVenueName() {
        return venueName;
    }

    /**
     * @param venueName
     */
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    /**
     * @return
     */
    public CourseScheduleDetailForm getCourseScheduleDetails() {
        return courseScheduleDetails;
    }

    /**
     * @param courseScheduleDetails
     */
    public void setCourseScheduleDetails(CourseScheduleDetailForm courseScheduleDetails) {
        this.courseScheduleDetails = courseScheduleDetails;
    }

    /**
     * @return
     */
    public int getMinRequired() {
        return minRequired;
    }

    /**
     * @param minRequired
     */
    public void setMinRequired(int minRequired) {
        this.minRequired = minRequired;
    }

    /**
     * @return
     */
    public int getMaxAllowed() {
        return maxAllowed;
    }

    /**
     * @param maxAllowed
     */
    public void setMaxAllowed(int maxAllowed) {
        this.maxAllowed = maxAllowed;
    }

    /**
     * @return
     */
    public int getTotalParticipants() {
        return totalParticipants;
    }

    /**
     * @param totalParticipants
     */
    public void setTotalParticipants(int totalParticipants) {
        this.totalParticipants = totalParticipants;
    }

	/**
     * @return mandatoryType
     */
    public String getMandatoryType() {
		return mandatoryType;
	}

    /**
     * @param mandatoryType
     */
	public void setMandatoryType(String mandatoryType) {
		this.mandatoryType = mandatoryType;
	}

	/**
     * @return mandatory
     */
	public String getMandatory() {
		return mandatory;
	}

	 /**
     * @param mandatory
     */
	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}

	@Override
    public String toString() {
        return "CourseScheduleForm [id = " + id + ", courseId = " + courseId + ", courseName = " + courseName
                + ", instructorId = " + instructorId + ", instructorName = " + instructorName + ", venueId = " + venueId
                + ", venueName = " + venueName + ", courseScheduleDetails = " + courseScheduleDetails
                + ", minRequired = " + minRequired + ", maxAllowed = " + maxAllowed + ", totalParticipants = "
                + totalParticipants + "]";
    }
    
    // pagination code ===========================
    /** Current Page Getter */
    public String getCurrentPage() {
        return currentPage;
    }

    /** Current Page Setter */
    public void setCurrentPage(String currentPage) {
        this.currentPage = currentPage;
    }
    // pagination code end ========================

	@Override
	public int compareTo(CourseScheduleForm arg0) { // added 8/07/2021
		return this.courseScheduleDetails.getScheduledStartDateTime().toInstant()
				.compareTo(arg0.courseScheduleDetails.getScheduledStartDateTime().toInstant());
	}

}

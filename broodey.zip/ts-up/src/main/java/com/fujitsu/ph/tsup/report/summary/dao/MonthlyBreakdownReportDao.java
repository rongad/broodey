//==================================================================================================
// Project Name : Training Sign-Up
// System Name  : MonthlyBreakdownReportDao
// Class Name   : MonthlyBreakdownReportDao.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/10/26 | WS) d.dinglasan       | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.ZonedDateTime;
import java.util.Set;

import com.fujitsu.ph.tsup.course.model.CoursesConducted;

/**
 * <pre>
 * DAO interface of Monthly Breakdown Report 
 * of Course Conducted
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public interface MonthlyBreakdownReportDao {

    /**
     * <pre>
     * Retrieve past courses conducted on a given period
     * </pre>
     * 
     * @param startDateTime
     * @param endDateTime
     * @return
     */
    Set<CoursesConducted> findAllConductedCoursesWithinPeriod(ZonedDateTime startDateTime,
            ZonedDateTime endDateTime);
    
    
    /**
     * <pre>
     * Get the earlest year recorded course schedule details
     * </pre>
     * 
     * @return
     */
    int getStartYear();
}

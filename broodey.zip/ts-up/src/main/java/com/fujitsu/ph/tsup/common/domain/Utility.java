//==================================================================================================
// Project Name : Training Sign Up
// System Name : Utility
// Class Name : Utility.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 1.0.0 | 2021/09/17 | WS) d.dinglasan  | New Creation
// 2.0.0 | 2021/10/08 | WS) mi.aguinaldo | Added getCurrentFpiUser
//==================================================================================================
package com.fujitsu.ph.tsup.common.domain;

import java.time.ZonedDateTime;

import org.springframework.security.core.context.SecurityContextHolder;

import com.fujitsu.ph.auth.model.FpiUser;

/**
 * <pre>
 *  Utility class handles all common function utilities which are used mostly by other classes
 * </pre>
 *
 * @version 1.00
 * @author WS) d.dinglasan
 */
public class Utility {
    
    private Utility() {
        super();
    }

    public static final ZonedDateTime getDefaultToDateTime(ZonedDateTime fromDateTime) {
        // set end date variable to specific end quarter
        // e.g. Mar-31 | Jun-30 | Sept-30 | Dec-31, 11:59 PM
        // for initial load of data

        int fromDateTimeMonthValue = fromDateTime.getMonthValue();
        int addMonths = 0;
        int quarterEndMonth = 3; // initial value of 3 to depict first quarter

        // get the difference of fromDateTimeMonthValue from its proper quarter range
        // then store it to addMonths
        while (quarterEndMonth <= 12) {
            if (fromDateTimeMonthValue <= quarterEndMonth) {
                addMonths = quarterEndMonth - fromDateTimeMonthValue;
                break;
            }
            quarterEndMonth += 3;
        }

        int daysOfTheMonth = (quarterEndMonth == 3 || quarterEndMonth == 12) ? 31 : 30;
        return fromDateTime.plusMonths(addMonths) // add months to set specific end quarter
                .withDayOfMonth(daysOfTheMonth) // set the end day of the month
                .withHour(23).withMinute(59); // this will set the time to 11:59 PM
    }
    
    public static FpiUser getCurrentFpiUser() {
        return (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

}

/**
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.importing.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.fujitsu.ph.tsup.importing.model.SabaDTO;

// ==================================================================================================
// Project Name : Training Sign Up
// Class Name : ImportingDataService.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/08/19 | WS) mi.aguinaldo | Initial Version
// 0.02 | 2021/09/07 | WS) mi.aguinaldo | Update
// 0.03 | 2021/09/28 | WS) j.lugtu      | Removed CSV methods
// 0.04 | 2021/10/14 | WS) j.lugtu      | Added methods for trainee info import
// 0.05 | 2021/10/14 | WS) j.lazo       | Added importData
// ==================================================================================================
public interface ImportingDataService {
    /**
     * Check if the file is in excel format
     * 
     * @param file the file
     * @return true, if successful
     */
    boolean hasExcelFormat(MultipartFile file);

    /**
     * Convert the excel file to a SabaDTO list
     * 
     * @param file the file
     * @return SabaDTO list
     */
    List<SabaDTO> excellToSabaDTOs(MultipartFile file);

    /**
     * Update courses that do not have course codes
     * 
     * @param dataForUpdate list of SabaDTO
     * @return sum of total updates done
     */
    int updateCoursesWithoutCourseCode(List<SabaDTO> dataForUpdate);

    /**
     * Create new courses
     * 
     * @param newData list of SabaDTO
     * @return sum of total creation done
     */
    int createCourses(List<SabaDTO> newData);

    /**
     * Create new course categories
     * 
     * @param newData list of SabaDTO
     * @return sum of total creation done
     */
    int createCourseCategories(List<SabaDTO> sabaDTOs);

    /**
     * Segregate existing and non existing courses
     * 
     * @param dtos list of SabaDTO
     * @return results
     */
    Map<String, List<SabaDTO>> segregateExistingAndNewOfCourses(List<SabaDTO> dtos);

    /**
     * Extract the trainee info emails from imported file
     * 
     * @param file the imported file
     * @return traineeInfoEmail list
     */
    List<String> extractTraineeInfoEmail(MultipartFile file);

    /**
     * Identify the number of new users from imported file
     * 
     * @param traineeInfoEmail list of trainee info emails
     * @return results.size number of new users
     */
    int getNumberOfNewUsers(List<String> traineeInfoEmail);

    /**
     * Create new course attendance, participant, schedule and schedule details
     * 
     * @param sabaDTOs list of SabaDTO
     * @return sum of total creation done
     */
    void importData(List<SabaDTO> sabaDTOs);
}

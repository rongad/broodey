package com.fujitsu.ph.tsup.tms.model;

import java.io.Serializable;

public class NotRegistered {
	private String employeeName;
	private String employeeStatus;
	private String manager;
	private String courseTitle;
	private String targetCompletion;
	private String actualCompletion;
	private String Status;
	private String benchStatus;
	private String sourceLearning;
	public String getSourceLearning() {
		return sourceLearning;
	}

	public void setSourceLearning(String sourceLearning) {
		this.sourceLearning = sourceLearning;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getCourseTitle() {
		return courseTitle;
	}

	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}

	public String getTargetCompletion() {
		return targetCompletion;
	}

	public void setTargetCompletion(String targetCompletion) {
		this.targetCompletion = targetCompletion;
	}

	public String getActualCompletion() {
		return actualCompletion;
	}

	public void setActualCompletion(String actualCompletion) {
		this.actualCompletion = actualCompletion;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
	
	public NotRegistered() {
	}
	
	public NotRegistered(String employeeName, String employeeStatus, String manager, String courseTitle, String targetCompletion, String actualCompletion, String status, String benchStatus, String sourceLearning) {
		this.employeeName = employeeName;
		this.employeeStatus = employeeStatus;
		this.manager = manager;
		this.courseTitle = courseTitle;
		this.targetCompletion = targetCompletion;
		this.actualCompletion = actualCompletion;
		this.Status = status;
		this.benchStatus = benchStatus;
		this.sourceLearning = sourceLearning;
	}
	public String getBenchStatus() {
		return this.benchStatus;
	}
	public void setBenchStatus(String benchStatus) {
		this.benchStatus = benchStatus;
	}
	@Override
	public String toString() {
		return "NotRegistered [employeeName=" + employeeName + ", employeeStatus=" + employeeStatus + ", manager="
				+ manager + ", courseTitle=" + courseTitle + ", targetCompletion=" + targetCompletion
				+ ", actualCompletion=" + actualCompletion + ", Status=" + Status + "]";
	}
	
	
}

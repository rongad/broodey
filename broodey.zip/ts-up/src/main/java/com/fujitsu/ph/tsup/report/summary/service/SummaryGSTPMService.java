/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.service;

import java.time.ZonedDateTime;
import java.util.List;

import com.fujitsu.ph.tsup.report.summary.model.SummaryGSTForm;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for PM
//Class Name   : SummaryGSTPMService.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/04/20 | WS) d.escala          | Initial Version
//0.02    | 2021/04/23 | WS) m.padaca          | Updated
//0.03    | 2021/04/27 | WS) m.padaca          | Updated
//0.04    | 2021/10/15 | WS) r.buot            | Updated
//0.04    | 2021/10/20 | WS) dw.cardenas       | Updated
//==================================================================================================
/**
 * <pre>
 * The controller for the SummaryGSTPMService
 * 
 * <pre>
 * 
 * @version 0.03
 * @author m.padaca
 * @author d.escala
 */

public interface SummaryGSTPMService {

    /**
     * <pre>
     * Show summary based on given date
     * </pre>
     */

    Long countTotalNumberOfJDUPM(int deptId, List<Integer> roleId);

    // Method for count total number JDU PM Last Week
    int countTotalNoJDUPMLastWeek();

    // Method for count total number original member
    int countTotalNoOrigMem();

    // Method for count total number new member
    int countTotalNoNewMem();

    // Method for count total number JDU PM final
    Long countTotalNoJDUPMF(List<Integer> gstCourses, int deptId, List<Integer> roleId,
            ZonedDateTime reportDate);

    // Method for count total number JDU PM last week final
    Long countTotalNoJDUPMLastWkF(ZonedDateTime reportDate, List<Integer> gstCourses, int deptId,
            List<Integer> roleId);

    // Method for accumulating summary data
    SummaryGSTForm getSummary(ZonedDateTime reportDate);

}

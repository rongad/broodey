/**
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.exception.handler;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fujitsu.ph.tsup.exception.ImportDataException;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name   : ImportDataExceptionHandler.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/08/19 | WS) mi.aguinaldo      | Initial Version
//==================================================================================================

@ControllerAdvice
public class ImportDataExceptionHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger("TS-UP");
     
    @ExceptionHandler(ImportDataException.class)
    @ResponseBody
    ResponseEntity<Object> handleControllerException(HttpServletRequest request, Throwable e) {
        HttpStatus status = getStatus(request);
        UUID uuid = UUID.randomUUID();
        LOGGER.error("TRACE ID:[" + uuid.toString() +"]: "+e.getMessage(),e);
        
        return new ResponseEntity<>("TRACE ID:[" + uuid.toString() +"]: "+e.getMessage(), status);
    }
 
    private HttpStatus getStatus(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        if (statusCode == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return HttpStatus.valueOf(statusCode);
    }
}
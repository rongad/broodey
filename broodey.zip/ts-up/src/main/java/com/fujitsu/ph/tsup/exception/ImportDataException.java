/**
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.exception;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name   : ImportDataException.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/08/19 | WS) mi.aguinaldo      | Initial Version
//==================================================================================================
public class ImportDataException extends RuntimeException {

    /**
     * Default Constructor
     */
    public ImportDataException() {
        super();
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public ImportDataException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @param message
     * @param cause
     */
    public ImportDataException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public ImportDataException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public ImportDataException(Throwable cause) {
        super(cause);
    }

    
}

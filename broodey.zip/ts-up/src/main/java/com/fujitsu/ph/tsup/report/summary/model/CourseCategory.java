//==================================================================================================
// Project Name : Training Sign-Up
// System Name : Course Category Model
// Class Name : CourseCategory.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.model;

import java.util.Map;

/**
 * <pre>
 * Course Category class
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public class CourseCategory {

    /**
     * Course category ID
     */
    private Long id;

    /**
     * Course category name
     */
    private String courseCategoryName;

    /**
     * Map of course name and id
     */
    private Map<Long, String> courseMap;

    /**
     * <pre>
     * CourseCategory Constructor
     * </pre>
     * 
     * @param id
     * @param courseCategoryName
     */
    public CourseCategory(Long id, String courseCategoryName) {
        this.id = id;
        this.courseCategoryName = courseCategoryName;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the courseCategory
     */
    public String getCourseCategoryName() {
        return courseCategoryName;
    }

    /**
     * @param courseCategory the courseCategory to set
     */
    public void setCourseCategoryName(String courseCategoryName) {
        this.courseCategoryName = courseCategoryName;
    }

    /**
     * @return the courseMap
     */
    public Map<Long, String> getCourseMap() {
        return courseMap;
    }

    /**
     * @param courseMap the courseMap to set
     */
    public void setCourseMap(Map<Long, String> courseMap) {
        this.courseMap = courseMap;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CourseCategory [id=" + id + ", courseCategoryName=" + courseCategoryName + ", courseMap="
                + courseMap + "]";
    }

}

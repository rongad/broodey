package com.fujitsu.ph.tsup.survey.domain;

import java.time.ZonedDateTime;

//==================================================================================================
//$Id:PR16$
//Project Name :Training Sign Up
//System Name  :Survey Form Process
//Class Name   :Survey.java
//
//<<Modification History>>
//Version | Date       | Updated By                                  | Content
//--------+------------+---------------------------------------------+---------------------------------
//0.01    | 08/12/2021 |  WS) KA.Espinoza                            | New Creation
//0.02    | 10/27/2021 |  WS) L.Celoso                               | Made the comments optional
//==================================================================================================
/**
* <pre>
* The Survey Form model. This uses a builder pattern
* 
* </pre>
* 
* @version 0.01
* @author ka.espinoza
*/

public class Survey {
    /**
     * Survey Form Id
     */
    private Long id;
    
    /**
     * Course Name
     */
    private String courseTitle;
    
    /**
     * Course Training Venue
     */
    private String trainingVenue;
    
    /**
     * Instructor Name
     */
    private String instructorName;
    
    /**
     * Course Start Date and Time
     */
    private ZonedDateTime courseDateTime;
    
    /**
     * Course End Date and Time
     */
    private ZonedDateTime courseEndDate;
    
    /**
     * Course Scheduled Id
     */
    private Long courseScheduleDetailId;
   
    /**
     * A. Module Design Question No 1
     */
    private Integer mdQuestion1;
    
    /**
     * A. Module Design Question No 2
     */
    private Integer mdQuestion2;
    
    /**
     * A. Module Design Question No 3
     */
    private Integer mdQuestion3;
    
    /**
     * A. Module Design Question No 4
     */
    private Integer mdQuestion4;
    
    /**
     * B. Materials Question 1
     */
    private Integer matQuestion1;
    
    /**
     * B. Materials Question 2
     */
    private Integer matQuestion2;
    
    /**
     * B. Materials Question 3
     */
    private Integer  matQuestion3;
    
    /**
     * B. Materials Question 4
     */
    private Integer  matQuestion4;
    
    /**
     * C. Instruction Question 1
     */
    private Integer insQuestion1;
    
    /**
     * C. Instruction Question 2
     */
    private Integer insQuestion2;
    
    /**
     * C. Instruction Question 3
     */
    private Integer insQuestion3;
    
    /**
     * C. Instruction Question 4
     */
    private Integer insQuestion4;

    /**
     * C. Instruction Question 5
     */
    private Integer insQuestion5;
    
    /**
     * C. Instruction Question 6
     */
    private Integer insQuestion6;
    
    /**
     * D. Equipment and Facilities Question 1
     */
    private Integer eqFaQuestion1;
    
    /**
     * D. Equipment and Facilities Question 2
     */
    private Integer eqFaQuestion2;
    
    /**
     * D. Equipment and Facilities Question 3
     */
    private Integer eqFaQuestion3;
    
    /**
     * Comments Question E
     */
    private String commentsE;
    
    /**
     * Comments Question F
     */
    private String commentsF;
    
    /**
     * Comments Question G
     */
    private String commentsG;
    
    protected Survey() {} 
    /**
     * Survey Constructor
     * @param builder Builder
     */
    private Survey(Builder builder) {
          
         this.id = builder.id;
            this.courseTitle = builder.courseTitle;
            this.trainingVenue = builder.trainingVenue;
            this.instructorName = builder.instructorName;
            this.courseDateTime = builder.courseDateTime;
            this.courseEndDate = builder.courseEndDate;
            this.courseScheduleDetailId = builder.courseScheduleDetailId;
           
            this.mdQuestion1 = builder.mdQuestion1;
            this.mdQuestion2 = builder.mdQuestion2;
            this.mdQuestion3 = builder.mdQuestion3;
            this.mdQuestion4 = builder.mdQuestion4;
            
            this.matQuestion1 = builder.matQuestion1;
            this.matQuestion2= builder.matQuestion2;
            this.matQuestion3 =builder.matQuestion3;
            this.matQuestion4 = builder.matQuestion4;
            
            this.insQuestion1 = builder.insQuestion1;
            this.insQuestion2 = builder.insQuestion2;
            this.insQuestion3 = builder.insQuestion3;
            this.insQuestion4 = builder.insQuestion4;
            this.insQuestion5 = builder.insQuestion5;
            this.insQuestion6 = builder.insQuestion6;
          
            this.eqFaQuestion1 = builder.eqFaQuestion1;
            this.eqFaQuestion2 = builder.eqFaQuestion2;
            this.eqFaQuestion3 = builder.eqFaQuestion3;
            
            this.commentsE = builder.commentsE;
            this.commentsF = builder.commentsF;
            this.commentsG = builder.commentsG;
    }
    
    
    public Long getId() {
        return id;
    }


    public String getCourseTitle() {
        return courseTitle;
    }

    
    public String getTrainingVenue() {
        return trainingVenue;
    }

    
    public String getInstructorName() {
        return instructorName;
    }
    

    public ZonedDateTime getCourseDateTime() {
        return courseDateTime;
    }
    
    
    public ZonedDateTime getCourseEndDate() {
        return courseEndDate;
    }
    
    
    public Long getCourseScheduleDetailId() {
        return courseScheduleDetailId;
    }
    
    
    public Integer getMdQuestion1() {
        return mdQuestion1;
    }

    
    public Integer getMdQuestion2() {
        return mdQuestion2;
    }
    
    
    public Integer getMdQuestion3() {
        return mdQuestion3;
    }
   
    
    public Integer getMdQuestion4() {
        return mdQuestion4;
    }
 

    public Integer getMatQuestion1() {
        return matQuestion1;
    }


    public Integer getMatQuestion2() {
        return matQuestion2;
    }

  
    public Integer getMatQuestion3() {
        return matQuestion3;
    }


    public Integer getMatQuestion4() {
        return matQuestion4;
    }

    
    public Integer getInsQuestion1() {
        return insQuestion1;
    }

    
    public Integer getInsQuestion2() {
        return insQuestion2;
    }

    
    public Integer getInsQuestion3() {
        return insQuestion3;
    }
    

    public Integer getInsQuestion4() {
        return insQuestion4;
    }

    
    public Integer getInsQuestion5() {
        return insQuestion5;
    }

    
    public Integer getInsQuestion6() {
        return insQuestion6;
    }

    

    public Integer getEqFaQuestion1() {
        return eqFaQuestion1;
    }

    

    public Integer getEqFaQuestion2() {
        return eqFaQuestion2;
    }

    

    public Integer getEqFaQuestion3() {
        return eqFaQuestion3;
    }

    

    public String getCommentsE() {
        return commentsE;
    }

    

    public String getCommentsF() {
        return commentsF;
    }

    

    public String getCommentsG() {
        return commentsG;
    }


    /**
     * The builder class of the survey form.
     * The builder is a public static
     * member class of survey form
     **/
    public static class Builder {
        /**
         * Survey Form Id
         */
        private Long id;
        
        /**
         * Course Name
         */
        private String courseTitle;
        
        /**
         * Course Training Venue
         */
        private String trainingVenue;
        
        /**
         * Instructor Name
         */
        private String instructorName;
        
        /**
         * Course Start Date and Time
         */
        private ZonedDateTime courseDateTime;
        
        /**
         * Course End Date and Time
         */
        private ZonedDateTime courseEndDate;
        
        /**
         * Course Scheduled Id
         */
        private Long courseScheduleDetailId;
       
        /**
         * A. Module Design Question No 1
         */
        private Integer mdQuestion1;
        
        /**
         * A. Module Design Question No 2
         */
        private Integer mdQuestion2;
        
        /**
         * A. Module Design Question No 3
         */
        private Integer mdQuestion3;
        
        /**
         * A. Module Design Question No 4
         */
        private Integer mdQuestion4;
        
        /**
         * B. Materials Question 1
         */
        private Integer matQuestion1;
        
        /**
         * B. Materials Question 2
         */
        private Integer matQuestion2;
        
        /**
         * B. Materials Question 3
         */
        private Integer  matQuestion3;
        
        /**
         * B. Materials Question 4
         */
        private Integer  matQuestion4;
        
        /**
         * C. Instruction Question 1
         */
        private Integer insQuestion1;
        
        /**
         * C. Instruction Question 2
         */
        private Integer insQuestion2;
        
        /**
         * C. Instruction Question 3
         */
        private Integer insQuestion3;
        
        /**
         * C. Instruction Question 4
         */
        private Integer insQuestion4;

        /**
         * C. Instruction Question 5
         */
        private Integer insQuestion5;
        
        /**
         * C. Instruction Question 6
         */
        private Integer insQuestion6;
        
        /**
         * D. Equipment and Facilities Question 1
         */
        private Integer eqFaQuestion1;
        
        /**
         * D. Equipment and Facilities Question 2
         */
        private Integer eqFaQuestion2;
        
        /**
         * D. Equipment and Facilities Question 3
         */
        private Integer eqFaQuestion3;
        
        /**
         * Comments Question E
         */
        private String commentsE;
        
        /**
         * Comments Question F
         */
        private String commentsF;
        
        /**
         * Comments Question G
         */
        private String commentsG;
      
      /**
       * Creates a new instance of course attendance Builder.
       * Validates and sets the argument into the Builder instance variables.
       * This method is used for setting
       * the data from the database  
       * 
       * @param courseEndDate
       * @param courseScheduleDetailId
       * @param courseTitle
       * @param trainingVenue
       * @param instructorName
       * @param courseDateTime
       * @param mdQuestion1
       * @param mdQuestion2
       * @param mdQuestion3
       * @param mdQuestion4
       * @param insQuestion1
       * @param insQuestion2
       * @param insQuestion3
       * @param insQuestion4
       * @param insQuestion5
       * @param insQuestion6
       * @param eqFaQuestion1
       * @param eqFaQuestion2
       * @param eqFaQuestion3
       * @param commentsE
       * @param commentsF
       * @param commentsG
       * 
       **/
      public Builder (ZonedDateTime courseEndDate, Long courseScheduleDetailId, String courseTitle, String trainingVenue, String instructorName, 
              ZonedDateTime courseDateTime, int mdQuestion1, int mdQuestion2, int mdQuestion3, int mdQuestion4,
              int matQuestion1, int matQuestion2, int matQuestion3, int matQuestion4, int insQuestion1, int insQuestion2, 
              int insQuestion3, int insQuestion4, int insQuestion5, int insQuestion6, int eqFaQuestion1, int eqFaQuestion2, int eqFaQuestion3,
              String commentsE, String commentsF, String commentsG) {
     
          validateCourseTitle(courseTitle);
          validateTrainingVenue(trainingVenue);
          validateInstructorName(instructorName);
          validateCourseDateTime(courseDateTime);
          
          validateMdQuestion1(mdQuestion1);
          validateMdQuestion2(mdQuestion2);
          validateMdQuestion3(mdQuestion3);
          validateMdQuestion4(mdQuestion4);
          
          validateMatQuestion1(matQuestion1);
          validateMatQuestion2(matQuestion2);
          validateMatQuestion3(matQuestion3);
          validateMatQuestion4(matQuestion4);
          
          validateInsQuestion1(insQuestion1);
          validateInsQuestion2(insQuestion2);
          validateInsQuestion3(insQuestion3);
          validateInsQuestion4(insQuestion4);
          validateInsQuestion5(insQuestion5);
          validateInsQuestion6(insQuestion6);
          
          validateEqFaQuestion1(eqFaQuestion1);
          validateEqFaQuestion2(eqFaQuestion2);
          validateEqFaQuestion3(eqFaQuestion3);
          
//          validateCommentsE(commentsE);
//          validateCommentsF(commentsF);
//          validateCommentsG(commentsG);
          
          this.courseTitle = courseTitle;
          this.trainingVenue = trainingVenue;
          this.instructorName = instructorName;
          this.courseDateTime = courseDateTime;
          this.courseEndDate = courseEndDate;
          this.courseScheduleDetailId = courseScheduleDetailId;
          this.mdQuestion1 = mdQuestion1;
          this.mdQuestion2 = mdQuestion2;
          this.mdQuestion3 = mdQuestion3;
          this.mdQuestion4 = mdQuestion4;
          this.matQuestion1 = matQuestion1;
          this.matQuestion2 = matQuestion2;
          this.matQuestion3 = matQuestion3;
          this.matQuestion4 = matQuestion4;
          this.insQuestion1 = insQuestion1;
          this.insQuestion2 = insQuestion2;
          this.insQuestion3 = insQuestion3;
          this.insQuestion4 = insQuestion4;
          this.insQuestion5 = insQuestion5;
          this.insQuestion6 = insQuestion6;
          this.eqFaQuestion1 = eqFaQuestion1;
          this.eqFaQuestion2 = eqFaQuestion2;
          this.eqFaQuestion3 = eqFaQuestion3;
          this.commentsE = commentsE;
          this.commentsF = commentsF;
          this.commentsG = commentsG;
      }
      
      /**
       * <pre>
       * Creates a new instance of survey form Builder.
       * Validates and sets the
       * argument into the Builder instance variables.
       * This method is used for setting the data from the database
       * 
       */
      public Survey build() {
          return new Survey(this);
      }
      
     // Validation 
      /**
       * Validate the course title based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateCourseTitle(String courseTitle){
          if(courseTitle == null || courseTitle.isEmpty()){
            throw new IllegalArgumentException("Course Title should not be empty");
          }
        }
      
      /**
       * Validate the training venue based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateTrainingVenue(String trainingVenue){
          if(trainingVenue == null || trainingVenue.isEmpty()){
            throw new IllegalArgumentException("Training Venue should not be empty");
          }
        }
      
      /**
       * Validate the instructor name based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInstructorName(String instructorName){
          if(instructorName == null || instructorName.isEmpty()){
            throw new IllegalArgumentException("Instructor Name should not be empty");
          }
        }
      
      /**
       * Validate the course date and time based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateCourseDateTime(ZonedDateTime courseDateTime){
          if(courseDateTime == null){
            throw new IllegalArgumentException("Course Date and Time should not be empty");
          }
        }
      
      /**
       * Validate the A. Module Design Question 1 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMdQuestion1(int mdQuestion1){
          if(mdQuestion1 == 0){
            throw new IllegalArgumentException("MdQuestion1 rating should not be empty");
          }
        }
     
      /**
       * Validate the A. Module Design Question 2 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMdQuestion2(int mdQuestion2){
          if(mdQuestion2 == 0){
            throw new IllegalArgumentException("MdQuestion2 rating should not be empty");
          }
        }
      
      /**
       * Validate the A. Module Design Question 3 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMdQuestion3(int mdQuestion3){
          if(mdQuestion3 == 0){
            throw new IllegalArgumentException("MdQuestion3 rating should not be empty");
          }
        }
      
      /**
       * Validate the A. Module Design Question 4 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMdQuestion4(int mdQuestion4){
          if(mdQuestion4 == 0){
            throw new IllegalArgumentException("MdQuestion4 rating should not be empty");
          }
        }
      
      /**
       * Validate the B. Materials Question 1 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMatQuestion1(int matQuestion1){
          if(matQuestion1 == 0){
            throw new IllegalArgumentException("MatQuestion1 rating should not be empty");
          }
        }
      
      /**
       * Validate the B. Materials Question 2 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMatQuestion2(int matQuestion2){
          if(matQuestion2 == 0){
            throw new IllegalArgumentException("MatQuestion2 rating should not be empty");
          }
        }
      
      /**
       * Validate the B. Materials Question 3 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMatQuestion3(int matQuestion3){
          if(matQuestion3 == 0){
            throw new IllegalArgumentException("MatQuestion3 rating should not be empty");
          }
        }
      
      /**
       * Validate the B. Materials Question 4 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateMatQuestion4(int matQuestion4){
          if(matQuestion4 == 0){
            throw new IllegalArgumentException("MatQuestion4 rating should not be empty");
          }
        }
      
      /**
       * Validate the C. Instruction Question 1 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInsQuestion1(int insQuestion1){
          if(insQuestion1 == 0){
            throw new IllegalArgumentException("InsQuestion1 rating should not be empty");
          }
        }
      
      /**
       * Validate the C. Instruction Question 2 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInsQuestion2(int insQuestion2){
          if(insQuestion2 == 0){
            throw new IllegalArgumentException("InsQuestion2 rating should not be empty");
          }
        }
      
      /**
       * Validate the C. Instruction Question 3 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInsQuestion3(int insQuestion3){
          if(insQuestion3 == 0){
            throw new IllegalArgumentException("InsQuestion3 rating should not be empty");
          }
        }
      
      /**
       * Validate the C. Instruction Question 4 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInsQuestion4(int insQuestion4){
          if(insQuestion4 == 0){
            throw new IllegalArgumentException("InsQuestion4 rating should not be empty");
          }
        }
      
      /**
       * Validate the C. Instruction Question 5 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInsQuestion5(int insQuestion5){
          if(insQuestion5 == 0){
            throw new IllegalArgumentException("InsQuestion5 rating should not be empty");
          }
        }
      
      /**
       * Validate the C. Instruction Question  based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateInsQuestion6(int insQuestion6){
          if(insQuestion6 == 0){
            throw new IllegalArgumentException("InsQuestion6 rating should not be empty");
          }
        }
      
      /**
       * Validate the D. Equipment and Facilities Question 1 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateEqFaQuestion1(int eqFaQuestion1){
          if(eqFaQuestion1 == 0){
            throw new IllegalArgumentException("EqFaQuestion1 rating should not be empty");
          }
        }
      
      /**
       * Validate the D. Equipment and Facilities Question 2 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateEqFaQuestion2(int eqFaQuestion2){
          if(eqFaQuestion2 == 0){
            throw new IllegalArgumentException("EqFaQuestion2 rating should not be empty");
          }
        }
      
      /**
       * Validate the D. Equipment and Facilities Question 3 based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
      private void validateEqFaQuestion3(int eqFaQuestion3){
          if(eqFaQuestion3 == 0){
            throw new IllegalArgumentException("EqFaQuestion3 rating should not be empty");
          }
        }
      
      /**
       * Validate the Comments Question E based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
//      private void validateCommentsE(String commentsE){
//          if(commentsE == null || commentsE.isEmpty()){
//            throw new IllegalArgumentException("CommentsE comment should not be empty");
//          }
//        }
      
      /**
       * Validate the Comments Question F based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
//      private void validateCommentsF(String CommentsF){
//          if(CommentsF == null || CommentsF.isEmpty()){
//            throw new IllegalArgumentException("CommentsF comment should not be empty");
//          }
//        }
      
      /**
       * Validate the Comments Question G based on the condition below.
       * If it is invalid then throw an IllegalArgumentException
       * with the corresponding message.
       * 
       **/
//      private void validateCommentsG(String commentsG){
//          if(commentsG == null || commentsG.isEmpty()){
//            throw new IllegalArgumentException("CommentsG comment should not be empty");
//          }
//        }   
    }
}

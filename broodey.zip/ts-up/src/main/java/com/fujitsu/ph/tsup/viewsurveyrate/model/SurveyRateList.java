/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.model;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : SurveyRateList
// Class Name : SurveyRateList.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// ---------+------------+-----------------------+---------------------------------------------------
// 0.1.0 | 2021/08/23 | WS)JD.Dominguez | New Creation
// 0.2.0 | 2021/08/23 | WS)E.Juan | Add the lacking getters and setters for getting the total data and
// calculation of average
// 0.3.0 | 2021/10/12 | WS)MI.Aguinaldo | Refactored the whole class

public class SurveyRateList {

    private double oaAverage;

    private ModuleDesignResponseForm moduleDesignResponseForm;

    private MaterialsResponseForm materialsResponseForm;

    private InstructionResponseForm instructionResponseForm;

    private EquipmentAndFacilitiesResponseForm equipmentAndFacilitiesResponseForm;

    public double getOaAverage() {
        return oaAverage;
    }

    public void setOaAverage(double oaAverage) {
        this.oaAverage = oaAverage;
    }

    /**
     * @return the moduleDesignResponseForm
     */
    public ModuleDesignResponseForm getModuleDesignResponseForm() {
        return moduleDesignResponseForm;
    }

    /**
     * @param moduleDesignResponseForm the moduleDesignResponseForm to set
     */
    public void setModuleDesignResponseForm(ModuleDesignResponseForm moduleDesignResponseForm) {
        this.moduleDesignResponseForm = moduleDesignResponseForm;
    }

    /**
     * @return the materialsResponseForm
     */
    public MaterialsResponseForm getMaterialsResponseForm() {
        return materialsResponseForm;
    }

    /**
     * @param materialsResponseForm the materialsResponseForm to set
     */
    public void setMaterialsResponseForm(MaterialsResponseForm materialsResponseForm) {
        this.materialsResponseForm = materialsResponseForm;
    }

    /**
     * @return the instructionResponseForm
     */
    public InstructionResponseForm getInstructionResponseForm() {
        return instructionResponseForm;
    }

    /**
     * @param instructionResponseForm the instructionResponseForm to set
     */
    public void setInstructionResponseForm(InstructionResponseForm instructionResponseForm) {
        this.instructionResponseForm = instructionResponseForm;
    }

    /**
     * @return the equipmentAndFacilitiesResponseForm
     */
    public EquipmentAndFacilitiesResponseForm getEquipmentAndFacilitiesResponseForm() {
        return equipmentAndFacilitiesResponseForm;
    }

    /**
     * @param equipmentAndFacilitiesResponseForm the equipmentAndFacilitiesResponseForm to set
     */
    public void setEquipmentAndFacilitiesResponseForm(
            EquipmentAndFacilitiesResponseForm equipmentAndFacilitiesResponseForm) {
        this.equipmentAndFacilitiesResponseForm = equipmentAndFacilitiesResponseForm;
    }

}

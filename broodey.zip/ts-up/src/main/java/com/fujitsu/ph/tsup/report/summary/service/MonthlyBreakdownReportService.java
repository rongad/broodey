//==================================================================================================
// Project Name : Training Sign-Up
// System Name  : MonthlyBreakdownReportService
// Class Name   : MonthlyBreakdownReportService.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/10/26 | WS) d.dinglasan       | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.util.Set;

import com.fujitsu.ph.tsup.course.model.CoursesConducted;

/**
 * <pre>
 * Service interface for Monthly Breakdwon Report of conducted courses
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public interface MonthlyBreakdownReportService {

    /**
     * <pre>
     * Finds all courses conducted within the given month
     * </pre>
     * 
     * @param monthStr
     * @param yearStr
     * @return CoursesConducted, Set
     */
    Set<CoursesConducted> findAllConductedCoursesWithinPeriod(int monthValue, int yearValue);
    
    /**
     * <pre>
     * Get the earlest year recorded course schedule details
     * </pre>
     * 
     * @return
     */
    int getStartYear();
    
}

package com.fujitsu.ph.tsup.instructorconduct.model;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: CourseScheduleViewForm.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja    | New Creation
//0.02    | 10/25/2021 | WS) L.Celoso    | Added Pagination
//=======================================================

/**
* <pre>
* JavaBean for CourseScheduleListForm
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.util.List;
import java.util.Set;

import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;

public class CourseScheduleListForm {
	
	/**
     *	Set of Course Schedule Form
     */
	private List<CourseSchedule> courseSchedules;
	
	private Set<InstructorForm> instructors;
	
	   /**
     * Course Id
     */
    private Long id;
    
    /**
     * List of courses
     */
    private List<CourseForm> courses;

    /* Current Page */
    private String currentPage;
	
	public List<CourseSchedule> getCourseSchedules() {
		return courseSchedules;
	}
	public void setCourseSchedules(List<CourseSchedule> courseSchedules) {
		this.courseSchedules = courseSchedules;
	}
	
	public List<CourseForm> getCourses() {
		return courses;
	}

	public void setCourses(List<CourseForm> courses) {
		this.courses = courses;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
    public String getCurrentPage() {
        return currentPage;
    }
    public void setCurrentPage(String currentPage) {
        this.currentPage = currentPage;
    }
	
	/**
     * @return the instructors
     */
    public Set<InstructorForm> getInstructors() {
        return instructors;
    }
    
    /**
     * @param instructors the instructors to set
     */
    public void setInstructors(Set<InstructorForm> instructors) {
        this.instructors = instructors;
    }
    
    @Override
	public String toString() {
		return "CourseScheduleListForm [id=" + id + ", courseSchedules=" + courseSchedules 
				+ ", courses=" + courses + "]";
	}
}

package com.fujitsu.ph.tsup.instructorconduct.dao;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: InstructorConductDao.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja    | New Creation
//0.02    | 10/08/2021 | WS) MI.Aguinaldo| Update
//0.03    | 10/25/2021 | WS) L.Celoso    | Added Pagination
//=======================================================

/**
* <pre>
* The data access object for course schedules assigned to instructor. 
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseForm;
import com.fujitsu.ph.tsup.instructorconduct.model.SurveySearchFilter;

public interface InstructorConductDao {
    
    /**
     * Find all course schedule.
     *
     * @return the sets the CourseSchedule
     */
    Set<CourseSchedule> findAllCourseSchedule(Pageable pageable);

    /**
     * Find Course Schedule assigned to instructor
     * @param instructorId
     */
	Set<CourseSchedule> findAllCourseScheduleByInstructorId(Pageable pageable, Long instructorId);
	
	 /**
     * Finds course schedule assigned to instructor by course Id 
     * @param long instructorId
     * @param courseId
     * 
     */
	Set<CourseSchedule> findAllCourseScheduleByCourseIdInstructorId(Pageable pageable, Long instructorId, Long courseId);
	
	/**
	 * Find all course schedule by course name.
	 *
	 * @param courseName the course name
	 * @return the sets of CourseSchedule
	 */
	Set<CourseSchedule> findAllCourseScheduleByCourseName(Pageable pageable, String courseName);
	
	

    /**
     * Find all course schedule by survey filter.
     *
     * @param surveySearchFilter the survey search filter
     * @return the sets the
     */
    Set<CourseSchedule> findAllCourseScheduleBySurveyFilter(Pageable pageable, SurveySearchFilter surveySearchFilter);
    
	
	
	/**
     * Finds course schedule assigned to instructor by instructor id
     * @param long id
     * 
     */
	Set<CourseForm> findAllScheduledCoursesByInstructorId(Long instructorId);

    /**
     * Count all course schedules by specific instructor
     * @param long instructorId
     * 
     */
	int countCourseForInstructor(Long instructorId);

    /**
     * Count all course schedules by specific instructor with filter of course
     * @param long instructorId
     * 
     */	
    int countCourseForInstructorFilter(Long instructorId, Long courseId);
    
    /**
     * Count all course schedules available
     * @param long instructorId
     * 
     */ 
	int countCourseForAll();
    
    /**
     * Count all course schedules available with filter of course
     * @param long instructorId
     * 
     */ 
    int countCourseForAllFilter(SurveySearchFilter surveySearchFilter);
	
}

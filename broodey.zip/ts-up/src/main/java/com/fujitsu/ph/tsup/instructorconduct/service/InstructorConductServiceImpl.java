package com.fujitsu.ph.tsup.instructorconduct.service;

import java.util.Collections;
import java.util.Objects;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.course.dao.CourseManagementDao;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.instructorconduct.dao.InstructorConductDao;
import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseForm;
import com.fujitsu.ph.tsup.instructorconduct.model.SurveySearchFilter;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: InstructorConductServicImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja     | New Creation
//0.02    | 10/08/2021 | WS) MI.Aguinaldo | Update
//0.03    | 10/26/2021 | WS) M.Yanoyan    | Added if condition
//=======================================================

/**
* <pre>
* The implementation of service for course schedules assigned to instructor. 
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

@Service
public class InstructorConductServiceImpl implements InstructorConductService {

	/**
	 * InstructorConduct Data Access Object
	 */
	@Autowired
	private InstructorConductDao instructorConductDao;

	@Autowired
	private CourseManagementDao courseManagementDao;
    /**
     * Find all course sched V form.
     *
     * @return the Set<CourseScheduleViewForm>
     */
    @Override
    public Set<CourseSchedule> findAllCourseSchedVForm(Pageable pageable) {
        return instructorConductDao.findAllCourseSchedule(pageable);

    }

    /**
	 * <pre>
	 * Find Course Schedule assigned to instructor, Call instructorConductDao.findAllScheduledCourses
	 * <pre>
	 */
    @Override
    public Set<CourseSchedule> findAllCourseSchedVFormByInstructorId(Pageable pageable, Long instructorId) {
        return instructorConductDao.findAllCourseScheduleByInstructorId(pageable, instructorId);
    }

	/**
	 * <pre>
	 * Find Course Schedule by course Id Call ScheduleDao.findCourseScheduleByCourseId by using course schedule
	 * <pre>
	 * @param courseSchedule
	 */
    @Override
    public Set<CourseSchedule> findAllCourseSchedVFormByInstructorIdCourseId(Pageable pageable, Long instructorId,Long courseId) {
        
        try {
            return instructorConductDao.findAllCourseScheduleByCourseIdInstructorId(pageable, instructorId, courseId);
            
        } catch (DataAccessException ex) {
            throw new IllegalArgumentException("Can't find Course Schedule");
        }
    }
	
	/**
	 * <pre>
	 * Find selected Course Schedule assigned to instructor, Call instructorConductDao.findAllScheduledCourses by using instructor id
	 * <pre>
	 */
	@Override
	public Set<CourseForm> findAssignCoursesByInstructor(Long instructorId) {
			return instructorConductDao.findAllScheduledCoursesByInstructorId(instructorId);
	}

    /**
     * Find all course form.
     *
     * @return the sets the
     */
    @Override
    public Set<CourseForm> findAllCourseForm() {
        Set<Course> courses = courseManagementDao.findAllCourses();
        
        return courses.stream()
                      .map(this::courseToCourseForm)
                      .collect(Collectors.toSet());
    }

    /**
     * Find all course schedule view form by course.
     *
     * @param courseName the course name
     * @return the sets the
     */
    @Override
    public Set<CourseSchedule> findAllCourseSchedVFormByCourse(Pageable pageable, String courseName) {
        
        Set<CourseSchedule> courseSchedules = instructorConductDao.findAllCourseScheduleByCourseName(pageable,courseName);
        
        if(courseSchedules.isEmpty()) {
            return Collections.emptySet();
        }
        
        return courseSchedules;
    }
    
   
	/**
	 * Find all course schedule view form by search filter.
	 *
	 * @param surveySearchFilter the survey search filter
	 * @return the sets the
	 */
	@Override
    public Set<CourseSchedule> findAllCourseSchedVFormBySearchFilter(Pageable pageable, SurveySearchFilter surveySearchFilter) {
        
        Set<CourseSchedule> courseSchedules = instructorConductDao.findAllCourseScheduleBySurveyFilter(pageable,surveySearchFilter);
	    
        if(courseSchedules.isEmpty()) {
            return Collections.emptySet();
        }
        
        return courseSchedules;
    }

    private CourseForm courseToCourseForm (Course course) {
        Objects.requireNonNull(course);
        
        CourseForm courseForm = new CourseForm();
        courseForm.setId(course.getId());
        courseForm.setName(course.getName());
        
        return courseForm;
    }
	
    /**
     * Method for counting the number of available course for specific Instructor
     * 
     * @author l.celoso
     *
     * @param string 
     */
	@Override
    public int countCourseForInstructor(Long instructorId) {
	    Objects.requireNonNull(instructorId);
	    
	    return instructorConductDao.countCourseForInstructor(instructorId);
	    
	}
	
    /**
     * Method for counting the number of available course for specific Instructor and Course
     * 
     * @author l.celoso
     *
     * @param string 
     */
    @Override
    public int countCourseForInstructorFilter(Long instructorId, Long courseId) {
        Objects.requireNonNull(instructorId);
        
        return instructorConductDao.countCourseForInstructorFilter(instructorId, courseId);
        
    }

    /**
     * Method for counting the number of available course
     * 
     * @author l.celoso
     *
     * @param string 
     */
    @Override
    public int countCourseForAll() {
        
        return instructorConductDao.countCourseForAll();
    }
    
    /**
     * Method for counting the number of available course with searchFilter
     * 
     * @author l.celoso
     *
     * @param string 
     */
    @Override
    public int countCourseForAllFilter(SurveySearchFilter surveySearchFilter) {
        
        return instructorConductDao.countCourseForAllFilter(surveySearchFilter);
    }
}

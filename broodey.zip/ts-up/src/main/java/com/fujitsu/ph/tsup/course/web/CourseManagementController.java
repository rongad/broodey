/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.web;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.category.service.CourseCategoryManagementService;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.course.model.CourseForm;
import com.fujitsu.ph.tsup.course.service.CourseManagementService;
import com.fujitsu.ph.tsup.department.domain.Department;
import com.fujitsu.ph.tsup.department.service.DepartmentService;
import com.fujitsu.ph.tsup.enrollment.web.EnrollmentController;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.roletype.domain.RoleType;
import com.fujitsu.ph.tsup.roletype.service.RoleTypeService;
import com.fujitsu.ph.tsup.search.CourseSearchFilter;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Course Management
// Class Name : CourseManagementController.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2020/08/28 | WS) c.lepiten | Initial Version
// 0.02 | 2021/04/20 | WS) i.fajardo | Updated
// 0.03 | 2021/05/10 | WS) D.Escala | Updated
// 0.04 | 2021/05/27 | WS) mi.aguinaldo | Added update path for updating course.
// 0.05 | 2021/07/2 | WS) mi.aguinaldo | Handle exception.
// 0.06 | 2021/07/16 | WS) mi.aguinaldo | Updated
// 0.07 | 2021/07/21 | WS) M.Taboada | Updated
// 0.08 | 2021/08/05 | WS) mi.aguinaldo | Updated
// 0.09 | 2021/09/06 | WS) d.dinglasan | Updated
// 0.10 | 2021/10/13 | WS) l.celoso | Adding Tags in filter search
// 0.10 | 2021/10/07 | WS) r.delacruz | Updated
// ==================================================================================================
@Controller
@RequestMapping("/courses")
public class CourseManagementController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CourseManagementController.class);

    private static final String CREATE_COURSE_REDIRECT_URL = "redirect:/courses/create";
    private static final String MANAGE_COURSE_REDIRECT_URL = "redirect:/courses/load";

    private static final String MANAGE_COURSE_FILE_PATH = "course-management/manageCourse";

    private static final String ERROR_MODAL_ATTRIBUTE = "ErrorModal";
    private static final String ERROR_MSG_MODAL_ATTRIBUTE = "errorMsg";

    @Autowired
    private CourseManagementService courseManagementService;

    @Autowired
    private CourseCategoryManagementService courseCategoryManagementService;

    @Autowired
    private DepartmentService deparmentService;

    @Autowired
    private EnrollmentController enrollmentController;

    @Autowired
    private RoleTypeService roleTypeService;

    @GetMapping("/load")
    public String load(Model model, @RequestParam("page") Optional<Integer> page,
            @RequestParam("size") Optional<Integer> size,
            @RequestParam("sortField") Optional<String> sortField,
            @RequestParam("sortDir") Optional<String> sortDir) {

        // 0.09 2021/09/06 WS) D.Dinglasan Mod_Start
        // Change refernce of default values
        int currentPage = page.orElse(Paging.DEFAULT_CURRENT_PAGE_NO);
        int pageSize = size.orElse(Paging.DEFAULT_PAGE_SIZE);
        // 0.09 2021/09/06 WS) D.Dinglasan Mod_End

        enrollmentController.getAllFilterOption(model);

        String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("courseCategory");

        String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");

        Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);
        Pageable pageable = PageRequest.of(currentPage - 1, pageSize, sort);

        // 0.09 2021/09/06 WS) D.Dinglasan Mod_Start
        Paged<Course> pagedCourse = courseManagementService.findAllCoursesAsPaged(pageable);
        // 0.09 2021/09/06 WS) D.Dinglasan Mod_End

        List<CourseCategory> courseCategoryList = courseCategoryManagementService.findAllCourseCategory()
                .stream().collect(Collectors.toList());

        List<Department> departments = deparmentService.findAllDepartments().stream()
                .collect(Collectors.toList());

        List<String> courseNames = courseManagementService.loadAllCourseName().stream()
                .collect(Collectors.toList());

        model.addAttribute("reverseSortDir", sortVal);

        model.addAttribute("currentPage", currentPage);

        model.addAttribute("paginatedCourse", pagedCourse); // 0.09 2021/09/06 WS) D.Dinglasan Mod

        model.addAttribute("courseCategory", courseCategoryList);

        model.addAttribute("departmentList", departments);

        model.addAttribute("courseNames", courseNames);

        model.addAttribute("course", new CourseForm());

        return MANAGE_COURSE_FILE_PATH;

    }

    /**
     * Method for getting course to update
     * 
     * @param formCourse
     * @param redirectAttributes
     * @return
     */
    @GetMapping("/update")
    public String showUpdateCourseForm(@ModelAttribute CourseForm formCourse,
            RedirectAttributes redirectAttributes) {

        if (Objects.isNull(formCourse.getId())) {
            return MANAGE_COURSE_REDIRECT_URL;
        }

        LOGGER.debug(formCourse.toString());

        redirectAttributes.addFlashAttribute("updateCourse", formCourse);

        return MANAGE_COURSE_REDIRECT_URL + "#updateConfirmModal";
    }

    /**
     * Method for updating the course
     * 
     * @param courseForUpdate
     * @param redirectAttributes
     * @return
     */
    @PostMapping("/update")
    public String updateCourseForm(@ModelAttribute CourseForm courseForUpdate,
            RedirectAttributes redirectAttributes) {

        if (!courseForUpdate.isValidForUpdate()) {
            return MANAGE_COURSE_REDIRECT_URL;
        }

        try {
            LOGGER.debug(courseForUpdate.toString());
            Course updatedCourse = Course.builder().withId(courseForUpdate.getId())
                    .withCourseCategoryId(courseForUpdate.getCourseCategoryId())
                    .withName(courseForUpdate.getName().trim()).withDetail(courseForUpdate.getDetail())
                    .withIsMandatory(courseForUpdate.getIsMandatory())
                    .withDeadline(courseForUpdate.getDeadline())
                    .withMandatoryType(courseForUpdate.getMandatoryType())
                    .withDepartmentId(courseForUpdate.getDepartmentId())
                    .withMemberRole(courseForUpdate.getMemberRole()).build();

            courseManagementService.updateCourse(updatedCourse);
        } catch (RuntimeException e) {
            LOGGER.error(e.getMessage(), e);
            redirectAttributes.addFlashAttribute(ERROR_MSG_MODAL_ATTRIBUTE, e.getMessage());
            return MANAGE_COURSE_REDIRECT_URL + "#errorModal";
        }

        redirectAttributes.addFlashAttribute("successMessage",
                "You have successfully update this course " + courseForUpdate.getName());

        return MANAGE_COURSE_REDIRECT_URL + "#successModal";
    }

    /**
     * Method for getting course id to delete
     * 
     * @param id Course Id
     * @param form Course Form
     * @param bindingResult Binding Result
     * @param model Model
     * @return View
     */
    @GetMapping("/{courseId}/delete")
    public String showDeleteCourseForm(@RequestParam(value = "courseIdInput") Long id, CourseForm form,
            BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {

            return MANAGE_COURSE_REDIRECT_URL + "?courseId=" + id + "#confirmModal";

        }

        // set value for Course object
        Course course = courseManagementService.findCourseById(id);

        // set value for CoruseForm object
        form.setId(course.getId());
        form.setName(course.getName());
        form.setDetail(course.getDetail());
        form.setIsMandatory(course.getIsMandatory());
        form.setDeadline(course.getDeadline());

        model.addAttribute("deleteCourseForm", form);

        return MANAGE_COURSE_REDIRECT_URL + "?courseId=" + id + "#confirmModal";
    }

    /**
     * Method for deleting course with the given id
     * 
     * @param id Course id
     * @param redirectAttributes RedirectAttributes
     * @param model Model
     * @return View
     */
    @PostMapping("/{courseId}/delete")
    public String submitDeleteCourseForm(@PathVariable("courseId") Long id,
            RedirectAttributes redirectAttributes, Model model) {

        // Call deleteCourseById() method.
        courseManagementService.deleteCourseById(id);

        redirectAttributes.addFlashAttribute("successMessage", "You have successfully delete this course");

        return MANAGE_COURSE_REDIRECT_URL + "#successModal";
    }

    @GetMapping("/search")
    public String submitSearchCourseForm(Model model, @ModelAttribute CourseSearchFilter courseSearchFilter,
            @RequestParam("page") Optional<Integer> page, @RequestParam("size") Optional<Integer> size,
            @RequestParam("sortField") Optional<String> sortField,
            @RequestParam("sortDir") Optional<String> sortDir) {

        // 0.09 202/09/06 WS) D.Dinglasan Mod_Start
        // Change reference of default values
        int currentPage = page.orElse(Paging.DEFAULT_CURRENT_PAGE_NO);
        int pageSize = size.orElse(Paging.DEFAULT_PAGE_SIZE);
        // 0.09 202/09/06 WS) D.Dinglasan Mod_End

        if (courseSearchFilter.isSearchEmpty()) {
            return MANAGE_COURSE_REDIRECT_URL;
        }

        try {

            enrollmentController.getAllFilterOption(model);

            String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("courseCategory");

            String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");

            Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);

            Pageable pageable = PageRequest.of(currentPage - 1, pageSize, sort);

            // 0.09 2021/09/06 WS) D.Dinglasan Mod_Start
            Paged<Course> pagedCourse = courseManagementService
                    .findCoursesByCourseSearchFilterAsPaged(courseSearchFilter, pageable);
            // 0.09 2021/09/06 WS) D.Dinglasan Mod_End

            List<CourseCategory> courseCategoryList = Optional
                    .ofNullable(courseCategoryManagementService.findAllCourseCategory())
                    .orElse(Collections.emptySet()).stream().collect(Collectors.toList());

            List<Department> departments = deparmentService.findAllDepartments().stream()
                    .collect(Collectors.toList());

            List<String> courseNames = courseManagementService.loadAllCourseName().stream()
                    .collect(Collectors.toList());

            model.addAttribute("currentPage", currentPage);
            model.addAttribute("paginatedCourse", pagedCourse); // 0.09 2021/09/06 WS) D.Dinglasan Mod
            model.addAttribute("courseCategory", courseCategoryList);
            model.addAttribute("departmentList", departments);
            model.addAttribute("courseNames", courseNames);
            model.addAttribute("course", new CourseForm());

        } catch (RuntimeException e) {
            LOGGER.error(e.getMessage(), e.getCause());
            return MANAGE_COURSE_FILE_PATH;
        }

        return MANAGE_COURSE_FILE_PATH;
    }

    /**
     * Author: WS)C.Arias Updated: WS)I.Fajardo
     * 
     * <pre>
     * Create the course. Method = GET
     * 
     * <pre>
     * 
     * @return course Form and view
     */
    @GetMapping("/create")
    public String showCreateCourseForm(Model model) {
        Set<CourseCategory> courseCategory = courseCategoryManagementService.findAllCourseCategory();
        List<CourseCategory> courseCategoryList = courseCategory.stream().collect(Collectors.toList());
        Set<RoleType> memberRoles = roleTypeService.loadAllRoleType();
        List<RoleType> memberRoleList = memberRoles.stream().collect(Collectors.toList());
        model.addAttribute("create");
        model.addAttribute("courseCategory", courseCategoryList);
        model.addAttribute("memberRoleList", memberRoleList);

        return "course-management/courseCreate";

    }

    /**
     * Author: WS)C.Arias Updated: WS)I.Fajardo
     * 
     * <pre>
     * Create the course. Method = POST
     * 
     * <pre>
     * 
     * @param CourseForm form
     * @param BindingResult bindingResult
     * @return course Form and view
     */
    @PostMapping("/create")
    public String submitCreateCourseForm(CourseForm courseForm, BindingResult bindingResult, Model model,
            RedirectAttributes redirectAttributes) {

        if (!courseForm.isValidForCreation()) {
            return CREATE_COURSE_REDIRECT_URL;
        }

        // remove irregular spaces
        String courseName = StringUtils.trim(courseForm.getName());

        if (courseManagementService.courseNameExists(courseForm.getName())) {
            redirectAttributes.addFlashAttribute(ERROR_MSG_MODAL_ATTRIBUTE,
                    courseName + ", Course Name Already Exists");
            redirectAttributes.addFlashAttribute(ERROR_MODAL_ATTRIBUTE, 1);
            return CREATE_COURSE_REDIRECT_URL;
        }

        try {

            // proceed with creating course
            Course courseDetail = Course.builder().withName(courseName).withDetail(courseForm.getDetail())
                    .withIsMandatory(courseForm.getIsMandatory()).withDeadline(courseForm.getDeadline())
                    .withCourseCategoryId(courseForm.getCourseCategoryId())
                    .withMandatoryType(courseForm.getMandatoryType())
                    .withDepartmentId(courseForm.getDepartmentId()).withMemberRole(courseForm.getMemberRole())
                    .build();

            courseManagementService.createCourse(courseDetail);
        } catch (RuntimeException e) {
            LOGGER.error(e.getMessage(), e);
            redirectAttributes.addFlashAttribute(ERROR_MSG_MODAL_ATTRIBUTE, e.getMessage());
            redirectAttributes.addFlashAttribute(ERROR_MODAL_ATTRIBUTE, 1);
            return CREATE_COURSE_REDIRECT_URL;
        }
        redirectAttributes.addFlashAttribute(ERROR_MODAL_ATTRIBUTE, 2);

        return CREATE_COURSE_REDIRECT_URL;
    }

}

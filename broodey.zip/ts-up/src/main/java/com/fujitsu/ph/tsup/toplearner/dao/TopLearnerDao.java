package com.fujitsu.ph.tsup.toplearner.dao;

import java.util.List;

import com.fujitsu.ph.tsup.enrollment.model.TopLearnerForm;

/** ==================================================================================================
  * Id:PR32
  * Project Name :Training Sign Up
  * System Name : Top Learners
  * Class Name : TopLearnerDao.java
  *
  * <<Modification History>>
  * Version | Date       | Updated By         | Content
  * --------+------------+-----------------------+---------------------------------------------------
  * 0.01    | 12/29/2021 | WS) ep.delosreyes  | Initial Create
  * ==================================================================================================
  */

public interface TopLearnerDao {
    /**
     * Finds the top learners of the month with dynamic number of result
     * @param numberOfResult
     * @return List<TopLearnerForm>
     */
    List<TopLearnerForm> findTopLearnerByMonth(int numberOfResult);


     /**
     * Finds the top learners of the quarter with dynamic number of result
     * @param numberOfResult
     * @return List<TopLearnerForm>
     */
     List<TopLearnerForm> findTopLearnerByQuarter(int numberOfResult);
}
//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : MandatoryCoursesDao                                                                                                                                                               
// Class Name   : MandatoryCoursesDao.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 1.0.0   | 2021/04/21 | WS)J.Barbadillo       | New Creation        
// 1.0.1   | 2021/05/05 | WS)J.Barbadillo       | Updated
// 1.0.2   | 2021/07/12 | WS)RL.Naval           | Updated
// 1.0.3   | 2021/08/13 | WS)RL.Naval           | Updated
// 1.0.4   | 2021/10/13 | WS)R.Buot             | Updated
// 1.0.5   | 2021/10/14 | WS)D.Dinglasan        | Updated
// 1.0.6   | 2021/10/21 | WS)DW.Cardenas        | Updated
//==================================================================================================                                                                                                                                                                                                                                                                                                                                                        
package com.fujitsu.ph.tsup.report.summary.dao; 

import java.time.LocalDateTime;
import java.util.Set;

import com.fujitsu.ph.tsup.report.summary.model.MandatoryCourses;

/**
* <pre>
*   The Dao for the MandatoryCoursesController
* </pre>
* 
* @author j.barbadillo
* @author rl.naval
* @author r.buot
* @version 1.0.4
*/

public interface MandatoryCoursesDao {

    /**
     *  Find the all mandatory courses
     * @return mandatoryCourses
     */
    Set<MandatoryCourses> findMandatoryCourses();
    
    /**
     *  Find the total number of  JDU based on the given date range
     * @param selectedReportDate
     * @return mandatoryCourses
     */
    Set<MandatoryCourses> findMandatoryCourses(LocalDateTime selectedReportDate);

    /**
     *  Count the total number of JDU
     * @return int
     */
    Long findTotalNumberOfJdu();

    /**
     *  Count the total number of JDU
     * @return int
     */
    Long findTotalNumberOfEnrolledJdu(String course);
    
    /**
     * Find the total number of JDU who finished training based on the courses
     * 
     * @param mandatoryCourses
     * @param reportDate
     * @return int
     */
    Long findTotalNumberOfJduWhoFinishedTraining(String mandatoryCourses, LocalDateTime reportDate);
    
    /**
     * Find the total number of JDU who finished training lastweek based on course
     * 
     * @param mandatoryCourses
     * @param reportDate
     * @return int
     */
    Long findTotalNumberOfJduWhoFinishedTrainingLastWeek(String mandatoryCourses, LocalDateTime reportDate);
    
}

/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */    
package com.fujitsu.ph.tsup.viewsurveyrate.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.springframework.jdbc.core.RowMapper;

import com.fujitsu.ph.tsup.viewsurveyrate.domain.SurveyRateForm;

//==================================================================================================                                                                                                                                                                            
//Project Name : Training Sign Up
//System Name  : SurveyRateRowMapper                                                                                                                                                              
//Class Name   : SurveyRateRowMapper.java                                                                                                                                                                          
//                                                                                                                                                                   
//<<Modification History>>                                                                                                                                                                             
//Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
//1.0.0   | 2021/08/16 | WS)E.Juan       | New Creation    

public class SurveyRateRowMapper implements RowMapper<SurveyRateForm>{

    @Override
    public SurveyRateForm mapRow(ResultSet rs, int rowNum) throws SQLException {
        
        long id=rs.getLong("id");
        String courseTitle=rs.getString("courseTitle");
        String instructorName=rs.getString("instructorName");
        ZonedDateTime courseDateTime = ZonedDateTime
                .ofInstant(rs.getTimestamp("courseDateTime").toInstant(), ZoneId.systemDefault());
        int mdQuestion1=rs.getInt("mdQuestion1");
        int mdQuestion2=rs.getInt("mdQuestion2");
        int mdQuestion3=rs.getInt("mdQuestion3");
        int mdQuestion4=rs.getInt("mdQuestion4");
        
        int matQuestion1=rs.getInt("matQuestion1");
        int matQuestion2=rs.getInt("matQuestion2");
        int matQuestion3=rs.getInt("matQuestion3");
        int matQuestion4=rs.getInt("matQuestion4");
        
        int insQuestion1=rs.getInt("insQuestion1");
        int insQuestion2=rs.getInt("insQuestion2");
        int insQuestion3=rs.getInt("insQuestion3");
        int insQuestion4=rs.getInt("insQuestion4");
        int insQuestion5=rs.getInt("insQuestion5");
        int insQuestion6=rs.getInt("insQuestion6");
        
        int eqFaQuestion1=rs.getInt("eqFaQuestion1");
        int eqFaQuestion2=rs.getInt("eqFaQuestion2");
        int eqFaQuestion3=rs.getInt("eqFaQuestion3");
        
        String commentsE=rs.getString("commentsE");
        String commentsF=rs.getString("commentsF");
        String commentsG=rs.getString("commentsG");
        
        
        return new SurveyRateForm.Builder(id,courseTitle,instructorName,courseDateTime, mdQuestion1, mdQuestion2, mdQuestion3, mdQuestion4, matQuestion1, matQuestion2, matQuestion3, matQuestion4, 
                insQuestion1, insQuestion2, insQuestion3, insQuestion4, insQuestion5,insQuestion6, eqFaQuestion1, eqFaQuestion2, eqFaQuestion3,  commentsE, 
                commentsF, commentsG).build();
    }

}

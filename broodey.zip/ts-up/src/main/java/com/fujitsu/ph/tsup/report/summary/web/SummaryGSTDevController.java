/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.web;

import java.time.ZonedDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fujitsu.ph.tsup.report.summary.model.SummaryGSTDevForm;
import com.fujitsu.ph.tsup.report.summary.service.SummaryGSTDevService;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for Dev
//Class Name   : SummaryGSTDevController.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    |  ---       | WS) g.cabiling        | Initial Version
//0.02    | 2021/06/14 | WS) m.padaca          | Updated
//0.03    | 2021/10/15 | WS) r.buot            | Updated
//==================================================================================================

/**
 * <pre>
 * The controller of G3CC standardization training for developers
 * </pre>
 * 
 * @version 0.02
 * @author g.cabiling
 * @author m.padaca
 */
@Controller
@RequestMapping("/report/summary")
public class SummaryGSTDevController {

    @Autowired
    private SummaryGSTDevService summaryGSTDevService;

    /**
     * @param Model model
     * @return SummaryGSTDev view
     */
    @GetMapping("/standardization/dev")
    public String loadSummary(SummaryGSTDevForm summaryGSTDev, Model model) {
        ZonedDateTime reportDate = summaryGSTDev.getReportDateTime();
        if (reportDate == null)
            reportDate = ZonedDateTime.now();

        SummaryGSTDevForm summaryForm = summaryGSTDevService.getSummary(reportDate);

        model.addAttribute("summaryGSTDev", summaryForm);
        return "reports/SummaryGSTDev";
    }
}

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Reports for Training Request
//Class Name   : ReportForTrainingRequestImpl.java                                                                                                                                                                      
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.01    | 2021/08/17  | WS)L.Celoso         	| New Creation        
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.util.LinkedHashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.report.summary.dao.ReportForTrainingRequestDao;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

/**
 * <pre>
 * The implementation of G3CC standardization training for dev service
 * </pre>
 * 
 * @version 0.03
 * @author n.dejesus
 * @author a.batongbacal
 * @author m.padaca
 */
@Service
public class ReportForTrainingRequestImpl implements ReportForTrainingRequest {

     //Reports for training requests                                                                                                                                      
	@Autowired
	private ReportForTrainingRequestDao reportForTrainingRequestDao;
	
	/**
     * <pre>
     * Get Report for Training Request
     * </pre> 
     * @return TrainingRequest
     */
	@Override
	public Set<TrainingRequest> getTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm) {

	    Set<TrainingRequest> trainingRequest = new LinkedHashSet<TrainingRequest>();
	    trainingRequest = reportForTrainingRequestDao.findAllTrainingRequest(trainingRequestSearchForm);
        return trainingRequest;
        
	}
	
}

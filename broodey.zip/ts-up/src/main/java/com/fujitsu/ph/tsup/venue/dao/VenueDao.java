/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.venue.dao;


import java.util.List;
import java.util.Set;
import org.springframework.data.domain.Pageable;
import com.fujitsu.ph.tsup.venue.domain.Venue;

//===============================================================================================
//Project Name: Training Sign Up
//Class Name: VenueDao.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 03/06/2021 | WS) dw.cardenas  | Created
//0.02    | 30/06/2021 | WS) mi.aguinaldo | added count venue and overload the findAllVenues
//0.03    | 29/07/2021 | WS) dw.cardenas  | findVenueByeName overload
//0.04    | 09/09/2021 | WS) d.dinglasan  | Declare findVenue and countVenue methods
//===============================================================================================
/**
 *
 * @version 0.01
 * @author dw.cardenas
 *
 */
public interface VenueDao {

	/**
	 * <pre>
	 * Adds a new venue to the database.
	 * <pre>
	 *
	 * @param venue
	 */
	void createVenue(Venue venue);

	/**
	 * <pre>
	 * Finds a specific venue in the database with specific id.
	 * <pre>
	 *
	 * @param id
	 * @return venue with specific id
	 */
	Venue findVenueById(Long id);

	/**
	 * <pre>
	 * Finds a specific venue in the database with specified name.
	 * <pre>
	 *
	 * @param name
	 * @return venue with specific name
	 */
	Set<Venue> findVenueByName(String name);

	/**
	 * <pre>
	 * Finds all venues in the database.
	 * <pre>
	 *
	 * @return all venues
	 */
	Set<Venue> findAllVenues();
	
	/**
	 * <pre>
	 * Finds all venues in the database.
	 * <pre>
	 *
	 * @return all venues
	 */
	Set<Venue> findAllVenues(Pageable pageable);
	
	/**
	 * <pre>
	 * Counts all the venue in the database.
	 * <pre>
	 *
	 * @return Total number of venue
	 */
	 int countVenue();

	/**
	 * <pre>
	 * Updates an existing venue in the database
	 * <pre>
	 *
	 * @param venue
	 */
	void updateVenue(Venue venue);

	/**
	 * <pre>
	 * Deletes an existing venue in the database using the id.
	 * <pre>
	 *
	 * @param id
	 */
	void deleteVenueById(Long id);

	/**
	 * <pre>
	 * Finds a specific venue in the database with specified name
	 * <pre>
	 *
	 * @param searchKey
	 * @param pageable
	 * @return
	 */
	Set<Venue> findVenueByName(String searchKey, Pageable pageable);
	
	   /**
     * <pre>
     * Finds a specific venue in the database with specified name
     * <pre>
     *
     * @param byKeyword
     * @param pageable
     * @return List
     */
    List<Venue> findVenue(String byKeyword, Pageable pageable);
	
    /**
     * <pre>
     * Counts venue retrieved in the database.
     * <pre>
     *
     * @return Total number of venue
     */
     int countVenue(String byKeyword);
	
}

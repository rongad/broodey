/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.pagination;

import org.springframework.data.domain.Page;

public class Paged<T> {

    private Page<T> page;

    private Paging paging;

    
    
    /**
     * @param page
     * @param paging
     */
    public Paged(Page<T> page, Paging paging) {
        super();
        this.page = page;
        this.paging = paging;
    }

    /**
     * @return the page
     */
    public Page<T> getPage() {
        return page;
    }

    /**
     * @return the paging
     */
    public Paging getPaging() {
        return paging;
    }
    
}
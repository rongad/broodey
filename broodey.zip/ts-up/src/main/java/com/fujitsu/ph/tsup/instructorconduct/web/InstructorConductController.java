package com.fujitsu.ph.tsup.instructorconduct.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.authz.config.TsupRole;
import com.fujitsu.ph.tsup.common.domain.Utility;
import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseForm;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.instructorconduct.model.SurveySearchFilter;
import com.fujitsu.ph.tsup.instructorconduct.service.InstructorConductService;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.scheduling.service.ScheduleService;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: InstructorConductServicImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja     | New Creation
//0.02    | 10/08/2021 | WS) MI.Aguinaldo | Update
//0.03    | 10/27/2021 | WS) L.Celoso     | Added the pagination
//0.03    | 10/28/2021 | WS) M.Yanoyan    | Update search
//=======================================================

@Controller
@RequestMapping("/surveysRates")
public class InstructorConductController {
    
	/**
	 * Instructor Conduct Service 
	 */
	@Autowired
	private InstructorConductService instructorConductService;
	
	@Autowired
	private ScheduleService scheduleService;
	
	private static String SURVEY_RATES_FILE_PATH = "survey/instructorsCourseConducted";
    private static String SURVEY_RATES_REDIRECT_URL = "redirect:/surveysRates/load";
    private static final int PAGE_SIZE = 10;

	/**
	 * <pre>
	 * View course schedule assigned to instructor. Method = GET
	 * 
	 * <pre>
	 * 
	 * @param Long 					 id
	 * @param CourseScheduleListForm form
	 * @param BindingResult          bindingResult
	 * @param Model                  model
	 * @return courseScheduleListForm and view
	 */
	@GetMapping("/load")
	public String viewAllCourseSchedule(@Valid @ModelAttribute("viewSurvey") CourseScheduleListForm courseScheduleListForm, Model model,
			                            @RequestParam("sortField") Optional<String> sortField,
			                            @RequestParam("sortDir") Optional<String> sortDir) {
	    
		FpiUser user = Utility.getCurrentFpiUser();

        int currentPage = 1;
        int availableCourse = 0;
        String currentPageStr = courseScheduleListForm.getCurrentPage();
        if (isNumeric(currentPageStr)) {
            currentPage = Integer.parseInt(currentPageStr);
        }
		
        String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("scheduled_start_datetime");
        String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");
        Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);
        
        Pageable pageable = PageRequest.of(currentPage - 1, PAGE_SIZE, sort);
		Page<CourseSchedule> paginatedCourse;
        Paged<CourseSchedule> pagedCourse;
		
		Set<CourseSchedule> courseScheduleViewFormList;
		Set<CourseForm> courseFormList;
		
		if(user.getRoles().contains(TsupRole.PMO)) {
		    courseScheduleViewFormList = instructorConductService.findAllCourseSchedVForm(pageable);
		    availableCourse = instructorConductService.countCourseForAll();
		    courseFormList = instructorConductService.findAllCourseForm();
		    courseScheduleListForm.setInstructors(scheduleService.findAllInstructors());
		    
		} else {
		    Long userId = user.getId();

            courseScheduleViewFormList = instructorConductService.findAllCourseSchedVFormByInstructorId(pageable,userId);
            availableCourse = instructorConductService.countCourseForInstructor(userId);
	        courseFormList = instructorConductService.findAssignCoursesByInstructor(userId);
		}

        List<CourseSchedule> sortedCourseScheduleViewForm = new ArrayList<>(courseScheduleViewFormList);
        List<CourseForm> sortedCourse = courseFormList.stream()
                                                      .sorted(CourseForm::sortedByStartDate)
                                                      .collect(Collectors.toList());
        
        // For Pagination ================================================================
        paginatedCourse = new PageImpl<>(sortedCourseScheduleViewForm, pageable, availableCourse);
        pagedCourse = new Paged<>(paginatedCourse, Paging.of(
                paginatedCourse.getTotalPages(), pageable.getPageNumber() + 1, pageable.getPageSize()));
        model.addAttribute("paginatedViewSurvey", pagedCourse);
        // ===============================================================================
        
		courseScheduleListForm.setCourseSchedules(sortedCourseScheduleViewForm);
		courseScheduleListForm.setCourses(sortedCourse);

		model.addAttribute("viewSurvey", courseScheduleListForm);
		return SURVEY_RATES_FILE_PATH;	
	}
	
	
	@GetMapping("/search")
	public String searchCourseSchedule(@Valid @ModelAttribute("viewSurvey") CourseScheduleListForm courseScheduleListForm,
	                                   @ModelAttribute SurveySearchFilter surveySearchFilter, Model model,
	                                   @RequestParam("sortField") Optional<String> sortField,
                                       @RequestParam("sortDir") Optional<String> sortDir) {
	    
	    FpiUser user = Utility.getCurrentFpiUser();
        
	    int currentPage = 1;
        int availableCourse = 0;
        String currentPageStr = courseScheduleListForm.getCurrentPage();
        if (isNumeric(currentPageStr)) {
            currentPage = Integer.parseInt(currentPageStr);
        }
        
        String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("scheduled_start_datetime");
        String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");
        Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);
        
        Pageable pageable = PageRequest.of(currentPage - 1, PAGE_SIZE, sort);
        Page<CourseSchedule> paginatedCourse;
        Paged<CourseSchedule> pagedCourse;
	    
        Set<CourseSchedule> courseScheduleViewFormList;
        Set<CourseForm> courseFormList;
        
        if(user.getRoles().contains(TsupRole.PMO)) {
            courseFormList = instructorConductService.findAllCourseForm();
            availableCourse = instructorConductService.countCourseForAllFilter(surveySearchFilter);
            courseScheduleViewFormList = instructorConductService.findAllCourseSchedVFormBySearchFilter(pageable, surveySearchFilter);
            
            courseScheduleListForm.setInstructors(scheduleService.findAllInstructors());

        } else {
            if(Objects.isNull(surveySearchFilter.getCourseId()) || Objects.equals(surveySearchFilter.getCourseId(), -1L)) {
                return SURVEY_RATES_REDIRECT_URL;
            }
            
            Long userId = user.getId();
            
            courseScheduleViewFormList = instructorConductService.findAllCourseSchedVFormByInstructorIdCourseId(pageable, userId, surveySearchFilter.getCourseId());
            availableCourse = instructorConductService.countCourseForInstructorFilter(userId, surveySearchFilter.getCourseId());
            courseFormList = instructorConductService.findAssignCoursesByInstructor(userId);
        
        }
        List<CourseSchedule> sortedCourseScheduleViewForm = new ArrayList<>(courseScheduleViewFormList);
        List<CourseForm> sortedCourse = courseFormList.stream()
                                                      .sorted(CourseForm::sortedByStartDate)
                                                      .collect(Collectors.toList());
        
        // For Pagination ================================================================
        paginatedCourse = new PageImpl<>(sortedCourseScheduleViewForm, pageable, availableCourse);
        pagedCourse = new Paged<>(paginatedCourse, Paging.of(
                paginatedCourse.getTotalPages(), pageable.getPageNumber() + 1, pageable.getPageSize()));
        model.addAttribute("paginatedViewSurvey", pagedCourse);
        // ===============================================================================
        
        courseScheduleListForm.setCourseSchedules(sortedCourseScheduleViewForm);
        courseScheduleListForm.setCourses(sortedCourse);

        model.addAttribute("viewSurvey", courseScheduleListForm);
	    return SURVEY_RATES_FILE_PATH;
	}
	
    /**
     * Check if String is Numeric
     * 
     * @return
     */
    public static boolean isNumeric(String strNum) {
        if (strNum == null || strNum.length() == 0) {
            return false;
        }

        try {
            Double.parseDouble(strNum);
            return true;

        } catch (NumberFormatException e) {
            return false;
        }
    }
}

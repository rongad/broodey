/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.roletype.dao;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.roletype.domain.RoleType;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Role Type Management
//Class Name   : RoleTypeDao.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/02/05 | WS) rl.naval          | Initial Version
//0.02    | 2021/02/15 | WS) rl.naval          | Updated
//0.03    | 2021/02/17 | WS) c.sinda           | Updated
//0.04    | 2021/02/22 | WS) j.sayaboc         | Updated
//0.05    | 2021/02/23 | WS) s.labador         | Updated
//0.06    | 2021/02/24 | WS) p.cui             | Updated
//0.07    | 2021/03/11 | WS) p.cui             | Updated
//0.08	  | 2021/07/12 | WS) r.gaquit		   | Updated
//0.09    | 2021/08/31 | WS) dw.cardenas       | Updated
//0.09    | 2021/09/09 | WS) d.dinglasan       | Updated
//==================================================================================================

/**
 * RoleTypeDao class
 * 
 * @version 0.09
 * @author rl.naval
 * @author c.sinda
 * @author s.labador
 * @author j.sayaboc
 * @author p.cui
 * @author r.gaquit
 * @author d.dinglasan
 */

public interface RoleTypeDao {

    // Method for finding Role Type by ID
    RoleType findRoleById(Long id);

    // Method for searching Role by Name
    Set<RoleType> findRoleTypeByName(String rolename);

    // Method for searching if Role is already existing
    Set<RoleType> findIfRoleNameExists(String rolename, Long id);

    // Method for searching Role by keyword
    Set<RoleType> findRoleTypeByKeyword(String keyword);
    
    // Method for loading all Role Type in Role View
    Set<RoleType> loadAllRoleType();
    
    //Method for loading all Role Type in Role View with pagination
    Set<RoleType> loadAllRoleType(Pageable pageable);
    
    /**
     * <pre>
     * Method for loading Role Type in Role View with pagination
     * </pre>
     * 
     * @param byKeyword
     * @param pageable
     * @return List
     */
    List<RoleType> loadRoleType(String byKeyword, Pageable pageable);
    
    //Method that counts the number of existing role type
    int countRoleType();
    
    /**
     * <pre>
     * Method that counts the number of role types based from keyword
     * </pre>
     * 
     * @param byKeyword
     * @return int
     */
    int countRoleType(String byKeyword);

    // Method for deleting Role Type by Id
    void deleteRoleTypeById(Long id);

    // Method for creating new Role Type
    void createRoleType(RoleType role);

    // Method for updating Role Type
    void updateRoleType(Long id, RoleType roleType);

    Set<RoleType> findRoleTypeByKeyword(String keyword, Pageable pageable);

    int countFilteredRoleTypes(String keyword);

}

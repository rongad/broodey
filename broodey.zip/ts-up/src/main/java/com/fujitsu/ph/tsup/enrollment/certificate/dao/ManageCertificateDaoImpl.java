/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.enrollment.certificate.dao;

import java.time.ZoneId;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.enrollment.certificate.model.ManageCertificate;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

//=======================================================
//Project Name: Training Sign Up
//Class Name: ManageCertificateDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 11/08/2021 | WS) k.mutia  | Created
//=======================================================

/**
*
* @author k.mutia
*
*/
@Repository
public class ManageCertificateDaoImpl implements ManageCertificateDao{ 

    // Call NamedParameterJdbcTemplate
    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Method for deleting Certificate by Id
     */
    @Override
    public Boolean deleteCertificateById(Long id) {
        String query = "DELETE FROM CERTIFICATE_UPLOAD WHERE ID =" + id;
        SqlParameterSource namedParameters = new MapSqlParameterSource("id", id);
        int queryResult = template.update(query, namedParameters);

        if(queryResult != 0){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Method for updating Certificate
     */
    @Override
    public Boolean updateCertificate(Certificate certificate) {
        String query = "UPDATE CERTIFICATE_UPLOAD SET " + "CERTIFICATE = :certificate, "
                + "UPLOAD_DATE = :uploadDate, " + "FILEDOWNLOADURI = :fileDownloadUri "
                + "WHERE COURSE_ID = :courseId";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("certificate", certificate.getCertificate())
                .addValue("uploadDate",
                        certificate.getUploadDate().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                .addValue("fileDownloadUri", certificate.getFileDownloadUri())
                .addValue("courseId", certificate.getCourseId());

        int queryResult  = template.update(query, sqlParameterSource);

        if(queryResult != 0){
            return true;
        }else{
            return false;
        }

    }
    
    /**
     * Method for downloading Certificate by userId and courseId
     */
    @Override
    public String getCertificateDownloadUri(Long userId, Long courseId) {
        String query = "SELECT filedownloaduri from tsup.certificate_upload"
                + " where upload_date =(select max(upload_date)" + " from tsup.certificate_upload"
                + " where course_id = :course_id and employee_id = :employee_id)";

        try {
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("course_id", courseId).addValue("employee_id", userId);

            return template.queryForObject(query, sqlParameterSource, String.class);

        } catch (EmptyResultDataAccessException e) {
            return null;
        }

    }

    // Method for find all Certificates base on Pageable object provided
    @Override
    public Set<ManageCertificate> loadAllCertificates(Pageable pageable) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String query = "SELECT CU.ID AS \"CU.ID\", " + "C.NAME AS \"C.NAME\", "
                + "CU.CERTIFICATE AS \"CU.CERTIFICATE\", " + "CU.EMPLOYEE_ID AS \"CU.EMPLOYEE_ID\", "
                + "CU.COURSE_ID AS \"CU.COURSE_ID\", " + "CU.UPLOAD_DATE AS \"CU.UPLOAD_DATE\", "
                + "CU.FILEDOWNLOADURI AS \"CU.FILEDOWNLOADURI\" " + "FROM CERTIFICATE_UPLOAD CU "
                + "JOIN COURSE C " + "ON CU.COURSE_ID = C.ID " + "WHERE CU.EMPLOYEE_ID = :employeeId "
                + "ORDER BY CU.UPLOAD_DATE DESC " + "LIMIT " + pageable.getPageSize() + " OFFSET "
                + pageable.getOffset();

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("employeeId",
                user.getId());

        List<ManageCertificate> certificateList = template.query(query, sqlParameterSource,
                new ManageCertificateRowMapper());
        return certificateList.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(certificateList);
    }

    // Method for counting certificate
    @Override
    public int countCertificates() {
        return jdbcTemplate.queryForObject("SELECT count(*) FROM certificate_upload", Integer.class);
    }
    
}

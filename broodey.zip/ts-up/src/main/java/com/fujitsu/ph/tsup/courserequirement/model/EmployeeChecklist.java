/*
*Copyright (C) 2020 FUJITSU LIMITED All rights reserved. 
 */
package com.fujitsu.ph.tsup.courserequirement.model;


/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : CourseChecklist
 * Class Name   : EmployeeChecklist.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * 0.02    | 2021/10/28 | WS) e.delosreyes      | Updated parameterized constructor
 * 0.03    | 2021/11/10 | WS) e.delosreyes      | Renamed isAccomplished to is_Accomplished
 * 0.04    | 2021/10/28 | WS) je.subelario      | Revised Comments
 * 0.05    | 2021/10/28 | WS) v.tallo           | Revised Comments
 * ===================================================================================================
 */

 /**
 * <pre>
 * The model for Employee Checklist
 * 
 * <pre>
 * 
 * @version 0.05
 * @author v.tallo
 */

public class EmployeeChecklist {
	private Integer id;
	private Employee employee;
	private CourseChecklist courseChecklist;
	private boolean is_Accomplished;
	private CourseParticipant courseParticipant;
	private CourseSchedule courseSchedule;

	/**
	 * @param id
	 * @param employee
	 * @param courseChecklist
	 * @param isAccomplished
	 */
	public EmployeeChecklist(Integer id, CourseChecklist courseChecklist, boolean isAccomplished, Employee employee) {
		this.id = id;
		this.courseChecklist = courseChecklist;
		this.is_Accomplished = isAccomplished;
		this.employee = employee;
	}
	
	
	
	
	/**
	 * Default Constructor
	 */
	public EmployeeChecklist() {
	}




	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the employee
	 */
	public Employee getEmployee() {
		return employee;
	}
	/**
	 * @param employee the employee to set
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	/**
	 * @return the courseChecklist
	 */
	public CourseChecklist getCourseChecklist() {
		return courseChecklist;
	}
	/**
	 * @param courseChecklist the courseChecklist to set
	 */
	public void setCourseChecklist(CourseChecklist courseChecklist) {
		this.courseChecklist = courseChecklist;
	}
	/**
	 * @return the isAccomplished
	 */
	public boolean getIs_Accomplished() {
		return is_Accomplished;
	}
	/**
	 * @param isAccomplished the isAccomplished to set
	 */
	public void setIs_Accomplished(boolean isAccomplished) {
		this.is_Accomplished = isAccomplished;
	}




	public CourseParticipant getCourseParticipant() {
		return courseParticipant;
	}




	public void setCourseParticipant(CourseParticipant courseParticipant) {
		this.courseParticipant = courseParticipant;
	}




	public CourseSchedule getCourseSchedule() {
		return courseSchedule;
	}




	public void setCourseSchedule(CourseSchedule courseSchedule) {
		this.courseSchedule = courseSchedule;
	}
	
	
}

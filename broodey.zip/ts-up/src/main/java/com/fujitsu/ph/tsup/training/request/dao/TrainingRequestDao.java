package com.fujitsu.ph.tsup.training.request.dao;

import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestForm;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

//=======================================================
//Project Name: Training Sign Up
//Class Name: TrainingRequestDao.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 07/12/2021 | WS) L.Celoso    | New Creation
//0.02    | 08/06/2021 | WS) L.Celoso    | Update
//=======================================================

/**
* <pre>
* Training Request Dao	
* 
* <pre>
* 
* @version 0.01
* @author L.Celoso
*/
public interface TrainingRequestDao {

	 /**
     * Saves the training request
     * @param courseSchedule
     */
	void saveTrainingRequest(TrainingRequestForm trainingRequestForm);
	
	 /**
     * Get all training request
     */
	Set<TrainingRequest> getAllTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm, Pageable pageable);

	int checkToCancelTrainingRequest(Long id);
	
	void cancelTrainingRequest(Long id);

	 /**
    * Saves the training request
    * @param courseSchedule
    */
	void updateTrainingRequest(TrainingRequestForm trainingRequestForm);

	void changeTrainingRequestStatus(Long id, String status, String remarks);

	void moveToArchive(Long id);
	
	int countTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm);
}

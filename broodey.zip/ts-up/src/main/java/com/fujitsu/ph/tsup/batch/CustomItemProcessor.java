/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.batch;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

import com.fujitsu.ph.tsup.authz.autoregister.model.AutoRegistration;
// =======================================================
// $Id:
// Project Name: Training Sign Up
// Class Name: CustomItemProcessor.java
//
// <<Modification History>>
// Version | Date | Updated by | Content
// --------+------------+------------------+---------------
// 0.01 | ----/--/-- | S.Anderson | Created
// =======================================================

/**
 * CustomItemProcessor class
 * 
 * @author S.Anderson (New Creation by: S.Anderson)
 * @author S.Anderson
 * @version 0.01
 */

public class CustomItemProcessor implements ItemProcessor<AutoRegistration, AutoRegistration> {

    /**
     * <pre>
     * Call requiredMonths from application-dev.properties
     *
     * <pre>
     */
    @Value("${employee.requiredMonths}")
    private int requiredMonths;
    
    

    /**
     * <pre>
     * Validates if the joining date >= 3 and Set status to existing if condition is true
     *
     * <pre>
     *
     * @param AutoRegistration autoRegistration
     * @return autoRegistration
     */
    @Override
    public AutoRegistration process(AutoRegistration autoRegistration) throws Exception {

        Date joiningDate = autoRegistration.getJoiningDate();
        LocalDate joiningDateToday = LocalDate.parse(new SimpleDateFormat("yyyy-MM-dd").format(joiningDate));
        LocalDate currentDate = LocalDate.now();
        Period p = Period.between(joiningDateToday, currentDate);
        int period = p.getMonths();

        if (period >= requiredMonths) {
            autoRegistration.status = "Existing";
        }

        return autoRegistration;
    }
}


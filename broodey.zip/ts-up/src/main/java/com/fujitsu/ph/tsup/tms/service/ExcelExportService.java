package com.fujitsu.ph.tsup.tms.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.tms.model.Completed;
import com.fujitsu.ph.tsup.tms.model.Course;
import com.fujitsu.ph.tsup.tms.model.Employee;
import com.fujitsu.ph.tsup.tms.model.NotRegistered;

@Service
public class ExcelExportService {

	public void export(HttpServletResponse response, List<NotRegistered> dataList, String filename) throws IOException {
		try (Workbook workbook = WorkbookFactory.create(true)) {

			Sheet sheet = workbook.createSheet("Data");
			int rowCount = 0;
			Row headerRow = sheet.createRow(rowCount++);
			headerRow.createCell(0).setCellValue("Employee Name");
			headerRow.createCell(1).setCellValue("Employee Status");
			headerRow.createCell(2).setCellValue("Manager");
			headerRow.createCell(3).setCellValue("Course Title	");
			headerRow.createCell(4).setCellValue("Target Completion");

			for (NotRegistered nrEmployee : dataList) {
				Row row = sheet.createRow(rowCount++);
				row.createCell(0).setCellValue(nrEmployee.getEmployeeName());
				row.createCell(1).setCellValue(nrEmployee.getEmployeeStatus());
				row.createCell(2).setCellValue(nrEmployee.getManager());
				row.createCell(3).setCellValue(nrEmployee.getCourseTitle());
				row.createCell(4).setCellValue(nrEmployee.getTargetCompletion());
			}

			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.setHeader("Content-Disposition", "attachment;filename=" + filename);
			try (ServletOutputStream outputStream = response.getOutputStream()) {
				workbook.write(outputStream);
			}
		}

	}

	public void exportMasterlist(HttpServletResponse response, List<Course> dataList,List<Employee> employees, String filename)
			throws IOException {
		final String PREFIX_ROLE = "JDU SSS ";
		final String MANAGERS_SHEET = "Managers Lists";
		final String[] COMMON_HEADERS = { "Employee Name", "Email", "Joining Date", "Current Engagement", "Role",
				"Employment Status", "Course ID", "Course Name" , "Course Status", "Course Acquired/Started",
				"Course Completed" ,"Course Origin"};
		;

		List<String> uniqueRoles = new ArrayList<>();
		List<Employee> uniqueEmployeeManagers = new ArrayList<>();
		// deduct by 6 since the last is not important for managers lists
		int managerColumnHeaderDecrease = 6;
		int defaultSheetZoom = 70;

		uniqueRoles = dataList.stream().map(course -> course.getCourseEmployeeAssigned().getEmployeeRole()).distinct()
				.collect(Collectors.toList());

		uniqueEmployeeManagers = employees.stream().filter(
				employee -> employee.getEmployeeRole().toLowerCase().equals("manager"))
				.collect(Collectors.toList());

		try (Workbook workbook = WorkbookFactory.create(true)) {

			Sheet managerSheet = workbook.createSheet(MANAGERS_SHEET);
			Row managerRowheader = managerSheet.createRow(0);

			
			for (int i = 0; i < COMMON_HEADERS.length-managerColumnHeaderDecrease; i++) {
				managerRowheader.createCell(i).setCellValue(COMMON_HEADERS[i]);
			}

			// Merge the cells with styles
			Font font = workbook.createFont();
			font.setFontHeightInPoints((short) 25); // Set font size to 12 points
			font.setBold(true);

			CellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setVerticalAlignment(VerticalAlignment.CENTER);
			style.setIndention((short) 2);
			style.setFont(font);
			


			CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 10, 0, 40);
			managerSheet.addMergedRegion(cellRangeAddress);
			managerRowheader.createCell(0).setCellValue(MANAGERS_SHEET);
			managerRowheader.getCell(0).setCellStyle(style);

			style = workbook.createCellStyle();
			style.setFillForegroundColor(IndexedColors.TURQUOISE.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setAlignment(HorizontalAlignment.CENTER);
			
			managerRowheader = managerSheet.createRow(11);
			
			// deduct by 5 since the last is not important for managers lists
			for (int i = 0; i < COMMON_HEADERS.length-managerColumnHeaderDecrease; i++) {
				
				font = workbook.createFont();
				font.setFontHeightInPoints((short) 12); // Set font size to 12 points
				font.setBold(true);
				style.setFont(font);
				managerRowheader.createCell(i).setCellValue(COMMON_HEADERS[i]);
				managerRowheader.getCell(i).setCellStyle(style);
				managerSheet.autoSizeColumn(i);
			}
			managerSheet.createFreezePane(COMMON_HEADERS.length-managerColumnHeaderDecrease, 12);
			managerSheet.setAutoFilter(new CellRangeAddress(11, 11, 0, COMMON_HEADERS.length - 6));
			managerSheet.setZoom(defaultSheetZoom);
			
			List<Integer> uniqueRolesCounter = new ArrayList<>();
			for (String role : uniqueRoles) {

				// To skip header when incrementing it is set to 1
				uniqueRolesCounter.add(12);
				Sheet workSheet = workbook.createSheet(PREFIX_ROLE + role);

				Row rowHeader = workSheet.createRow(0);

				// Merge the cells with styles
				font = workbook.createFont();
				font.setFontHeightInPoints((short) 25); // Set font size to 12 points
				font.setBold(true);

				style = workbook.createCellStyle();
				style.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
				style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				style.setVerticalAlignment(VerticalAlignment.CENTER);
				style.setIndention((short) 2);
				style.setFont(font);

				cellRangeAddress = new CellRangeAddress(0, 10, 0, 40);
				workSheet.addMergedRegion(cellRangeAddress);

				rowHeader.createCell(0).setCellValue(PREFIX_ROLE + role);
				rowHeader.getCell(0).setCellStyle(style);

				style = workbook.createCellStyle();
				style.setFillForegroundColor(IndexedColors.TURQUOISE.getIndex());
				style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				style.setAlignment(HorizontalAlignment.CENTER);

				rowHeader = workSheet.createRow(11);

				for (int i = 0; i < COMMON_HEADERS.length; i++) {
					font = workbook.createFont();
					font.setFontHeightInPoints((short) 12); // Set font size to 12 points
					font.setBold(true);
					style.setFont(font);
					rowHeader.createCell(i).setCellValue(COMMON_HEADERS[i]);
					rowHeader.getCell(i).setCellStyle(style);
					workSheet.autoSizeColumn(i);
				}
				workSheet.createFreezePane(COMMON_HEADERS.length, 12);
				workSheet.setAutoFilter(new CellRangeAddress(11, 11, 0, COMMON_HEADERS.length - 1));
				workSheet.setZoom(defaultSheetZoom);

			}
			int managerRowCount = 12;
			for(Employee manager : uniqueEmployeeManagers) {
				if (manager.getEmployeeRole().toLowerCase().equals("manager")) {
					Row rowManager = managerSheet.createRow(managerRowCount++);
					rowManager.createCell(0).setCellValue(manager.getEmployeeName());
					rowManager.createCell(1)
							.setCellValue(manager.getEmployeeStatus());
					rowManager.createCell(2)
							.setCellValue(manager.getEmployeeJoinDate().toString());
					rowManager.createCell(3).setCellValue("SSS");
					rowManager.createCell(4).setCellValue(manager.getEmployeeRole());
					rowManager.createCell(5)
							.setCellValue(manager.getEmployeeStatus());
					
					style = workbook.createCellStyle();
					if (managerRowCount % 2 == 0) {
						style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
					} else {
						style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
					}
					style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
					style.setAlignment(HorizontalAlignment.CENTER);
					
					// deduct by 5 since the last is not important for managers lists
					for (int i = 0; i < COMMON_HEADERS.length-managerColumnHeaderDecrease ; i++) {
						if (rowManager != null) {
							rowManager.getCell(i).setCellStyle(style);
						}
					}
				}
			}
			
			for (Course employeeCourse : dataList) {
				int rowCount = uniqueRolesCounter
						.get(uniqueRoles.indexOf(employeeCourse.getCourseEmployeeAssigned().getEmployeeRole()));
				Sheet sheet = workbook
						.getSheet(PREFIX_ROLE + employeeCourse.getCourseEmployeeAssigned().getEmployeeRole());

				style = workbook.createCellStyle();
				if (rowCount % 2 == 0) {
					style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
				} else {
					style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
				}
				style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				style.setAlignment(HorizontalAlignment.CENTER);

				Row row = sheet.createRow(rowCount++);

				row.createCell(0).setCellValue(employeeCourse.getCourseEmployeeAssigned().getEmployeeName());
				row.createCell(1).setCellValue(employeeCourse.getCourseEmployeeAssigned().getEmployeeEmail());
				row.createCell(2)
						.setCellValue(employeeCourse.getCourseEmployeeAssigned().getEmployeeJoinDate().toString());
				row.createCell(3).setCellValue("SSS");
				row.createCell(4).setCellValue(employeeCourse.getCourseEmployeeAssigned().getEmployeeRole());
				row.createCell(5).setCellValue(employeeCourse.getCourseEmployeeAssigned().getEmployeeStatus());
				row.createCell(6).setCellValue(employeeCourse.getCourseID());
				row.createCell(7).setCellValue(employeeCourse.getCourseName());
				row.createCell(8).setCellValue(employeeCourse.getCourseStatus());
				if(employeeCourse.getCourseStatus().toLowerCase().equals("completed")) {
					Date acquiredDate = employeeCourse.getCourseAcquiredDate();
					Date assignedDate = employeeCourse.getCourseAssignedDate();
					Date completedDate = employeeCourse.getCourseCompletedDate();
					row.createCell(9).setCellValue(acquiredDate != null ? acquiredDate.toString() : "");
					row.createCell(10).setCellValue(completedDate !=null ? completedDate.toString() : "");
				}else {
					row.createCell(9).setCellValue("");
					row.createCell(10).setCellValue("");
					
				}
				row.createCell(11).setCellValue(employeeCourse.getCourseOrigin());


				for (int i = 0; i < COMMON_HEADERS.length; i++) {
					row.getCell(i).setCellStyle(style);
				}
				uniqueRolesCounter.set(
						uniqueRoles.indexOf(employeeCourse.getCourseEmployeeAssigned().getEmployeeRole()), rowCount);
			}

			for (String role : uniqueRoles) {
				Sheet sheet = workbook.getSheet(PREFIX_ROLE + role);
				int counter = uniqueRolesCounter.get(uniqueRoles.indexOf(role));
				for (int i = 0; i < COMMON_HEADERS.length; i++) {
					sheet.autoSizeColumn(i);
				}
				sheet.createFreezePane(COMMON_HEADERS.length, 12);
				sheet.setAutoFilter(new CellRangeAddress(11, 11, 0, COMMON_HEADERS.length - 1));
				sheet.setZoom(defaultSheetZoom);
			}
			for (int i = 0; i < COMMON_HEADERS.length; i++) {
				workbook.getSheet(MANAGERS_SHEET).autoSizeColumn(i);
			}
			workbook.setActiveSheet(1);

			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.setHeader("Content-Disposition", "attachment;filename=" + filename);
			try (ServletOutputStream outputStream = response.getOutputStream()) {
				workbook.write(outputStream);
			}

		}

	}

	public void exportCompleted(HttpServletResponse response, List<Completed> dataList, String filename)
			throws IOException {
		try (Workbook workbook = WorkbookFactory.create(true)) {

			Sheet sheet = workbook.createSheet("Data");
			int rowCount = 0;
			Row headerRow = sheet.createRow(rowCount++);
			headerRow.createCell(0).setCellValue("Employee Name");
			headerRow.createCell(1).setCellValue("Employee Status");
			headerRow.createCell(2).setCellValue("Manager");
			headerRow.createCell(3).setCellValue("Course Title	");
			headerRow.createCell(4).setCellValue("Target Completion");

			for (Completed cEmployee : dataList) {
				Row row = sheet.createRow(rowCount++);
				row.createCell(0).setCellValue(cEmployee.getEmployeeName());
				row.createCell(1).setCellValue(cEmployee.getEmployeeStatus());
				row.createCell(2).setCellValue(cEmployee.getManager());
				row.createCell(3).setCellValue(cEmployee.getCourseTitle());
				row.createCell(4).setCellValue(cEmployee.getTargetCompletion());
			}

			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.setHeader("Content-Disposition", "attachment;filename=" + filename);
			try (ServletOutputStream outputStream = response.getOutputStream()) {
				workbook.write(outputStream);
			}
		}

	}
}

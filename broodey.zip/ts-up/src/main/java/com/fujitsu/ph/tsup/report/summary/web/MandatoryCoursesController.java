/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
// ==================================================================================================
// Project Name : Training Sign Up
// System Name : MandatoryCoursesDaoImpl
// Class Name : MandatoryCoursesDaoImpl.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// ---------+------------+-----------------------+---------------------------------------------------
// 1.0.0 | ----/--/-- | WS)-.- | New Creation
// 1.0.1 | 2021/07/12 | WS)RL.Naval | Updated
// 1.0.2 | 2021/08/02 | WS)RL.Naval | Updated
// 1.0.3 | 2021/10/13 | WS)R.Buot | Updated
// 1.0.4 | 2021/10/14 | WS)D.Dinglasan | Updated
// ==================================================================================================
package com.fujitsu.ph.tsup.report.summary.web;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fujitsu.ph.tsup.report.summary.model.MandatoryCourses;
import com.fujitsu.ph.tsup.report.summary.service.MandatoryCoursesService;

/**
 * The controller of mandatory courses
 * 
 * @author j.zamora (New Creation by: j.zamora)
 * @author rl.naval
 * @author d.dinglasan
 * @author r.buot
 * @version Revision: 0.04 Date: 2021-10-12 r.buot
 */

@Controller
@RequestMapping("mandatoryCourses")
public class MandatoryCoursesController {
    @Autowired
    private MandatoryCoursesService mandatoryCoursesService;
    /**
     * loads the summaryMandatoryCourses view
     * 
     * @return string
     */
    @GetMapping("load")
    public String loadGenerateReport(Model model) {

        LocalDateTime reportDate = LocalDateTime.now();

        Set<MandatoryCourses> findMandatoryCourse = mandatoryCoursesService.getMandatoryCourses();
        Comparator<MandatoryCourses> coursecomparator = Comparator.comparing(MandatoryCourses::getName);
        List<MandatoryCourses> mandatoryCourseList = findMandatoryCourse.stream()
                .sorted(coursecomparator)
                .collect(Collectors.toList());

        model.addAttribute("mandatoryCourseList", mandatoryCourseList);
        model.addAttribute("startTime", reportDate);

        // Set default display values upon loading
        model.addAttribute("totalNumberOfJduMembers", 0L);
        model.addAttribute("totalNumberOfEnrolledJduMembers", 0L);
        model.addAttribute("totalNumberOfCompletion", 0L);
        model.addAttribute("totalNumberOfCompletionLastWeek", 0L);
        model.addAttribute("percentageCompletion", 0.0);
        model.addAttribute("percentageCompletionLastWeek", 0.0);

        return "reports/summaryMandatoryCourses";
    }

    // 1.0.4 2021/10/13 WS) D.Dinglasan Del_Start
    // Not being used
    /**
     * Passes the data to summaryMandatoryCourses
     * 
     * @param reportDate
     * @param model
     * @return string
     */
    // @GetMapping("/load/getMandatoryCourses")
    // public String generateMandatoryCourses(@RequestParam(value = "startDateTime") String reportDate,
    // Model model) {
    //
    // LocalDateTime newReportDate = LocalDateTime.parse(reportDate);
    //
    // Set<MandatoryCourses> mandatoryCourses = mandatoryCoursesService.getMandatoryCourses(newReportDate);
    //
    // model.addAttribute("mandatoryCourses", mandatoryCourses);
    //
    // return "reports/summaryMandatoryCourses";
    //
    // }
    // 1.0.4 2021/10/13 WS) D.Dinglasan Del_End

    /**
     * Passes the data to summaryMandatoryCourses when view button is pressed
     * 
     * @param reportDate
     * @param course inputCourse
     * @param model
     * @return string
     */
    @GetMapping("/load/summary")
    public String viewMandatoryCoursesReports(@RequestParam(value = "hReportDate") String reportDate,
            @RequestParam(value = "hCourse") String course, Model model) {

        LocalDateTime localReportDate = LocalDateTime.parse(reportDate);

        Set<MandatoryCourses> findMandatoryCourse = mandatoryCoursesService.getMandatoryCourses();
        Comparator<MandatoryCourses> coursecomparator = Comparator.comparing(MandatoryCourses::getName);
        List<MandatoryCourses> mandatoryCourseList = findMandatoryCourse.stream()
                .sorted(coursecomparator)
                .collect(Collectors.toList());

        model.addAttribute("mandatoryCourseList", mandatoryCourseList);
        model.addAttribute("startTime", reportDate);

        model.addAttribute("totalNumberOfJduMembers", mandatoryCoursesService.getTotalNumberOfJduMembers());
        model.addAttribute("totalNumberOfEnrolledJduMembers",
                mandatoryCoursesService.getTotalNumberOfEnrolledJdu(course));
        model.addAttribute("totalNumberOfCompletion",
                mandatoryCoursesService.getTotalNumberOfCompletion(course, localReportDate));
        model.addAttribute("totalNumberOfCompletionLastWeek",
                mandatoryCoursesService.getTotalNumberOfCompletionLastWeek(course, localReportDate));
        model.addAttribute("percentageCompletion", mandatoryCoursesService.getCompletionPercentage("TODAY"));
        model.addAttribute("percentageCompletionLastWeek",
                mandatoryCoursesService.getCompletionPercentage("LAST WEEK"));

        return "reports/summaryMandatoryCourses";
    }
}

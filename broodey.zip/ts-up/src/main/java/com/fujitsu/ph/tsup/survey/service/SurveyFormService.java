package com.fujitsu.ph.tsup.survey.service;

import com.fujitsu.ph.tsup.survey.domain.Survey;

//==================================================================================================
//$Id:PR16$
//Project Name : Training Sign up
//System Name  : Survey Form Process 
//Class Name   : SurveyFormService.java
//
//<<Modification History>>
//Version | Date       | Updated By                                       | Content
//--------+------------+--------------------------------------------------+-------------------------
//0.01    | 08/12/2021 | WS) J.Gabalones                                  | New Creation
//==================================================================================================
/**
* <pre>
* It is the interface of survey form service
* In this interface, it consists of the method required for the initial setting of the database
* </pre>
* 
* @version 0.01
* @author j.gabalones
*
*/
 
public interface SurveyFormService {
    
    /**
     * <pre>
     * 
     * Creates survey form 
     * 
     * </pre>
     * 
     * @param survey
     */
    void createSurvey(Survey survey);

}

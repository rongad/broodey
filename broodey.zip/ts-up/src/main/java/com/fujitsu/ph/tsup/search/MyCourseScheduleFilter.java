/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.search;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Course Management
// Class Name : MyCourseScheduleFilter.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/08/06 | WS) km.sevilla | Initial Version
// 0.02 | 2021/08/23 | WS) km.sevilla | Updated
// 0.03 | 2021/09/13 | WS) km.sevilla | Updated
// ==================================================================================================

public class MyCourseScheduleFilter {
    private String courseName;
    private String courseCategory;
    private String instructorName;
    private String venueName;
    private String memberRole;

    public MyCourseScheduleFilter() {
        super();
    }

    /* From Date and Time */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime fromDateTime;

    /* To Date and Time */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime toDateTime;

    /** From Date and Time Getter */
    public ZonedDateTime getFromDateTime() {
        return fromDateTime;
    }

    /** From Date and Time Setter */
    public void setFromDateTime(ZonedDateTime fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    /** To Date and Time Getter */
    public ZonedDateTime getToDateTime() {
        return toDateTime;
    }

    /** To Date and Time Setter */
    public void setToDateTime(ZonedDateTime toDateTime) {
        this.toDateTime = toDateTime;
    }

    /**
     * @return the courseName
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * @return the courseCategory
     */
    public String getCourseCategory() {
        return courseCategory;
    }

    /**
     * @return the instructorName
     */
    public String getInstructorName() {
        return instructorName;
    }

    /**
     * @return the venueName
     */
    public String getVenueName() {
        return venueName;
    }

    /**
     * @return the memberRole
     */
    public String getMemberRole() {
        return memberRole;
    }
    
    /**
     * @param courseName the courseName to set
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    /**
     * @param courseCategory the courseCategory to set
     */
    public void setCourseCategory(String courseCategory) {
        this.courseCategory = courseCategory;
    }

    /**
     * @param instructorName the instructorName to set
     */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    /**
     * @param venueName the venueName to set
     */
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    /**
     * @param memberRole the memberRole to set
     */
    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }
    
    // Method for checking if the search is empty
    public boolean isSearchEmpty() {
        return StringUtils.isAllBlank(getCourseName(), getCourseCategory(), getMemberRole())
                && (Objects.isNull(getToDateTime()) && Objects.isNull(getFromDateTime()));
    }

    public OffsetDateTime getFromDateTimeTimezoneOnUTC() {
        if (Objects.isNull(fromDateTime)) {
            return null;
        }
        return fromDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime();
    }

    public OffsetDateTime getToDateTimeTimezoneOnUTC() {
        if (Objects.isNull(toDateTime)) {
            return null;
        }
        return toDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime();
    }

    @Override
    public String toString() {
        return "CourseSearchFilter [courseName=" + courseName + ", courseCategory=" + courseCategory
                + ", instructorName=" + instructorName + ", venueName=" + venueName + ", memberRole=" + memberRole + "]";
    }

}

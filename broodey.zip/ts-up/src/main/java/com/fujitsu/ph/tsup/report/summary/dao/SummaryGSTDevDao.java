/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.ZonedDateTime;
import java.util.Set;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for Dev
//Class Name   : SummaryGSTDevDao.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    |    ---     | WS) r.rivero          | Initial Version
//0.01    |    ---     | WS) g.cabiling        | Initial Version
//0.02    | 2021/06/14 | WS) m.padaca          | Updated
//0.03    | 2021/10/11 | WS) r.buot            | Updated
//==================================================================================================
/**
 * <pre>
 * The interface of G3CC standardization training for dev dao
 * </pre>
 * 
 * @version 0.02
 * @author r.rivero
 * @author g.cabiling
 * @author m.padaca
 */
public interface SummaryGSTDevDao {

    /**
     * <pre>
     * Find All Courses By Category ID
     * </pre>
     * @return courses
     */
    Set<Long> findAllCoursesByCategoryId();

    /**
     * <pre>
     * Find All JDU Dev
     * </pre>
     * @return employee
     */
    Set<Long> findAllJDUDev();

    /**
     * <pre>
     * Find All JDU Dev Last Week
     * </pre>
     * @return
     */
    int findAllJDUDevLastWeek();

    /**
     * <pre>
     * Find All JDU Existing Members
     * </pre>
     * @return
     */
    int findAllJDUExisitingMembers();

    /**
     * <pre>
     * Find All JDU New Members
     * </pre>
     * @return
     */
    int findAllJDUNewMembers();

    
    /**
     * <pre>
     * Find Total Course of JDU Dev Finished
     * </pre>
     * @param course_id
     * @param participant_id
     * @param reportDate
     * @return no_of_course
     */
    int findTotalCoursePerEmployee(Set<Long> course_id, Long participant_id, ZonedDateTime reportDate);

    /**
     * <pre>
     * Find Total Course of JDU Dev Finished Last Week
     * </pre>
     * @param reportDate
     * @param course_id
     * @param participant_id
     * @return no_of_course
     */
    int findTotalCoursePerEmployeeLastWeek(ZonedDateTime reportDate, Set<Long> course_id,
            Long participant_id);

}

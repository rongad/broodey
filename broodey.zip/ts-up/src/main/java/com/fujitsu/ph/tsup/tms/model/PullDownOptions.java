package com.fujitsu.ph.tsup.tms.model;

import java.util.List;

public class PullDownOptions {
	private List<Object> listManagers;
	private List<Object> listCourses;
	
	public List<Object> getListManagers() {
		return listManagers;
	}
	public void setListManagers(List<Object> listManagers) {
		this.listManagers = listManagers;
	}
	public List<Object> getListCourses() {
		return listCourses;
	}
	public void setListCourses(List<Object> listCourses) {
		this.listCourses = listCourses;
	}
	
	

}

/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.roletype.web;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.config.Task;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.roletype.domain.RoleType;
import com.fujitsu.ph.tsup.roletype.model.RoleTypeForm;
import com.fujitsu.ph.tsup.roletype.service.RoleTypeService;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Role Type Management
// Class Name : RoleTypeController.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/02/05 | WS) rl.naval          | Initial Version
//0.02    | 2021/02/15 | WS) rl.naval          | Updated
//0.03    | 2021/02/17 | WS) c.sinda           | Updated
//0.04    | 2021/02/18 | WS) c.rondina         | Updated
//0.05    | 2021/02/21 | WS) j.sayaboc         | Updated
//0.06    | 2021/02/24 | WS) p.cui             | Updated
//0.07    | 2021/02/26 | WS) c.sinda           | Updated
//0.08    | 2021/03/11 | WS) p.cui             | Updated
//0.09    | 2021/03/11 | WS) j.sayaboc         | Updated
//0.10    | 2021/03/18 | WS) rl.naval          | Updated
//0.11	  | 2021/06/08 | WS) r.gaquit		   | Updated
//0.12	  | 2021/07/12 | WS) r.gaquit		   | Updated
//0.13    | 2021/09/08 | WS) d.dinglasan       | Updated
//0.13    | 2021/08/31 | WS) dw.cardenas       | Updated
//0.14    | 2021/12/19 | WS) ep.delosreyes     | Updated Post for Create
// ==================================================================================================
/**
 * <pre>
 * This is the implementation of Role Type Controller.
 * </pre>
 * 
 * @version 0.12
 * @author rl.naval
 * @author c.sinda
 * @author c.rondina
 * @author p.cui
 * @author j.sayaboc
 * @author r.gaquit
 */
@Controller
@RequestMapping("/roletype")
public class RoleTypeController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RoleTypeController.class);

    @Autowired
    private RoleTypeService roleTypeService;

    /**
     * Load the Role Type on the screen
     * 
     * @param model Model
     * @return View
     */
    @GetMapping("/load")
    public String manageRoleType(Model model, @RequestParam("page") Optional<Integer> page,
			@RequestParam("size") Optional<Integer> size, 
			@RequestParam("sortField") Optional<String> sortField,
			@RequestParam("sortDir") Optional<String> sortDir) {
    	
        int currentPage = page.orElse(Paging.DEFAULT_CURRENT_PAGE_NO);
        int pageSize = size.orElse(Paging.DEFAULT_PAGE_SIZE);

        String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("roleType");
        String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");

        Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);

        Pageable pageable = PageRequest.of(currentPage - 1, pageSize, sort);
        Page<RoleType> paginatedRoleType = roleTypeService.loadAllRoleType(pageable);
        Paged<RoleType> pagedRoleType = new Paged<>(paginatedRoleType, Paging
                .of(paginatedRoleType.getTotalPages(), pageable.getPageNumber() + 1, pageable.getPageSize()));

        // model.addAttribute("reverseSortDir", sortVal); // Removed 09.23.2021
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("pagedRoleType", pagedRoleType);

        return "roletype-management/roleTypeView";

    }

    /**
     * Method for getting role type id to delete
     * 
     * @param id Role Type id
     * @param form RoleType Form
     * @param bindingResult Binding Result
     * @param model Model
     * @return View
     */
    @GetMapping("/{roleId}/delete")
    public String showDeleteRoleTypeForm(@RequestParam(value = "roleIdInput") Long id, RoleTypeForm form,
            BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "redirect:/roletype/load?roleId=" + id + "#confirmModal";
        }

        // Set Value for RoleType Object
        RoleType role = roleTypeService.findRoleById(id);

        // Set Value for RoleTypeForm
        form.setId(role.getId());
        form.setRolename(role.getRolename());
        form.setRoledesc(role.getRoledesc());
        model.addAttribute("deleteRoleTypeForm", form);
        return "redirect:/roletype/load?roleId=" + id + "#confirmModal";
    }

    /**
     * Method for deleting role with the given id
     * 
     * @param id role id
     * @param redirectAttributes RedirectAttributes
     * @param model Model
     * @return View
     */
    @PostMapping("/{roleId}/delete")
    public String submitDeleteRoleTypeform(@PathVariable("roleId") Long id,
            RedirectAttributes redirectAttributes, Model model) {

        // Call deleteRoleTypeById() method
        roleTypeService.deleteRoleTypeById(id);
        redirectAttributes.addFlashAttribute("successMessage", "You have successfully deleted this role type");
        return "redirect:/roletype/load#successModal";
    }

    /**
     * Method for searching role type
     * 
     * @param page
     * @param searchRoleName Role name
     * @param model Model
     * @return View
     */
    @GetMapping("/search")
    public String submitSearchRoleTypeForm(Model model, @RequestParam("searchRole") String searchRole,
            @RequestParam("page") Optional<Integer> page, @RequestParam("size") Optional<Integer> size,
            @RequestParam("sortField") Optional<String> sortFieldParam,
            @RequestParam("sortDir") Optional<String> sortDirParam) {
        if (searchRole.isEmpty()) {
            return "redirect:/roletype/load";
        }

        try {
            int currentPage = page.orElse(Paging.DEFAULT_CURRENT_PAGE_NO);
            int pageSize = size.orElse(Paging.DEFAULT_PAGE_SIZE);

            String sortField = sortFieldParam.filter(str -> !str.isEmpty()).orElse("roleType");
            String sortDir = sortDirParam.filter(str -> !str.isEmpty()).orElse("asc");

            Sort sort = Sort.by(Direction.valueOf(sortDir.toUpperCase()), sortField);
            Pageable pageable = PageRequest.of(currentPage - 1, pageSize, sort);

            Page<RoleType> paginatedRoleType = roleTypeService.findRoleTypeByKeyword(searchRole, pageable);
            Paged<RoleType> pagedRoleType = new Paged<>(paginatedRoleType, Paging.of(
                    paginatedRoleType.getTotalPages(), pageable.getPageNumber() + 1, pageable.getPageSize()));

            model.addAttribute("searchRole", searchRole);
            model.addAttribute("currentPage", currentPage);
            model.addAttribute("pagedRoleType", pagedRoleType);
        } catch (RuntimeException e) {
            LOGGER.error(e.getMessage(), e.getCause());
        }

        return "roletype-management/roleTypeView";
    }

    /**
     * Create the role type. Method = GET
     * 
     * @param model Model
     * @return roleTypeForm and view
     */
    @GetMapping("/create")
    public String showCreateRoleTypeForm(Model model) {
        Set<RoleType> roletype = roleTypeService.loadAllRoleType();
        List<RoleType> roletypeList = roletype.stream().collect(Collectors.toList());
        model.addAttribute("roletypeList", roletypeList);
        model.addAttribute("create");
        return "roletype-management/roleTypeCreate";
    }

    /**
     * Create the role type. Method = POST
     * 
     * @param form RoleTypeForm
     * @param bindingResult BindingResult
     * @param model Model
     * @return RoleTypeForm and view
     * @throws Exception
     */
    @PostMapping(value = "/create", consumes="application/json")
    public ResponseEntity<Task> submitCreateRoleTypeForm(@RequestBody RoleTypeForm form) throws Exception {

        // remove irregular spaces
        String rName = form.getRolename().replaceAll("\\s+", " ");

        // assign all roletypes to roletypeList model attribute
        Set<RoleType> roletype = roleTypeService.loadAllRoleType();
        List<RoleType> roletypeList = roletype.stream().collect(Collectors.toList());
        Set<RoleType> roleSize = roleTypeService.findRoleTypeByName(form.getRolename().toLowerCase());

        if (roleSize == null) {
            RoleType roleDetails = new RoleType.Builder(rName.trim(), form.getRoledesc()).build();
            roleTypeService.createRoleType(roleDetails);
        } else {
            throw new Exception("Failed to Create");
        }

        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Update the role type. Method = GET
     * 
     * @param id roleId
     * @param form RoleTypeForm
     * @param model Model
     * @return RoleTypeForm and view
     */
    @GetMapping("/update/{roleIdUpdate}")
    public String showUpdateRoleTypeForm(@PathVariable("roleIdUpdate") Long id, RoleTypeForm form,
            Model model) {

        // assign all roletypes to roletypeList model attribute
        Set<RoleType> roletype = roleTypeService.loadAllRoleType();
        List<RoleType> roletypeList = roletype.stream().collect(Collectors.toList());
        model.addAttribute("roletypeList", roletypeList);
        model.addAttribute("roleIdUpdate", id);

        // Set Value for RoleType Object
        RoleType role = roleTypeService.findRoleById(id);

        // Set Value for RoleTypeForm
        form.setId(role.getId());
        form.setRolename(role.getRolename());
        form.setRoledesc(role.getRoledesc());
        model.addAttribute("updateRoleTypeForm", form);

        return "redirect:/roletype/load?roleIdUpdate= " + id + "#confirmUpdateModal";
    }

    /**
     * Update the role type. Method = POST
     * 
     * @param id roleId
     * @param form RoleTypeForm
     * @param model Model
     * @param redirectAttributes RedirectAttributes
     * @return RoleTypeForm and view
     */
    @PostMapping("/update/{roleId}")
    public String submitUpdateRoleTypeForm(@RequestParam("id") Long id, RoleTypeForm form, Model model,
            RedirectAttributes redirectAttributes) {

        // remove irregular spaces
        String rName = form.getRolename().replaceAll("\\s+", " ");

        // assign all roletypes to roletypeList model attribute
        Set<RoleType> roletype = roleTypeService.loadAllRoleType();
        List<RoleType> roletypeList = roletype.stream().collect(Collectors.toList());
        model.addAttribute("roletypeList", roletypeList);
        model.addAttribute("roleId", id);
        boolean isRoleExisting = roleTypeService.findIfRoleNameExists(form.getRolename().toLowerCase(), id);

        // Check if Role Type is already existing in the table
        if (isRoleExisting) {
            form.setId(id);
            model.addAttribute("updateRoleTypeForm", form);
            return "redirect:/roletype/load";
        } else {
            RoleType updatedRoleType = new RoleType.Builder(rName.trim(), form.getRoledesc()).build();
            roleTypeService.updateRoleType(id, updatedRoleType);
            redirectAttributes.addFlashAttribute("successMessage", "You have successfully updated this role type");

            // set 2 seconds delay
            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        return "redirect:/roletype/load#successModal";
    }
    
    /**
     * Load the Role Type on the screen
     * 
     * @param model Model
     * @return View
     */
    @GetMapping("/manage")
    public String loadRoleType(Model model,
            @RequestParam("searchRole") Optional<String> searchCriteria,
            @RequestParam("page") Optional<Integer> page,
            @RequestParam("size") Optional<Integer> size, 
            @RequestParam("sortField") Optional<String> sortField,
            @RequestParam("sortDir") Optional<String> sortDir) {
        
      int currentPage = page.orElse(Paging.DEFAULT_CURRENT_PAGE_NO);
      int pageSize = size.orElse(Paging.DEFAULT_PAGE_SIZE);
      String searchRole = searchCriteria.filter(str -> !str.isEmpty()).orElse("");
       
       String sortFieldVal = sortField.filter(str -> !str.isEmpty())
               .orElse("roleType");

       String sortVal = sortDir.filter(str -> !str.isEmpty())
               .orElse("asc");

       Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);
        
       Pageable pageable = PageRequest.of(currentPage - 1, pageSize, sort);
       Paged<RoleType> pagedRoleType = roleTypeService.loadRoleType(searchRole, pageable);
       
       model.addAttribute("searchRole", searchRole);
       model.addAttribute("currentPage", currentPage);
       model.addAttribute("paginatedRoleType", pagedRoleType);
       
       return "roletype-management/roleTypeView";

    }
}

/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.pagination;

/**
 * This is a test class for XXXXXXXX.java
 *
 * @version 0.1
 * @author mi.aguinaldo
 */
public enum PageItemType {
    DOTS,
    PAGE
}

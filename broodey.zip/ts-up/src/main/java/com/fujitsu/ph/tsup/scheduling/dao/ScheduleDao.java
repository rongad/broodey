package com.fujitsu.ph.tsup.scheduling.dao;

//=======================================================
//$Id: PR02$
//Project Name: Training Sign Up
//Class Name: ScheduleDao.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 06/23/2020 | WS) J.Macabugao  | New Creation
//0.02    | 08/05/2021 | WS) mi.aguinaldo | Update
//0.03    | 08/05/2021 | WS) DW.Cardenas  | Pagination for View and Change Sched, Change Sched Status
//0.04    | 09/03/2021 | WS) RU.delaCruz  | Filter Functions for Instructor Course Schedule List
//0.05    | 10/14/2021 | WS) Ju.Cuevas    | Update Filter Functions for Instructor Course Schedule List
//0.06    | 12/29/2021 | WS) ep.delosreyes| Removed top learners
//=======================================================

/**
* <pre>
* The data access interface for schedule related database access
* <pre>
* @version 0.06
* @author j.macabugao
*
*/

import java.time.ZonedDateTime;
import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.scheduling.domain.CourseSchedule;
import com.fujitsu.ph.tsup.scheduling.model.CourseForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.TrainingPeriod;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;

public interface ScheduleDao {

    /**
     * Finds the scheduled courses starting from today onwards
     * 
     * @param scheduledStartDate
     * @param scheduledEndDateTime
     */
    Set<CourseSchedule> findAllScheduledCourses(ZonedDateTime scheduledStartDateTime,
	    ZonedDateTime scheduledEndDateTime);

    /**
     * Finds all the scheduled courses starting from today onwards of the instructor
     * 
     * @param instructorId
     * @param trainingPeriod
     * @param pageable
     * @return
     */

    Set<CourseSchedule> findAllInstructorCourseSchedules(Long instructorId, TrainingPeriod trainingperiod, 
    		CourseScheduleListForm courseScheduleListForm, Pageable pageable);

    /**
     * Count all the scheduled courses starting from today onwards of the instructor
     * 
     * @param instructorId
     * @param trainingPeriod
     * @param pageable
     * @return
     */
    int countAllInstructorCourseSchedules(Long id, TrainingPeriod trainingPeriod,String courseCategoryId,String courseNameId, String venueId, String mandatory, String mandatoryType);

    /**
     * Count all enrolled courses by Instructor Id
     * 
     * @param long id
     * 
     */
    int countAllEnrolledCoursesByInstructorId(Long id);

    /**
     * Finds all courses
     * 
     */
    Set<CourseForm> findAllCourses();

    /**
	 * <pre>
	 *
	 *Method for loading all course category in Instructor Course Schedule List
	 *@author ru.delaruz
	 *
	 * <pre>
	 */
    Set<CourseCategory> findAllCourseCategory();
    
    /**
     * Finds all instructors
     * 
     */
    Set<InstructorForm> findAllInstructors();

    /**
     * Finds all venues
     * 
     */
    Set<VenueForm> findAllVenues();

    /**
     * Finds all course schedule by Id
     * 
     * @param long id
     * 
     */
    CourseSchedule findCourseScheduleById(Long id);

    /**
     * Saves the CourseSchedule and CourseScheduleDetail object
     * 
     * @param courseSchedule
     */
    void saveCourseSchedule(CourseSchedule courseSchedule);

    /**
     * Update a course schedule
     * 
     * @param courseSchedule
     */
    void updateCourseSchedule(CourseSchedule courseSchedule);

    /**
     * Deletes the CourseSchedule and CourseScheduleDetail by ID
     * 
     * @param id
     */
    void deleteCourseScheduleById(Long id);

    /**
     * Finds course schedule by course Id
     * 
     * @param long id
     * 
     */
    Set<CourseSchedule> findCourseScheduleByCourseId(Long id);

    /**
     * Update course schedule status
     * 
     * @param courseSchedules
     * 
     */

    void updateCourseScheduleStatus(Set<CourseSchedule> courseSchedules);

    Set<CourseSchedule> findCourseScheduleByCourseId(Long id, Pageable pageable);

    int countCoursesById(Long id);

    Set<CourseSchedule> findAllScheduledCoursesWithinPeriod(TrainingPeriod trainingPeriod, Pageable pageable);

    int countAllScheduledCoursesWithinPeriod(TrainingPeriod trainingPeriod);

}

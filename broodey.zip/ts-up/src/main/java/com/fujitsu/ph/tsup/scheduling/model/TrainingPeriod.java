package com.fujitsu.ph.tsup.scheduling.model;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Objects;

//=======================================================
//$Id: PR02$
//Project Name: Training Sign Up
//Class Name: TrainingPeriod.java
//
//<<Modification History>>
//Version | Date       | Updated by        | Content
//--------+------------+-------------------+---------------
//0.01    | 08/05/2021 | WS) MI.Aguinaldo  | New Creation
//0.02    | 10/14/2021 | WS) Ju.Cuevas     | Added Member Role
// 0.03 | 10/19/2021 | WS) D.Dinglasan | Added Status
//=======================================================

public class TrainingPeriod {

	private ZonedDateTime fromDate;

	private ZonedDateTime toDate;

	private String courseNameId;
	
	private String courseCategoryId;
	
	private String instructorId;

	private String venueId;
	
	private String memberRole;
	
    private String status;

	private TrainingPeriod(ZonedDateTime fromDate, ZonedDateTime toDate, String courseNameId,
            String courseCategoryId, String instructorId, String venueId, String memberRole) {
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.courseNameId = courseNameId;
		this.courseCategoryId = courseCategoryId;
		this.instructorId = instructorId;
		this.venueId = venueId;
		this.memberRole = memberRole;
	}

    private TrainingPeriod(ChangeStatusForm changeStatusForm) {
        this.fromDate = changeStatusForm.getFromDateTime();
        this.toDate = changeStatusForm.getToDateTime();
        this.courseNameId = changeStatusForm.getCourseNameId();
        this.instructorId = changeStatusForm.getInstructorId();
        this.venueId = changeStatusForm.getVenueId();
        this.memberRole = changeStatusForm.getMemberRole();
        this.status = changeStatusForm.getStatus();

        this.courseCategoryId = "%";
    }

	private TrainingPeriod(ZonedDateTime fromDate, ZonedDateTime toDate) {
	    this.fromDate = fromDate;
        this.toDate = toDate;
	}
	
	public static TrainingPeriod of(ZonedDateTime fromDate, ZonedDateTime toDateTime, String courseId,
            String courseCategoryId, String instructorId, String venueId, String memberRole) {
		Objects.requireNonNull(fromDate, "From date must not be null");
		Objects.requireNonNull(toDateTime, "To date must not be null");

        return new TrainingPeriod(fromDate, toDateTime, courseId, courseCategoryId, instructorId, venueId,
                memberRole);
	}

	public static TrainingPeriod of(ChangeStatusForm changeStatusForm) {
        Objects.requireNonNull(changeStatusForm, "CourseScheduleListForm must not be null");
        return new TrainingPeriod(changeStatusForm);
    }
	
	public static TrainingPeriod of(CourseScheduleListForm courseScheduleListForm) {
		Objects.requireNonNull(courseScheduleListForm, "CourseScheduleListForm must not be null");

		return of(courseScheduleListForm.getFromDateTimeZone(), courseScheduleListForm.getToDateTimeZone(),
				courseScheduleListForm.getCourseNameId(), courseScheduleListForm.getCourseCategoryId(),
				courseScheduleListForm.getInstructorId(), courseScheduleListForm.getVenueId(),
                courseScheduleListForm.getMemberRole());
	}
	
	
	
	public static TrainingPeriod of(ZonedDateTime fromDateTime, ZonedDateTime toDateTime) {
	    return new TrainingPeriod(fromDateTime, toDateTime);
	}

	/**
	 * @return the fromDate
	 */
	public ZonedDateTime getFromDate() {
		return fromDate;
	}

	/**
	 * @return the toDate
	 */
	public ZonedDateTime getToDate() {
		return toDate;
	}

	public OffsetDateTime getFromDateTimeTimezoneOnUTC() {
		return fromDate.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime();
	}

	public OffsetDateTime getToDateTimeTimezoneOnUTC() {
		return toDate.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime();
	}
	
	/**
	 * @return the courseNameId
	 */
	public String getCourseNameId() {
		return courseNameId;
	}

	/**
	 * @return the courseCategoryId
	 */
	public String getCourseCategoryId() {
		return courseCategoryId;
	}
	
	/**
	 * @return the instructorId
	 */
	public String getInstructorId() {
		return instructorId;
	}

	/**
	 * @return the venueId
	 */
	public String getVenueId() {
		return venueId;
	}
	

	/**
	 * @return the memberRole
	 */
	public String getMemberRole() {
		return memberRole;
	}

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
}

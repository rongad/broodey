package com.fujitsu.ph.tsup.instructorconduct.dao;

import java.util.Collections;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: InstructorConductDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja    | New Creation
//0.02    | 10/08/2021 | WS) MI.Aguinaldo| Update
//0.03    | 10/27/2021 | WS) L.Celoso    | Added Pagination
//0.03    | 10/28/2021 | WS) M.Yanoyan   | Refactored method name 
//=======================================================

/**
* <pre>
* The implementation of data access object for course schedules assigned to instructor. 
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;

import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseForm;
import com.fujitsu.ph.tsup.instructorconduct.model.SurveySearchFilter;

@Repository
public class InstructorConductDaoImpl implements InstructorConductDao {
    
    private static final String FIND_ALL_COURSE_SCHEDULE_QUERY = "SELECT " 
            + "CSCHED.ID AS ID, " 
            + "CSCHED.COURSE_ID AS COURSE_ID, "
            + "C.NAME AS COURSE_NAME, "
            + "C.DETAIL AS DETAILS, " 
            + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, "
            + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " 
            + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
            + "CSCHED.VENUE_ID AS VENUE_ID, " 
            + "V.NAME AS VENUE_NAME, "
            + "V.OVERLAP AS VENUE_OVERLAP, "
            + "CSCHED.MIN_REQUIRED AS MIN_REQUIRED, " 
            + "CSCHED.MAX_ALLOWED AS MAX_ALLOWED, "
            + "(SELECT COUNT(PARTICIPANT_ID)"
            + " FROM COURSE_PARTICIPANT"
            + " WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, "
            + "CSCHED.STATUS AS STATUS, "
            + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
            + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
            + " CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
            + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
            + " CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
            + "CSCHEDDET.DURATION AS DURATION "
            + "FROM COURSE_SCHEDULE AS CSCHED " 
            + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
            + " ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " 
            + "INNER JOIN COURSE AS C "
            + " ON CSCHED.COURSE_ID = C.ID " 
            + "INNER JOIN EMPLOYEE AS E"
            + " ON CSCHED.INSTRUCTOR_ID = E.ID " 
            + "INNER JOIN VENUE AS V " 
            + "ON CSCHED.VENUE_ID = V.ID ";

    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;

    /**
     * Find all course schedule.
     *
     * @return the sets the CourseSchedule
     */
    @Override
    public Set<CourseSchedule> findAllCourseSchedule(Pageable pageable) {

        StringBuilder querySb = new StringBuilder(FIND_ALL_COURSE_SCHEDULE_QUERY);
        querySb.append("ORDER BY SCHEDULED_START_DATETIME ASC ");
        querySb.append("LIMIT " + pageable.getPageSize() + " ");
        querySb.append("OFFSET " + pageable.getOffset() + " ");
        
        List<CourseSchedule> courseSchedules = template.query(querySb.toString(), new CourseScheduleRowMapper());
        
        return courseSchedules.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(courseSchedules);
    }

    /**
     * Find all course schedule by instructor id.
     *
     * @param instructorId the instructor id
     * @return the sets the
     */
    @Override
    public Set<CourseSchedule> findAllCourseScheduleByInstructorId(Pageable pageable, Long instructorId) {
        
    	 /**
         * <pre>
         * Find Course Schedule assigned to instructor
         * 
         * <pre>
         * 
         * @param Long id
         */
        StringBuilder querySb = new StringBuilder(FIND_ALL_COURSE_SCHEDULE_QUERY);
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("SCHEDULED_START_DATETIME");
        String orderProperty = getOrderProperty(order);
        
        querySb.append("WHERE CSCHED.INSTRUCTOR_ID = :instructorId ");
        querySb.append("ORDER BY " + orderProperty + " ");
        querySb.append("LIMIT " + pageable.getPageSize() + " ");
        querySb.append("OFFSET " + pageable.getOffset() + " ");
        
        
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                                                          .addValue("instructorId", instructorId);

        List<CourseSchedule> courseScheduleList = template.query(querySb.toString(), courseScheduleParameters,
                new CourseScheduleRowMapper());
   

        return courseScheduleList.isEmpty() ? Collections.emptySet() :  new LinkedHashSet<>(courseScheduleList);
    }
    
    /**
     * <pre>
     * Finds course schedule assigned to instructor by course Id 
     * <pre>
     * @param Long id
     */
    @Override
    public Set<CourseSchedule> findAllCourseScheduleByCourseIdInstructorId(Pageable pageable, Long instructorId, Long courseId) {
    
        
        StringBuilder querySb = new StringBuilder(FIND_ALL_COURSE_SCHEDULE_QUERY);
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("SCHEDULED_START_DATETIME");
        String orderProperty = getOrderProperty(order);
        
        querySb.append("WHERE CSCHED.INSTRUCTOR_ID = :instructorId ");
        if(courseId != null) {
            querySb.append("AND CSCHED.COURSE_ID = :courseId ");
        }
        querySb.append("ORDER BY " + orderProperty + " ");
        querySb.append("LIMIT " + pageable.getPageSize() + " ");
        querySb.append("OFFSET " + pageable.getOffset() + " ");

        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                .addValue("courseId", courseId)
                .addValue("instructorId", instructorId);

        List<CourseSchedule> courseScheduleList = template.query(querySb.toString(), courseScheduleParameters,
                new CourseScheduleRowMapper());
         

        return courseScheduleList.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(courseScheduleList);
    }
    
    /**
     * Find all course schedule by course name.
     *
     * @param courseName the course name
     * @return the sets the
     */
    @Override
    public Set<CourseSchedule> findAllCourseScheduleByCourseName(Pageable pageable, String courseName) {
        StringBuilder querySb = new StringBuilder(FIND_ALL_COURSE_SCHEDULE_QUERY);
        querySb.append("WHERE LOWER(C.NAME) LIKE :courseName");
        
        String formattedCourseName = "%" + courseName.toLowerCase() + "%";
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                                                          .addValue("courseName", formattedCourseName);

        List<CourseSchedule> courseScheduleList = template.query(querySb.toString(), courseScheduleParameters,
                new CourseScheduleRowMapper());
   

        return courseScheduleList.isEmpty() ? Collections.emptySet() :  new LinkedHashSet<>(courseScheduleList);
    }
    

    /**
     * Find all course schedule by survey filter.
     *
     * @param surveySearchFilter the survey search filter
     * @return the sets the
     */
    @Override
    public Set<CourseSchedule> findAllCourseScheduleBySurveyFilter(Pageable pageable, SurveySearchFilter surveySearchFilter) {
        Objects.requireNonNull(surveySearchFilter);
        
        if(surveySearchFilter.isAllFieldsNonValid()) {
            return Collections.emptySet();
        }
        
        StringBuilder querySb = new StringBuilder(FIND_ALL_COURSE_SCHEDULE_QUERY);
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("SCHEDULED_START_DATETIME");
        String orderProperty = getOrderProperty(order);
        
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource();
        
        List<CourseSchedule> courseScheduleList;
        
        if (Objects.nonNull(surveySearchFilter.getCourseId())
                && Objects.isNull(surveySearchFilter.getInstructorId())) {

            querySb.append("WHERE CSCHED.COURSE_ID = :courseId ");

            courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("courseId",surveySearchFilter.getCourseId());

        } else if (Objects.isNull(surveySearchFilter.getCourseId())
                && Objects.nonNull(surveySearchFilter.getInstructorId())) {
            
            querySb.append("WHERE CSCHED.INSTRUCTOR_ID = :instructorId ");

            courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("instructorId",surveySearchFilter.getInstructorId());

        } else if (Objects.nonNull(surveySearchFilter.getCourseId())
                && Objects.nonNull(surveySearchFilter.getInstructorId())){
            querySb.append("WHERE CSCHED.COURSE_ID = :courseId ");
            querySb.append("AND  CSCHED.INSTRUCTOR_ID = :instructorId ");

            courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("courseId",surveySearchFilter.getCourseId())
                    .addValue("instructorId",surveySearchFilter.getInstructorId());
        }

        querySb.append("ORDER BY " + orderProperty + " ");
        querySb.append("LIMIT " + pageable.getPageSize() + " ");
        querySb.append("OFFSET " + pageable.getOffset() + " ");
        
        courseScheduleList = template.query(querySb.toString(), courseScheduleParameters,  new CourseScheduleRowMapper());
        
        return courseScheduleList.isEmpty() ? Collections.emptySet() :  new LinkedHashSet<>(courseScheduleList);
    }

    /**
     * <pre>
     * Finds course schedule assigned to instructor by intructor Id 
     * <pre>
     * 
     * @param Long id
     */    
    @Override
    public Set<CourseForm> findAllScheduledCoursesByInstructorId(Long instructorId) {
       
                String sql = "SELECT "
                + "DISTINCT C.NAME, "
                + "CSCHED.COURSE_ID AS ID, "
                + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID "
                + "FROM COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID "
                + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID "
                + "INNER JOIN VENUE AS V "
                + "ON CSCHED.VENUE_ID = V.ID "
                + "WHERE CSCHED.INSTRUCTOR_ID = :id "
                + "ORDER BY C.NAME";

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("id", instructorId);
           
            List<CourseForm> listCourseSchedule = template.query(sql, courseScheduleParameters, new CourseRowMapper());
            return new LinkedHashSet<>(listCourseSchedule);
        
    }
    
    public int countCourseForInstructor(Long instructorId) {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT COUNT(CSCHED.ID) ");
        query.append(" FROM COURSE_SCHEDULE AS CSCHED ");
        query.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        query.append(" ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " );
        query.append("INNER JOIN COURSE AS C ");
        query.append(" ON CSCHED.COURSE_ID = C.ID " );
        query.append("INNER JOIN EMPLOYEE AS E");
        query.append(" ON CSCHED.INSTRUCTOR_ID = E.ID " );
        query.append("INNER JOIN VENUE AS V " );
        query.append("ON CSCHED.VENUE_ID = V.ID ");
        query.append("WHERE CSCHED.INSTRUCTOR_ID = :instructorId ");
        
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource().addValue("instructorId", instructorId);
        
        return template.queryForObject(query.toString(), courseScheduleParameters, Integer.class);
        
    }
    
    public int countCourseForInstructorFilter(Long instructorId, Long courseId) {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT COUNT(CSCHED.ID) ");
        query.append(" FROM COURSE_SCHEDULE AS CSCHED ");
        query.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        query.append(" ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " );
        query.append("INNER JOIN COURSE AS C ");
        query.append(" ON CSCHED.COURSE_ID = C.ID " );
        query.append("INNER JOIN EMPLOYEE AS E");
        query.append(" ON CSCHED.INSTRUCTOR_ID = E.ID " );
        query.append("INNER JOIN VENUE AS V " );
        query.append("ON CSCHED.VENUE_ID = V.ID ");
        query.append("WHERE CSCHED.INSTRUCTOR_ID = :instructorId ");
        if(courseId != null) {
            query.append("AND CSCHED.COURSE_ID = :courseId ");
        }
        
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                .addValue("instructorId", instructorId)
                .addValue("courseId", courseId);
        
        return template.queryForObject(query.toString(), courseScheduleParameters, Integer.class);
        
    }
    
    public int countCourseForAll() {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT COUNT(CSCHED.ID) ");
        query.append(" FROM COURSE_SCHEDULE AS CSCHED ");
        query.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        query.append(" ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " );
        query.append("INNER JOIN COURSE AS C ");
        query.append(" ON CSCHED.COURSE_ID = C.ID " );
        query.append("INNER JOIN EMPLOYEE AS E");
        query.append(" ON CSCHED.INSTRUCTOR_ID = E.ID " );
        query.append("INNER JOIN VENUE AS V " );
        query.append("ON CSCHED.VENUE_ID = V.ID ");
        
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource();
        
        return template.queryForObject(query.toString(), courseScheduleParameters, Integer.class);
        
    }
    
    
    public int countCourseForAllFilter(SurveySearchFilter surveySearchFilter) {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT COUNT(CSCHED.ID) ");
        query.append(" FROM COURSE_SCHEDULE AS CSCHED ");
        query.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        query.append(" ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " );
        query.append("INNER JOIN COURSE AS C ");
        query.append(" ON CSCHED.COURSE_ID = C.ID " );
        query.append("INNER JOIN EMPLOYEE AS E");
        query.append(" ON CSCHED.INSTRUCTOR_ID = E.ID " );
        query.append("INNER JOIN VENUE AS V " );
        query.append("ON CSCHED.VENUE_ID = V.ID ");

        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource();
        
        if (Objects.nonNull(surveySearchFilter.getCourseId())
                && Objects.isNull(surveySearchFilter.getInstructorId())) {

            query.append("WHERE CSCHED.COURSE_ID = :courseId ");

            courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("courseId",surveySearchFilter.getCourseId());

        } else if (Objects.isNull(surveySearchFilter.getCourseId())
                && Objects.nonNull(surveySearchFilter.getInstructorId())) {
            
            query.append("WHERE CSCHED.INSTRUCTOR_ID = :instructorId ");

            courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("instructorId",surveySearchFilter.getInstructorId());

        } else if (Objects.nonNull(surveySearchFilter.getCourseId())
                && Objects.nonNull(surveySearchFilter.getInstructorId())){
            
            query.append("WHERE CSCHED.COURSE_ID = :courseId ");
            query.append("AND  CSCHED.INSTRUCTOR_ID = :instructorId ");

            courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("courseId",surveySearchFilter.getCourseId())
                    .addValue("instructorId",surveySearchFilter.getInstructorId());
        }
        
        return template.queryForObject(query.toString(), courseScheduleParameters, Integer.class);
        
    }
    
    /**
     * <pre>
     * Map the correct and proper field name
     * 
     * <pre>
     * 
     * @param order
     * @return String
     * @author ru.delacruz
     * @author d.dinglasan
     */
    private String getOrderProperty(Order order) {
        switch (order.getProperty()) {
            case "course_category":
                return "COURSE_CATEGORY " + order.getDirection();
            case "course_name":
                return "COURSE_NAME " + order.getDirection();
            case "instructor":
                return "INSTRUCTOR_LAST_NAME " + order.getDirection() + ", INSTRUCTOR_FIRST_NAME "
                        + order.getDirection();
            case "mandatory":
                return "MANDATORY " + order.getDirection();
            case "mandatory_type":
                return "MANDATORY_TYPE " + order.getDirection();
            case "department":
                return "DEPARTMENT " + order.getDirection();
            case "scheduled_start_datetime":
                return "SCHEDULED_START_DATETIME " + order.getDirection();
            case "scheduled_end_datetime":
                return "SCHEDULED_END_DATETIME " + order.getDirection();
            case "duration":
                return "DURATION " + order.getDirection();
            case "total_participants":
                return "TOTAL_PARTICIPANTS " + order.getDirection();
            case "venue":
                return "VENUE_NAME " + order.getDirection();
            case "min_participants":
                return "MIN_REQUIRED " + order.getDirection();
            case "max_participants":
                return "MAX_ALLOWED " + order.getDirection();
            case "deadline":
                return "DEADLINE " + order.getDirection();
            case "course_status":
                return "STATUS " + order.getDirection();
            case "venue_name":
                return "VENUE_NAME " + order.getDirection();
            case "jduType":
                return "JDU_TYPE " + order.getDirection();
            default:
                return "";
        }
    }
}
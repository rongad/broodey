package com.fujitsu.ph.tsup.scheduling.dao;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.course.category.dao.CourseCategoryRowMapper;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.enrollment.dao.EnrollmentDaoImpl;
import com.fujitsu.ph.tsup.scheduling.domain.CourseSchedule;
import com.fujitsu.ph.tsup.scheduling.domain.CourseScheduleDetail;
import com.fujitsu.ph.tsup.scheduling.model.CourseForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.TopLearnersForm;
import com.fujitsu.ph.tsup.scheduling.model.TrainingPeriod;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;

// =======================================================
// $Id: PR02$
// Project Name: Training Sign Up
// Class Name: ScheduleDaoImpl.java
//
// <<Modification History>>
// Version | Date       | Updated by       | Content
// --------+------------+------------------+---------------
// 0.01    | 06/26/2020 | WS) J.Macabugao  |  New Creation
// 0.01    | 06/26/2020 | WS) JC.Jimenez   |  New Creation
// 0.01    | 06/26/2020 | WS) J.Balanon    |  New Creation
// 0.02    | 05/28/2021 | WS) J.Atendido   |  Bug fixes and enhancements
// 0.03    | 06/04/2021 | WS) J.Atendido   |  Added overlap attribute for venue
// 0.04    | 06/04/2021 | WS) J.Atendido   |  Updated date format for SQL statement
// 0.05    | 08/05/2021 | WS) MI.Aguinaldo |  Implemented findAllInstructorCourseSchedules
// 0.06    | 08/05/2021 | WS) DW.Cardenas  |  Pagination for View and Change Sched, Change Sched Status
// 0.07    | 09/03/2021 | WS) RU.DelaCruz  |  Added courseCategory, mandatory, mandatoryType
// 0.07    | 09/07/2021 | WS) L.Celoso     |  Added Course Category
// 0.08    | 10/14/2021 | WS) Ju.Cuevas    |  Added Member Role
// 0.09    | 10/19/2021 | WS) D.Dinglasan  |  Added Status
// 0.10    | 12/29/2021 | WS) ep.delosreyes|  Removed top learners
// =======================================================

/**
 * <pre>
 * The data access class for schedule related database access
 * 
 * <pre>
 * 
 * @version 0.10
 * @author jc.jimenez
 * @author j.balanon
 * @author j.macabugao
 * @author j.atendido
 */
@Repository
public class ScheduleDaoImpl implements ScheduleDao {

    private static Logger logger = LoggerFactory.getLogger(ScheduleDaoImpl.class);

    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private EnrollmentDaoImpl enrollmentDaoImpl;
    
    /**
     * <pre>
     * Finds the scheduled courses starting from today onwards
     * 
     * <pre>
     * 
     * @param ZonedDateTime scheduledStartDateTime
     * @param ZonedDateTime scheduledEndDateTime
     */

    @Override
    public Set<CourseSchedule> findAllScheduledCourses(ZonedDateTime fromDateTime, ZonedDateTime toDateTime) {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        ZonedDateTime fromDateTimeConflictLowerLimit = ZonedDateTime.now().withHour(0).withMinute(0);
        ZonedDateTime toDateTimeConflictUpperLimit = ZonedDateTime.now().withHour(23).withMinute(59)
                .withSecond(59).withYear(9999);

        String query = "SELECT " + "CSCHED.ID AS ID, " + "CSCHED.COURSE_ID AS COURSE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, "
                + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "C.MANDATORY AS MANDATORY," + "C.MANDATORY_TYPE AS MANDATORY_TYPE,"
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "CSCHED.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, " + "V.OVERLAP AS VENUE_OVERLAP, "
                + "CSCHED.MIN_REQUIRED AS MIN_REQUIRED, " + "CSCHED.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID)" + " FROM COURSE_PARTICIPANT"
                + " WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, "
                + "CSCHED.STATUS AS STATUS, " + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + " CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + " CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSCHEDDET.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CSCHED.VENUE_ID = V.ID ";

        if ((!(user.getRoles().contains("Instructor")) || (user.getRoles().contains("PMO")))
                && !(fromDateTime.equals(fromDateTimeConflictLowerLimit)
                        && toDateTime.equals(toDateTimeConflictUpperLimit))) {
            query += "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                    + " CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                    + "ORDER BY SCHEDULED_START_DATETIME";
        } else {
            query += "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                    + " CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                    + "AND (CSCHED.STATUS NOT IN ('C', 'D'))" + "ORDER BY SCHEDULED_START_DATETIME";

        }
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                .addValue("fromDateTime",
                        fromDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                .addValue("toDateTime", toDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());

        List<CourseSchedule> courseScheduleList = template.query(query, courseScheduleParameters,
                new CourseScheduleRowMapper());

        return new LinkedHashSet<>(courseScheduleList);
    }

    /**
     * Finds all the scheduled courses starting from today onwards of the instructor
     * 
     * @param instructorId
     * @param trainingPeriod
     * @param pageable
     * @return
     */
    @Override
    public Set<CourseSchedule> findAllInstructorCourseSchedules(Long instructorId, TrainingPeriod trainingPeriod, 
            CourseScheduleListForm courseScheduleListForm, Pageable pageable) {

        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("SCHEDULED_START_DATETIME");
        String orderProperty = getScheduleSortOrder(order);
        StringBuilder queryBuilder = new StringBuilder();
        List<String> conditionList = new LinkedList<>();
        boolean withTags = trainingPeriod.getMemberRole() != null && !trainingPeriod.getMemberRole().isEmpty();
        
        queryBuilder.append("SELECT DISTINCT ");
        queryBuilder.append("CSCHED.ID AS ID, ");
        queryBuilder.append("CSCHED.COURSE_ID AS COURSE_ID, ");
        queryBuilder.append("C.NAME AS COURSE_NAME, ");
        queryBuilder.append("C.DETAIL AS DETAILS, ");
        queryBuilder.append("CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, ");
        queryBuilder.append("CC.CATEGORY AS COURSE_CATEGORY, "); // Added 2021/08/31
        queryBuilder.append("C.MANDATORY AS MANDATORY, "); // Added 2021/08/31
        queryBuilder.append("C.MANDATORY_TYPE AS MANDATORY_TYPE, "); // Added 2021/08/31
        queryBuilder.append("E.LAST_NAME AS INSTRUCTOR_LAST_NAME, ");
        queryBuilder.append("E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, ");
        queryBuilder.append("CSCHED.VENUE_ID AS VENUE_ID, ");
        queryBuilder.append("V.NAME AS VENUE_NAME, ");
        queryBuilder.append("V.OVERLAP AS VENUE_OVERLAP, ");
        queryBuilder.append("CSCHED.MIN_REQUIRED AS MIN_REQUIRED, ");
        queryBuilder.append("CSCHED.MAX_ALLOWED AS MAX_ALLOWED, ");
        queryBuilder.append("(SELECT COUNT(PARTICIPANT_ID)");
        queryBuilder.append("FROM COURSE_PARTICIPANT ");
        queryBuilder.append("WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, ");
        queryBuilder.append("CSCHED.STATUS AS STATUS, ");
        queryBuilder.append("CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, ");
        queryBuilder.append("COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
        queryBuilder.append(" CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, ");
        queryBuilder.append("COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, ");
        queryBuilder.append(" CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, ");
        queryBuilder.append("CSCHEDDET.DURATION AS DURATION ");
        queryBuilder.append("FROM COURSE_SCHEDULE AS CSCHED ");
        queryBuilder.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        queryBuilder.append("ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID ");
        queryBuilder.append("INNER JOIN COURSE AS C ");
        queryBuilder.append("ON CSCHED.COURSE_ID = C.ID ");
        queryBuilder.append("INNER JOIN EMPLOYEE AS E ");
        queryBuilder.append("ON CSCHED.INSTRUCTOR_ID = E.ID ");
        queryBuilder.append("INNER JOIN VENUE AS V ");
        queryBuilder.append("ON CSCHED.VENUE_ID = V.ID ");
        queryBuilder.append("INNER JOIN COURSE_CATEGORY AS CC ");
        queryBuilder.append("ON C.COURSE_CATEGORY_ID = CC.ID ");
        
        
        if(withTags) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM ");
            queryBuilder.append("ON CTM.course_id = C.ID ");
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR ");
            queryBuilder.append("ON MR.id = CTM.tag_id ");
            
            enrollmentDaoImpl.addTagsToConditionList(conditionList ,trainingPeriod.getMemberRole());
        }
        
        queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
        queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
        queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
        queryBuilder.append("AND TO_CHAR(CSCHED.COURSE_ID, 'FM9999') LIKE :courseNameId ");
        queryBuilder.append("AND TO_CHAR(CSCHED.VENUE_ID, 'FM9999') LIKE :venueId ");
        queryBuilder.append("AND C.MANDATORY LIKE :mandatory ");
        queryBuilder.append("AND C.MANDATORY_TYPE LIKE :mandatoryType ");
        queryBuilder.append("AND CSCHED.INSTRUCTOR_ID  = :instructorId ");
        
        if(withTags) {
            queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining()));
        }
        
        queryBuilder.append(" ORDER BY ");
        queryBuilder.append(orderProperty);
        queryBuilder.append(" ");
        queryBuilder.append(order.getDirection());

        queryBuilder.append(" LIMIT ");
        queryBuilder.append(pageable.getPageSize());
        queryBuilder.append(" OFFSET ");
        queryBuilder.append(pageable.getOffset());

        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                .addValue("instructorId", instructorId)
                .addValue("fromDateTime", trainingPeriod.getFromDateTimeTimezoneOnUTC())
                .addValue("toDateTime", trainingPeriod.getToDateTimeTimezoneOnUTC())
                .addValue("courseCategoryID", courseScheduleListForm.getCourseCategoryId())
                .addValue("courseNameId", courseScheduleListForm.getCourseNameId())
                .addValue("venueId", courseScheduleListForm.getVenueId())
                .addValue("mandatory", courseScheduleListForm.getMandatory())
                .addValue("mandatoryType", courseScheduleListForm.getMandatoryType());

        List<CourseSchedule> courseScheduleList = template.query(queryBuilder.toString(), courseScheduleParameters,
                new CourseScheduleRowMapper());

        return new LinkedHashSet<>(courseScheduleList);
    }

    /**
     * Count all the scheduled courses starting from today onwards of the instructor
     * 
     * @param instructorId
     * @param trainingPeriod
     * @param pageable
     * @return
     */
    @Override
    public int countAllInstructorCourseSchedules(Long instructorId, TrainingPeriod trainingPeriod,
            String courseCategoryId, String courseNameId, String venueId, String mandatory,
            String mandatoryType) {
        try {
            
            StringBuilder queryBuilder = new StringBuilder();
            List<String> conditionList = new LinkedList<>();
            boolean withTags = trainingPeriod.getMemberRole() != null && !trainingPeriod.getMemberRole().isEmpty();
            
            queryBuilder.append("SELECT COUNT( DISTINCT CSCHED.ID) ");
            queryBuilder.append("FROM COURSE_SCHEDULE AS CSCHED ");
            queryBuilder.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
            queryBuilder.append("ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID ");
            queryBuilder.append("INNER JOIN COURSE AS C ");
            queryBuilder.append("ON CSCHED.COURSE_ID = C.ID ");
            queryBuilder.append("INNER JOIN EMPLOYEE AS E ");
            queryBuilder.append("ON CSCHED.INSTRUCTOR_ID = E.ID ");
            queryBuilder.append("INNER JOIN VENUE AS V ");
            queryBuilder.append("ON CSCHED.VENUE_ID = V.ID ");
            queryBuilder.append("INNER JOIN COURSE_CATEGORY AS CC ");
            queryBuilder.append("ON C.COURSE_CATEGORY_ID = CC.ID ");
            
            if(withTags) {
                queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM ");
                queryBuilder.append("ON CTM.course_id = C.ID ");
                queryBuilder.append("INNER JOIN MEMBER_ROLE MR ");
                queryBuilder.append("ON MR.id = CTM.tag_id ");
                enrollmentDaoImpl.addTagsToConditionList(conditionList ,trainingPeriod.getMemberRole());
            }
            
            queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
            queryBuilder.append("AND TO_CHAR(CSCHED.COURSE_ID, 'FM9999') LIKE :courseNameId ");
            queryBuilder.append("AND TO_CHAR(CSCHED.VENUE_ID, 'FM9999') LIKE :venueId ");
            queryBuilder.append("AND C.MANDATORY LIKE :mandatory ");
            queryBuilder.append("AND C.MANDATORY_TYPE LIKE :mandatoryType ");
            queryBuilder.append("AND CSCHED.INSTRUCTOR_ID  = :instructorId ");

            if(withTags) {
                queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining()));
            }

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("instructorId", instructorId)
                    .addValue("fromDateTime", trainingPeriod.getFromDateTimeTimezoneOnUTC())
                    .addValue("toDateTime", trainingPeriod.getToDateTimeTimezoneOnUTC())
                    .addValue("courseCategoryID", courseCategoryId)
                    .addValue("courseNameId", courseNameId)
                    .addValue("instructorId", instructorId)
                    .addValue("venueId", venueId)
                    .addValue("mandatory", mandatory)
                    .addValue("mandatoryType", mandatoryType);

            return template.queryForObject(queryBuilder.toString(), courseScheduleParameters, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    /**
     * <pre>
     * Finds all courses
     * 
     * <pre>
     */
    @Override
    public Set<CourseForm> findAllCourses() {
        String query = "SELECT * FROM COURSE ORDER BY name ASC";

        List<CourseForm> courseList = template.query(query, new CourseRowMapper());

        return new LinkedHashSet<>(courseList);
    }

    /**
     * <pre>
     * Finds all instructors
     * 
     * <pre>
     */

    @Override
    public Set<InstructorForm> findAllInstructors() {

        String query = "SELECT E.ID," + " E.FIRST_NAME," + " E.LAST_NAME " + "FROM EMPLOYEE AS E "
                + " INNER JOIN EMPLOYEE_AUTH AS EA " + " ON E.USERNAME = EA.USERNAME "
                + "WHERE EA.AUTH_NAME = 'Instructor'" + " ORDER BY E.LAST_NAME ASC";

        List<InstructorForm> instructorList = template.query(query, new InstructorRowMapper());

        return new LinkedHashSet<>(instructorList);
    }

    /**
     * <pre>
     * Finds all venues
     * 
     * <pre>
     */
    @Override
    public Set<VenueForm> findAllVenues() {

        String query = "SELECT * FROM VENUE ORDER BY name ASC";

        List<VenueForm> venueList = template.query(query, new VenueRowMapper());

        return new LinkedHashSet<>(venueList);
    }

    /**
     * <pre>
     * Finds all categories
     * 
     * <pre>
     */
    @Override
    public Set<CourseCategory> findAllCourseCategory() {

        String query = "SELECT * FROM COURSE_CATEGORY ORDER BY category";
        List<CourseCategory> courseCategoryList = template.query(query, new CourseCategoryRowMapper());
        Set<CourseCategory> courseCategory = new LinkedHashSet<>(courseCategoryList);
        return courseCategory;
    }

    /**
     * <pre>
     * Saves the CourseSchedule and CourseScheduleDetail object
     * 
     * <pre>
     * 
     * @param CourseSchedule courseSchedule
     */
    @Override
    public void saveCourseSchedule(CourseSchedule courseSchedule) {

        try {
            KeyHolder generatedKeyHolder = new GeneratedKeyHolder();
            String courseScheduleSql = "INSERT INTO COURSE_SCHEDULE" + "(COURSE_ID, " + " INSTRUCTOR_ID,"
                    + " VENUE_ID," + " MIN_REQUIRED," + " MAX_ALLOWED, STATUS) " + "VALUES (:course_id,"
                    + " :instructor_id," + " :venue_id," + " :min_required," + " :max_allowed," + " :status)";

            Set<CourseScheduleDetail> courseScheduleDetail = courseSchedule.getCourseScheduleDetail();

            String courseScheduleDetailSql = "INSERT INTO COURSE_SCHEDULE_DETAIL" + "(COURSE_SCHEDULE_ID,"
                    + " SCHEDULED_START_DATETIME," + " SCHEDULED_END_DATETIME," + " DURATION)"
                    + "VALUES (:course_schedule_id," + " :scheduled_start_datetime,"
                    + " :scheduled_end_datetime, " + " :duration)";

            for (CourseScheduleDetail courseSchedDetail : courseScheduleDetail) {
                SqlParameterSource courseSchedParameters = new MapSqlParameterSource()
                        .addValue("course_id", courseSchedule.getCourseId())
                        .addValue("instructor_id", courseSchedule.getInstructorId())
                        .addValue("venue_id", courseSchedule.getVenueId())
                        .addValue("min_required", courseSchedule.getMinRequired())
                        .addValue("max_allowed", courseSchedule.getMaxAllowed())
                        .addValue("status", String.valueOf(courseSchedule.getStatus()));
                template.update(courseScheduleSql, courseSchedParameters, generatedKeyHolder);

                Long key = (Long) generatedKeyHolder.getKeys().get("id");
                logger.debug("Generated Course Schedule ID: {}", key);

                KeyHolder courseSchedDetailGeneratedKeyHolder = new GeneratedKeyHolder();
                SqlParameterSource courseSchedDetailParameters = new MapSqlParameterSource()
                        .addValue("course_schedule_id", key)
                        .addValue("scheduled_start_datetime",
                                courseSchedDetail.getScheduledStartDateTime().toOffsetDateTime())
                        .addValue("scheduled_end_datetime",
                                courseSchedDetail.getScheduledEndDateTime().toOffsetDateTime())
                        .addValue("duration", courseSchedDetail.getDuration());
                template.update(courseScheduleDetailSql, courseSchedDetailParameters,
                        courseSchedDetailGeneratedKeyHolder);

                Long courseSchedDetailKey = (Long) courseSchedDetailGeneratedKeyHolder.getKeys().get("id");
                logger.debug("Generated Course Schedule Detail ID: {}", courseSchedDetailKey);
            }
        } catch (NullPointerException e) {
            throw new NullPointerException("");
        }
    }

    /**
     * <pre>
     * Update a course schedule
     * 
     * <pre>
     * 
     * @param Long id
     */
    @Override
    public void updateCourseSchedule(CourseSchedule courseSchedule) {
        String sql = "UPDATE COURSE_SCHEDULE "
                + "SET COURSE_ID = :course_id, INSTRUCTOR_ID = :instructor_id, VENUE_ID = :venue_id, "
                + "MIN_REQUIRED = :min_required, MAX_ALLOWED = :max_allowed , STATUS = 'A' "
                + "WHERE ID = :cs_id";

        SqlParameterSource courseSchedParameters = new MapSqlParameterSource()
                .addValue("course_id", courseSchedule.getCourseId())
                .addValue("instructor_id", courseSchedule.getInstructorId())
                .addValue("venue_id", courseSchedule.getVenueId())
                .addValue("min_required", courseSchedule.getMinRequired())
                .addValue("max_allowed", courseSchedule.getMaxAllowed())
                .addValue("cs_id", courseSchedule.getId());
        template.update(sql, courseSchedParameters);

        String courseSchedDetSql = "UPDATE COURSE_SCHEDULE_DETAIL "
                + "SET COURSE_SCHEDULE_ID = :course_schedule_id, "
                + "RESCHEDULED_START_DATETIME = :scheduled_start_datetime, "
                + "RESCHEDULED_END_DATETIME = :scheduled_end_datetime, " + "DURATION = :duration "
                + "WHERE ID = :csdet_id";

        for (CourseScheduleDetail courseSchedDetail : courseSchedule.getCourseScheduleDetail()) {
            SqlParameterSource courseSchedDetailParameters = new MapSqlParameterSource()
                    .addValue("course_schedule_id", courseSchedDetail.getCourseScheduleId())
                    .addValue("scheduled_start_datetime",
                            courseSchedDetail.getScheduledStartDateTime().toOffsetDateTime())
                    .addValue("scheduled_end_datetime",
                            courseSchedDetail.getScheduledEndDateTime().toOffsetDateTime())
                    .addValue("duration", courseSchedDetail.getDuration())
                    .addValue("csdet_id", courseSchedDetail.getId());
            template.update(courseSchedDetSql, courseSchedDetailParameters);
        }
    }

    /**
     * <pre>
     * Delete a course schedule
     * 
     * <pre>
     * 
     * @param Long id
     */
    @Override
    public void deleteCourseScheduleById(Long id) {
        String courseSchedSql = "DELETE FROM COURSE_SCHEDULE WHERE ID = :id ";
        String courseSchedDetSql = "DELETE FROM COURSE_SCHEDULE_DETAIL WHERE COURSE_SCHEDULE_ID = :cs_id";

        SqlParameterSource courseSchedParameters = new MapSqlParameterSource().addValue("id", id);
        template.update(courseSchedSql, courseSchedParameters);

        SqlParameterSource courseSchedDetParameters = new MapSqlParameterSource().addValue("cs_id", id);
        template.update(courseSchedDetSql, courseSchedDetParameters);
    }

    /**
     * <pre>
     * Count all Enrolled Courses By Instructor
     * 
     * <pre>
     * 
     * @param Long id
     */
    @Override
    public int countAllEnrolledCoursesByInstructorId(Long id) {
        try {
            String query = "SELECT COUNT(C.NAME) " + "FROM COURSE_SCHEDULE AS CSCHED "
                    + "INNER JOIN COURSE AS C " + " ON CSCHED.COURSE_ID = C.ID "
                    + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                    + " ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN EMPLOYEE AS E "
                    + " ON CSCHED.INSTRUCTOR_ID = E.ID " + "WHERE CSCHED.INSTRUCTOR_ID = :id "
                    + "AND :today BETWEEN "
                    + " DATE(COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, CSCHEDDET.SCHEDULED_START_DATETIME)) AND "
                    + " DATE(COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, CSCHEDDET.SCHEDULED_END_DATETIME)) "
                    + "AND (CSCHED.STATUS = 'A' OR CSCHED.STATUS = 'O');";

            SqlParameterSource countParameters = new MapSqlParameterSource().addValue("id", id)
                    .addValue("today", LocalDate.now());
            return template.queryForObject(query, countParameters, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    /**
     * <pre>
     * Find a course schedule by id
     * 
     * <pre>
     * 
     * @param Long id
     */
    @Override
    public CourseSchedule findCourseScheduleById(Long id) {

        String query = "SELECT " + "CSCHED.ID AS ID, " + "CSCHED.COURSE_ID AS COURSE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, "
                + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "C.MANDATORY AS MANDATORY," + "C.MANDATORY_TYPE AS MANDATORY_TYPE,"
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "CSCHED.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, " + "V.OVERLAP AS VENUE_OVERLAP, "
                + "CSCHED.MIN_REQUIRED AS MIN_REQUIRED, " + "CSCHED.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID)" + " FROM COURSE_PARTICIPANT"
                + " WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, "
                + " CSCHED.STATUS AS STATUS, " + " CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
                + " COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + " CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + " COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + " CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + " CSCHEDDET.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + " ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + " ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "INNER JOIN EMPLOYEE AS E"
                + " ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V "
                + " ON CSCHED.VENUE_ID = V.ID " + "WHERE CSCHED.ID = :id ";

        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource().addValue("id", id);

        return template.queryForObject(query, courseScheduleParameters, new CourseScheduleRowMapper());
    }

    /**
     * <pre>
     * Find course schedule by course id
     * 
     * <pre>
     * 
     * @param Long id
     */
    @Override
    public Set<CourseSchedule> findCourseScheduleByCourseId(Long id) {
        String query = "SELECT " + "CSCHED.ID AS ID, " + "CSCHED.COURSE_ID AS COURSE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, "
                + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "C.MANDATORY AS MANDATORY," + "C.MANDATORY_TYPE AS MANDATORY_TYPE,"
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "CSCHED.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, " + "V.OVERLAP AS VENUE_OVERLAP, "
                + "CSCHED.MIN_REQUIRED AS MIN_REQUIRED, " + "CSCHED.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID)" + " FROM COURSE_PARTICIPANT"
                + " WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, "
                + " CSCHED.STATUS AS STATUS, " + " CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
                + " COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + " CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + " COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + " CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + " CSCHEDDET.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + " ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + " ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "INNER JOIN EMPLOYEE AS E"
                + " ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V "
                + " ON CSCHED.VENUE_ID = V.ID " + "WHERE CSCHED.COURSE_ID = :c_id "
                + "ORDER BY ID, SCHEDULED_START_DATETIME";

        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource().addValue("c_id", id);

        List<CourseSchedule> courseScheduleList = template.query(query, courseScheduleParameters,
                new CourseScheduleRowMapper());
        return new HashSet<>(courseScheduleList);
    }

    /**
     * <pre>
     * Update a course schedule status
     * 
     * <pre>
     * 
     * @param courseSchedules
     */
    @Override
    public void updateCourseScheduleStatus(Set<CourseSchedule> courseSchedules) {
        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("UPDATE COURSE_SCHEDULE ");
        queryBuilder.append("SET STATUS = :status ");
        queryBuilder.append("WHERE ID = :id AND COURSE_ID = :course_id");

        for (CourseSchedule courseSchedule : courseSchedules) {
            SqlParameterSource courseSchedParameters = new MapSqlParameterSource()
                    .addValue("status", courseSchedule.getStatus())
                    .addValue("id", courseSchedule.getId())
                    .addValue("course_id", courseSchedule.getCourseId());
            template.update(queryBuilder.toString(), courseSchedParameters);
        }
    }

    @Override
    public Set<CourseSchedule> findCourseScheduleByCourseId(Long id, Pageable pageable) {
        String query = "SELECT " + "CSCHED.ID AS ID, " + "CSCHED.COURSE_ID AS COURSE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, "
                + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "C.MANDATORY AS MANDATORY," + "C.MANDATORY_TYPE AS MANDATORY_TYPE,"
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "CSCHED.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, " + "V.OVERLAP AS VENUE_OVERLAP, "
                + "CSCHED.MIN_REQUIRED AS MIN_REQUIRED, " + "CSCHED.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID)" + " FROM COURSE_PARTICIPANT"
                + " WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, "
                + " CSCHED.STATUS AS STATUS, " + " CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
                + " COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + " CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + " COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + " CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + " CSCHEDDET.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + " ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + " ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "INNER JOIN EMPLOYEE AS E"
                + " ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V "
                + " ON CSCHED.VENUE_ID = V.ID " + "WHERE CSCHED.COURSE_ID = :courseId "
                + "ORDER BY SCHEDULED_START_DATETIME DESC, SCHEDULED_END_DATETIME DESC "
                + "LIMIT :pageSize OFFSET :pageOffset";

        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource().addValue("courseId", id)
                .addValue("pageSize", pageable.getPageSize()).addValue("pageOffset", pageable.getOffset());

        List<CourseSchedule> courseScheduleList = template.query(query, courseScheduleParameters,
                new CourseScheduleRowMapper());

        return new HashSet<>(courseScheduleList);
    }

    @Override
    public int countCoursesById(Long id) {
        try {
            String query = "SELECT COUNT(course_id) FROM COURSE_SCHEDULE WHERE course_id = :id";
            SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);

            return template.queryForObject(query, paramSource, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    @Override
    public Set<CourseSchedule> findAllScheduledCoursesWithinPeriod(TrainingPeriod trainingPeriod,
            Pageable pageable) {
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("SCHEDULED_START_DATETIME");
        String orderProperty = getScheduleSortOrder(order);
        StringBuilder queryBuilder = new StringBuilder();
        List<String> conditionList = new LinkedList<>();
        boolean withTags = (trainingPeriod.getMemberRole() != null && !trainingPeriod.getMemberRole().isEmpty());
 
        queryBuilder.append("SELECT DISTINCT CSCHED.ID AS ID, ");
        queryBuilder.append("CSCHED.COURSE_ID AS COURSE_ID, ");
        queryBuilder.append("C.NAME AS COURSE_NAME, ");
        queryBuilder.append("C.DETAIL AS DETAILS, ");
        queryBuilder.append("CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID, ");
        queryBuilder.append("CC.CATEGORY AS COURSE_CATEGORY, ");
        queryBuilder.append("C.MANDATORY AS MANDATORY, ");
        queryBuilder.append("C.MANDATORY_TYPE AS MANDATORY_TYPE, ");
        queryBuilder.append("E.LAST_NAME AS INSTRUCTOR_LAST_NAME, ");
        queryBuilder.append("E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, ");
        queryBuilder.append("CSCHED.VENUE_ID AS VENUE_ID, ");
        queryBuilder.append("V.NAME AS VENUE_NAME, ");
        queryBuilder.append("V.OVERLAP AS VENUE_OVERLAP, ");
        queryBuilder.append("CSCHED.MIN_REQUIRED AS MIN_REQUIRED, ");
        queryBuilder.append("CSCHED.MAX_ALLOWED AS MAX_ALLOWED, ");
        queryBuilder.append("(SELECT COUNT(PARTICIPANT_ID) ");
        queryBuilder.append("FROM COURSE_PARTICIPANT ");
        queryBuilder.append("WHERE COURSE_SCHEDULE_ID = CSCHED.ID) AS TOTAL_PARTICIPANTS, ");
        queryBuilder.append("CSCHED.STATUS AS STATUS, ");
        queryBuilder.append("CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, ");
        queryBuilder.append("COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
        queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, ");
        queryBuilder.append("COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, ");
        queryBuilder.append("CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, ");
        queryBuilder.append("CSCHEDDET.DURATION AS DURATION ");
        queryBuilder.append("FROM COURSE_SCHEDULE AS CSCHED ");
        queryBuilder.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        queryBuilder.append("ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID ");
        queryBuilder.append("INNER JOIN COURSE AS C ");
        queryBuilder.append("ON CSCHED.COURSE_ID = C.ID ");
        queryBuilder.append("INNER JOIN COURSE_CATEGORY AS CC ");
        queryBuilder.append("ON C.COURSE_CATEGORY_ID = CC.ID ");
        queryBuilder.append("INNER JOIN EMPLOYEE AS E ");
        queryBuilder.append("ON CSCHED.INSTRUCTOR_ID = E.ID ");
        queryBuilder.append("INNER JOIN VENUE AS V ");
        queryBuilder.append("ON CSCHED.VENUE_ID = V.ID ");
        
        if(withTags) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM ");
            queryBuilder.append("ON CTM.course_id = C.ID ");
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR ");
            queryBuilder.append("ON MR.id = CTM.tag_id ");
            enrollmentDaoImpl.addTagsToConditionList(conditionList ,trainingPeriod.getMemberRole());
        }
        
        queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
        queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
        queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
        queryBuilder.append("AND TO_CHAR(CSCHED.COURSE_ID, 'FM9999') LIKE :courseNameId ");
        queryBuilder.append("AND TO_CHAR(CSCHED.INSTRUCTOR_ID, 'FM9999') LIKE :instructorId ");
        queryBuilder.append("AND TO_CHAR(CSCHED.VENUE_ID, 'FM9999') LIKE :venueId ");
        queryBuilder.append("AND CSCHED.STATUS LIKE :status ");
        
        if(withTags) {
            queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining()));
        }
        
        queryBuilder.append("ORDER BY ");
        queryBuilder.append(orderProperty);
        queryBuilder.append(" ");
        queryBuilder.append(order.getDirection());
        queryBuilder.append(" ");
        queryBuilder.append("LIMIT :pageSize OFFSET :pageOffset");

        if (trainingPeriod.getStatus() == null || trainingPeriod.getStatus().isEmpty()) {
            trainingPeriod.setStatus("%");
        }

        SqlParameterSource queryParams = new MapSqlParameterSource()
                .addValue("fromDateTime", trainingPeriod.getFromDateTimeTimezoneOnUTC())
                .addValue("toDateTime", trainingPeriod.getToDateTimeTimezoneOnUTC())
                .addValue("pageSize", pageable.getPageSize())
                .addValue("pageOffset", pageable.getOffset())
                .addValue("courseCategoryID", trainingPeriod.getCourseCategoryId())
                .addValue("courseNameId", trainingPeriod.getCourseNameId())
                .addValue("instructorId", trainingPeriod.getInstructorId())
                .addValue("venueId", trainingPeriod.getVenueId())
                .addValue("status", trainingPeriod.getStatus());

        List<CourseSchedule> courseSchedules = template.query(queryBuilder.toString(), queryParams,
                new CourseScheduleRowMapper());

        return new LinkedHashSet<>(courseSchedules);
    }
     
    @Override
    public int countAllScheduledCoursesWithinPeriod(TrainingPeriod trainingPeriod) {
        
        try {
            StringBuilder queryBuilder = new StringBuilder();
            List<String> conditionList = new LinkedList<>();
            boolean withTags = (trainingPeriod.getMemberRole() != null && !trainingPeriod.getMemberRole().isEmpty());
            
            queryBuilder.append("SELECT COUNT(DISTINCT COURSE_SCHEDULE_ID) ");
            queryBuilder.append("FROM COURSE_SCHEDULE AS CSCHED ");
            queryBuilder.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
            queryBuilder.append("ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID ");
            queryBuilder.append("INNER JOIN COURSE AS C ");
            queryBuilder.append("ON CSCHED.COURSE_ID = C.ID ");
            queryBuilder.append("INNER JOIN EMPLOYEE AS E ");
            queryBuilder.append("ON CSCHED.INSTRUCTOR_ID = E.ID ");
            queryBuilder.append("INNER JOIN VENUE AS V ");
            queryBuilder.append("ON CSCHED.VENUE_ID = V.ID ");
            queryBuilder.append("INNER JOIN COURSE_CATEGORY AS CC ");
            queryBuilder.append("ON C.COURSE_CATEGORY_ID = CC.ID ");
            
            if(withTags) {
                queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM ");
                queryBuilder.append("ON CTM.course_id = C.ID ");
                queryBuilder.append("INNER JOIN MEMBER_ROLE MR ");
                queryBuilder.append("ON MR.id = CTM.tag_id ");
                enrollmentDaoImpl.addTagsToConditionList(conditionList ,trainingPeriod.getMemberRole());
            }
            
            queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
            queryBuilder.append("AND TO_CHAR(CSCHED.COURSE_ID, 'FM9999') LIKE :courseNameId ");
            queryBuilder.append("AND TO_CHAR(CSCHED.INSTRUCTOR_ID, 'FM9999') LIKE :instructorId ");
            queryBuilder.append("AND TO_CHAR(CSCHED.VENUE_ID, 'FM9999') LIKE :venueId ");
            queryBuilder.append("AND CSCHED.STATUS LIKE :status ");
            
            if(withTags) {
                queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining()));
            }
            
            if (trainingPeriod.getStatus() == null || trainingPeriod.getStatus().isEmpty()) {
                trainingPeriod.setStatus("%");
            }

            SqlParameterSource paramSource = new MapSqlParameterSource()
                    .addValue("fromDateTime", trainingPeriod.getFromDateTimeTimezoneOnUTC())
                    .addValue("toDateTime", trainingPeriod.getToDateTimeTimezoneOnUTC())
                    .addValue("courseCategoryID", trainingPeriod.getCourseCategoryId())
                    .addValue("courseNameId", trainingPeriod.getCourseNameId())
                    .addValue("instructorId", trainingPeriod.getInstructorId())
                    .addValue("venueId", trainingPeriod.getVenueId())
                    .addValue("status", trainingPeriod.getStatus());

            return template.queryForObject(queryBuilder.toString(), paramSource, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    private String getScheduleSortOrder(Order order) {
        switch(order.getProperty()) {
            case "toDate":              return "SCHEDULED_END_DATETIME";
            case "fromDate":            return "SCHEDULED_START_DATETIME";
            case "courseName":          return "COURSE_NAME";
            case "instructorName":      return "INSTRUCTOR_LAST_NAME";
            case "venueName":           return "VENUE_NAME";
            case "duration":            return "DURATION";
            case "minAllowed":          return "MIN_REQUIRED";
            case "maxAllowed":          return "MAX_ALLOWED";
            case "totalParticipants":   return "TOTAL_PARTICIPANTS";
            case "courseCategory":      return "COURSE_CATEGORY";
            case "mandatory":           return "MANDATORY";
            case "mandatoryType":       return "MANDATORY_TYPE";
            case "status":              return "STATUS";
            default:                    return "SCHEDULED_START_DATETIME";
        }
    }
}

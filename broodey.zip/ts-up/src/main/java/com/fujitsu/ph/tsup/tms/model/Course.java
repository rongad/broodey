package com.fujitsu.ph.tsup.tms.model;

import java.util.Date;

public class Course {
	private String courseID;
	private String courseName;
	private String courseOrigin;
	private String courseStatus;
	private Date courseStartedDate;
	private Date courseAcquiredDate;
	private Date courseCompletedDate;
	private Date courseAssignedDate;;

	private Employee courseEmployeeAssigned;
	

	public Date getCourseAssignedDate() {
		return courseAssignedDate;
	}



	public void setCourseAssignedDate(Date courseAssignedDate) {
		this.courseAssignedDate = courseAssignedDate;
	}



	public String getCourseID() {
		return courseID;
	}



	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}



	public String getCourseName() {
		return courseName;
	}



	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}



	public String getCourseOrigin() {
		return courseOrigin;
	}



	public void setCourseOrigin(String courseOrigin) {
		this.courseOrigin = courseOrigin;
	}



	public String getCourseStatus() {
		return courseStatus;
	}



	public void setCourseStatus(String courseStatus) {
		this.courseStatus = courseStatus;
	}



	public Date getCourseStartedDate() {
		return courseStartedDate;
	}



	public void setCourseStartedDate(Date courseStartedDate) {
		this.courseStartedDate = courseStartedDate;
	}



	public Date getCourseAcquiredDate() {
		return courseAcquiredDate;
	}



	public void setCourseAcquiredDate(Date courseAcquiredDate) {
		this.courseAcquiredDate = courseAcquiredDate;
	}



	public Date getCourseCompletedDate() {
		return courseCompletedDate;
	}



	public void setCourseCompletedDate(Date courseCompletedDate) {
		this.courseCompletedDate = courseCompletedDate;
	}



	public Employee getCourseEmployeeAssigned() {
		return courseEmployeeAssigned;
	}



	public void setCourseEmployeeAssigned(Employee courseEmployeeAssigned) {
		this.courseEmployeeAssigned = courseEmployeeAssigned;
	}



	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Course(String courseID, String courseName, String courseOrigin, String courseStatus, Date courseStartedDate,
			Date courseAcquiredDate, Date courseCompletedDate, Date courseAssignedDate,
			Employee courseEmployeeAssigned) {
		super();
		this.courseID = courseID;
		this.courseName = courseName;
		this.courseOrigin = courseOrigin;
		this.courseStatus = courseStatus;
		this.courseStartedDate = courseStartedDate;
		this.courseAcquiredDate = courseAcquiredDate;
		this.courseCompletedDate = courseCompletedDate;
		this.courseAssignedDate = courseAssignedDate;
		this.courseEmployeeAssigned = courseEmployeeAssigned;
	}





}

package com.fujitsu.ph.tsup.common.domain;

/**
 * @author j.macabudbud
 *
 */
public enum Auth {
	PMO, INSTRUCTOR, MEMBER
}

/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.model;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : ResponseResult.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

public class ResponseResult {

    private Number countOfTotallyDisagree;
    private Number countOfDisagree;
    private Number countOfAgree;
    private Number countOfTotallyAgree;
    private Number countOfnonApplicable;
    
    private ResponseResult(Number sumOfTotallyDisagree, Number sumOfDisagree, Number sumOfAgree, Number sumOftotallyAgree,
            Number sumOfnonApplicable) {
        super();
        this.countOfTotallyDisagree = sumOfTotallyDisagree;
        this.countOfDisagree = sumOfDisagree;
        this.countOfAgree = sumOfAgree;
        this.countOfTotallyAgree = sumOftotallyAgree;
        this.countOfnonApplicable = sumOfnonApplicable;
    }
    
    
    public static ResponseResult of (Number sumOfTotallyDisagree, Number sumOfDisagree, Number sumOfAgree, Number sumOftotallyAgree,
            Number sumOfnonApplicable) {
        return new ResponseResult(sumOfTotallyDisagree,sumOfDisagree,sumOfAgree,sumOftotallyAgree,sumOfnonApplicable);
    }


    /**
     * @return the countOfTotallyDisagree
     */
    public Number getCountOfTotallyDisagree() {
        return countOfTotallyDisagree;
    }


    /**
     * @return the countOfDisagree
     */
    public Number getCountOfDisagree() {
        return countOfDisagree;
    }


    /**
     * @return the countOfAgree
     */
    public Number getCountOfAgree() {
        return countOfAgree;
    }


    /**
     * @return the countOftotallyAgree
     */
    public Number getCountOfTotallyAgree() {
        return countOfTotallyAgree;
    }


    /**
     * @return the countOfnonApplicable
     */
    public Number getCountOfnonApplicable() {
        return countOfnonApplicable;
    }
    
}

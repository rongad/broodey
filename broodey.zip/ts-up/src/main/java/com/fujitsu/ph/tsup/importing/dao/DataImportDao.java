//==================================================================================================
//Project Name : Training Sign Up Project
//System Name  : Training Sign Up Project
//Class Name   : DataImportDao.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/10/13 | WS)j.lugtu            | Initial Version
//0.02    | 2021/10/13 | WS)j.lazo             | Added saveSabaImport
//==================================================================================================
package com.fujitsu.ph.tsup.importing.dao;

import java.util.Set;

import com.fujitsu.ph.tsup.importing.model.SabaDTO;

/**
 * <pre>
 * Dao Interface for Data Import
 * </pre>
 * 
 * @author WS)J.Lugtu
 * @version 0.02
 */
public interface DataImportDao {
    /**
     * <pre>
     * Method for loading all employee emails
     * </pre>
     * 
     * @param emeail address
     * @return Set<String>
     */
    Set<String> loadAllUserEmail();

    /**
     * Saves SABA Import data for the following tables:
     * course_attendance
     * course_participant
     * course_schedule
     * course_schedule_detail
     * 
     * @param dto SabaDTO to process
     */
    public void saveSabaImport(SabaDTO dto);

}

/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

//==================================================================================================
// Project Name : Training Sign Up
// System Name  : Summary Reports
// Class Name   : ReportUtils.java
//
// <<Modification History>>
// Version | Date       | Updated By            | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/10/21 | WS) dw.cardenas       | New Creation
//==================================================================================================

/**
* <pre>
* Utilities class for the Reports system.
* <pre>
* 
* @version 0.01
* @author dw.cardenas
*/
public final class ReportUtils {

    /**
     * <pre>
     * Private constructor for ReportUtils.
     * Must not be called since this is a utility class
     * <pre>
     */
    private ReportUtils() {
        throw new UnsupportedOperationException();
    }

    /**
     * <pre>
     * Calculates the completion percentage of based from provided count of members who finished
     * and total count of members.
     * <pre>
     * 
     * @param membersFinished
     * @param memberCount
     * @return
     */
    public static BigDecimal calculateCompletionPercentage(Long membersFinished, Long memberCount) {
        final MathContext mc = new MathContext(4, RoundingMode.HALF_UP);
        final BigDecimal ONE_HUNDRED = BigDecimal.valueOf(100);
        BigDecimal finished = BigDecimal.valueOf(membersFinished);
        BigDecimal count = BigDecimal.valueOf(memberCount);

        return finished.divide(count, mc).multiply(ONE_HUNDRED, mc);
    }
}

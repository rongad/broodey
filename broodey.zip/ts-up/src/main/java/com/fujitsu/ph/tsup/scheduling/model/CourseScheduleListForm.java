package com.fujitsu.ph.tsup.scheduling.model;

import java.time.LocalDateTime;

//=======================================================
//$Id: PR02$
//Project Name: Training Sign Up
//Class Name: CourseScheduleListForm.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 06/22/2020 | WS) J.Macabugao  | New Creation
//0.02    | 08/05/2021 | WS) MI.Aguinaldo | Update
//0.03    | 09/07/2021 | WS) RU.delaCuz   | Update
//0.03    | 09/07/2021 | WS) L.Celoso     | Update
//=======================================================

/**
* <pre>
* It is a JavaBean for CourseScheduleListForm
* <pre>
* @version 0.01
* @author j.macabugao
*
*/
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;

import com.fujitsu.ph.tsup.pagination.Paged;

public class CourseScheduleListForm {

    /**
     *  Start Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime fromDateTime;
    
    /**
     *  End Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime toDateTime;
    
    /**
     * From Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    private ZonedDateTime fromDateTimeZone;

    /**
     * To Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    private ZonedDateTime toDateTimeZone;
	
    private Set<CourseScheduleViewForm> courseSchedules;
    
	private Paged<CourseScheduleViewForm> paginatedCourse;
    
    /* Filter course category ID */
    private String courseCategoryId;

    /* Filter course name ID */
    private String courseNameId;
    
    /* Filter venue ID */
    private String venueId;

    /* Filter instructor ID */
    private String instructorId;
    
    /* Filter mandatory */
    private String mandatory;
    
    /* Filter mandatory type */
    private String mandatoryType;

    /* Filter Tags */
    private String memberRole;

    /**
     * Total count of trainigs today
     */
    private int totalTrainings;

    /**
     * Monthly top learners
     */
    private List<TopLearnersForm> monthlyTopLearners;

    /**
     * Quarterly top learners
     */
    private List<TopLearnersForm> quarterlyTopLearners;
    
    private Page<CourseScheduleViewForm> paginatedCourseSchedules;
    
    /**
     * Paged course schedules
     */
    private Paged<CourseScheduleViewForm> pagedCourseSchedules;
    
    public ZonedDateTime getFromDateTimeZone() {
        return fromDateTimeZone;
    }

    public void setFromDateTimeZone(ZonedDateTime fromDateTimeZone) {
        this.fromDateTimeZone = fromDateTimeZone;
    }

    public ZonedDateTime getToDateTimeZone() {
        return toDateTimeZone;
    }

    public void setToDateTimeZone(ZonedDateTime toDateTimeZone) {
        this.toDateTimeZone = toDateTimeZone;
    }
    
    public LocalDateTime getFromDateTime() {
        return fromDateTime;
    }

    public void setFromDateTime(LocalDateTime fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    public LocalDateTime getToDateTime() {
        return toDateTime;
    }

    public void setToDateTime(LocalDateTime toDateTime) {
        this.toDateTime = toDateTime;
    }

    public int getTotalTrainings() {
	return totalTrainings;
    }

    public void setTotalTrainings(int totalTrainings) {
	this.totalTrainings = totalTrainings;
    }

    public List<TopLearnersForm> getMonthlyTopLearners() {
	return monthlyTopLearners;
    }

    public void setMonthlyTopLearners(List<TopLearnersForm> monthlyTopLearners) {
	this.monthlyTopLearners = monthlyTopLearners;
    }

    public List<TopLearnersForm> getQuarterlyTopLearners() {
	return quarterlyTopLearners;
    }

    public void setQuarterlyTopLearners(List<TopLearnersForm> quarterlyTopLearners) {
	this.quarterlyTopLearners = quarterlyTopLearners;
    }

    public Set<CourseScheduleViewForm> getCourseSchedules() {
	return courseSchedules;
    }

    public void setCourseSchedules(Set<CourseScheduleViewForm> courseSchedules) {
	this.courseSchedules = courseSchedules;
    }
    
    public Page<CourseScheduleViewForm> getPaginatedCourseSchedules() {
        return paginatedCourseSchedules;
    }
    
    public String getInstructorId() {
        return instructorId;
    } 
    
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    } 

    public void setPaginatedCourseSchedules(Page<CourseScheduleViewForm> paginatedCourseSchedules) {
        this.paginatedCourseSchedules = paginatedCourseSchedules;
    }
    
    /**
     * <pre>
     * Get course schedules and store as Paged
     * </pre>
     * 
     * @return Paged
     */
	public Paged<CourseScheduleViewForm> getPagedCourseSchedules() {
		return pagedCourseSchedules;
	}

    /**
     * <pre>
     * Set paged course schedules
     * </pre>
     * 
     * @param pagedCourseSchedules
     */
	public void setPagedCourseSchedules(Paged<CourseScheduleViewForm> pagedCourseSchedules) {
		this.pagedCourseSchedules = pagedCourseSchedules;
	}

	public Paged<CourseScheduleViewForm> getPaginatedCourse() {
		return paginatedCourse;
	}

	public void setPaginatedCourse(Paged<CourseScheduleViewForm> paginatedCourse) {
		this.paginatedCourse = paginatedCourse;
	}
    
    /** Filter course category ID Getter */
    public String getCourseCategoryId() {
        return courseCategoryId;
    }

    /** Filter course category ID Setter */
    public void setCourseCategoryId(String courseCategoryId) {
        this.courseCategoryId = courseCategoryId;
    }
    
    /** Filter course name ID Getter */
    public String getCourseNameId() {
        return courseNameId;
    }

    /** Filter course name ID Setter */
    public void setCourseNameId(String courseNameId) {
        this.courseNameId = courseNameId;
    }
    
    /** Filter venue ID Getter */
    public String getVenueId() {
        return venueId;
    }

    /** Filter venue ID Setter */
    public void setVenueId(String venueId) {
        this.venueId = venueId;
    }
    
    /** Filter Mandatory Getter */
    public String getMandatory() {
        return mandatory;
    }

    /** Filter Mandatory Setter */
    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }
    
    /** Filter Mandatory Type Getter */
    public String getMandatoryType() {
        return mandatoryType;
    }

    /** Filter Mandatory Type Setter */
    public void setMandatoryType(String mandatoryType) {
        this.mandatoryType = mandatoryType;
    }
    
    /** Filter Member Role Getter */
    public String getMemberRole() {
        return memberRole;
    }

    /** Filter Member Role Setter */
    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }

    @Override
    public String toString() {
	return "CourseScheduleListForm [fromDateTime=" + fromDateTime 
		+ ", toDateTime=" + toDateTime
		+ ", totalTrainings=" + totalTrainings 
		+ ", monthlyTopLearners=" + monthlyTopLearners
		+ ", quarterlyTopLearners=" + quarterlyTopLearners 
		+ ", courseSchedules=" + courseSchedules 
        + ", courseCategoryId=" + courseCategoryId
        + ", courseNameId=" + courseNameId
        + ", venueId=" + venueId
        + ", mandatory=" + mandatory
        + ", mandatoryType=" + mandatoryType
		+ "]";
    }
}

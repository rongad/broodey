/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.course.model.Course.Builder;
import com.fujitsu.ph.tsup.department.domain.Department;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Course Management
//Class Name   : CourseRowMapper.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2020/08/28 | WS) c.lepiten         | Initial Version
//0.02    | 2021/04/19 | WS) st.diaz           | Updated
//0.03    | 2021/05/10 | WS) D.Escala          | Updated
//0.04    | 2021/05/28 | WS) mi.aguinaldo      | Updated
//0.05    | 2021/07/21 | WS) mi.aguinaldo      | Updated
//0.06    | 2021/09/07 | WS) mi.aguinaldo      | Updated
//0.07    | 2021/10/13  | WS) l.celoso         | Adding Tags in filter search
//==================================================================================================

public class CourseRowMapper implements RowMapper<Course> {

    @Override
    public Course mapRow(ResultSet rs, int rowNum) throws SQLException {

        Long id = rs.getLong("id");
        String name = rs.getString("name");
        String detail = rs.getString("detail");
        String isMandatory = rs.getString("mandatory");
        String deadline = rs.getString("deadline");
        Long courseCategoryId = rs.getLong("course_category_id");
        String madatoryType = rs.getString("mandatory_type");
        Long departmentId = rs.getLong("department_id");
        String courseCode = rs.getString("course_code");
        String memberRole = "";
        
        if (hasColumn(rs, "role_type")) {
            memberRole = rs.getString("role_type");
        }
        
    	Builder coursBuilder = Course.builder()
    				     .withId(id)
    				     .withName(name)
    				     .withDetail(detail)
    				     .withIsMandatory(isMandatory)
    				     .withDeadline(deadline)
    				     .withCourseCategoryId(courseCategoryId)
    				     .withMandatoryType(madatoryType)
    				     .withDepartmentId(departmentId)
    				     .withCourseCode(courseCode)
                         .withMemberRole(memberRole);
    
    	
    	if (hasColumn(rs, "category")) {
    	    String category = rs.getString("category");
    	    CourseCategory courseCategory = CourseCategory.builder()
    	            .addId(courseCategoryId)
    	            .addCategory(category)
    	            .build();
    	    
    	    coursBuilder.withCourseCategory(courseCategory);
    			 
    	}
    	if (hasColumn(rs, "department_name")) {
    	    String departmentName = rs.getString("department_name");
    	    Department department = Department.builder()
    					      .addId(departmentId)
    					      .addDepartmentName(departmentName)
    					      .build();
    	    
    	   coursBuilder.withDepartment(department);
    	}
    	
	    return coursBuilder.build();
    }
    
    private static boolean hasColumn(ResultSet rs, String columnName) throws SQLException {
    	ResultSetMetaData rsmd = rs.getMetaData();
    	int columns = rsmd.getColumnCount();
    	for (int x = 1; x <= columns; x++) {
    	    if (columnName.equals(rsmd.getColumnName(x))) {
    		return true;
    	    }
    	}
    	return false;
    }
}

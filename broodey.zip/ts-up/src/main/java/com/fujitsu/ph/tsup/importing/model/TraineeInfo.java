/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.importing.model;

import java.util.Objects;

import com.opencsv.bean.CsvBindByName;

// ==================================================================================================
// Project Name : Training Sign Up
// Class Name : TraineeInfo.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/08/19 | WS) mi.aguinaldo | Initial Version
// 0.02 | 2021/10/14 | WS) j.lazo       | Added timeSpent field
// ==================================================================================================

public class TraineeInfo {
    @CsvBindByName(column = "First Name")
    private String firstName;

    @CsvBindByName(column = "Last Name")
    private String lastName;

    @CsvBindByName(column = "E-mail")
    private String email;

    @CsvBindByName(column = "Completion Date")
    private String completionDate;

    @CsvBindByName(column = "Time Spent in Class (Minutes)")
    private String timeSpent;

    public TraineeInfo() {
        super();
    }

    private TraineeInfo(Builder builder) {
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.email = builder.email;
        this.completionDate = builder.completionDate;
        this.timeSpent = builder.timeSpent;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the completionDate
     */
    public String getCompletionDate() {
        return completionDate;
    }

    /**
     * @param completionDate the completionDate to set
     */
    public void setCompletionDate(String completionDate) {
        this.completionDate = completionDate;
    }

    /**
     * @return the timeSpent
     */
    public String getTimeSpent() {
        return timeSpent;
    }

    /**
     * @param timeSpent the timeSpent to set
     */
    public void setTimeSpent(String timeSpent) {
        this.timeSpent = timeSpent;
    }

    public boolean isValid() {
        return Objects.nonNull(firstName) && Objects.nonNull(lastName) && Objects.nonNull(email)
                && Objects.nonNull(completionDate) && Objects.nonNull(timeSpent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(email);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TraineeInfo other = (TraineeInfo) obj;
        return Objects.equals(email, other.email);
    }

    @Override
    public String toString() {
        return "TraineeInfo [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
                + ", completionDate=" + completionDate + ", timeSpent=" +timeSpent + "]";
    }

    /**
     * Creates builder to build {@link TraineeInfo}.
     * 
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link TraineeInfo}.
     */
    public static final class Builder {
        private String firstName;
        private String lastName;
        private String email;
        private String completionDate;
        private String timeSpent;

        private Builder() {
        }

        public Builder withFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withEmail(String email) {
            this.email = email;
            return this;
        }

        public Builder withCompletionDate(String completionDate) {
            this.completionDate = completionDate;
            return this;
        }

        public Builder withTimeSpent(String timeSpent) {
            this.timeSpent = timeSpent;
            return this;
        }

        public TraineeInfo build() {
            return new TraineeInfo(this);
        }
    }

}

package com.fujitsu.ph.tsup.courserequirement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import com.fujitsu.ph.tsup.courserequirement.model.CourseSchedule;
import com.fujitsu.ph.tsup.courserequirement.model.CourseScheduleDetail;

import org.springframework.jdbc.core.RowMapper;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : Course Checklist
 * Class Name   : CourseScheduleDetailRowMapper.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * ===================================================================================================
 */

 /**
 * <pre>
 * The Row Mapper for  Course Schedule Detail
 * 
 * <pre>
 * 
 * @version 0.01
 * @author e.delosreyes
 */

public class CourseScheduleDetailRowMapper implements RowMapper<CourseScheduleDetail> {

    @Override
    public CourseScheduleDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
        CourseSchedule courseSchedule = new CourseSchedule();
        courseSchedule.setId(rs.getInt("course_schedule_id"));
        CourseScheduleDetail courseScheduleDetail = new CourseScheduleDetail();
        courseScheduleDetail.setId(rs.getLong("id"));
        courseScheduleDetail.setScheduledStart( ZonedDateTime.ofInstant(rs.getTimestamp("SCHEDULED_START_DATETIME").toInstant(),
        ZoneId.systemDefault()));
        courseScheduleDetail.setScheduledEnd( ZonedDateTime.ofInstant(rs.getTimestamp("SCHEDULED_END_DATETIME").toInstant(),
        ZoneId.systemDefault()));
        courseScheduleDetail.setDuration(rs.getInt("duration"));
        courseScheduleDetail.setCourseSchedule(courseSchedule);
        return courseScheduleDetail;
    }
    
}

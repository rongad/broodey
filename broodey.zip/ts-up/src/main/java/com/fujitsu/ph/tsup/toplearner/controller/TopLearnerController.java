package com.fujitsu.ph.tsup.toplearner.controller;

import java.time.ZonedDateTime;
import java.util.List;

import com.fujitsu.ph.tsup.enrollment.model.TopLearnerForm;
import com.fujitsu.ph.tsup.toplearner.service.TopLearnerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** ==================================================================================================
  * Id:PR32
  * Project Name :Training Sign Up
  * System Name : Top Learners
  * Class Name : TopLearnerController.java
  *
  * <<Modification History>>
  * Version | Date       | Updated By         | Content
  * --------+------------+-----------------------+---------------------------------------------------
  * 0.01    | 12/29/2021 | WS) ep.delosreyes  | Initial Create
  * ==================================================================================================
  */

@RestController
@RequestMapping("/topLearner")
public class TopLearnerController {

    @Autowired
    private TopLearnerService topLearnerService;

	/**
	 * Returns the list of top learners for the month Method: GET
	 *
	 * @param numberOfResult
	 * @return ResponseEntity and List<TopLearnerForm>
     * @author WS)ep.delosreyes
	 */
    @GetMapping("/getTopLearnersByMonth")
	public ResponseEntity<List<TopLearnerForm>> getTopLearnersByMonth(int numberOfResult){
        List<TopLearnerForm> listTopLearnerByMonth = topLearnerService.findTopLearner(ZonedDateTime.now(),
        ZonedDateTime.now().plusMonths(1), numberOfResult);
        return new ResponseEntity<>(listTopLearnerByMonth, HttpStatus.OK);
	}

     /**
	 * <pre>
	 * Returns the list of top learners for the quarter Method: GET
	 * <pre>
	 *
	 * @param numberOfResult
	 * @return ResponseEntity and List<TopLearnerForm>
     * @author WS)ep.delosreyes
	 */
    @GetMapping("/getTopLearnersByQuarter")
	public ResponseEntity<List<TopLearnerForm>> getTopLearnersByQuarter(Integer numberOfResult){
        List<TopLearnerForm> listTopLearnerByQuarter = topLearnerService.findTopLearner(ZonedDateTime.now(),
        ZonedDateTime.now().plusMonths(4), numberOfResult); 
        return new ResponseEntity<>(listTopLearnerByQuarter, HttpStatus.OK);
	}
}

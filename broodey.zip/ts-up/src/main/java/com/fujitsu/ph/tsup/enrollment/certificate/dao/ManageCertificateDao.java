/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.enrollment.certificate.dao;

import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.enrollment.certificate.model.ManageCertificate;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;

//=======================================================
//Project Name: Training Sign Up
//Class Name: ManageCertificateDao.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 11/08/2021 | WS) k.mutia  | Created
//=======================================================

/**
*
* @author k.mutia
*
*/
public interface ManageCertificateDao { 

    // Method for find all Certificates base on Pageable object provided
    Set<ManageCertificate> loadAllCertificates(Pageable pageable);
    
    // Method for deleting Certificate by Id
    Boolean deleteCertificateById(Long id);
    
    // Method for counting certificate
    int countCertificates();

    // Method for downloading Certificate by userId and courseID
    String getCertificateDownloadUri(Long userId, Long courseId);

    // Method for updating Certificate
    Boolean updateCertificate(Certificate certificate);
    
}

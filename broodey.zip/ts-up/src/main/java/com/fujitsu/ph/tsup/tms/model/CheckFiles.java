package com.fujitsu.ph.tsup.tms.model;

import java.util.ArrayList;
import java.util.List;

public class CheckFiles {
	
	private boolean tmsDirectoryExist;
	private boolean employeeListFileExist;
	private boolean courseListFileExist;
	private boolean linkedInFileExist;
	private boolean sabaFileExist;
	private String message;
	private boolean disableMenu = false;
	private List<String> requiredFiles = new ArrayList<String>();
	
	public boolean isTmsDirectoryExist() {
		return tmsDirectoryExist;
	}
	public void setTmsDirectoryExist(boolean tmsDirectoryExist) {
		this.tmsDirectoryExist = tmsDirectoryExist;
	}
	public boolean isEmployeeListFileExist() {
		return employeeListFileExist;
	}
	public void setEmployeeListFileExist(boolean employeeListFileExist) {
		this.employeeListFileExist = employeeListFileExist;
	}
	public boolean isCourseListFileExist() {
		return courseListFileExist;
	}
	public void setCourseListFileExist(boolean courseListFileExist) {
		this.courseListFileExist = courseListFileExist;
	}
	public boolean isLinkedInFileExist() {
		return linkedInFileExist;
	}
	public void setLinkedInFileExist(boolean linkedInFileExist) {
		this.linkedInFileExist = linkedInFileExist;
	}
	public boolean isSabaFileExist() {
		return sabaFileExist;
	}
	public void setSabaFileExist(boolean sabaFileExist) {
		this.sabaFileExist = sabaFileExist;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isDisableMenu() {
		return disableMenu;
	}
	public void setDisableMenu(boolean disableMenu) {
		this.disableMenu = disableMenu;
	}
	public List<String> getRequiredFiles() {
		return requiredFiles;
	}
	public void setRequiredFiles(List<String> requiredFiles) {
		this.requiredFiles = requiredFiles;
	}
	
}

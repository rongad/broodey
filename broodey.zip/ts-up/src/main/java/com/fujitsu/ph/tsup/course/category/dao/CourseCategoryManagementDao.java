/**
 * 
 */
package com.fujitsu.ph.tsup.course.category.dao;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;

// =======================================================
// $Id: PR10$
// Project Name: Training Sign Up
// System Name : Course Category Management Process
// Class Name: CourseCategoryManagementDao.java
//
//<<Modification History>>
//Version | Date       | Updated by          | Content
//--------+------------+---------------------+---------------
//0.01    | 02/08/2020 | WS) A.Batongbacal   | New Creation
//0.02    | 02/15/2020 | WS) A.Batongbacal   | Update
//0.03    | 02/24/2020 | WS) R.Rivero        | Update
//0.04    | 02/24/2020 | WS) J.Lira          | Update
//0.05    | 02/24/2020 | WS) R.Piloto        | Update
//0.06	  | 07/09/2021 | WS) R.Gaquit		 | Update
//0.07    | 09/02/2021 | WS) DW.Cardenas     | Update
//0.07    | 09/07/2021 | WS) MI.Aguinaldo    | Update
//0.07    | 09/09/2021 | WS) D.Dinglasan     | Update
//=======================================================
/**
* <pre>
* The interface of Course Category Management Dao
* 
* <pre>
* 
* @version 0.07
* @author a.batongbacal
* @author r.rivero
* @author j.lira
* @author r.piloto
* @author r.gaquit
* @author d.dinglasan
*
*/
public interface CourseCategoryManagementDao {

    void updateCourseCategory(CourseCategory courseCategory);

    // Method for searching course category by category
    Set<CourseCategory> findCourseCategoryByName(String name);

    // Method for creating course categories
    void createCourseCategory(CourseCategory courseCategory);

    // Method for loading all course category in Course Category View
    Set<CourseCategory> findAllCourseCategory();

    // Method for loading all course category in Course Category View with @Param page
    Set<CourseCategory> findAllCourseCategory(Pageable pageable);
    
    // Method for loading and searching course category in Course Category View
    List<CourseCategory> findCourseCategory(String byKeyword, Pageable pageable);
    
    //counts the number of items in database
    int countCourseCategory();
    
    //counts the number of items in database by keyword
    int countCourseCategory(String byKeyword);

    // Method for finding Course Category by Id
    CourseCategory findCourseCategoryById(Long id);

    // Method for deleting Course Category by Id
    void deleteCourseCategoryById(Long id);

    List<CourseCategory> findCourseCategoryByName(String searchKey, Pageable pageable);

    int countFilteredCourseCategories(String searchKey);

    // Method for batch creating course categories
    int[] batchCreateCourseCategory(List<CourseCategory> categories);
}

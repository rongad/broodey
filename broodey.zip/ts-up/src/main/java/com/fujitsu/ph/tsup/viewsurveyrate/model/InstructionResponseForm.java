/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.model;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : InstructionResponseForm.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

import java.util.Objects;

public class InstructionResponseForm {
    private int question1TotallyDisagree;
    private int question1Disagree;
    private int question1Agree;
    private int question1TotallyAgree;
    private int question1NotApplicable;
    
    private int question2TotallyDisagree;
    private int question2Disagree;
    private int question2Agree;
    private int question2TotallyAgree;
    private int question2NotApplicable;
    
    
    private int question3TotallyDisagree;
    private int question3Disagree;
    private int question3Agree;
    private int question3TotallyAgree;
    private int question3NotApplicable;
    
    
    private int question4TotallyDisagree;
    private int question4Disagree;
    private int question4Agree;
    private int question4TotallyAgree;
    private int question4NotApplicable;
    
    private int question5TotallyDisagree;
    private int question5Disagree;
    private int question5Agree;
    private int question5TotallyAgree;
    private int question5NotApplicable;
    
    private int question6TotallyDisagree;
    private int question6Disagree;
    private int question6Agree;
    private int question6TotallyAgree;
    private int question6NotApplicable;
    
    private double question1Ratings;
    private double question2Ratings;
    private double question3Ratings;
    private double question4Ratings;
    private double question5Ratings;
    private double question6Ratings;
    
    private double average;

    public InstructionResponseForm() {
    }
    
    
    public static InstructionResponseForm ofResponseResults(ResponseResult question1,
            ResponseResult question2, ResponseResult question3, ResponseResult question4,
            ResponseResult question5, ResponseResult question6) {
        Objects.requireNonNull(question1);
        Objects.requireNonNull(question2);
        Objects.requireNonNull(question3);
        Objects.requireNonNull(question4);
        Objects.requireNonNull(question5);
        Objects.requireNonNull(question6);
        
        return new InstructionResponseForm(question1, question2, question3, question4,question5,question6);
    }
    
    private InstructionResponseForm(ResponseResult question1, ResponseResult question2,
            ResponseResult question3, ResponseResult question4, ResponseResult question5,
            ResponseResult question6) {
        this.question1TotallyDisagree = question1.getCountOfTotallyDisagree().intValue();
        this.question1Disagree = question1.getCountOfDisagree().intValue();
        this.question1Agree = question1.getCountOfAgree().intValue();
        this.question1TotallyAgree = question1.getCountOfTotallyAgree().intValue();
        this.question1NotApplicable = question1.getCountOfnonApplicable().intValue();
        
        this.question2TotallyDisagree = question2.getCountOfTotallyDisagree().intValue();
        this.question2Disagree = question2.getCountOfDisagree().intValue();
        this.question2Agree = question2.getCountOfAgree().intValue();
        this.question2TotallyAgree = question2.getCountOfTotallyAgree().intValue();
        this.question2NotApplicable = question2.getCountOfnonApplicable().intValue();
        
        this.question3TotallyDisagree = question3.getCountOfTotallyDisagree().intValue();
        this.question3Disagree = question3.getCountOfDisagree().intValue();
        this.question3Agree = question3.getCountOfAgree().intValue();
        this.question3TotallyAgree = question3.getCountOfTotallyAgree().intValue();
        this.question3NotApplicable = question3.getCountOfnonApplicable().intValue();
        
        
        this.question4TotallyDisagree = question4.getCountOfTotallyDisagree().intValue();
        this.question4Disagree = question4.getCountOfDisagree().intValue();
        this.question4Agree = question4.getCountOfAgree().intValue();
        this.question4TotallyAgree = question4.getCountOfTotallyAgree().intValue();
        this.question4NotApplicable = question4.getCountOfnonApplicable().intValue();
        
        this.question5TotallyDisagree = question5.getCountOfTotallyDisagree().intValue();
        this.question5Disagree = question5.getCountOfDisagree().intValue();
        this.question5Agree = question5.getCountOfAgree().intValue();
        this.question5TotallyAgree = question5.getCountOfTotallyAgree().intValue();
        this.question5NotApplicable = question5.getCountOfnonApplicable().intValue();
        
        this.question6TotallyDisagree = question6.getCountOfTotallyDisagree().intValue();
        this.question6Disagree = question6.getCountOfDisagree().intValue();
        this.question6Agree = question6.getCountOfAgree().intValue();
        this.question6TotallyAgree = question6.getCountOfTotallyAgree().intValue();
        this.question6NotApplicable = question6.getCountOfnonApplicable().intValue();
     
    }
    

    private InstructionResponseForm(Builder builder) {
        this.question1TotallyDisagree = builder.question1TotallyDisagree;
        this.question1Disagree = builder.question1Disagree;
        this.question1Agree = builder.question1Agree;
        this.question1TotallyAgree = builder.question1TotallyAgree;
        this.question1NotApplicable = builder.question1NotApplicable;
        this.question2TotallyDisagree = builder.question2TotallyDisagree;
        this.question2Disagree = builder.question2Disagree;
        this.question2Agree = builder.question2Agree;
        this.question2TotallyAgree = builder.question2TotallyAgree;
        this.question2NotApplicable = builder.question2NotApplicable;
        this.question3TotallyDisagree = builder.question3TotallyDisagree;
        this.question3Disagree = builder.question3Disagree;
        this.question3Agree = builder.question3Agree;
        this.question3TotallyAgree = builder.question3TotallyAgree;
        this.question3NotApplicable = builder.question3NotApplicable;
        this.question4TotallyDisagree = builder.question4TotallyDisagree;
        this.question4Disagree = builder.question4Disagree;
        this.question4Agree = builder.question4Agree;
        this.question4TotallyAgree = builder.question4TotallyAgree;
        this.question4NotApplicable = builder.question4NotApplicable;
        this.question5TotallyDisagree = builder.question5TotallyDisagree;
        this.question5Disagree = builder.question5Disagree;
        this.question5Agree = builder.question5Agree;
        this.question5TotallyAgree = builder.question5TotallyAgree;
        this.question5NotApplicable = builder.question5NotApplicable;
        this.question6TotallyDisagree = builder.question6TotallyDisagree;
        this.question6Disagree = builder.question6Disagree;
        this.question6Agree = builder.question6Agree;
        this.question6TotallyAgree = builder.question6TotallyAgree;
        this.question6NotApplicable = builder.question6NotApplicable;
        this.question1Ratings = builder.question1Ratings;
        this.question2Ratings = builder.question2Ratings;
        this.question3Ratings = builder.question3Ratings;
        this.question4Ratings = builder.question4Ratings;
        this.question5Ratings = builder.question5Ratings;
        this.question6Ratings = builder.question6Ratings;
        this.average = builder.average;
    }
    
    
  
    /**
     * @return the question1TotallyDisagree
     */
    public int getQuestion1TotallyDisagree() {
        return question1TotallyDisagree;
    }

    /**
     * @param question1TotallyDisagree the question1TotallyDisagree to set
     */
    public void setQuestion1TotallyDisagree(int question1TotallyDisagree) {
        this.question1TotallyDisagree = question1TotallyDisagree;
    }

    /**
     * @return the question1Disagree
     */
    public int getQuestion1Disagree() {
        return question1Disagree;
    }

    /**
     * @param question1Disagree the question1Disagree to set
     */
    public void setQuestion1Disagree(int question1Disagree) {
        this.question1Disagree = question1Disagree;
    }

    /**
     * @return the question1Agree
     */
    public int getQuestion1Agree() {
        return question1Agree;
    }

    /**
     * @param question1Agree the question1Agree to set
     */
    public void setQuestion1Agree(int question1Agree) {
        this.question1Agree = question1Agree;
    }

    /**
     * @return the question1TotallyAgree
     */
    public int getQuestion1TotallyAgree() {
        return question1TotallyAgree;
    }

    /**
     * @param question1TotallyAgree the question1TotallyAgree to set
     */
    public void setQuestion1TotallyAgree(int question1TotallyAgree) {
        this.question1TotallyAgree = question1TotallyAgree;
    }

    /**
     * @return the question1NotApplicable
     */
    public int getQuestion1NotApplicable() {
        return question1NotApplicable;
    }

    /**
     * @param question1NotApplicable the question1NotApplicable to set
     */
    public void setQuestion1NotApplicable(int question1NotApplicable) {
        this.question1NotApplicable = question1NotApplicable;
    }

    /**
     * @return the question2TotallyDisagree
     */
    public int getQuestion2TotallyDisagree() {
        return question2TotallyDisagree;
    }

    /**
     * @param question2TotallyDisagree the question2TotallyDisagree to set
     */
    public void setQuestion2TotallyDisagree(int question2TotallyDisagree) {
        this.question2TotallyDisagree = question2TotallyDisagree;
    }

    /**
     * @return the question2Disagree
     */
    public int getQuestion2Disagree() {
        return question2Disagree;
    }

    /**
     * @param question2Disagree the question2Disagree to set
     */
    public void setQuestion2Disagree(int question2Disagree) {
        this.question2Disagree = question2Disagree;
    }

    /**
     * @return the question2Agree
     */
    public int getQuestion2Agree() {
        return question2Agree;
    }

    /**
     * @param question2Agree the question2Agree to set
     */
    public void setQuestion2Agree(int question2Agree) {
        this.question2Agree = question2Agree;
    }

    /**
     * @return the question2TotallyAgree
     */
    public int getQuestion2TotallyAgree() {
        return question2TotallyAgree;
    }

    /**
     * @param question2TotallyAgree the question2TotallyAgree to set
     */
    public void setQuestion2TotallyAgree(int question2TotallyAgree) {
        this.question2TotallyAgree = question2TotallyAgree;
    }

    /**
     * @return the question2NotApplicable
     */
    public int getQuestion2NotApplicable() {
        return question2NotApplicable;
    }

    /**
     * @param question2NotApplicable the question2NotApplicable to set
     */
    public void setQuestion2NotApplicable(int question2NotApplicable) {
        this.question2NotApplicable = question2NotApplicable;
    }

    /**
     * @return the question3TotallyDisagree
     */
    public int getQuestion3TotallyDisagree() {
        return question3TotallyDisagree;
    }

    /**
     * @param question3TotallyDisagree the question3TotallyDisagree to set
     */
    public void setQuestion3TotallyDisagree(int question3TotallyDisagree) {
        this.question3TotallyDisagree = question3TotallyDisagree;
    }

    /**
     * @return the question3Disagree
     */
    public int getQuestion3Disagree() {
        return question3Disagree;
    }

    /**
     * @param question3Disagree the question3Disagree to set
     */
    public void setQuestion3Disagree(int question3Disagree) {
        this.question3Disagree = question3Disagree;
    }

    /**
     * @return the question3Agree
     */
    public int getQuestion3Agree() {
        return question3Agree;
    }

    /**
     * @param question3Agree the question3Agree to set
     */
    public void setQuestion3Agree(int question3Agree) {
        this.question3Agree = question3Agree;
    }

    /**
     * @return the question3TotallyAgree
     */
    public int getQuestion3TotallyAgree() {
        return question3TotallyAgree;
    }

    /**
     * @param question3TotallyAgree the question3TotallyAgree to set
     */
    public void setQuestion3TotallyAgree(int question3TotallyAgree) {
        this.question3TotallyAgree = question3TotallyAgree;
    }

    /**
     * @return the question3NotApplicable
     */
    public int getQuestion3NotApplicable() {
        return question3NotApplicable;
    }

    /**
     * @param question3NotApplicable the question3NotApplicable to set
     */
    public void setQuestion3NotApplicable(int question3NotApplicable) {
        this.question3NotApplicable = question3NotApplicable;
    }

    /**
     * @return the question4TotallyDisagree
     */
    public int getQuestion4TotallyDisagree() {
        return question4TotallyDisagree;
    }

    /**
     * @param question4TotallyDisagree the question4TotallyDisagree to set
     */
    public void setQuestion4TotallyDisagree(int question4TotallyDisagree) {
        this.question4TotallyDisagree = question4TotallyDisagree;
    }

    /**
     * @return the question4Disagree
     */
    public int getQuestion4Disagree() {
        return question4Disagree;
    }

    /**
     * @param question4Disagree the question4Disagree to set
     */
    public void setQuestion4Disagree(int question4Disagree) {
        this.question4Disagree = question4Disagree;
    }

    /**
     * @return the question4Agree
     */
    public int getQuestion4Agree() {
        return question4Agree;
    }

    /**
     * @param question4Agree the question4Agree to set
     */
    public void setQuestion4Agree(int question4Agree) {
        this.question4Agree = question4Agree;
    }

    /**
     * @return the question4TotallyAgree
     */
    public int getQuestion4TotallyAgree() {
        return question4TotallyAgree;
    }

    /**
     * @param question4TotallyAgree the question4TotallyAgree to set
     */
    public void setQuestion4TotallyAgree(int question4TotallyAgree) {
        this.question4TotallyAgree = question4TotallyAgree;
    }

    /**
     * @return the question4NotApplicable
     */
    public int getQuestion4NotApplicable() {
        return question4NotApplicable;
    }

    /**
     * @param question4NotApplicable the question4NotApplicable to set
     */
    public void setQuestion4NotApplicable(int question4NotApplicable) {
        this.question4NotApplicable = question4NotApplicable;
    }

    /**
     * @return the question5TotallyDisagree
     */
    public int getQuestion5TotallyDisagree() {
        return question5TotallyDisagree;
    }

    /**
     * @param question5TotallyDisagree the question5TotallyDisagree to set
     */
    public void setQuestion5TotallyDisagree(int question5TotallyDisagree) {
        this.question5TotallyDisagree = question5TotallyDisagree;
    }

    /**
     * @return the question5Disagree
     */
    public int getQuestion5Disagree() {
        return question5Disagree;
    }

    /**
     * @param question5Disagree the question5Disagree to set
     */
    public void setQuestion5Disagree(int question5Disagree) {
        this.question5Disagree = question5Disagree;
    }

    /**
     * @return the question5Agree
     */
    public int getQuestion5Agree() {
        return question5Agree;
    }

    /**
     * @param question5Agree the question5Agree to set
     */
    public void setQuestion5Agree(int question5Agree) {
        this.question5Agree = question5Agree;
    }

    /**
     * @return the question5TotallyAgree
     */
    public int getQuestion5TotallyAgree() {
        return question5TotallyAgree;
    }

    /**
     * @param question5TotallyAgree the question5TotallyAgree to set
     */
    public void setQuestion5TotallyAgree(int question5TotallyAgree) {
        this.question5TotallyAgree = question5TotallyAgree;
    }

    /**
     * @return the question5NotApplicable
     */
    public int getQuestion5NotApplicable() {
        return question5NotApplicable;
    }

    /**
     * @param question5NotApplicable the question5NotApplicable to set
     */
    public void setQuestion5NotApplicable(int question5NotApplicable) {
        this.question5NotApplicable = question5NotApplicable;
    }

    /**
     * @return the question6TotallyDisagree
     */
    public int getQuestion6TotallyDisagree() {
        return question6TotallyDisagree;
    }

    /**
     * @param question6TotallyDisagree the question6TotallyDisagree to set
     */
    public void setQuestion6TotallyDisagree(int question6TotallyDisagree) {
        this.question6TotallyDisagree = question6TotallyDisagree;
    }

    /**
     * @return the question6Disagree
     */
    public int getQuestion6Disagree() {
        return question6Disagree;
    }

    /**
     * @param question6Disagree the question6Disagree to set
     */
    public void setQuestion6Disagree(int question6Disagree) {
        this.question6Disagree = question6Disagree;
    }

    /**
     * @return the question6Agree
     */
    public int getQuestion6Agree() {
        return question6Agree;
    }

    /**
     * @param question6Agree the question6Agree to set
     */
    public void setQuestion6Agree(int question6Agree) {
        this.question6Agree = question6Agree;
    }

    /**
     * @return the question6TotallyAgree
     */
    public int getQuestion6TotallyAgree() {
        return question6TotallyAgree;
    }

    /**
     * @param question6TotallyAgree the question6TotallyAgree to set
     */
    public void setQuestion6TotallyAgree(int question6TotallyAgree) {
        this.question6TotallyAgree = question6TotallyAgree;
    }

    /**
     * @return the question6NotApplicable
     */
    public int getQuestion6NotApplicable() {
        return question6NotApplicable;
    }

    /**
     * @param question6NotApplicable the question6NotApplicable to set
     */
    public void setQuestion6NotApplicable(int question6NotApplicable) {
        this.question6NotApplicable = question6NotApplicable;
    }

    /**
     * @return the question1Ratings
     */
    public double getQuestion1Ratings() {
        return question1Ratings;
    }

    /**
     * @param question1Ratings the question1Ratings to set
     */
    public void setQuestion1Ratings(double question1Ratings) {
        this.question1Ratings = question1Ratings;
    }

    /**
     * @return the question2Ratings
     */
    public double getQuestion2Ratings() {
        return question2Ratings;
    }

    /**
     * @param question2Ratings the question2Ratings to set
     */
    public void setQuestion2Ratings(double question2Ratings) {
        this.question2Ratings = question2Ratings;
    }

    /**
     * @return the question3Ratings
     */
    public double getQuestion3Ratings() {
        return question3Ratings;
    }

    /**
     * @param question3Ratings the question3Ratings to set
     */
    public void setQuestion3Ratings(double question3Ratings) {
        this.question3Ratings = question3Ratings;
    }

    /**
     * @return the question4Ratings
     */
    public double getQuestion4Ratings() {
        return question4Ratings;
    }

    /**
     * @param question4Ratings the question4Ratings to set
     */
    public void setQuestion4Ratings(double question4Ratings) {
        this.question4Ratings = question4Ratings;
    }

    /**
     * @return the question5Ratings
     */
    public double getQuestion5Ratings() {
        return question5Ratings;
    }

    /**
     * @param question5Ratings the question5Ratings to set
     */
    public void setQuestion5Ratings(double question5Ratings) {
        this.question5Ratings = question5Ratings;
    }

    /**
     * @return the question6Ratings
     */
    public double getQuestion6Ratings() {
        return question6Ratings;
    }

    /**
     * @param question6Ratings the question6Ratings to set
     */
    public void setQuestion6Ratings(double question6Ratings) {
        this.question6Ratings = question6Ratings;
    }

    /**
     * @return the average
     */
    public double getAverage() {
        return average;
    }

    /**
     * @param average the average to set
     */
    public void setAverage(double average) {
        this.average = average;
    }

    /**
     * Creates builder to build {@link InstructionResponseForm}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link InstructionResponseForm}.
     */
    public static final class Builder {
        private int question1TotallyDisagree;
        private int question1Disagree;
        private int question1Agree;
        private int question1TotallyAgree;
        private int question1NotApplicable;
        private int question2TotallyDisagree;
        private int question2Disagree;
        private int question2Agree;
        private int question2TotallyAgree;
        private int question2NotApplicable;
        private int question3TotallyDisagree;
        private int question3Disagree;
        private int question3Agree;
        private int question3TotallyAgree;
        private int question3NotApplicable;
        private int question4TotallyDisagree;
        private int question4Disagree;
        private int question4Agree;
        private int question4TotallyAgree;
        private int question4NotApplicable;
        private int question5TotallyDisagree;
        private int question5Disagree;
        private int question5Agree;
        private int question5TotallyAgree;
        private int question5NotApplicable;
        private int question6TotallyDisagree;
        private int question6Disagree;
        private int question6Agree;
        private int question6TotallyAgree;
        private int question6NotApplicable;
        private double question1Ratings;
        private double question2Ratings;
        private double question3Ratings;
        private double question4Ratings;
        private double question5Ratings;
        private double question6Ratings;
        private double average;

        private Builder() {
        }

        public Builder withQuestion1TotallyDisagree(int question1TotallyDisagree) {
            this.question1TotallyDisagree = question1TotallyDisagree;
            return this;
        }

        public Builder withQuestion1Disagree(int question1Disagree) {
            this.question1Disagree = question1Disagree;
            return this;
        }

        public Builder withQuestion1Agree(int question1Agree) {
            this.question1Agree = question1Agree;
            return this;
        }

        public Builder withQuestion1TotallyAgree(int question1TotallyAgree) {
            this.question1TotallyAgree = question1TotallyAgree;
            return this;
        }

        public Builder withQuestion1NotApplicable(int question1NotApplicable) {
            this.question1NotApplicable = question1NotApplicable;
            return this;
        }

        public Builder withQuestion2TotallyDisagree(int question2TotallyDisagree) {
            this.question2TotallyDisagree = question2TotallyDisagree;
            return this;
        }

        public Builder withQuestion2Disagree(int question2Disagree) {
            this.question2Disagree = question2Disagree;
            return this;
        }

        public Builder withQuestion2Agree(int question2Agree) {
            this.question2Agree = question2Agree;
            return this;
        }

        public Builder withQuestion2TotallyAgree(int question2TotallyAgree) {
            this.question2TotallyAgree = question2TotallyAgree;
            return this;
        }

        public Builder withQuestion2NotApplicable(int question2NotApplicable) {
            this.question2NotApplicable = question2NotApplicable;
            return this;
        }

        public Builder withQuestion3TotallyDisagree(int question3TotallyDisagree) {
            this.question3TotallyDisagree = question3TotallyDisagree;
            return this;
        }

        public Builder withQuestion3Disagree(int question3Disagree) {
            this.question3Disagree = question3Disagree;
            return this;
        }

        public Builder withQuestion3Agree(int question3Agree) {
            this.question3Agree = question3Agree;
            return this;
        }

        public Builder withQuestion3TotallyAgree(int question3TotallyAgree) {
            this.question3TotallyAgree = question3TotallyAgree;
            return this;
        }

        public Builder withQuestion3NotApplicable(int question3NotApplicable) {
            this.question3NotApplicable = question3NotApplicable;
            return this;
        }

        public Builder withQuestion4TotallyDisagree(int question4TotallyDisagree) {
            this.question4TotallyDisagree = question4TotallyDisagree;
            return this;
        }

        public Builder withQuestion4Disagree(int question4Disagree) {
            this.question4Disagree = question4Disagree;
            return this;
        }

        public Builder withQuestion4Agree(int question4Agree) {
            this.question4Agree = question4Agree;
            return this;
        }

        public Builder withQuestion4TotallyAgree(int question4TotallyAgree) {
            this.question4TotallyAgree = question4TotallyAgree;
            return this;
        }

        public Builder withQuestion4NotApplicable(int question4NotApplicable) {
            this.question4NotApplicable = question4NotApplicable;
            return this;
        }

        public Builder withQuestion5TotallyDisagree(int question5TotallyDisagree) {
            this.question5TotallyDisagree = question5TotallyDisagree;
            return this;
        }

        public Builder withQuestion5Disagree(int question5Disagree) {
            this.question5Disagree = question5Disagree;
            return this;
        }

        public Builder withQuestion5Agree(int question5Agree) {
            this.question5Agree = question5Agree;
            return this;
        }

        public Builder withQuestion5TotallyAgree(int question5TotallyAgree) {
            this.question5TotallyAgree = question5TotallyAgree;
            return this;
        }

        public Builder withQuestion5NotApplicable(int question5NotApplicable) {
            this.question5NotApplicable = question5NotApplicable;
            return this;
        }

        public Builder withQuestion6TotallyDisagree(int question6TotallyDisagree) {
            this.question6TotallyDisagree = question6TotallyDisagree;
            return this;
        }

        public Builder withQuestion6Disagree(int question6Disagree) {
            this.question6Disagree = question6Disagree;
            return this;
        }

        public Builder withQuestion6Agree(int question6Agree) {
            this.question6Agree = question6Agree;
            return this;
        }

        public Builder withQuestion6TotallyAgree(int question6TotallyAgree) {
            this.question6TotallyAgree = question6TotallyAgree;
            return this;
        }

        public Builder withQuestion6NotApplicable(int question6NotApplicable) {
            this.question6NotApplicable = question6NotApplicable;
            return this;
        }

        public Builder withQuestion1Ratings(double question1Ratings) {
            this.question1Ratings = question1Ratings;
            return this;
        }

        public Builder withQuestion2Ratings(double question2Ratings) {
            this.question2Ratings = question2Ratings;
            return this;
        }

        public Builder withQuestion3Ratings(double question3Ratings) {
            this.question3Ratings = question3Ratings;
            return this;
        }

        public Builder withQuestion4Ratings(double question4Ratings) {
            this.question4Ratings = question4Ratings;
            return this;
        }

        public Builder withQuestion5Ratings(double question5Ratings) {
            this.question5Ratings = question5Ratings;
            return this;
        }

        public Builder withQuestion6Ratings(double question6Ratings) {
            this.question6Ratings = question6Ratings;
            return this;
        }

        public Builder withAverage(double average) {
            this.average = average;
            return this;
        }

        public InstructionResponseForm build() {
            return new InstructionResponseForm(this);
        }
    }
    
    
    
    
}

package com.fujitsu.ph.tsup.tms.model;

public class IncompleteTraining {
        
	private String employeeName;
	private String employeeStatus;
	private String manager;
	private String courseTitle;
	private String targetCompletion;
	

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getCourseTitle() {
		return courseTitle;
	}

	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}
	
	public String getTargetCompletion() {
		return targetCompletion;
	}
	
	public void setTargetCompletion(String targetCompletion) {
		this.targetCompletion = targetCompletion;
	}
	
	@Override
	public String toString() {
		return "incompletetraining [employeeName=" + employeeName + ", employeeStatus=" + employeeStatus + ", manager="
				+ manager + ", courseTitle=" + courseTitle + ", targetCompletion=" + targetCompletion
				+ "]";
	}
	
}
package com.fujitsu.ph.tsup.enrollment.model;

//==================================================================================================
//$Id:PR01$
//Project Name :  Training Sign Up
//System Name  : Enrollment process
//Class Name   : CourseEnrolledListForm.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 06/22/2020 | WS) G.Cabiling        | New Creation
//0.01    | 07/30/2020 | WS) M.Lumontad        | Updated
//0.02    | 06/16/2021 | WS) K.Sevilla         | Updated
//0.03    | 07/16/2021 | WS) MI.Aguinaldo      | Updated
//==================================================================================================

/** 
*<pre>  
* It is a JavaBean for CourseEnrolledListForm       
*</pre> 
*   
* @version 0.01
* @author m.lumontad 
* 
*/
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;

import com.fujitsu.ph.tsup.pagination.Paged;

public class CourseEnrolledListForm {

    /* From Date and Time */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) 
    private ZonedDateTime fromDateTime;

    /* To Date and Time */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) 
    private ZonedDateTime toDateTime;

    /* Set of Course Enrollment Form */
    private List<CourseEnrollmentForm> courseSchedules;
    
    private Page<CourseEnrollmentForm> paginatedCourseSchedules;
    
    /**
     * CourseEnrollmentForm stored in Paged
     */
    private Paged<CourseEnrollmentForm> pagedCourseSchedules;

    /** From Date and Time Getter */
    public ZonedDateTime getFromDateTime() {
        return fromDateTime;
    }

    /** From Date and Time Setter */
    public void setFromDateTime(ZonedDateTime fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    /** To Date and Time Getter */
    public ZonedDateTime getToDateTime() {
        return toDateTime;
    }

    /** To Date and Time Setter */
    public void setToDateTime(ZonedDateTime toDateTime) {
        this.toDateTime = toDateTime;
    }

    /** Set of Course Enrollment Form Getter */
    public List<CourseEnrollmentForm> getCourseSchedules() {
        return courseSchedules;
    }

    /** Set of Course Enrollment Form Setter */
    public void setCourseScheduleDetailForm(List<CourseEnrollmentForm> courseSchedules) {
        this.courseSchedules = courseSchedules;
    }
    
    /**
     * @return the paginatedCourseSchedules
     */
    public Page<CourseEnrollmentForm> getPaginatedCourseSchedules() {
        return paginatedCourseSchedules;
    }

    /**
     * @param paginatedCourseSchedules the paginatedCourseSchedules to set
     */
    public void setPaginatedCourseSchedules(Page<CourseEnrollmentForm> paginatedCourseSchedules) {
        this.paginatedCourseSchedules = paginatedCourseSchedules;
    }
    
    /**
     * @return the pagedCourseSchedules
     */
    public Paged<CourseEnrollmentForm> getPagedCourseSchedules() {
        return pagedCourseSchedules;
    }

    /**
     * @param pagedCourseSchedules the pagedCourseSchedules to set
     */
    public void setPagedCourseSchedules(Paged<CourseEnrollmentForm> pagedCourseSchedules) {
        this.pagedCourseSchedules = pagedCourseSchedules;
    }

    @Override
	public String toString() {
		return "CourseEnrolledListForm [FromDateTime = " + fromDateTime + ", ToDateTime = " + toDateTime + ","
				+ " CourseSchedules =" + courseSchedules + "]";
	}
}

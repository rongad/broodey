/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.service;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.report.summary.dao.SummaryGSTPMDao;
import com.fujitsu.ph.tsup.report.summary.model.SummaryGSTForm;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Summary of JDU Standardization Training for PM
// Class Name : SummaryGSTPMServiceImpl.java
//
// <<Modification History>>
// Version | Date       | Updated By            | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/04/20 | WS) d.escala          | Initial Version
// 0.02    | 2021/04/23 | WS) m.padaca          | Updated
// 0.03    | 2021/04/27 | WS) m.padaca          | Updated
// 0.04    | 2021/04/28 | WS) d.escala          | Updated
// 0.05    | 2021/10/15 | WS) r.buot            | Updated
// 0.05    | 2021/10/20 | WS) dw.cardenas       | Updated
// ==================================================================================================
/**
 * <pre>
 * The controller for the SummaryGSTPMServiceImpl
 * 
 * <pre>
 * 
 * @version 0.04
 * @author m.padaca
 * @author d.escala
 * @author r.buot
 */

@Service
public class SummaryGSTPMServiceImpl implements SummaryGSTPMService {

    @Autowired
    private SummaryGSTPMDao summaryGSTPMDao;

    @Override
    public Long countTotalNumberOfJDUPM(int deptId, List<Integer> roleId) {
        return summaryGSTPMDao.countTotalNumberOfJDUPM(deptId, roleId);
    }

    @Override
    public int countTotalNoJDUPMLastWeek() {
        return 0;
    }

    @Override
    public int countTotalNoOrigMem() {
        return 0;
    }

    @Override
    public int countTotalNoNewMem() {
        return 0;
    }

    @Override
    public Long countTotalNoJDUPMF(List<Integer> gstCourses, int deptId, List<Integer> roleId,
            ZonedDateTime reportDate) {
        return summaryGSTPMDao.countTotalNumberJDUPMFinished(gstCourses, deptId, roleId, reportDate);
    }

    @Override
    public Long countTotalNoJDUPMLastWkF(ZonedDateTime reportDate, List<Integer> gstCourses, int deptId,
            List<Integer> roleId) {
        return summaryGSTPMDao.countTotalNumberJDUPMFinishedLW(reportDate, gstCourses, deptId, roleId);
    }

    @Override
    public SummaryGSTForm getSummary(ZonedDateTime reportDate) {
        List<Integer> gstCourses = summaryGSTPMDao.gstCourses(summaryGSTPMDao.getCatId());
        List<Integer> roleId = summaryGSTPMDao.getEmployeeRoleId();
        int deptId = summaryGSTPMDao.getDeptId();

        Long totalCountOfPm = countTotalNumberOfJDUPM(deptId, roleId);
        Long countOfPmFinished = countTotalNoJDUPMF(gstCourses, deptId, roleId, reportDate);
        Long countOfPmFinishedLastWeek = countTotalNoJDUPMLastWkF(reportDate, gstCourses, deptId, roleId);

        SummaryGSTForm summaryGSTForm = new SummaryGSTForm();
        summaryGSTForm.setReportDateTime(reportDate);
        summaryGSTForm.setTotalNoJDUPMValue(totalCountOfPm);
        summaryGSTForm.setTotalNoJDUPMLastWeekValue(countTotalNoJDUPMLastWeek());
        summaryGSTForm.setTotalNoOrigMemValue(countTotalNoOrigMem());
        summaryGSTForm.setTotalNoNewMemValue(countTotalNoNewMem());
        summaryGSTForm.setTotalNoJDUPMFinValue(countOfPmFinished);
        summaryGSTForm.setTotalNoJDUPMLastWkFinValue(countOfPmFinishedLastWeek);
        summaryGSTForm.setPercentageFinTodayValue(
                ReportUtils.calculateCompletionPercentage(countOfPmFinished, totalCountOfPm));
        summaryGSTForm.setPercentageFinLastWkValue(
                ReportUtils.calculateCompletionPercentage(countOfPmFinishedLastWeek, totalCountOfPm));

        return summaryGSTForm;
    }
}

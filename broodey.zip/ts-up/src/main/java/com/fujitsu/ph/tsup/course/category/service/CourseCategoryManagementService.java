/**
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.category.service;

import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.pagination.Paged;
//=======================================================
//$Id: PR10$
//Project Name: Training Sign Up
//System Name : Course Category Management Process
//Class Name: CourseCategoryManagementService.java
//
//<<Modification History>>
//Version | Date       | Updated by          | Content
//--------+------------+---------------------+---------------
//0.01    | 02/08/2020 | WS) A.Batongbacal   | New Creation
//0.02    | 02/15/2020 | WS) A.Batongbacal   | Update
//0.03    | 02/15/2020 | WS) J.Zamora        | Update
//0.04    | 02/15/2020 | WS) G.Cabiling      | Update
//0.05    | 02/24/2020 | WS) Z.DeGuia        | Update
//0.06	  | 07/09/2021 | WS) R.Gaquit		 | Update
//0.07    | 09/02/2021 | WS) DW.Cardenas     | Update
//0.07    | 09/09/2021 | WS) D.Dinglasan     | Update
//=======================================================
/**
* <pre>
* The interface of course category management service
* 
* <pre>
* 
* @version 0.07
* @author a.batongbaca
* @author j.zamora
* @author g.cabiling
* @author z.deguia
* @author r.gaquit
* @author d.dinglasan
*
*/
public interface CourseCategoryManagementService {

    String updateCourseCategory(CourseCategory courseCategory);

    // A method that checks if the input has a duplicate
    Set<CourseCategory> findCourseCategoryByName(String name);

    // A method that creates course category
    String createCourseCategory(CourseCategory courseCategory);    

    Page<CourseCategory> findAllCourseCategory(Pageable pagable);
    
    Paged<CourseCategory> findCourseCategory(String byKeyword, Pageable pagable);
    
    Set<CourseCategory> findAllCourseCategory();
    
    boolean deleteCourseCategoryById(Long id);

    CourseCategory findCourseCategoryById(Long id);

    Page<CourseCategory> findCourseCategoryByName(String searchKey, Pageable pageable);

}

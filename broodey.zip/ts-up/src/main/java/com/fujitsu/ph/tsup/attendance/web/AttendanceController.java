package com.fujitsu.ph.tsup.attendance.web;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.ServletContextAware;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.attendance.domain.CourseParticipant;
import com.fujitsu.ph.tsup.attendance.model.AttendanceParticipantDetail;
import com.fujitsu.ph.tsup.attendance.model.ChangeStatusForm;
import com.fujitsu.ph.tsup.attendance.model.ChangeStatusParticipant;
import com.fujitsu.ph.tsup.attendance.model.CourseAttendanceForm;
import com.fujitsu.ph.tsup.attendance.model.CourseParticipantsForm;
import com.fujitsu.ph.tsup.attendance.model.CourseScheduleDetailForm;
import com.fujitsu.ph.tsup.attendance.model.CourseScheduleForm;
import com.fujitsu.ph.tsup.attendance.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.attendance.model.ScheduleDetail;
import com.fujitsu.ph.tsup.attendance.model.GenerateAttendanceForm;
import com.fujitsu.ph.tsup.attendance.model.PdfGenerator;
import com.fujitsu.ph.tsup.attendance.service.AttendanceService;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.enrollment.service.EnrollmentService;
import com.fujitsu.ph.tsup.enrollment.web.EnrollmentController;
import com.fujitsu.ph.tsup.scheduling.model.DepartmentForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;

// ===================================================================================================================
// $Id:PR03$
// Project Name : Training Sign up
// System Name : Attendance process
// Class Name : AttendanceController.java
//
// <<Modification History>>
// Version | Date       | Updated By                                                              | Content
// --------+------------+-------------------------------------------------------------------------+-------------------
// 0.01    | 06/23/2020 | WS) K.Abad, WS) M.Angara, WS) H.Francisco, WS) J.Iwarat, WS) R.Ramos    | New Creation
// 0.02    | 06/29/2020 | WS) J.Iwarat                                                            | Update
// 0.03    | 06/30/2020 | WS) J.Iwarat                                                            | Update
// 0.04    | 07/08/2020 | WS) R.Ramos                                                             | Update
// 0.05    | 07/30/2020 | WS) K.Abad, WS) J.Iwarat, WS) R.Ramos                                   | Update
// 0.06    | 08/05/2020 | WS) K.Abad, WS) J.Iwarat, WS) R.Ramos                                   | Update
// 0.07    | 08/26/2020 | WS) K.Abad, WS) J.Iwarat, WS) R.Ramos                                   | Update
// 0.08    | 09/17/2020 | WS) K.Abad, WS) J.Iwarat, WS) R.Ramos                                   | Update
// 0.09    | 09/18/2020 | WS) K.Abad, WS) J.Iwarat, WS) R.Ramos                                   | Update
// 0.10    | 07/09/2021 | WS) M.padaca                                                            | Update
// 0.10    | 08/17/2021 | WS) Jo.Dominguez                                                        | Update
// 0.11    | 08/13/2021 | WS) R.Gaquit                                                            | Update
// 0.12    | 08/17/2021 | WS) R.Gaquit                                                            | Update
// 0.13    | 08/17/2021 | WS) D.Dinglasan                                                         | Update
// 0.14    | 08/31/2021 | WS) CJ.Zamora                                                           | Update
//0.14     | 10/13/2021 | WS) Mj.liwag                                                            | Update
//0.15	   | 11/03/2021 | WS) An.Wasawas									                      | Update
// ===================================================================================================================
/**
 * <pre>
 * It is the implementation of attendance service
 * In this class, it implements the AttendanceService class for the initial setting of the database
 * </pre>
 * 
 * @version 0.12
 * @author k.abad
 * @author m.angara
 * @author h.francisco
 * @author j.iwarat
 * @author r.ramos
 * @author r.gaquit
 */

@Controller
@RequestMapping("/attendance")
public class AttendanceController implements ServletContextAware {

    /*
     * <pre> It is the interface of attendance service <pre>
     */
    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private EnrollmentService enrollmentService;
    
    @Autowired
    private EnrollmentController enrollmentController;

    
    /*
     * <pre> It is the interface of ServletContext
     * 
     * <pre>
     */
    @Autowired private ServletContext contextServlet;
    @Override
    public void setServletContext(ServletContext servletContext) {
       this.contextServlet=servletContext;
        
    }
    
    /*
     * <pre> Useful methods for logging and also decouple the logging implementation from application <pre>
     */
    private static Logger logger = LoggerFactory.getLogger(AttendanceController.class);

    /**
     * <pre>
     * US26. As an instructor, I can view the participants of my courses. URL Value =
     * /schedules/{courseScheduleId}/participants, method = GET Call
     * attendanceService.findAllScheduledCoursesByInstructor using the date today, date today + 5 days and the
     * user id from the Authentication object Call attendanceService.findCourseScheduleById using the given id
     * Set the values from the previous step into the CourseParticipantsForm Return the course participants
     * form and view
     * 
     * <pre>
     * 
     * @param id
     * @param model
     * @return attendance/viewInstructorCourseParticipants
     */
    @GetMapping("/schedules/{courseScheduleId}/participants")
    public String showCourseParticipantsForm(@PathVariable("courseScheduleId") Long id, Model model) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ZonedDateTime toDateTime = ZonedDateTime.now().plusDays(5);
        ZonedDateTime fromDateTime = ZonedDateTime.now().minusHours(15);

        logger.debug("Model:{}", model);

        CourseParticipantsForm courseParticipantsForm = new CourseParticipantsForm();

        Set<CourseScheduleDetailForm> setCourseScheduleDetailForm = new HashSet<>();
        Set<AttendanceParticipantDetail> setAttendanceParticipantDetail = new HashSet<>();

        Map<String, List<ScheduleDetail>> scheduledCourses = attendanceService
                .findAllScheduledCourses(fromDateTime, toDateTime, user.getId());

        Set<CourseParticipant> courseParticipantList = attendanceService.findCourseScheduleById(id);
        for (CourseParticipant courseParticipant : courseParticipantList) {
            CourseScheduleDetailForm courseScheduleDetailForm = new CourseScheduleDetailForm();
            AttendanceParticipantDetail attendanceParticipantDetail = new AttendanceParticipantDetail();

            courseParticipantsForm.setCourseName(courseParticipant.getCourseName());
            courseParticipantsForm.setInstructorName(courseParticipant.getInstructorName());

            courseScheduleDetailForm.setScheduledStartDateTime(courseParticipant.getScheduledStartDateTime());
            courseScheduleDetailForm.setScheduledEndDateTime(courseParticipant.getScheduledEndDateTime());
            courseScheduleDetailForm.setDuration(courseParticipant.getDuration());
            setCourseScheduleDetailForm.add(courseScheduleDetailForm);

            attendanceParticipantDetail.setName(courseParticipant.getParticipantName());
            attendanceParticipantDetail.setId(courseParticipant.getParticipantId());
            attendanceParticipantDetail.setEmail(courseParticipant.getEmail());
            attendanceParticipantDetail.setEmployeeNumber(courseParticipant.getEmployeeNumber());
            setAttendanceParticipantDetail.add(attendanceParticipantDetail);
        }

        List<AttendanceParticipantDetail> setSortedAttendanceParticipantDetail = setAttendanceParticipantDetail
                .stream().collect(Collectors.toCollection(ArrayList::new));
        List<AttendanceParticipantDetail> sortedAttendanceParticipantDetail = setSortedAttendanceParticipantDetail
                .stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName()))
                .collect(Collectors.toList());

        courseParticipantsForm.setCourseScheduleDetails(setCourseScheduleDetailForm);
        courseParticipantsForm.setParticipants(sortedAttendanceParticipantDetail);
        courseParticipantsForm.setCourseSchedules(scheduledCourses);

        model.addAttribute("lastSelected", id);
        model.addAttribute("courseParticipant", courseParticipantsForm);
        return "attendance/viewInstructorCourseParticipants";
    }

    /**
     * <pre>
     * US13. As an instructor, I can set the attendance status - Present or Absent. URL Value = /participants,
     * method = GET Call attendanceService.findAllScheduledCoursesByInstructor using the date today as from
     * and to date if form.id is not null and not zero, Call
     * attendanceService.findCourseAttendanceByCourseScheduleDetailId using the given form.id Set the values
     * from the previous step into the ChangeStatusForm Return the change status form and view
     * 
     * <pre>
     * 
     * @param id
     * @param form
     * @param bindingResult
     * @param model
     * @param @PathVariable("courseScheduleDetailId")
     * @return
     */
    @GetMapping("/{courseScheduleDetailId}/participants")
    public String showChangeStatusParticipantsForm(@PathVariable("courseScheduleDetailId") Long id,
            @Valid ChangeStatusForm form, BindingResult bindingResult, Model model) {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ZonedDateTime toDateTime = ZonedDateTime.now().plusDays(5);
        ZonedDateTime fromDateTime = ZonedDateTime.now().minusHours(15);

        List<ChangeStatusParticipant> participantAsList = new ArrayList<>();
        Map<String, List<ScheduleDetail>> scheduledCourses = attendanceService
                .findAllScheduledCourses(fromDateTime, toDateTime, user.getId());
        form.setId(id);
        form.setCourses(scheduledCourses);

        if (id != null && id != 0) {

            Set<CourseAttendance> courseAttendanceSet = attendanceService
                    .findCourseAttendanceByCourseScheduleDetailId(id);

            for (CourseAttendance courseAttendance : courseAttendanceSet) {
                ChangeStatusParticipant changeStatusParticipantForm = new ChangeStatusParticipant();
                changeStatusParticipantForm.setCourseAttendanceId(form.getId());
                changeStatusParticipantForm.setName(courseAttendance.getParticipantName());
                changeStatusParticipantForm.setLoginDateTime(courseAttendance.getLoginDateTime());
                changeStatusParticipantForm.setParticipantId(courseAttendance.getParticipantId());
                changeStatusParticipantForm.setLogoutDateTime(courseAttendance.getLogoutDateTime());
                changeStatusParticipantForm.setStatus(courseAttendance.getStatus());
                changeStatusParticipantForm.setEmail(courseAttendance.getEmail());
                participantAsList.add(changeStatusParticipantForm);
            }
        }
        List<ChangeStatusParticipant> sortedAttendanceParticipantDetail = participantAsList.stream()
                .sorted((e1, e2) -> e1.getName().compareTo(e2.getName())).collect(Collectors.toList());

        form.setParticipants(sortedAttendanceParticipantDetail);
        logger.debug("---- WAYAT sortedAttendanceParticipantDetail {}", sortedAttendanceParticipantDetail);

        model.addAttribute("changeStatusForm", form);
        model.addAttribute("lastSelected", id);
        logger.debug("ChangeStatusForm: {}", form);
        logger.debug("Result: {}", bindingResult);
        return "attendance/changeAttendanceStatus";
    }

    /**
     * <pre>
     * US13. As an instructor, I can set the attendance status - Present or Absent. URL Value = /participants,
     * method = POST Call attendanceService.findAllScheduledCoursesByInstructor using the date today as from
     * and to date if form.id is not null and not zero, Call
     * attendanceService.findCourseAttendanceByCourseScheduleDetailId using the given form.id if
     * bindingResult.hasErrors(), Return the change status form and view Transform the form into
     * CourseAttendance and add into a Set Call attendanceService.changeStatus using the Set created in the
     * previous step Redirect to /participants and return a success message.
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return redirect:/participants
     */
    @PostMapping("/{courseScheduleDetailId}/participants")
    public String submitChangeStatusParticipantsForm(
            @Valid @ModelAttribute("changeStatusForm") ChangeStatusForm form, BindingResult bindingResult,
            Model model, RedirectAttributes redirectAttributes) {
        logger.debug("ChangeStatusForm: {}", form);
        logger.debug("Result: {}", bindingResult);
        List<ChangeStatusParticipant> participantList = form.getParticipants();

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ZonedDateTime toDateTime = ZonedDateTime.now().plusDays(5);
        ZonedDateTime fromDateTime = ZonedDateTime.now();

        model.addAttribute("changeStatusForm", form);

        attendanceService.findAllScheduledCoursesByInstructor(fromDateTime, toDateTime, user.getId());

        if (form.getId() != null && form.getId() != 0) {
            attendanceService.findCourseAttendanceByCourseScheduleDetailId(form.getId());
        }

        if (bindingResult.hasErrors()) {
            return "attendance/changeAttendanceStatus";
        }

        Set<CourseAttendance> courseAttendanceSet = new HashSet<CourseAttendance>();

        for (int i = 0; participantList.size() > i; i++) {
            CourseAttendance courseAttendance = new CourseAttendance.Builder(form.getId(),
                    form.getParticipants()).build();
            courseAttendanceSet.add(courseAttendance);
        }

        redirectAttributes.addFlashAttribute("message", "");
        attendanceService.changeStatus(courseAttendanceSet);
        return "redirect:/attendance/0/participants";
    }

    /**
     * <pre>
     * UC15. As an instructor, I can generate an attendance sheet. URL Value =
     * /generate/{courseScheduleDetailId}/present, method = GET Call
     * attendanceService.findAllScheduledCoursesByInstructor using the date today minus 5 days as from and
     * date today as to date if id is not null and not zero, Call
     * attendanceService.findCourseAttendanceByCourseScheduleDetailId using the given id Set the values from
     * the previous step into the GenerateAttendanceForm Return the generate status form and view
     * 
     * <pre>
     * 
     * @param id
     * @param model
     * @param @PathVariable("courseScheduleDetailId")
     * @return
     */
    @GetMapping("/generate/{courseScheduleDetailId}/present")
    public String showGenerateAttendanceForm(@PathVariable("courseScheduleDetailId") Long id, Model model) {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ZonedDateTime fromDate = ZonedDateTime.now().minusHours(15);
        ZonedDateTime toDate = ZonedDateTime.now().plusDays(5);

        GenerateAttendanceForm generateAttendanceForm = new GenerateAttendanceForm();

        Set<AttendanceParticipantDetail> setAttendanceParticipantDetail = new HashSet<AttendanceParticipantDetail>();

        /*
         * <pre> Id is for authentication implementation <pre>
         */

        Map<String, List<ScheduleDetail>> scheduledCourses = attendanceService
                .findAllScheduledCourses(fromDate, toDate, user.getId());

        if (id != null && id != 0) {

            Set<CourseAttendance> courseAttendanceList = attendanceService
                    .findCourseAttendanceByCourseScheduleDetailId(id);

            for (CourseAttendance courseAttendance : courseAttendanceList) {
                generateAttendanceForm.setCourseName(courseAttendance.getCourseName());
                generateAttendanceForm.setInstructorName(courseAttendance.getInstructorName());
                generateAttendanceForm.setVenueName(courseAttendance.getVenueName());
                generateAttendanceForm.setDuration(courseAttendance.getDuration());
                generateAttendanceForm.setScheduledStartDateTime(courseAttendance.getScheduleStartDateTime());
                generateAttendanceForm.setScheduledEndDateTime(courseAttendance.getScheduleEndDateTime());

                AttendanceParticipantDetail attendanceParticipantDetail = new AttendanceParticipantDetail();
                attendanceParticipantDetail.setEmployeeNumber(courseAttendance.getEmployeeNumber());
                attendanceParticipantDetail.setDepartment(courseAttendance.getDepartmentName());
                attendanceParticipantDetail.setLoginDateTime(courseAttendance.getLoginDateTime());
                attendanceParticipantDetail.setLogoutDateTime(courseAttendance.getLogoutDateTime());
                attendanceParticipantDetail.setName(courseAttendance.getParticipantName());
                attendanceParticipantDetail.setStatus(courseAttendance.getStatus());
                setAttendanceParticipantDetail.add(attendanceParticipantDetail);
            }
        }

        List<AttendanceParticipantDetail> setSortedAttendanceParticipantDetail = setAttendanceParticipantDetail
                .stream().collect(Collectors.toCollection(ArrayList::new));

        List<AttendanceParticipantDetail> sortedAttendanceParticipantDetail = setSortedAttendanceParticipantDetail
                .stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName()))
                .collect(Collectors.toList());

        generateAttendanceForm.setCourses(scheduledCourses);
        generateAttendanceForm.setParticipants(sortedAttendanceParticipantDetail);
        
        model.addAttribute("lastSelected", id);
        model.addAttribute("generateAttendance", generateAttendanceForm);
        return "attendance/generateAttendanceSheet";

    }

    /**
     * <pre>
     * As a PMO, I can generate an attendance sheet together with the sign up sheet so that I will know who
     * signed up but didn't attend. URL Value = /generate/{courseScheduleDetailId}/absent, method = GET Call
     * attendanceService.findAllScheduledCoursesByInstructor using the date today minus 5 days as from and
     * date today as to date if id is not null and not zero Call
     * attendanceService.findCourseAbsentParticipantByCourseScheduleDetailId using the given id Set the values
     * from the previous step into the GenerateAttendanceForm 4. Return the generate status form and view
     * 
     * <pre>
     * 
     * @param id
     * @param model
     * @param @PathVariable("courseScheduleDetailId")
     * @return attendance/generateAbsentSheet
     */
    @GetMapping("/generate/{courseScheduleDetailId}/absent")
    public String showGenerateAbsentForm(@PathVariable("courseScheduleDetailId") Long id, Model model) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ZonedDateTime fromDate = ZonedDateTime.now().minusHours(15);
        ZonedDateTime toDate = ZonedDateTime.now().plusDays(5);

        logger.debug("Model:{}{}", model, id);

        GenerateAttendanceForm generateAttendanceForm = new GenerateAttendanceForm();

        Set<AttendanceParticipantDetail> attendanceParticipantDetailSet = new HashSet<AttendanceParticipantDetail>();

        Map<String, List<ScheduleDetail>> scheduledCourses = attendanceService
                .findAllScheduledCourses(fromDate, toDate, user.getId());

        if (id != null && id != 0) {
            Set<CourseAttendance> courseAttendanceSet = attendanceService
                    .findCourseAbsentParticipantByCourseScheduleDetailId(id);

            for (CourseAttendance courseAttendance : courseAttendanceSet) {
                AttendanceParticipantDetail attendanceParticipantDetail = new AttendanceParticipantDetail();
                attendanceParticipantDetail.setEmployeeNumber(courseAttendance.getEmployeeNumber());
                attendanceParticipantDetail.setEmail(courseAttendance.getEmail());
                attendanceParticipantDetail.setDepartment(courseAttendance.getDepartmentName());
                attendanceParticipantDetail.setName(courseAttendance.getParticipantName());
                attendanceParticipantDetail.setLoginDateTime(courseAttendance.getLoginDateTime());
                attendanceParticipantDetail.setStatus(courseAttendance.getStatus());
                attendanceParticipantDetailSet.add(attendanceParticipantDetail);

                generateAttendanceForm.setCourseName(courseAttendance.getCourseName());
                generateAttendanceForm.setInstructorName(courseAttendance.getInstructorName());
                generateAttendanceForm.setVenueName(courseAttendance.getVenueName());
                generateAttendanceForm.setScheduledStartDateTime(courseAttendance.getScheduleStartDateTime());
                generateAttendanceForm.setScheduledEndDateTime(courseAttendance.getScheduleEndDateTime());
                generateAttendanceForm.setDuration(courseAttendance.getDuration());
            }
        }

        List<AttendanceParticipantDetail> setSortedAttendanceParticipantDetail = attendanceParticipantDetailSet
                .stream().collect(Collectors.toCollection(ArrayList::new));
        List<AttendanceParticipantDetail> sortedAttendanceParticipantDetail = setSortedAttendanceParticipantDetail
                .stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName()))
                .collect(Collectors.toList());

        generateAttendanceForm.setCourses(scheduledCourses);
        generateAttendanceForm.setParticipants(sortedAttendanceParticipantDetail);

        model.addAttribute("attendanceForAbsent", generateAttendanceForm);
        model.addAttribute("lastSelected", id);
        return "attendance/attendanceForAbsent";
    }

    /**
     * <pre>
     * US14. As an member, I can attend the courses. URL Value = /signin/{courseScheduleDetailId}, method =
     * GET Call attendanceService.findCourseScheduleDetailById using the given id Set the values from the
     * previous step into the CourseAttendanceForm Return the course attendance form and view
     * 
     * <pre>
     * 
     * @param id
     * @param model
     * @param @PathVariable("courseScheduleDetailId")
     * @return attendance/attend
     * @author r.ramos
     */
    @GetMapping("/signin/{courseScheduleDetailId}")
    public String showAttendanceForm(@PathVariable("courseScheduleDetailId") Long id, Model model) {
        logger.debug("Model:{}", model);

        CourseAttendanceForm courseAttendanceForm = new CourseAttendanceForm();

        Set<CourseAttendance> courseAttendanceList = attendanceService.findCourseScheduleDetailById(id);
        Set<CourseAttendance> setCourseAttendance = new HashSet<CourseAttendance>();

        for (CourseAttendance courseAttendance : courseAttendanceList) {
            courseAttendanceForm.setId(courseAttendance.getId());
            courseAttendanceForm.setCourseScheduleDetailId(courseAttendance.getCourseScheduleDetailId());
            courseAttendanceForm.setParticipantId(courseAttendance.getParticipantId());
            courseAttendanceForm.setCourseName(courseAttendance.getCourseName());
            courseAttendanceForm.setInstructorName(courseAttendance.getInstructorName());
            courseAttendanceForm.setScheduledStartDateTime(courseAttendance.getScheduleStartDateTime());
            courseAttendanceForm.setScheduledEndDateTime(courseAttendance.getScheduleEndDateTime());
            courseAttendanceForm.setVenueName(courseAttendance.getVenueName());
            courseAttendanceForm.setLoginDateTime(courseAttendance.getLoginDateTime());
            courseAttendanceForm.setLogoutDateTime(courseAttendance.getLogoutDateTime());
            courseAttendanceForm.setCourseDescription(courseAttendance.getCourseDescription());
            setCourseAttendance.add(courseAttendance);
        }

        model.addAttribute("courseAttendance", courseAttendanceForm);
        return "attendance/attend";
    }

    /**
     * <pre>
     * US14. As an member, I can attend the courses. URL Value = /signin/{courseScheduleDetailId}, method =
     * POST if bindingResult.hasErrors() Return the course attendance form and view Transform the form into
     * CourseAttendance Call attendanceService.attend using the courseAttendance from previous step Return the
     * course attendance form and view
     * 
     * <pre>
     * 
     * @param id
     * @param form
     * @param bindingResult
     * @param model
     * @param redirectAttributes
     * @param @PathVariable("courseScheduleDetailId")
     * @return redirect:/attendance/signin/{courseScheduleDetailId}
     * @author r.ramos
     */
    @PostMapping("/signin/{courseScheduleDetailId}")
    public String submitAttendanceForm(@PathVariable("courseScheduleDetailId") Long id,
            @Valid @ModelAttribute("courseAttendance") CourseAttendanceForm form, BindingResult bindingResult,
            Model model, RedirectAttributes redirectAttributes) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        logger.debug("CourseAttendanceForm: {}", form);
        logger.debug("Result: {}", bindingResult);

        if (bindingResult.hasErrors()) {
            return "attendance/attend";
        }

        Set<CourseAttendance> courseAttendanceList = attendanceService.findCourseScheduleDetailById(id);
        for (CourseAttendance courseAttendance : courseAttendanceList) {
            form.setLoginDateTime(courseAttendance.getLoginDateTime());
        }
        if (form.getLoginDateTime() == null) {
            CourseAttendance courseAttendance = new CourseAttendance.Builder(form.getId(),
                    form.getCourseScheduleDetailId(), user.getId()).present(ZonedDateTime.now()).build();
            attendanceService.attendLogin(courseAttendance);
            redirectAttributes.addFlashAttribute("message", "signed in");
        } else {
            CourseAttendance courseAttendance = new CourseAttendance.Builder(form.getId(),
                    form.getCourseScheduleDetailId(), user.getId()).logout(ZonedDateTime.now()).build();
            attendanceService.attendLogout(courseAttendance);
            redirectAttributes.addFlashAttribute("message", "signed out");
        }

        model.addAttribute("courseAttendance", form);
        return "redirect:/attendance/signin/{courseScheduleDetailId}";

    }

    /**
     * <pre>
     * US14. As an member, I can attend the courses (view a list of enrolled course schedules). URL Value =
     * /signin, method = GET
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return attendance/attendCourseList
     * @author r.ramos
     */
    @GetMapping("/signin")
    public String viewEnrolledCourseSchedule(CourseScheduleListForm form, BindingResult bindingResult,
            Model model, @RequestParam("sortField") Optional<String> sortField,
            @RequestParam("sortDir") Optional<String> sortDir) {

        logger.debug("CourseScheduleListForm: {}", form);
        logger.debug("Result: {}", bindingResult);

        enrollmentController.getAllFilterOption(model);
        // Get all course categories
        try {
            Set<CourseCategory> courseCategory = enrollmentService.findAllCourseCategory();
            List<CourseCategory> listOfCourseCategory = courseCategory.stream().collect(Collectors.toList());
            model.addAttribute("categoryList", listOfCourseCategory);
        } catch (Exception e) {
            model.addAttribute("categoryListError", e.getMessage());
        }

        // Get all courses
        try {
            Set<Course> courseName = enrollmentService.findAllCourseName();
            List<Course> listOfCourseName = courseName.stream().collect(Collectors.toList());
            model.addAttribute("courseNameList", listOfCourseName);
        } catch (Exception e) {
            model.addAttribute("courseNameListError", e.getMessage());
        }

        // Get all instructors
        try {
            Set<InstructorForm> intructor = enrollmentService.findAllInstructor();
            List<InstructorForm> listOfInstructors = intructor.stream().collect(Collectors.toList());
            model.addAttribute("instructorList", listOfInstructors);
        } catch (Exception e) {
            model.addAttribute("instructorListError", e.getMessage());
        }

        // Get all venues
        try {
            Set<VenueForm> venue = enrollmentService.findAllVenue();
            List<VenueForm> listOfVenues = venue.stream().collect(Collectors.toList());
            model.addAttribute("venueList", listOfVenues);
        } catch (Exception e) {
            model.addAttribute("venueListError", e.getMessage());
        }

        // Get all departments
        try {
            Set<DepartmentForm> department = enrollmentService.findAllDepartment();
            List<DepartmentForm> listOfDepartment = department.stream().collect(Collectors.toList());
            model.addAttribute("departmentList", listOfDepartment);
        } catch (Exception e) {
            model.addAttribute("departmentListError", e.getMessage());
        }

        // Check filters ----
        form.setCourseCategoryId(checkFilterId(form.getCourseCategoryId()));
        form.setCourseNameId(checkFilterId(form.getCourseNameId()));
        form.setInstructorId(checkFilterId(form.getInstructorId()));
        form.setVenueId(checkFilterId(form.getVenueId()));
        form.setDepartmentId(checkFilterId(form.getDepartmentId()));
        form.setMandatory(checkFilterId(form.getMandatory()));
        form.setMandatoryType(checkFilterId(form.getMandatoryType()));
        form.setDeadline(checkFilterId(form.getDeadline()));

        // sorting
        String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("scheduled_start_datetime");
        String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");
        Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);

        // pagination code========================
        int currentPage = Paging.DEFAULT_CURRENT_PAGE_NO;
        String currentPageStr = form.getCurrentPage();
        if (isNumeric(currentPageStr)) {
            currentPage = Integer.parseInt(currentPageStr);
        }

        Pageable pageable = PageRequest.of(currentPage - 1, Paging.DEFAULT_PAGE_SIZE, sort);

        // pagination code end====================
        
        final String ATTEND_COURSE_LIST_HTML = "attendance/attendCourseList";
        if (bindingResult.hasErrors()) {
            model.addAttribute("errorMessage", bindingResult.getAllErrors());
            return ATTEND_COURSE_LIST_HTML;
        }

        if (form.getFromDateTime() == null) {
            form.setFromDateTime(ZonedDateTime.now().withHour(0).withMinute(0));
        }

        Page<CourseScheduleForm> paginatedCourseEnroll = new PageImpl<>(new ArrayList<>());
        Paged<CourseScheduleForm> pagedCoursedEnroll = new Paged<>(paginatedCourseEnroll, new Paging());
        
        if (form.getToDateTime() == null) {
            // set end date variable to specific end quarter
            // e.g. Mar-31 | Jun-30 | Sept-30 | Dec-31, 11:59 PM
            // for initial load of data

            int fromDateTimeMonthValue = form.getFromDateTime().getMonthValue();
            int addMonths = 0;
            int quarterEndMonth = 3; // initial value of 3 to depict first quarter

            // get the difference of fromDateTimeMonthValue from its proper quarter range
            // then store it to addMonths
            while (quarterEndMonth <= 12) {
                if (fromDateTimeMonthValue <= quarterEndMonth) {
                    addMonths = quarterEndMonth - fromDateTimeMonthValue;
                    break;
                }
                quarterEndMonth += 3;
            }

            try {
                int daysOfTheMonth = (quarterEndMonth == 3 || quarterEndMonth == 12) ? 31 : 30;
                ZonedDateTime toDatePlaceHolder = form.getFromDateTime().plusMonths(addMonths) // add months
                                                                                               // to set
                                                                                               // specific end
                                                                                               // quarter
                        .withDayOfMonth(daysOfTheMonth) // set the end day of the month
                        .withHour(23).withMinute(59); // this will set the time to 11:59 PM
                form.setToDateTime(toDatePlaceHolder);
            } catch (Exception e) {
                model.addAttribute("paginatedAttendCourseList", pagedCoursedEnroll);
                model.addAttribute("attendCourseList", form);
                model.addAttribute("nullMessage", e.getMessage());
            }
        }

        if (form.getFromDateTime().isAfter(form.getToDateTime())) {
            model.addAttribute("attendCourseList", form);
            model.addAttribute("error", "To Date should be greater than or equal to From Date");
            model.addAttribute("nullMessage", "No schedules found");
            // pagination code ======================
            model.addAttribute("paginatedAttendCourseList", pagedCoursedEnroll);
            // pagination code end ====================
            return ATTEND_COURSE_LIST_HTML;
        }
        try {
            FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            Set<CourseParticipant> courseParticipantList = attendanceService
                    .findAllScheduledCoursesByParticipant(form, pageable);

            Set<CourseScheduleForm> setCourseScheduleForm = new LinkedHashSet<>();
            // Pagination variable to get sortedCourseScheduleForm out of the loop ======
            List<CourseScheduleForm> courseScheduleFormListForPagination = null;
            // Pagination end ===========================================================

            for (CourseParticipant courseParticipant : courseParticipantList) {
                CourseScheduleForm courseScheduleForm = new CourseScheduleForm();
                CourseScheduleDetailForm courseScheduleDetailForm = new CourseScheduleDetailForm();
                courseScheduleForm.setId(courseParticipant.getId());
                courseScheduleForm.setCourseName(courseParticipant.getCourseName());
                courseScheduleForm.setInstructorName(courseParticipant.getInstructorName());
                courseScheduleForm.setVenueName(courseParticipant.getVenueName());
                courseScheduleForm.setMandatory(courseParticipant.getMandatory()); // added 8/13/2021
                courseScheduleForm.setMandatoryType(courseParticipant.getMandatoryType()); // added 8/13/2021
                courseScheduleDetailForm.setId(courseParticipant.getCourseScheduleId());
                courseScheduleDetailForm
                        .setScheduledStartDateTime(courseParticipant.getScheduledStartDateTime());
                courseScheduleDetailForm.setScheduledEndDateTime(courseParticipant.getScheduledEndDateTime());
                courseScheduleDetailForm.setDuration(courseParticipant.getDuration());
                courseScheduleDetailForm.setCourseCategory(courseParticipant.getCourseCategory());
                courseScheduleForm.setCourseScheduleDetails(courseScheduleDetailForm);
                setCourseScheduleForm.add(courseScheduleForm);

                form.setCourseSchedules(
                        setCourseScheduleForm.stream().collect(Collectors.toCollection(ArrayList::new)));
                courseScheduleFormListForPagination = setCourseScheduleForm.stream()
                        .collect(Collectors.toCollection(ArrayList::new));

            }

            model.addAttribute("attendCourseList", form);
            logger.debug("attendCourseList: {}", form);

            // For Pagination
            // ================================================================
            List<CourseScheduleForm> listOfAttendCourse = courseScheduleFormListForPagination.stream()
                    .collect(Collectors.toList());

            int availableCourse = attendanceService.countCourse(form);
            paginatedCourseEnroll = new PageImpl<>(listOfAttendCourse, pageable, availableCourse);
                        pagedCoursedEnroll = new Paged<>(paginatedCourseEnroll,
                                Paging.of(paginatedCourseEnroll.getTotalPages(), pageable.getPageNumber() + 1,
                                        pageable.getPageSize()));
            model.addAttribute("currentPage", currentPage);
            model.addAttribute("paginatedAttendCourseList", pagedCoursedEnroll);
            // ===============================================================================

        } catch (Exception e) {
            model.addAttribute("paginatedAttendCourseList", pagedCoursedEnroll);
            model.addAttribute("attendCourseList", form);
            model.addAttribute("nullMessage", e.getMessage());
        }

        return ATTEND_COURSE_LIST_HTML;
    }

    /**
     * Check if filter Id is null, empty or undefined
     * 
     * @return
     */
    private String checkFilterId(String filterId) {

        if (filterId == null || filterId.isEmpty() || filterId.equals("undefined") || filterId.equals("-")) {
            return "%";
        }

        return filterId;
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null || strNum.length() == 0) {
            return false;
        }

        try {
            Double.parseDouble(strNum);
            return true;

        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    /**
     * <pre>
     * As an PMO, I can generate a pdf file of all the present or the one who attend the training.
     * URL Value =/generate/{courseScheduleDetailId}/present/createPDF
     * <pre>
     * 
     * @param id
     * @param request
     * @param response
     * @param @PathVariable("courseScheduleDetailId")
     * @return
     * @author jo.dominguez
     */
    @GetMapping("/generate/{courseScheduleDetailId}/present/createPDF")
    public void createPdfAttendance(@PathVariable("courseScheduleDetailId")Long id,HttpServletRequest request,
         HttpServletResponse response, @ModelAttribute("generateAttendance")GenerateAttendanceForm generate) {
        
     Set<CourseAttendance> attendee = attendanceService.findCourseAttendanceByCourseScheduleDetailId(id);
     try {
         boolean isFlag=attendanceService.createPdf(attendee,contextServlet,generate.getTypeOfTraining());
         for(CourseAttendance courseAttendance : attendee) {
        
             DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
             String dateStart = courseAttendance.getScheduleStartDateTime().format(formatter);
             String courseName= courseAttendance.getCourseName();
             String instructorName=courseAttendance.getInstructorName().replaceAll("[^a-zA-Z0-9]"," ");
         if(isFlag) {
             String fullPath=request.getServletContext().getRealPath("/resource/reports/"+"export"+".pdf");
             attendanceService.fileDownload(fullPath,response,contextServlet,"Attendance_"+courseName
                +"_"+instructorName+"_"+dateStart+".pdf");
       }}}catch(Exception e) {
           System.out.println(e);
       }}
    
    /**
     * <pre>
     * As an PMO, I can generate a pdf file of all the absent or the one who didn't attend the training.
     * URL Value =/generate/{courseScheduleDetailId}/absent/createPDF
     * <pre>
     * 
     * @param id
     * @param request
     * @param response
     * @param @PathVariable("courseScheduleDetailId")
     * @return
     * @author jo.dominguez
     */
    @GetMapping("/generate/{courseScheduleDetailId}/absent/createPDF")
    public void createPdfAbsent(@PathVariable("courseScheduleDetailId")Long id,HttpServletRequest request
            ,HttpServletResponse response, @ModelAttribute("attendanceForAbsent")GenerateAttendanceForm generate) {
   
    Set<CourseAttendance> absent = attendanceService.findCourseAbsentParticipantByCourseScheduleDetailId(id);
    try {
        boolean isFlag=attendanceService.createPdf(absent,contextServlet,generate.getTypeOfTraining());
        for(CourseAttendance courseAttendance : absent) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String dateStart = courseAttendance.getScheduleStartDateTime().format(formatter);
            String courseName= courseAttendance.getCourseName();
            String instructorName=courseAttendance.getInstructorName().replaceAll("[^a-zA-Z0-9]"," ");
       if(isFlag) {
           String fullPath=request.getServletContext().getRealPath("/resource/reports/"+"export"+".pdf");
           attendanceService.fileDownload(fullPath,response,contextServlet,"Absent_"+courseName
                +"_"+instructorName+"_"+dateStart+".pdf");
        }}}catch(Exception e) {
            System.out.println(e);
    }}
    
    /**
	 * <pre>
	 * US02. As an instructor, I can export  the participants of my courses in pdf . URL Value =
	 * /schedules/{courseScheduleId}/participants/exportpdf, method = GET Call
	 * attendanceService.findAllScheduledCoursesByInstructor using the date today, date today + 5 days and the
	 * user id from the Authentication object Call attendanceService.findCourseScheduleById using the given id
	 * Set the values from the previous step into the CourseParticipantsForm 
	 * Parse CourseParticipantsForm to ByteArrayInputStream using PdfGenerator.exportCourseParticipants
	 * add ByteArrayInputStream to headers as an attachment file
	 * return ResonseEntity
	 * 
	 * <pre>
	 * 
	 * @param id
	 * @param model
	 * @param response
	 * @return ResponseEntity
	 * 
	 */
	@GetMapping(value = "/schedules/{courseScheduleId}/participants/exportpdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> exportCourseParticipant(HttpServletResponse response, @PathVariable("courseScheduleId") Long id, Model model) throws IOException {


		FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		ZonedDateTime toDateTime = ZonedDateTime.now().plusDays(5);
		ZonedDateTime fromDateTime = ZonedDateTime.now().minusHours(15);

		logger.debug("Model:{}", model);

		CourseParticipantsForm courseParticipantsForm = new CourseParticipantsForm();
		
	    
	    
		Set<CourseScheduleDetailForm> setCourseScheduleDetailForm = new HashSet<>();
		Set<AttendanceParticipantDetail> setAttendanceParticipantDetail = new HashSet<>();

			Map<String, List<ScheduleDetail>> scheduledCourses = attendanceService.findAllScheduledCourses(fromDateTime, toDateTime, user.getId());
	
		Set<CourseParticipant> courseParticipantList = attendanceService.findCourseScheduleById(id);
		for (CourseParticipant courseParticipant : courseParticipantList) {
			CourseScheduleDetailForm courseScheduleDetailForm = new CourseScheduleDetailForm();
			AttendanceParticipantDetail attendanceParticipantDetail = new AttendanceParticipantDetail();

			courseParticipantsForm.setCourseName(courseParticipant.getCourseName());
			courseParticipantsForm.setInstructorName(courseParticipant.getInstructorName());

			courseScheduleDetailForm.setScheduledStartDateTime(courseParticipant.getScheduledStartDateTime());
			courseScheduleDetailForm.setScheduledEndDateTime(courseParticipant.getScheduledEndDateTime());
			courseScheduleDetailForm.setDuration(courseParticipant.getDuration());
			
			setCourseScheduleDetailForm.add(courseScheduleDetailForm);

			attendanceParticipantDetail.setName(courseParticipant.getParticipantName());
			attendanceParticipantDetail.setId(courseParticipant.getParticipantId());
			attendanceParticipantDetail.setEmail(courseParticipant.getEmail());
			attendanceParticipantDetail.setEmployeeNumber(courseParticipant.getEmployeeNumber());
			setAttendanceParticipantDetail.add(attendanceParticipantDetail);
		}

		List<AttendanceParticipantDetail> setSortedAttendanceParticipantDetail = setAttendanceParticipantDetail
				.stream().collect(Collectors.toCollection(ArrayList::new));
		List<AttendanceParticipantDetail> sortedAttendanceParticipantDetail = setSortedAttendanceParticipantDetail
				.stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName()))
				.collect(Collectors.toList());

		courseParticipantsForm.setCourseScheduleDetails(setCourseScheduleDetailForm);
		courseParticipantsForm.setParticipants(sortedAttendanceParticipantDetail);
		courseParticipantsForm.setCourseSchedules(scheduledCourses);



		ByteArrayInputStream bis = PdfGenerator.exportCourseParticipant(courseParticipantsForm);

		HttpHeaders headers = new HttpHeaders();
		
		headers.add("Content-Disposition", "attachment;filename=CourseParticipants"+courseParticipantsForm.getCourseName()+".pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}


}

package com.fujitsu.ph.tsup.roletype.dao;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.roletype.domain.RoleType;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Role Type Management
// Class Name : RoleTypeDaoImpl.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/02/05 | WS) rl.naval | Initial Version
// 0.02 | 2021/02/16 | WS) s.labador | Updated
// 0.03 | 2021/02/17 | WS) j.sayaboc | Updated
// 0.04 | 2021/02/22 | WS) j.sayaboc | Updated
// 0.05 | 2021/02/24 | WS) p.cui | Updated
// 0.06 | 2021/02/26 | WS) c.sinda | Updated
// 0.07 | 2021/03/03 | WS) m.baton | Updated
// 0.08 | 2021/03/09 | WS) j.sayaboc | Updated
// 0.09 | 2021/03/11 | WS) p.cui | Updated
// 0.10 | 2021/03/12 | WS) i.fajardo | Updated
// 0.11 | 2021/03/18 | WS) rl.naval | Updated
// 0.12 | 2021/07/12 | WS) r.gaquit | Updated
// 0.13 | 2021/09/09 | WS) d.dinglasan | Updated
// 0.13 | 2021/08/31 | WS) dw.cardenas | Updated
// ==================================================================================================

/**
 * RoleTypeDaoImpl class
 * 
 * @version 0.12
 * @author rl.naval
 * @author s.labador
 * @author p.cui
 * @author j.sayaboc
 * @author c.sinda
 * @author m.baton
 * @author i.fajardo
 * @author r.gaquit
 */

@Repository
public class RoleTypeDaoImpl implements RoleTypeDao {

    // Call NamedParameterJdbcTemplate
    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * For logging purposes in RoleTypeDaoImpl
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(RoleTypeDaoImpl.class);

    /**
     * Method for finding Role by Id
     * 
     * @param id Role id
     */
    @Override
    public RoleType findRoleById(Long id) {
        String query = "SELECT id, role_type, role_desc FROM MEMBER_ROLE where ID = " + id;
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("id", id);
        return template.queryForObject(query, sqlParameterSource, new RoleTypeRowMapper());
    }

    /**
     * Method for finding Role by name
     * 
     * @param rolename Role name
     */
    @Override
    public Set<RoleType> findRoleTypeByName(String rolename) {
        String query = "SELECT * FROM MEMBER_ROLE WHERE LOWER(role_type) LIKE LOWER('%" + rolename
                + "%') AND deleted_at IS NULL";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("role_type", rolename);

        List<RoleType> roleList = template.query(query, sqlParameterSource, new RoleTypeRowMapper());
        return new LinkedHashSet<>(roleList);
    }

    /**
     * Find if Role name is already existing
     * 
     * @param rolename Role name
     * @param id Role id
     * @return roles
     */
    @Override
    public Set<RoleType> findIfRoleNameExists(String rolename, Long id) {
        String query = "SELECT * FROM MEMBER_ROLE WHERE LOWER(role_type) LIKE LOWER('" + rolename
                + "') AND id NOT IN (" + id + ") AND deleted_at IS NULL";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("role_type", rolename);

        List<RoleType> roleList = template.query(query, sqlParameterSource, new RoleTypeRowMapper());
        return new LinkedHashSet<>(roleList);
    }

    /**
     * Load all role types
     * 
     * @return roles
     */
    @Override
    public Set<RoleType> loadAllRoleType() {
        String query = "SELECT id, role_type, role_desc, deleted_at  FROM MEMBER_ROLE  WHERE deleted_at IS NULL";

        List<RoleType> roleList = template.query(query, new RoleTypeRowMapper());
        return new LinkedHashSet<>(roleList);
    }

    /**
     * Load all role types with pagination
     * 
     * @param pageable
     * @return roleTypeList
     */
    @Override
    public Set<RoleType> loadAllRoleType(Pageable pageable) {
        String orderProperty = "role_type";
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc(orderProperty);
        String query = "SELECT id, role_type, role_desc, deleted_at "
                + "FROM MEMBER_ROLE WHERE deleted_at IS NULL " + "ORDER BY " + orderProperty + " "
                + order.getDirection() + " " + "LIMIT " + pageable.getPageSize() + " OFFSET "
                + pageable.getOffset();

        List<RoleType> roleTypeList = template.query(query, new RoleTypeRowMapper());
        return roleTypeList.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(roleTypeList);

    }

    /**
     * Count all role types
     * 
     * @return roleTypeList
     */
    @Override
    public int countRoleType() {
        try {
            return jdbcTemplate.queryForObject("SELECT count(id) FROM MEMBER_ROLE WHERE deleted_at IS NULL",
                    Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    /**
     * Method for deleting Role by Id
     * 
     * @param id Role id
     */
    @Override
    public void deleteRoleTypeById(Long id) {
        String query = "UPDATE MEMBER_ROLE SET deleted_at = now() WHERE ID = " + id;
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("id", id);
        template.update(query, sqlParameterSource);

    }

    /**
     * Method for creating role type
     * 
     * @param role Role type
     */
    @Override
    public void createRoleType(RoleType role) {
        String query = "INSERT INTO MEMBER_ROLE" + "(role_type, role_desc)"
                + "VALUES (:rolename , :roledesc)";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("rolename", role.getRolename()).addValue("roledesc", role.getRoledesc());

        template.update(query, sqlParameterSource);
    }

    /**
     * Method for updating Role Type
     * 
     * @param id Role id
     * @param roleType RoleType
     */

    @Override
    public void updateRoleType(Long id, RoleType roleType) {
        String query = "UPDATE MEMBER_ROLE " + "SET role_type = '" + roleType.getRolename()
                + "', role_desc = '" + roleType.getRoledesc() + "' " + "WHERE id = " + id + ";";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("roletype", roleType.getRolename()).addValue("roledesc", roleType.getRoledesc());
        template.update(query, sqlParameterSource);
    }

    /**
     * Method for searching Role Type
     * 
     * @param keyword search keyword
     */
    @Override
    public Set<RoleType> findRoleTypeByKeyword(String keyword) {
        String query = "SELECT * FROM MEMBER_ROLE " + "WHERE (LOWER(role_type) LIKE LOWER('%" + keyword
                + "%') " + "OR LOWER(role_desc) LIKE LOWER('%" + keyword + "%')) AND deleted_at IS NULL";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("role_type", keyword)
                .addValue("role_desc", keyword);

        List<RoleType> roleTypeList = template.query(query, sqlParameterSource, new RoleTypeRowMapper());
        return roleTypeList.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(roleTypeList);
    }

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.roletype.dao.RoleTypeDao#loadRoleType(java.lang.String,
     * org.springframework.data.domain.Pageable) Method for loading and searching role type
     */
    @Override
    public List<RoleType> loadRoleType(String byKeyword, Pageable pageable) {
        String query = "SELECT id, role_type, role_desc, deleted_at FROM MEMBER_ROLE WHERE deleted_at IS NULL ";
        if (!byKeyword.isEmpty()) {
            String lowerStrKeyword = byKeyword.toLowerCase();
            query += "AND (LOWER(role_type) LIKE '%" + lowerStrKeyword + "%' OR LOWER(role_desc) LIKE '%"
                    + lowerStrKeyword + "%') ";
        }

        String orderProperty = "role_type";
        Order order = (pageable.getSort().isEmpty()) ? Order.asc(orderProperty)
                : pageable.getSort().toList().get(0);

        query += "ORDER BY " + orderProperty + " " + order.getDirection() + " " + "LIMIT "
                + pageable.getPageSize() + " OFFSET " + pageable.getOffset();

        return template.query(query, new RoleTypeRowMapper());
    }

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.roletype.dao.RoleTypeDao#countRoleType(java.lang.String)
     */
    @Override
    public int countRoleType(String byKeyword) {
        try {
            String query = "SELECT COUNT(*) FROM MEMBER_ROLE WHERE deleted_at IS NULL";
            if (!byKeyword.isEmpty()) {
                String lowerStrKeyword = byKeyword.toLowerCase();
                query += " AND (LOWER(role_type) LIKE '%" + lowerStrKeyword + "%' OR LOWER(role_desc) LIKE '%"
                        + lowerStrKeyword + "%') ";
            }
            return jdbcTemplate.queryForObject(query, Integer.class);
        } catch (DataAccessException dataAccessExeption) {
            // nothing to do here
            // return 0 when exception occurs
            LOGGER.error(dataAccessExeption.getMessage(), "(param)[byKeyword]=" + byKeyword);
            return 0;
        } catch (NullPointerException nullPointerException) {
            // nothing to do here
            // return 0 when exception occurs
            LOGGER.error(nullPointerException.getMessage(), "(param)[byKeyword]=" + byKeyword);
            return 0;
        }
    }

    /**
     * Filters role type based on keyword and pageable.
     * 
     * @param keyword
     * @param pageable
     */
    @Override
    public Set<RoleType> findRoleTypeByKeyword(String keyword, Pageable pageable) {
        Order order = pageable.getSort().toList().get(0);
        String columnName;

        switch (order.getProperty()) {
            case "roleType":
                columnName = "role_type";
                break;

            default:
                columnName = "role_type";
        }

        String query = "SELECT * FROM MEMBER_ROLE " + "WHERE LOWER(role_type) LIKE LOWER('%" + keyword
                + "%') " + "ORDER BY " + columnName + " " + order.getDirection() + " "
                + "LIMIT :pageSize OFFSET :pageOffset";
        SqlParameterSource sqlParamSource = new MapSqlParameterSource()
                .addValue("pageSize", pageable.getPageSize()).addValue("pageOffset", pageable.getOffset());

        List<RoleType> roleTypeList = template.query(query, sqlParamSource, new RoleTypeRowMapper());
        return new LinkedHashSet<>(roleTypeList);
    }

    /**
     * Counts number of role types queried using search key
     * 
     * @param keyword
     */
    @Override
    public int countFilteredRoleTypes(String keyword) {
        try {
            String query = "SELECT count(id) FROM MEMBER_ROLE " + "WHERE deleted_at IS NULL "
                    + "AND LOWER(role_type) LIKE LOWER('%" + keyword + "%')";
            return jdbcTemplate.queryForObject(query, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }
}

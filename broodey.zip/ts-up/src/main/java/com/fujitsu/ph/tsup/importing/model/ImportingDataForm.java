package com.fujitsu.ph.tsup.importing.model;

import java.util.List;

// ==================================================================================================
// Project Name : Training Sign Up
// Class Name : ImportingDataForm.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/09/07 | WS) mi.aguinaldo | Initial Version
// ==================================================================================================

public class ImportingDataForm {

    private List<SabaDTO> sabaDTOs;

    private int importedData;

    /**
     * @return the sabaDTOs
     */
    public List<SabaDTO> getSabaDTOs() {
        return sabaDTOs;
    }

    /**
     * @param sabaDTOs the sabaDTOs to set
     */
    public void setSabaDTOs(List<SabaDTO> sabaDTOs) {
        this.sabaDTOs = sabaDTOs;
    }

    /**
     * @return the importedData
     */
    public int getImportedData() {
        return importedData;
    }

    /**
     * @param importedData the importedData to set
     */
    public void setImportedData(int importedData) {
        this.importedData = importedData;
    }

    @Override
    public String toString() {
        return "ImportingDataForm [sabaDTOs=" + sabaDTOs + ", importedData=" + importedData + "]";
    }

}

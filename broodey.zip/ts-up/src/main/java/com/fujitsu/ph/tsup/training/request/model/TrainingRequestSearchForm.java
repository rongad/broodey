package com.fujitsu.ph.tsup.training.request.model;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import org.springframework.format.annotation.DateTimeFormat;

//==================================================================================================
//Project Name :Training Sign Up
//System Name  :Training Request
//Class Name   :TrainingRequestForm.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 07/13/2021 | WS) L.Celoso          | New Creation
//0.02    | 08/06/2021 | WS) L.Celoso          | Update
//0.03    | 08/20/2021 | WS) L.Celoso          | Added requester as filter search
//==================================================================================================
/**
 * <pre>
 * Form for the search in training request
 * 
 * <pre>
 * 
 * @version 0.01
 * @author L.Celoso
 */
public class TrainingRequestSearchForm {
	
	/**
     *	Start Date and Time
     */
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime searchStartDateTime;
	
	/**
     *	End Date and Time
     */
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime searchEndDateTime;
	
	/**
     *	Start Date and Time
     */
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private ZonedDateTime searchStartDateTimeZone;
	
	/**
     *	End Date and Time
     */
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private ZonedDateTime searchEndDateTimeZone;

    /* Current Page */
    private String currentPage;

    /* Status */
    private String status;
    
    /* Requester */
    private String requester;
    
	public LocalDateTime getSearchStartDateTime() {
		return searchStartDateTime;
	}
    
	public void setSearchStartDateTime(LocalDateTime searchStartDateTime) {
		this.searchStartDateTime = searchStartDateTime;
	}
	
    public LocalDateTime getSearchEndDateTime() {
		return searchEndDateTime;
	}
	
    public void setSearchEndDateTime(LocalDateTime searchEndDateTime) {
		this.searchEndDateTime = searchEndDateTime;
	}
	
    public ZonedDateTime getSearchStartDateTimeZone() {
		return searchStartDateTimeZone;
	}
    
	public void setSearchStartDateTimeZone(ZonedDateTime searchStartDateTimeZone) {
		this.searchStartDateTimeZone = searchStartDateTimeZone;
	}
	
    public ZonedDateTime getSearchEndDateTimeZone() {
		return searchEndDateTimeZone;
	}
	
    public void setSearchEndDateTimeZone(ZonedDateTime searchEndDateTimeZone) {
		this.searchEndDateTimeZone = searchEndDateTimeZone;
	}
    
    /** Current Page Getter */
    public String getCurrentPage() {
        return currentPage;
    }

    /** Current Page Setter */
    public void setCurrentPage(String currentPage) {
        this.currentPage = currentPage;
    }
    
    /** Status Getter */
    public String getStatus() {
        return status;
    }

    /** Status Setter */
    public void setStatus(String status) {
        this.status = status;
    }
    
    /** Requester Getter */
    public String getRequester() {
        return requester;
    }

    /** Requester Setter */
    public void setRequester(String requester) {
        this.requester = requester;
    }
}

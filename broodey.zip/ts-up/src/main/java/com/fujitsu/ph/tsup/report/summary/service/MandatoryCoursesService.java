//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : MandatoryCoursesService                                                                                                                                                               
// Class Name   : MandatoryCoursesService.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 1.0.0   | 2021/04/21 | WS)C.Fuerzas          | New Creation      
// 1.0.1   | 2021/05/05 | WS)C.Fuerzas          | Updated
// 1.0.2   | 2021/07/12 | WS)RL.Naval           | Updated
// 1.0.3   | 2021/08/13 | WS)RL.Naval           | Updated
// 1.0.4   | 2021/10/13 | WS)R.Buot             | Updated
// 1.0.5   | 2021/10/14 | WS)D.Dinglasan        | Updated
// 1.0.6   | 2021/10/21 | WS)DW.Cardenas        | Updated
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

import com.fujitsu.ph.tsup.report.summary.model.MandatoryCourses;

/**
 * <pre>
 * Service for the MandatoryCoursesController
 * </pre>
 * 
 * @author c.fuerzas
 * @author rl.naval
 * @author r.buot
 * @author d.dinglasan
 * @version 1.0.5
 */
public interface MandatoryCoursesService {

    /**
     * <pre>
     * Finds all the mandatory courses
     * </pre>
     * @return Set of MandatoryCourses
     */
    public Set<MandatoryCourses> getMandatoryCourses();
 
	/**
	 * <pre>
     * Finds all the mandatory courses for all members based on the given date range
     * </pre>
     * @param selectedReportDate
     * @return Set of MandatoryCourses
     */
    public Set<MandatoryCourses> getMandatoryCourses(LocalDateTime selectedReportDate);

    /**
     * Acquires the total number of JDU members.
     * @return long
     */
    public long getTotalNumberOfJduMembers();

    /**
     * Acquires the total number of enrolled JDU members.
     * @return long
     */
    public long getTotalNumberOfEnrolledJdu(String course);

    /**
     * Acquires the total number of completion for the specified course.
     * 
     * @param mandatoryCourse
     * @param reportDate
     * @return long
     */
    public long getTotalNumberOfCompletion(String mandatoryCourse, LocalDateTime reportDate);

    /**
     * Acquires the total number of completion for the specified course within last week
     * 
     * @param mandatoryCourse
     * @param reportDate
     * @return long
     */
    public long getTotalNumberOfCompletionLastWeek(String mandatoryCourse, LocalDateTime reportDate);

    /**
     * Calculates the completion percentage per course today or last week
     * @param when
     * @return
     */
    BigDecimal getCompletionPercentage(String when);
}

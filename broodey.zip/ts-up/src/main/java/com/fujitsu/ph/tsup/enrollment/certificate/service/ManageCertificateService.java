package com.fujitsu.ph.tsup.enrollment.certificate.service;

import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import com.fujitsu.ph.tsup.enrollment.certificate.model.ManageCertificate;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;
import com.fujitsu.ph.tsup.enrollment.model.FileStorageProperties;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Manage Certificate
//Class Name   : ManageCertificateService.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/08/11 | WS) hl.berja       | Initial Version
//==================================================================================================

/**
 * <pre>
 * It is the interface of manage certificate service
 * In this interface, it consists of the method required for the initial setting of the database
 * </pre>
 * 
 * @author WS) hl.berja
 * 
 * */
public interface ManageCertificateService {
    
    // Method to find all certificates base on Pageable object provided
    Page<ManageCertificate> loadAllCertificates(Pageable pageable);

    // Method for deleting the certificate
    Boolean deleteCertificateById(Long id); 
    
    // Method for updating the certificate
    Boolean updateCertificate(Certificate certificate);

    // Method for finding the certificate download URI base on employee id and course id
    String getCertificateDownloadUri(Long employeeId, Long courseId);

    // Method for storing the file in the specified directory
    String storeFile(MultipartFile file, Long id, FileStorageProperties fileStorageProperties,
            Long employeeId);

    // Method for getting the certificate file for viewing and downloading certificate
    Resource loadFileAsResource(String fileName, FileStorageProperties fileStorageProperties);
}

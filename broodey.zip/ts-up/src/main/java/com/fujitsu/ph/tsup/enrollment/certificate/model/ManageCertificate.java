/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.enrollment.certificate.model;

import java.time.ZonedDateTime;
//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Manage Certificate
//Class Name   : ManageCertificate.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/08/11 | WS) jp.maestro         | Initial Version
//==================================================================================================

public class ManageCertificate {
    private Long id;
    private Long employeeId;
    private Long courseId;
    private String courseName;
    private String certificate;
    private String fileDownloadUri;
    private ZonedDateTime uploadDate;
    
    /**
     * Empty Constructor for ManageCertificate class
     */
    protected ManageCertificate() {

    }

    private ManageCertificate(Builder builder) {
        this.id = builder.id;
        this.employeeId = builder.employeeId;
        this.courseId = builder.courseId;
        this.courseName = builder.courseName;
        this.certificate = builder.certificate;
        this.fileDownloadUri = builder.fileDownloadUri;
        this.uploadDate = builder.uploadDate;
    }
    
    /**
     * Getter method for Id
     * 
     * @return Id
     */
    public Long getId() {
        return id;
    }
    
    /**
     * Setter method for Id
     * 
     * @param id Id
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    /**
     * Getter method for Employee Id
     * 
     * @return Employee Id
     */
    public Long getEmployeeId() {
        return employeeId;
    }
    
    /**
     * Setter method for Employee Id
     * 
     * @param employeeId Employee Id
     */
    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    /**
     * Getter method for Course Name
     * 
     * @return Course Name
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * Setter method for Course Name
     * 
     * @param courseName Course Name
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    /**
     * Getter method for Certificate
     * 
     * @return Certificate
     */
    public String getCertificate() {
        return certificate;
    }

    /**
     * Setter method for Certificate
     * 
     * @param certificate Certificate
     */
    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    /**
     * Getter method for File Download URI
     * 
     * @return File Download URI
     */
    public String getFileDownloadUri() {
        return fileDownloadUri;
    }
    
    /**
     * Setter method for File Download URI
     * 
     * @param fileDownloadUri File Download URI
     */
    public void setFileDownloadUri(String fileDownloadUri) {
        this.fileDownloadUri = fileDownloadUri;
    }

    /**
     * Getter method for Upload date
     * 
     * @return Upload date
     */
    public ZonedDateTime getUploadDate() {
        return uploadDate;
    }

    /**
     * Setter method for Upload date
     * 
     * @param uploadDate Upload date
     */
    public void setUploadDate(ZonedDateTime uploadDate) {
        this.uploadDate = uploadDate;
    }
    
    /**
     * Getter method for Course ID
     * 
     * @return Course ID
     */
    public Long getCourseId() {
        return courseId;
    }

    /**
     * Setter method for Course ID
     * 
     * @param courseId Course ID
     */
    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    @Override
    public String toString() {
        return "ManageCertificate [certificate=" + certificate + ", courseId=" + courseId + ", courseName="
                + courseName + ", employeeId=" + employeeId + ", fileDownloadUri=" + fileDownloadUri + ", id="
                + id + ", uploadDate=" + uploadDate + "]";
    }

    /**
     * Builder Class
     * 
     * 
     * @author jp.maestro
     */
    public static class Builder {
        private Long id;
        private Long employeeId;
        private String courseName;
        private String certificate;
        private String fileDownloadUri;
        private ZonedDateTime uploadDate;
        private Long courseId;

        public Builder(Long id, Long employeeId, Long courseId, String courseName, String certificate,
                String fileDownloadUri, ZonedDateTime uploadDate) {

            validateId(id);
            validateEmployeeId(employeeId);
            validateCourseName(courseName);
            validateCertificate(certificate);
            validateFileDownloadUri(fileDownloadUri);
            validateUploadDate(uploadDate);

            this.id = id;
            this.employeeId = employeeId;
            this.courseId = courseId;
            this.courseName = courseName;
            this.certificate = certificate;
            this.fileDownloadUri = fileDownloadUri;
            this.uploadDate = uploadDate;
        }

        public ManageCertificate build() {
            return new ManageCertificate(this);
        }

        
        /**
         * Validate if ID is null or 0
         * 
         * @param id ID
         */
        private void validateId(Long id) {
            if (id == null || id == 0) {
                throw new IllegalArgumentException("Id should not be empty.");
            }
        }

        /**
         * Validate if Employee ID is null or 0
         * 
         * @param EmployeeId Employee ID
         */
        private void validateEmployeeId(Long employeeId) {
            if (employeeId == null || employeeId == 0) {
                throw new IllegalArgumentException("Employee Id should not be empty.");
            }
        }

        /**
         * Validate if Course Name is null or empty
         * 
         * @param CourseName Course Name
         */
        private void validateCourseName(String courseName) {
            if (courseName == null || courseName.isEmpty()) {
                throw new IllegalArgumentException("Course Name should not be empty.");
            }
        }

        /**
         * Validate if Certificate is null or empty
         * 
         * @param certificate Certificate
         */
        private void validateCertificate(String certificate) {
            if (certificate == null || certificate.isEmpty()) {
                throw new IllegalArgumentException("Certificate should not be empty.");
            }
        }

        /**
         * Validate if File download URI is null or empty
         * 
         * @param fileDownloadUri File download URI
         */
        private void validateFileDownloadUri(String fileDownloadUri) {
            if (fileDownloadUri == null || fileDownloadUri.isEmpty()) {
                throw new IllegalArgumentException("Download URI should not be empty.");
            }
        }

        /**
         * Validate if Upload date is null
         * 
         * @param UploadDate Upload date
         */
        private void validateUploadDate(ZonedDateTime uploadDate) {
            if (uploadDate == null) {
                throw new IllegalArgumentException("Upload Date should not be empty.");
            }
        }
    }

}

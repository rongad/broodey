package com.fujitsu.ph.tsup.instructorconduct.model;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: CourseScheduleForm.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja | New Creation
//=======================================================

/**
* <pre>
* JavaBean for CourseScheduleForm
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.util.Set;

public class CourseScheduleForm {

    /**
     * Course Schedule Id
     */
    private Long id;

    /**
     * Course Id
     */
    private Long courseId;

    /**
     * Course Name
     */
    private String courseName;

    /**
     * Instructor Id
     */
    private Long instructorId;

    /**
     * Instructor Name(LASTNAME, FIRSTNAME)
     */
    private String instructorName;

    /**
     * Venue Id
     */
    private Long venueId;

    /**
     * Venue Name
     */
    private String venueName;

    /**
     * Minimum number of participants
     */
    private int minRequired;

    /**
     * Maximum number of participants
     */
    private int maxAllowed;

    /**
     * Total Number of Participants currently enrolled
     */
    private int totalParticipants;

    /**
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return
     */
    public Long getCourseId() {
        return courseId;
    }

    /**
     * @param courseId
     */
    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    /**
     * @return
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * @param courseName
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    /**
     * @return
     */
    public Long getInstructorId() {
        return instructorId;
    }

    /**
     * @param instructorId
     */
    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    /**
     * @return
     */
    public String getInstructorName() {
        return instructorName;
    }

    /**
     * @param instructorName
     */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    /**
     * @return
     */
    public Long getVenueId() {
        return venueId;
    }

    /**
     * @param venueId
     */
    public void setVenueId(Long venueId) {
        this.venueId = venueId;
    }

    /**
     * @return
     */
    public String getVenueName() {
        return venueName;
    }

    /**
     * @param venueName
     */
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    /**
     * @return
     */
    public int getMinRequired() {
        return minRequired;
    }

    /**
     * @param minRequired
     */
    public void setMinRequired(int minRequired) {
        this.minRequired = minRequired;
    }

    /**
     * @return
     */
    public int getMaxAllowed() {
        return maxAllowed;
    }

    /**
     * @param maxAllowed
     */
    public void setMaxAllowed(int maxAllowed) {
        this.maxAllowed = maxAllowed;
    }

    /**
     * @return
     */
    public int getTotalParticipants() {
        return totalParticipants;
    }

    /**
     * @param totalParticipants
     */
    public void setTotalParticipants(int totalParticipants) {
        this.totalParticipants = totalParticipants;
    }

    @Override
    public String toString() {
        return "CourseScheduleForm [id = " + id + ", courseId = " + courseId + ", courseName = " + courseName
                + ", instructorId = " + instructorId + ", instructorName = " + instructorName + ", venueId = " + venueId
                + ", venueName = " + venueName  + ", minRequired = " + minRequired + ", maxAllowed = " + maxAllowed
                + ", totalParticipants = " + totalParticipants + "]";
    }

}

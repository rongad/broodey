/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.instructorconduct.model;

import java.util.Objects;

//=======================================================
//Project Name: Training Sign Up
//Class Name: SurveySearchFilter.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/10/2021 | WS) MI.Aguinaldo | New Creation
//0.02    | 08/26/2021 | WS) M.Yanoyan    | Update isAllFieldsNonValid
//=======================================================

public class SurveySearchFilter {
    
    private String courseName;
    
    private String instructorName;
    
    private Long instructorId;
    
    private Long courseId;
    
    /**
     * @return the courseName
     */
    public String getCourseName() {
        return courseName;
    }
    /**
     * @param courseName the courseName to set
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    /**
     * @return the instructorName
     */
    public String getInstructorName() {
        return instructorName;
    }
    /**
     * @param instructorName the instructorName to set
     */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }
    
    /**
     * @return the instructorId
     */
    public Long getInstructorId() {
        return instructorId;
    }
    /**
     * @param instructorId the instructorId to set
     */
    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }
    
    
    /**
     * @return the courseId
     */
    public Long getCourseId() {
        return courseId;
    }
    /**
     * @param courseId the courseId to set
     */
    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }
    public boolean isAllFieldsNonValid() {
        return Objects.equals(getCourseId(),-1L) && Objects.equals(getInstructorId(),-1L);
    }
    

}

/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.search;

import org.apache.commons.lang3.StringUtils;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Course Management
//Class Name   : CourseSearchFilter.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/06/09 | WS) mi.aguinaldo       | Initial Version
//0.02    | 2021/08/05 | WS) mi.aguinaldo       | Update
//==================================================================================================

public class CourseSearchFilter {
    private String courseName;
    private String courseCategory;
    private String mandatory;
    private String deadline;
    private String mandatoryType;
    private String department;
    private String memberRole;
    
    public CourseSearchFilter() {
	super();
    }

    
    /**
     * @return the courseName
     */
    public String getCourseName() {
        return courseName;
    }



    /**
     * @return the courseCategory
     */
    public String getCourseCategory() {
        return courseCategory;
    }


    /**
     * @return the mandatory
     */
    public String getMandatory() {
        return mandatory;
    }


    
    /**
     * @return the deadline
     */
    public String getDeadline() {
        return deadline;
    }


    /**
     * @param courseName the courseName to set
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

  
    /**
     * @param courseCategory the courseCategory to set
     */
    public void setCourseCategory(String courseCategory) {
        this.courseCategory = courseCategory;
    }

    /**
     * @param mandatory the mandatory to set
     */
    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }


    /**
     * @param deadline the deadline to set
     */
    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }
    
    
    

    /**
     * @return the mandatoryType
     */
    public String getMandatoryType() {
        return mandatoryType;
    }


    /**
     * @param mandatoryType the mandatoryType to set
     */
    public void setMandatoryType(String mandatoryTypeString) {
        this.mandatoryType = mandatoryTypeString;
    }
    

    /**
     * @return the department
     */
    public String getDepartment() {
        return department;
    }


    /**
     * @param department the department to set
     */
    public void setDepartment(String department) {
        this.department = department;
    }
    
    /**
     * @return the member role
     */
    public String getMemberRole() {
        return memberRole;
    }


    /**
     * @param member role the member role to set
     */
    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }
    
    // Method for checking if the search is empty
    public boolean isSearchEmpty() {
	return StringUtils.isAllBlank(getCourseName(),getCourseCategory(),
				      getMandatory(),getDeadline(),
				      getDepartment(),getMandatoryType(),getMemberRole());
    }
}

package com.fujitsu.ph.tsup.enrollment.model;

//==================================================================================================
//$Id:PR01$
//Project Name :Training Sign Up
//System Name  :Enroll Course
//Class Name   :CourseEnrollmentForm.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 06/23/2020 | WS) M. Rivera         | New Creation
//0.02    | 06/16/2021 | WS) K.Sevilla         | Updated
//0.03    | 07/16/2021 | WS) MI.Aguinaldo      | Updated
//0.04    | 07/22/2021 | WS) K.Sevilla         | Updated
//==================================================================================================
/**
* <pre>
* JavaBean for CourseEnrollmentForm
* <pre>
* 
* @version 0.01
* @author m.rivera                          
*/

import java.time.ZonedDateTime;
import java.util.Comparator;
import java.util.Objects;

import com.fujitsu.ph.tsup.enrollment.domain.CourseParticipant;
import com.fujitsu.ph.tsup.enrollment.domain.CourseScheduleDetail;

public class CourseEnrollmentForm {
    /* Course ID */
    private Long id;
    
    /* Course Id*/
    private Long courseId;

	/* Course Schedule ID */
    private Long courseScheduleId;

    /* Course Name */
    private String courseName;
    
    /* Course participant ID */
    private Long participantId;

    /* Instructor Name (LASTNAME, FIRSTNAME) */
    private String instructorName;

    /* Venue Name */
    private String venueName;
    
    private String courseStatus;
    private String courseCategory;
    private String departmentType;
    
    public String mandatoryType;
    
    /* Email Address */
    //NEW
    private String emailAddress;

    /* Course Participant ID */
    private CourseScheduleDetailForm courseScheduleDetails;

    /* Course Participant ID */
    private ZonedDateTime registrationDate;
    
    private String attendanceStatus;
    
    private String courseDetails;


    private CourseEnrollmentForm(Builder builder) {
	this.id = builder.id;
	this.courseId = builder.courseId;
	this.courseScheduleId = builder.courseScheduleId;
	this.courseName = builder.courseName;
	this.participantId = builder.participantId;
	this.instructorName = builder.instructorName;
	this.venueName = builder.venueName;
	this.courseStatus = builder.courseStatus;
	this.emailAddress = builder.emailAddress;
	this.courseScheduleDetails = builder.courseScheduleDetails;
	this.registrationDate = builder.registrationDate;
	this.attendanceStatus = builder.attendanceStatus;
	this.courseDetails = builder.courseDetails;
    }
    

    public CourseEnrollmentForm() {
	super();
    }
    
    public CourseEnrollmentForm(CourseParticipant courseParticipant) {
	Objects.requireNonNull(courseParticipant, "CourseParticipant must not be null");
	Objects.requireNonNull(courseParticipant.getCourseScheduleDetail(), "CourseScheduleDetail must not be null");

	this.id = courseParticipant.getId();
	this.courseId = courseParticipant.getCourseId();
	this.courseScheduleId = courseParticipant.getCourseScheduleId();
	this.courseName = courseParticipant.getCourseName();
	this.instructorName = courseParticipant.getInstructorName();
	this.venueName = courseParticipant.getVenueName();
	this.courseStatus = courseParticipant.getCourseStatus();
	this.courseCategory = courseParticipant.getCourseCategory();
	this.departmentType = courseParticipant.getDepartmentType();
	this.mandatoryType = courseParticipant.getMandatoryType();
	this.registrationDate = courseParticipant.getRegistrationDate();
	this.participantId = courseParticipant.getParticipantId();
	this.attendanceStatus = courseParticipant.getAttendanceStatus();
	this.courseDetails = courseParticipant.getCourseDetails();
	
	CourseScheduleDetail courseSchedDet = courseParticipant.getCourseScheduleDetail();
	CourseScheduleDetailForm courseScheduleDetailForm = new CourseScheduleDetailForm();
	
	courseScheduleDetailForm.setScheduledStartDateTime(courseSchedDet.getScheduledStartDateTime());
	courseScheduleDetailForm.setScheduledEndDateTime(courseSchedDet.getScheduledEndDateTime());
	courseScheduleDetailForm.setDuration(courseSchedDet.getDuration());
	
	this.courseScheduleDetails = courseScheduleDetailForm;

    }
    
    
    
    
    public String getCourseDetails() {
        return courseDetails;
    }
    public void setCourseDetails(String courseDetails) {
        this.courseDetails = courseDetails;
    }
    /** Course Participant ID Getter */
    public Long getId() {
        return id;
    }
    /* Course Id Getter*/
    public Long getCourseId() {
	return courseId;
    }

    /* Course Id Setter */
    public void setCourseId(Long courseId) {
	this.courseId = courseId;
    }
	
    /** Schedule ID Getter */
    public Long getCourseScheduleId() {
        return courseScheduleId;
    }

    /** Course Name Getter */
    public String getCourseName() {
        return courseName;
    }

    /** Instructor Name Getter */
    public String getInstructorName() {
        return instructorName;
    }

    /** Venue Name Getter */
    public String getVenueName() {
        return venueName;
    }
    
    /** setCourseStatus Getter */
    public String getCourseStatus() {
        return courseStatus;
    }
    /** setcourseCategory Getter */
    public String getCourseCategory() {
        return courseCategory;
    }
    /** setdepartmentType Getter */
    public String getDepartmentType() {
        return departmentType;
    }
    
    /** setMandatoryType Getter */
    public String getMandatoryType() {
        return mandatoryType;
    }
    
    public String getEmailAddress() {
	return emailAddress;
    }

    public String getAttendanceStatus() {
	return attendanceStatus;
    }

    public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
    }

    /** Course Schedule Details Getter */
    public CourseScheduleDetailForm getCourseScheduleDetails() {
        return courseScheduleDetails;
    }

    /** Registration Date Getter */
    public ZonedDateTime getRegistrationDate() {
        return registrationDate;
    }

    /** Course Participant ID Setter */
    public void setId(Long id) {
        this.id = id;
    }

    /** Course Schedule ID Setter */
    public void setCourseScheduleId(Long courseScheduleId) {
        this.courseScheduleId = courseScheduleId;
    }

    /** Course Name Setter */
    public void setCourseName(String courseName) {
        this.courseName = courseName;

    }

    /** Instructor ID Setter */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;

    }

    /** Venue Name Setter */
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }
    
    /** setCourseStatus Setter */
    public void setCourseStatus(String courseStatus) {
    	this.courseStatus = courseStatus;
	}
    public void setCourseCategory(String courseCategory) {
    	this.courseCategory = courseCategory;
	}
    public void setDepartmentType(String departmentType) {
    	this.departmentType = departmentType;
	}
    public void setMandatoryType(String mandatoryType) {
    	this.mandatoryType = mandatoryType;
	}

    /** CourseScheduleDetails Setter */
    public void setCourseScheduleDetails(CourseScheduleDetailForm courseScheduleDetails) {
        this.courseScheduleDetails = courseScheduleDetails;
    }

    /** Registration Date Setter */
    public void setRegistrationDate(ZonedDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }
    
    public void setAttendanceStatus(String attendanceStatus) {
        this.attendanceStatus = attendanceStatus;
    }
    
    public Long getParticipantId() {
        return participantId;
    }
    
    public void setParticipantId(Long participantId) {
        this.participantId = participantId;
    }
    
    public Comparator<CourseEnrollmentForm> sortedByCourseName() {
	return Comparator.comparing(CourseEnrollmentForm::getCourseName);
    }
    
    @Override
    public String toString() {

	return "CourseEnrollmentForm [courseName=" + courseName + ", instructorName=" + instructorName + ", venueName="
		+ venueName + ", courseStatus=" + courseStatus + ", courseCategory=" + courseCategory 
		+ ", departmentType=" + departmentType + ", mandatoryType=" + mandatoryType + ", emailAddress=" + emailAddress
		+ ", courseScheduleDetails=" + courseScheduleDetails + ", registrationDate=" + registrationDate
		+ ", attendanceStatus=" + attendanceStatus + ", courseDetails=" + courseDetails + "]";
    }

    /**
     * Creates builder to build {@link CourseEnrollmentForm}.
     * @return created builder
     */
    public static Builder builder() {
	return new Builder();
    }

    /**
     * Builder to build {@link CourseEnrollmentForm}.
     */
    public static final class Builder {
	private Long id;
	private Long courseId;
	private Long courseScheduleId;
	private String courseName;
	private Long participantId;
	private String instructorName;
	private String venueName;
	private String courseStatus;
	private String emailAddress;
	private CourseScheduleDetailForm courseScheduleDetails;
	private ZonedDateTime registrationDate;
	private String attendanceStatus;
	private String courseDetails;

	private Builder() {
	}

	public Builder withId(Long id) {
	    this.id = id;
	    return this;
	}

	public Builder withCourseId(Long courseId) {
	    this.courseId = courseId;
	    return this;
	}

	public Builder withCourseScheduleId(Long courseScheduleId) {
	    this.courseScheduleId = courseScheduleId;
	    return this;
	}

	public Builder withCourseName(String courseName) {
	    this.courseName = courseName;
	    return this;
	}

	public Builder withParticipantId(Long participantId) {
	    this.participantId = participantId;
	    return this;
	}

	public Builder withInstructorName(String instructorName) {
	    this.instructorName = instructorName;
	    return this;
	}

	public Builder withVenueName(String venueName) {
	    this.venueName = venueName;
	    return this;
	}

	public Builder withCourseStatus(String courseStatus) {
	    this.courseStatus = courseStatus;
	    return this;
	}

	public Builder withEmailAddress(String emailAddress) {
	    this.emailAddress = emailAddress;
	    return this;
	}

	public Builder withCourseScheduleDetails(CourseScheduleDetailForm courseScheduleDetails) {
	    this.courseScheduleDetails = courseScheduleDetails;
	    return this;
	}

	public Builder withRegistrationDate(ZonedDateTime registrationDate) {
	    this.registrationDate = registrationDate;
	    return this;
	}

	public Builder withAttendanceStatus(String attendanceStatus) {
	    this.attendanceStatus = attendanceStatus;
	    return this;
	}

	public Builder withCourseDetails(String courseDetails) {
	    this.courseDetails = courseDetails;
	    return this;
	}
	
	public Builder withCourseParticipant(CourseParticipant courseParticipant) {
	    Objects.requireNonNull(courseParticipant, "CourseParticipant must not be null");
	    
	    this.id = courseParticipant.getId();
	    this.courseId = courseParticipant.getCourseId();
	    this.courseScheduleId = courseParticipant.getCourseScheduleId();
	    this.courseName = courseParticipant.getCourseName();
	    this.instructorName = courseParticipant.getInstructorName();
	    this.venueName = courseParticipant.getVenueName();
	    this.courseStatus = courseParticipant.getCourseStatus();
	    this.registrationDate = courseParticipant.getRegistrationDate();
	    this.participantId = courseParticipant.getParticipantId();
	    this.attendanceStatus = courseParticipant.getAttendanceStatus();
	    this.courseDetails = courseParticipant.getCourseDetails();
	    
	    return this;
	}
	
	public Builder withCourseScheduleDetail(CourseScheduleDetail courseScheduleDetail) {
	    Objects.requireNonNull(courseScheduleDetail, "CourseScheduleDetail must not be null");

	    CourseScheduleDetailForm courseScheduleDetailForm = new CourseScheduleDetailForm();

	    courseScheduleDetailForm.setScheduledStartDateTime(courseScheduleDetail.getScheduledStartDateTime());
	    courseScheduleDetailForm.setScheduledEndDateTime(courseScheduleDetail.getScheduledEndDateTime());
	    courseScheduleDetailForm.setDuration(courseScheduleDetail.getDuration());

	    this.courseScheduleDetails = courseScheduleDetailForm;

	    return this;
	}

	public CourseEnrollmentForm build() {
	    return new CourseEnrollmentForm(this);
	}

	
    }
    
  
	
}

/*
 *Copyright (C) 2020 FUJITSU LIMITED All rights reserved.  
 */
package com.fujitsu.ph.tsup.courserequirement.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.config.Task;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.CourseScheduleDetail;
import com.fujitsu.ph.tsup.courserequirement.model.EmployeeChecklist;
import com.fujitsu.ph.tsup.courserequirement.service.CourseRequirementService;

/*==================================================================================================
 * $Id: PR30$
 *Project Name : Training Sign Up
 *System Name  : Course Checklist
 *Class Name   : CourseRequirementController.java
 *
 *<<Modification History>>
 *Version | Date       | Updated By            | Content
 *--------+------------+-----------------------+-----------------------------------------------------
 *0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 *0.02    | 2021/10/19 | WS) e.delosreyes      | change requirement method model.addAttribute
 *0.03    | 2021/10/29 | WS) e.delosreyes      | update
 *0.04    | 2021/11/03 | WS) e.delosreyes      | update
 *0.05    | 2021/11/04 | WS) a.abellanosa      | update deleteCourseRequirement, $Id
 *0.06    | 2021/11/05 | WS) a.abellanosa      | update unnecessary imports, add comments, remove getAttendeeChecklist
 *0.07    | 2021/11/10 | WS) e.delosreyes      | corrected view location for /courserequirement
 *===================================================================================================
 */

/**
 * <pre>
 * The controller for Course Checklist Requirements
 * 
 * <pre>
 * 
 * @version 0.06
 * @author a.abellanosa
 */
@Controller
@RequestMapping("/courseRequirement")
public class CourseRequirementController {

	@Autowired
	private CourseRequirementService courseRequirementService;


	/**
	 * <pre>
	 * View course requirement checklist page Method: GET
	 * 
	 * <pre>
	 *
	 * @param model
	 * @return requirementChecklistPage (file-url)
	 */
	@GetMapping("/load")
	public String requirement(Model model) {
		List<Course> courses = courseRequirementService.getCourses();
		model.addAttribute("title", "Course Checklist Requirement");
		model.addAttribute("courses", courses);

		return "course-requirement/courseRequirement";
	}

	/**
	 * <pre>
	 * Returns the list of course requirement of the selected course Method: GET
	 * 
	 * <pre>
	 *
	 * @param courseScheduleId
	 * @return ResponseEntity and List<CourseParticipant>
	 */
	@GetMapping("/getCourseParticipants")
	public ResponseEntity<List<CourseParticipant>> getCourseParticipants(Integer courseScheduleId){
		List<CourseParticipant> courseParticipants = courseRequirementService.getCourseParticipants(courseScheduleId);
		return new ResponseEntity<>(courseParticipants, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * Returns the list of course requirement of the selected course Method: GET
	 * 
	 * <pre>
	 *
	 * @param participantId
	 * @param courseId
	 * @return ResponseEntity and List<EmployeeChecklist>
	 */
	@GetMapping("/getParticipantChecklist")
	public ResponseEntity<List<EmployeeChecklist>> getParticipantChecklist(Integer participantId, Integer courseId){
		List<EmployeeChecklist> courseParticipants = courseRequirementService.getParticipantChecklist(participantId, courseId);
		return new ResponseEntity<>(courseParticipants, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * Returns the list of course requirement of the selected course Method: GET
	 * 
	 * <pre>
	 *
	 * @param courseId
	 * @return ResponseEntity and List<CourseChecklist>
	 */
	@GetMapping("/getCourseRequirement")
	public ResponseEntity<List<CourseChecklist>> getCourseRequirement(Integer courseId) {
		List<CourseChecklist> courseChecklists = courseRequirementService.getCourseRequirements(courseId);
		return new ResponseEntity<>(courseChecklists, HttpStatus.OK);
	}

		/**
	 * <pre>
	 * Returns the list of course schedules
	 * Method: GET
	 * <pre>
	 *
	 * @param courseId
	 * @return ResponseEntity and Set<CourseAttendance>
	 */
	@GetMapping("/getSchedules")
	public ResponseEntity<List<CourseScheduleDetail>> getSchedules(Integer courseId){
		List<CourseScheduleDetail> courseScheduleDetails = courseRequirementService.getCourseScheduleDetails(courseId);
		return new ResponseEntity<>(courseScheduleDetails, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * Create the submitted course requirement Method: POST
	 * 
	 * <pre>
	 * 
	 * @param courseChecklist
	 * @return ResponseEntity<Task>
	 */
	@PostMapping(value = "/createCourseRequirement", consumes="application/json")
	public ResponseEntity<Task> createCourseRequirement(@RequestBody CourseChecklist courseChecklist) {
		courseRequirementService.createCourseRequirement(courseChecklist);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * Update the submitted course requirement Method: POST
	 * 
	 * <pre>
	 * 
	 * @param courseChecklist
	 * @return ResponseEntity<Task>
	 */
	@PostMapping(value = "/updateCourseRequirement", consumes="application/json")
	public ResponseEntity<Task> updateCourseRequirement(@RequestBody CourseChecklist courseChecklist) {
		courseRequirementService.updateCourseRequirement(courseChecklist);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * Delete the course requirement Method: POST
	 * 
	 * <pre>
	 *
	 * @param courseId
	 * @return ResponseEntity<Task>
	 */
	@PostMapping(value = "/deleteCourseRequirement", consumes="application/json")
	public ResponseEntity<Task> deleteCourseRequirement(@RequestBody Integer courseRequirementId) {
		courseRequirementService.deleteCourseRequirement(courseRequirementId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * Update the employee's checklist Method: POST
	 * 
	 * <pre>
	 *
	 * @param employeeChecklists
	 * @return ResponseEntity<Task>
	 * @throws Exception
	 */
	@PostMapping(value = "/updateAttendeeChecklist", consumes="application/json")
	public ResponseEntity<Task> updateAttendeeChecklist(@RequestBody List<EmployeeChecklist> employeeChecklists) throws Exception {
		if (employeeChecklists == null) {
			throw new Exception("Null");
		}
		courseRequirementService.updateAttendeeChecklist(employeeChecklists);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}

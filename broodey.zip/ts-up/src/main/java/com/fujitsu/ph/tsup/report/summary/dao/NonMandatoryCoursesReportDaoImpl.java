//==================================================================================================
// Project Name : Training Sign-Up
// System Name : NonMandatoryCoursesReportDaoImpl
// Class Name : NonMandatoryCoursesReportDaoImpl.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/06 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.report.summary.model.Attendee;
import com.fujitsu.ph.tsup.report.summary.model.CourseCategory;

/**
 * <pre>
 * Put Class Description here
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
@Repository
public class NonMandatoryCoursesReportDaoImpl implements NonMandatoryCoursesReportDao {

    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;

    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(NonMandatoryCoursesReportDaoImpl.class);

    /**
     * Parameter value for parameter name [mandatory]
     */
    private static final String NON_MANDATORY = "No";

    /**
     * Parameter name [mandatory]
     */
    private static final String PARAM_MANDATORY = "mandatory";

    /**
     * Parameter name [courseCategoryId]
     */
    private static final String PARAM_COURSE_CATEGORY_ID = "courseCategoryId";

    /**
     * Parameter name [jduId]
     */
    private static final String PARAM_JDU_ID = "jduId";

    /**
     * Parameter name [employee_id]
     */
    private static final String PARAM_EMPLOYEE_ID = "employee_id";

    /**
     * Placeholder for results
     */
    private static final String LOGGER_RESULT = "Result: {}";

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.dao.NonMadatoryCoursesReportDao#findAllNonMandatoryCourses()
     */
    @Override
    public Set<CourseCategory> findAllNonMandatoryCourseCategory() {
        String query = "SELECT DISTINCT c.course_category_id AS ID, cc.category AS CATEGORY "
                + "FROM  tsup.course c "
                + "INNER JOIN tsup.course_category cc ON c.course_category_id = cc.id "
                + "WHERE c.mandatory = :mandatory";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue(PARAM_MANDATORY,
                NON_MANDATORY);

        List<CourseCategory> coursecategoryList = template.query(query, sqlParameterSource,
                new CourseCategoryRowMapper());

        logger.debug(LOGGER_RESULT, coursecategoryList);

        return new LinkedHashSet<>(coursecategoryList);
    }

    /*
     * (non-Javadoc)
     * @see
     * com.fujitsu.ph.tsup.report.summary.dao.NonMandatoryCoursesReportDao#findAllCoursesUnderCourseCategory(
     * java.lang.Long)
     */
    @Override
    public Map<Long, String> findAllCoursesUnderCourseCategory(Long courseCategoryID) {
        String query = "SELECT c.id AS COURSE_ID, c.name AS COURSE_NAME " + "FROM tsup.course c "
                + "WHERE c.course_category_id = :courseCategoryId AND c.mandatory = :mandatory "
                + "ORDER BY c.name";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue(PARAM_COURSE_CATEGORY_ID, courseCategoryID)
                .addValue(PARAM_MANDATORY, NON_MANDATORY);

        Map<Long, String> courseMap = template.query(query, sqlParameterSource, (ResultSet rs) -> {
            Map<Long, String> resultMap = new HashMap<>();
            while (rs.next()) {
                resultMap.put(rs.getLong("COURSE_ID"), rs.getString("COURSE_NAME"));
            }
            return resultMap;
        });

        logger.debug(LOGGER_RESULT, courseMap);

        return courseMap;
    }

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.dao.NonMandatoryCoursesReportDao#findAllMembers(java.lang.Long)
     */
    @Override
    public Set<Attendee> findAllMembers(Long jduId) {
        String query = "SELECT DISTINCT '0' AS COURSE_ID, '' AS COURSE_NAME, e.id AS EMPLOYEE_ID, CONCAT(e.last_name,', ', e.first_name) AS EMPLOYEE_NAME, '' AS DATE_ATTENDED "
                + "FROM tsup.employee e INNER JOIN tsup.department d "
                + "ON d.id = e.department_id WHERE d.jdu_id = :jduId ORDER BY EMPLOYEE_NAME";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue(PARAM_JDU_ID, jduId);

        List<Attendee> memberList = template.query(query, sqlParameterSource,
                new NonMandatoryCoursesReportRowMapper());

        logger.debug(LOGGER_RESULT, memberList);

        return new LinkedHashSet<>(memberList);
    }

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.dao.NonMandatoryCoursesReportDao#getJDUType()
     */
    @Override
    public Long getJDUType() {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        String query = "SELECT jt.id FROM tsup.jdu_type jt "
                + "INNER JOIN tsup.department d ON d.jdu_id = jt.id "
                + "INNER JOIN tsup.employee e ON e.department_id = d.id WHERE e.id = :employee_id";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue(PARAM_EMPLOYEE_ID,
                user.getId());

        Long jduType = template.queryForObject(query, sqlParameterSource, Long.class);

        logger.debug(LOGGER_RESULT, jduType);
        return jduType;
    }

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.dao.NonMandatoryCoursesReportDao#
     * findAllAttendeesOfNonMandatoryCourses(java.lang.Long)
     */
    @Override
    public Set<Attendee> findAllAttendeesOfNonMandatoryCourses(Long courseCategoryID, Long jduId) {
        String query = "SELECT c.id AS COURSE_ID, c.name AS COURSE_NAME, e.id as EMPLOYEE_ID, "
                + "CONCAT(e.last_name, ', ', e.first_name) AS EMPLOYEE_NAME, "
                + "to_char(ca.log_in_datetime, 'YYYY-MM-DD') AS DATE_ATTENDED FROM tsup.course c "
                + "INNER JOIN tsup.course_category cc ON cc.id = c.course_category_id "
                + "INNER JOIN tsup.course_schedule cs ON c.id = cs.course_id "
                + "INNER JOIN tsup.course_schedule_detail csd ON cs.id = csd.course_schedule_id "
                + "INNER JOIN tsup.course_attendance ca ON ca.course_schedule_detail_id = csd.id "
                + "INNER JOIN tsup.employee e ON e.id = ca.participant_id "
                + "INNER JOIN tsup.department d ON d.id = c.department_id "
                + "WHERE cc.id = :courseCategoryId AND c.mandatory = :mandatory AND d.jdu_id = :jduId AND ca.status = 'P' "
                + "ORDER BY EMPLOYEE_NAME ASC";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue(PARAM_COURSE_CATEGORY_ID, courseCategoryID).addValue(PARAM_MANDATORY, NON_MANDATORY)
                .addValue(PARAM_JDU_ID, jduId);
        List<Attendee> attendeeList = template.query(query, sqlParameterSource,
                new NonMandatoryCoursesReportRowMapper());
        logger.debug(LOGGER_RESULT, attendeeList);
        return new LinkedHashSet<>(attendeeList);
    }

}

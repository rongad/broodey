package com.fujitsu.ph.tsup.instructorconduct.service;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: InstructorConductService.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja     | New Creation
//0.02    | 10/08/2021 | WS) MI.Aguinaldo | Update
//0.03    | 10/27/2021 | WS) L.Celoso     | Added Pagination
//=======================================================

/**
* <pre>
* The service for course schedules assigned to instructor. 
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseForm;
import com.fujitsu.ph.tsup.instructorconduct.model.SurveySearchFilter;

public interface InstructorConductService {
    
    
    /**
     * Find all course schedule view form.
     *
     * @return the sets the
     */
    Set<CourseSchedule> findAllCourseSchedVForm(Pageable pageable);
    
    /**
     * Find all course form.
     *
     * @return the sets the
     */
    Set<CourseForm> findAllCourseForm();
    
    /**
     * <pre>
     * Finds all course schedule view form assigned to instructor
     * <pre>
     * @param instructorId
     * @return Set<CourseScheduleViewForm>
     */
    Set<CourseSchedule> findAllCourseSchedVFormByInstructorId(Pageable pageable, Long instructorId);
    
    /**
     * Finds course schedule view form assigned to instructor by course Id 
     * @param instructorId 
     * @param courseId
     * @return Set<CourseScheduleViewForm>
     */
    Set<CourseSchedule> findAllCourseSchedVFormByInstructorIdCourseId(Pageable pageable, Long instructorId, Long courseId);
    
    /**
     * Find assign courses by instructor.
     *
     * @param instructorId the instructor id
     * @return the sets the
     */ 
    Set<CourseForm> findAssignCoursesByInstructor(Long instructorId);

    Set<CourseSchedule> findAllCourseSchedVFormByCourse(Pageable pageable, String courseName);

    /**
     * @param surveySearchFilter
     * @return
     */
    Set<CourseSchedule> findAllCourseSchedVFormBySearchFilter(Pageable pageable, SurveySearchFilter surveySearchFilter);
    
    /**
     * Method for counting the number of available course for specific Instructor
     * 
     * @author l.celoso
     *
     * @param string 
     */
    int countCourseForInstructor(Long instructorId);
    
    /**
     * Method for counting the number of available course for specific Instructor and Course
     * 
     * @author l.celoso
     *
     * @param string 
     */
    int countCourseForInstructorFilter(Long instructorId, Long courseId);
    
    
    /**
     * Method for counting the number of available course
     * 
     * @author l.celoso
     *
     * @param string 
     */
    int countCourseForAll();
    
    /**
     * Method for counting the number of available course with searchFilter
     * 
     * @author l.celoso
     *
     * @param string 
     */
    int countCourseForAllFilter(SurveySearchFilter surveySearchFilter);
}
package com.fujitsu.ph.tsup.attendance.service;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import com.fujitsu.ph.tsup.attendance.dao.AttendanceDao;
import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.attendance.domain.CourseParticipant;
import com.fujitsu.ph.tsup.attendance.domain.CourseSchedule;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseField;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.RadioCheckField;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.attendance.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.attendance.model.ScheduleDetail;

// ==================================================================================================
// $Id:PR03$
// Project Name : Training Sign up
// System Name : Attendance process
// Class Name : AttendanceServiceImpl.java
//
// <<Modification History>>
// Version | Date | Updated By                                                    | Content
// --------+------------+---------------------------------------------------------+-----------------
// 0.01 | 06/23/2020 | WS) K.Abad, WS) M.Angara, WS) J.Iwarat, WS) R.Ramos        | New Creation
// 0.02 | 07/03/2020 | WS) K.abad, WS) R.Ramos                                    | Update
// 0.03 | 07/07/2020 | WS) J.iwarat                                               | Update
// 0.04 | 07/08/2020 | WS) J.iwarat                                               | Update
// 0.05 | 07/08/2020 | WS) R.ramos                                                | Update
// 0.06 | 07/09/2020 | WS) R.ramos                                                | Update
// 0.07 | 07/30/2020 | WS) K.Abad, WS) R.Ramos                                    | Update
// 0.08 | 08/05/2020 | WS) K.Abad, WS) R.Ramos                                    | Update
// 0.09 | 08/26/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos                      | Update
// 0.10 | 08/18/2021 | WS) DW.Cardenas                                            | Update
// 0.10 | 08/17/2021 | WS) Jo.Dominguez                                           | Update
// 0.11 | 09/02/2021 | WS) CJ.Zamora                                              | Update
// 0.12 | 09/27/2021 | WS) L.Celoso                                               | Integrate the PDF Export functionality
// ==================================================================================================
/**
 * <pre>
 * It is the implementation of attendance service
 * In this class, it implements the AttendanceService class for the initial setting of the database
 * </pre>
 * 
 * @version 0.09
 * @author k.abad
 * @author m.angara
 * @author j.iwarat
 * @author r.ramos
 */

@Service
public class AttendanceServiceImpl implements AttendanceService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AttendanceServiceImpl.class);
    /*
     * AttendanceDao
     */
    @Autowired
    private AttendanceDao attendanceDao;

    /**
     * <pre>
     * Finds all scheduled courses based on the given date range Call attendanceDao.findAllScheduledCourses
     * using the given fromDateTime, toDateTime, instructor id and return the result
     * 
     * <pre>
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param instructorId
     * @return CourseScheduleSet
     */

    @Override
    public Set<CourseSchedule> findAllScheduledCoursesByInstructor(ZonedDateTime fromDateTime,
            ZonedDateTime toDateTime, Long instructorId) {
        try {
            return attendanceDao.findAllScheduledCourses(fromDateTime, toDateTime, instructorId);
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("Can't find from date time, to date time and instructor Id.",
                    e);
        }

    }

    /**
     * <pre>
     * Finds course schedule based on the given course id Call attendanceDao.findCourseScheduleById using the
     * given course id and return the result
     * 
     * <pre>
     * 
     * @param id
     * @return CourseParticipant Set
     */
    @Override
    public Set<CourseParticipant> findCourseScheduleById(Long id) {
        try {
            return attendanceDao.findCourseScheduleById(id);
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("Course Schedule not found.", e);
        }
    }

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule Id
     * Get those you signed up Call the attendanceDao.findCourseScheduleDetailParticipantsById using the given
     * id and return the result Get those you logged-in Call the
     * attendanceDao.findCourseAttendanceByCourseScheduleDetailId using the given id and return the result
     * Merge the the results of the previous steps. Ensure that there are no duplicate participants. If there
     * are duplicate participants, retain the record from Step 2.1 Return the result of the merge course
     * attendance set.
     * 
     * <pre>
     * 
     * @param id
     * @return CourseAttendance Set
     */

    @Override
    public Set<CourseAttendance> findCourseAttendanceByCourseScheduleDetailId(Long id) {
        try {
            Set<CourseAttendance> signedUp = attendanceDao.findCourseScheduleDetailParticipantsById(id);
            Set<CourseAttendance> loggedIn = attendanceDao.findCourseAttendanceByCourseScheduleDetailId(id);
            Map<Long, CourseAttendance> signUpAndLoggedIn = new HashMap<>();

            for (CourseAttendance p : signedUp) {
                signUpAndLoggedIn.put(p.getParticipantId(), p);
            }

            for (CourseAttendance l : loggedIn) {
                if (!signUpAndLoggedIn.containsKey(l.getParticipantId())) {
                    signUpAndLoggedIn.put(l.getParticipantId(), l);
                }
            }

            return new HashSet<>(signUpAndLoggedIn.values());
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("No record found.", e);
        }
    }

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule Id
     * For each courseAttendance in the Set if courseAttendance.id = null, Call attendanceDao.saveAttendance
     * using the courseAttendance otherwise, Call attendanceDao.updateAttendance using the courseAttendance
     * 
     * <pre>
     * 
     * @param courseAttendanceSet
     */
    @Override
    public void changeStatus(Set<CourseAttendance> courseAttendanceSet) {
        try {
            for (CourseAttendance courseAttendance : courseAttendanceSet) {

                if (courseAttendance.getId() == null) {
                    attendanceDao.saveAttendance(courseAttendance);
                } else {
                    attendanceDao.updateAttendance(courseAttendance);
                }
            }
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("Cannot insert/update data", e);
        }

    }

    /**
     * <pre>
     * Finds Course absent participant Call attendanceDao.findCourseScheduleDetailParticipantsById and return
     * the result Call attendanceDao.findCourseAttendanceByCourseScheduleDetailId and return the result Merged
     * the results and get only the participants that have signed-up but didn't logged-in
     * 
     * <pre>
     * 
     * @param id
     * @return CourseAttendance Set
     */
    @Override
    public Set<CourseAttendance> findCourseAbsentParticipantByCourseScheduleDetailId(Long id) {
        try {
            Map<Long, CourseAttendance> absentMap = new HashMap<>();
            Set<CourseAttendance> signedUp = attendanceDao.findCourseScheduleDetailParticipantsById(id);
            Set<CourseAttendance> loggedIn = attendanceDao.findCourseAttendanceByCourseScheduleDetailId(id);

            for (CourseAttendance a : signedUp) {
                absentMap.put(a.getParticipantId(), a);
            }

            for (CourseAttendance l : loggedIn) {
                if (!absentMap.containsKey(l.getParticipantId())) {
                    absentMap.remove(l.getParticipantId());
                }
            }
            return new HashSet<>(absentMap.values());
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("No record found.", e);
        }
    }

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule
     * detail Id Call the attendanceDao.findCourseScheduleDetailById using the given id and return the result
     * 
     * <pre>
     * 
     * @param id
     * @return courseAttendance
     */
    @Override
    public Set<CourseAttendance> findCourseScheduleDetailById(Long id) {
        try {
            return attendanceDao.findCourseScheduleDetailById(id);
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("No records found.", e);
        }

    }

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule
     * detail Id Call the attendanceDao.saveAttendance using the courseAttendance
     * 
     * <pre>
     * 
     * @param courseAttendance
     */
    @Override
    public void attendLogin(CourseAttendance courseAttendance) {
        try {
            System.out.println("service login");
            attendanceDao.saveAttendance(courseAttendance);
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("No records found.", e);
        }
    }

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule
     * detail Id Call the attendanceDao.updateLogout using the courseAttendance
     * 
     * <pre>
     * 
     * @param courseAttendance
     */
    @Override
    public void attendLogout(CourseAttendance courseAttendance) {
        try {
            System.out.println("service logout");
            attendanceDao.updateLogout(courseAttendance);
        } catch (DataAccessException e) {
            throw new IllegalArgumentException("No records found.", e);
        }
    }

    /**
     * <pre>
     * Finds all scheduled courses based on the given date range Call
     * attendanceDao.findAllScheduledCoursesByParticipant using the given fromDateTime, toDateTime,
     * participant id and return the result
     * 
     * <pre>
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param participantId
     * @param pageable
     * @param courseCategoryId
     * @param courseNameId
     * @param instructorId
     * @param venueId
     * @param departmentId
     * @param mandatory
     * @param mandatoryType
     * @return Course Participant Set
     */
    @Override
    public Set<CourseParticipant> findAllScheduledCoursesByParticipant(CourseScheduleListForm courseScheduleListForm, Pageable pageable) {
        try {
            Set<CourseParticipant> courseParticipant = attendanceDao.findAllScheduledCoursesByParticipant(
            		courseScheduleListForm, pageable);
            if (courseParticipant == null || courseParticipant.isEmpty()) {
                throw new IllegalArgumentException("No schedules found");
            }
            return courseParticipant;
        } catch (DataAccessException e) {
            LOGGER.error(e.getMessage(), e);
            throw new IllegalArgumentException("Can't find from date time, to date time and participant Id.",
                    e);
        }
    }

    // for pagination ===========================================
    @Override
    public int countCourse(CourseScheduleListForm courseScheduleListForm) {

        return attendanceDao.countCourse(courseScheduleListForm);

    }
    // for pagination end =======================================

    @Override
    public Map<String, List<ScheduleDetail>> findAllScheduledCourses(ZonedDateTime fromDate,
            ZonedDateTime toDate, Long instructorId) {
        try {
            Set<CourseSchedule> courseScheds = attendanceDao.findAllScheduledCourses(fromDate, toDate,
                    instructorId);
            Map<String, List<ScheduleDetail>> courseScheduleMap = new HashMap<>();

            for (CourseSchedule courseSched : courseScheds) {
                courseScheduleMap.computeIfAbsent(courseSched.getCourseName(), cs -> new ArrayList<>())
                        .add(new ScheduleDetail(courseSched.getCourseName(), courseSched)); // WORKAROUND FOR
                                                                                            // PRIO TASK
                // .add(new ScheduleDetail(courseSched));
            }

            return courseScheduleMap;
        } catch (DataAccessException e) {
            String err = String.format("Can't find available course schedules from date and time. [%s]",
                    e.getMessage());
            throw new IllegalArgumentException(err);
        }
    }

    /**
     * <pre>
     * Create a PDF Template Base on the Attendance absent or Present, Using the parameter of export,
     * context,request and checkBox.
     * 
     * <pre>
     * 
     * @param export
     * @param context
     * @param request
     * @param checkBox
     * @return
     */
    @Override
    public boolean createPdf(Set<CourseAttendance> export, ServletContext context, int[] typeOfTraining) {
        DateTimeFormatter formatterTime = DateTimeFormatter.ofPattern("HH:mm a");
        DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("MMM dd, yyyy(EEE)");
        Document document = new Document(PageSize.A4, 15, 15, 45, 30);
        try {
            String filePath = context.getRealPath("/resource/reports");
            File file = new File(filePath);
            boolean exists = new File(filePath).exists();
            if (!exists) {
                new File(filePath).mkdirs();
            }

            PdfWriter writer = PdfWriter.getInstance(document,
                    new FileOutputStream(file + "/" + "export" + ".pdf"));
            document.open();

            PdfPTable tableList = new PdfPTable(6);
            tableList.setWidthPercentage(100);
            tableList.setSpacingBefore(5f);
            tableList.setSpacingAfter(5);

            PdfPTable tableCourseDescription = new PdfPTable(4);
            tableCourseDescription.setWidthPercentage(100);
            tableList.setSpacingBefore(5f);
            tableList.setSpacingAfter(5);

            Font fontHeader = FontFactory.getFont("Arial", 11, Font.BOLD);
            Font tableHeader = FontFactory.getFont("Arial", 10, Font.BOLD);
            Font trainingTypeFont = FontFactory.getFont("Arial", 9, Font.BOLD);
            Font tableBody = FontFactory.getFont("Arial", 9);

            float[] columnWidthTableLists = { 3f, 3f, 3f, 2f, 2f, 2f };
            tableList.setWidths(columnWidthTableLists);

            float[] columnWidthsCourseDescription = { 85f, 85f, 85f, 145f };
            tableCourseDescription.setWidths(columnWidthsCourseDescription);

            // CheckBox
            RadioCheckField checkBoxInduction = new RadioCheckField(writer, new Rectangle(20, 648, 30, 658),
                    "check1", "Yes");
            checkBoxInduction.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxInduction.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxInduction.setBorderColor(BaseColor.BLACK);
            checkBoxInduction.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxLanguage = new RadioCheckField(writer, new Rectangle(20, 620, 30, 630),
                    "check2", "Yes");
            checkBoxLanguage.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxLanguage.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxLanguage.setBorderColor(BaseColor.BLACK);
            checkBoxLanguage.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxTeamBuilding = new RadioCheckField(writer,
                    new Rectangle(20, 592, 30, 602), "check3", "Yes");
            checkBoxTeamBuilding.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxTeamBuilding.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxTeamBuilding.setBorderColor(BaseColor.BLACK);
            checkBoxTeamBuilding.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxItTechnicalSoftware = new RadioCheckField(writer,
                    new Rectangle(88, 648, 98, 658), "check4", "Yes");
            checkBoxItTechnicalSoftware.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxItTechnicalSoftware.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxItTechnicalSoftware.setBorderColor(BaseColor.BLACK);
            checkBoxItTechnicalSoftware.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxItTechnicalHardware = new RadioCheckField(writer,
                    new Rectangle(88, 620, 98, 630), "check5", "Yes");
            checkBoxItTechnicalHardware.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxItTechnicalHardware.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxItTechnicalHardware.setBorderColor(BaseColor.BLACK);
            checkBoxItTechnicalHardware.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxItTechnicalProcess = new RadioCheckField(writer,
                    new Rectangle(109, 592, 119, 602), "check6", "Yes");
            checkBoxItTechnicalProcess.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxItTechnicalProcess.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxItTechnicalProcess.setBorderColor(BaseColor.BLACK);
            checkBoxItTechnicalProcess.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxStandard = new RadioCheckField(writer, new Rectangle(109, 565, 119, 575),
                    "check7", "Yes");
            checkBoxStandard.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxStandard.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxStandard.setBorderColor(BaseColor.BLACK);
            checkBoxStandard.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxSoftSkill = new RadioCheckField(writer, new Rectangle(227, 648, 237, 658),
                    "check8", "Yes");
            checkBoxSoftSkill.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxSoftSkill.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxSoftSkill.setBorderColor(BaseColor.BLACK);
            checkBoxSoftSkill.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxManagement = new RadioCheckField(writer,
                    new Rectangle(227, 620, 237, 630), "check9", "Yes");
            checkBoxManagement.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxManagement.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxManagement.setBorderColor(BaseColor.BLACK);
            checkBoxManagement.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxPolicy = new RadioCheckField(writer, new Rectangle(245, 592, 255, 602),
                    "check10", "Yes");
            checkBoxPolicy.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxPolicy.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxPolicy.setBorderColor(BaseColor.BLACK);
            checkBoxPolicy.setBackgroundColor(BaseColor.WHITE);

            RadioCheckField checkBoxOthers = new RadioCheckField(writer, new Rectangle(245, 565, 255, 575),
                    "check11", "Yes");
            checkBoxOthers.setCheckType(RadioCheckField.TYPE_CHECK);
            checkBoxOthers.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            checkBoxOthers.setBorderColor(BaseColor.BLACK);
            checkBoxOthers.setBackgroundColor(BaseColor.WHITE);

            for (int checkBox : typeOfTraining) {
                if (checkBox == 1) {
                    checkBoxInduction.setChecked(true);
                }
                if (checkBox == 2) {
                    checkBoxLanguage.setChecked(true);
                }
                if (checkBox == 3) {
                    checkBoxTeamBuilding.setChecked(true);
                }
                if (checkBox == 4) {
                    checkBoxItTechnicalSoftware.setChecked(true);
                }
                if (checkBox == 5) {
                    checkBoxItTechnicalHardware.setChecked(true);
                }
                if (checkBox == 6) {
                    checkBoxItTechnicalProcess.setChecked(true);
                }
                if (checkBox == 7) {
                    checkBoxStandard.setChecked(true);

                }
                if (checkBox == 8) {
                    checkBoxSoftSkill.setChecked(true);
                }
                if (checkBox == 9) {
                    checkBoxManagement.setChecked(true);
                }
                if (checkBox == 10) {
                    checkBoxPolicy.setChecked(true);
                }
                if (checkBox == 11) {
                    checkBoxOthers.setChecked(true);
                }
            }

            PdfFormField checkBox1 = checkBoxInduction.getCheckField();
            writer.addAnnotation(checkBox1);

            PdfFormField checkBox2 = checkBoxLanguage.getCheckField();
            writer.addAnnotation(checkBox2);

            PdfFormField checkBox3 = checkBoxTeamBuilding.getCheckField();
            writer.addAnnotation(checkBox3);

            PdfFormField checkBox4 = checkBoxItTechnicalSoftware.getCheckField();
            writer.addAnnotation(checkBox4);

            PdfFormField checkBox5 = checkBoxItTechnicalHardware.getCheckField();
            writer.addAnnotation(checkBox5);

            PdfFormField checkBox6 = checkBoxItTechnicalProcess.getCheckField();
            writer.addAnnotation(checkBox6);

            PdfFormField checkBox7 = checkBoxStandard.getCheckField();
            writer.addAnnotation(checkBox7);

            PdfFormField checkBox8 = checkBoxSoftSkill.getCheckField();
            writer.addAnnotation(checkBox8);

            PdfFormField checkBox9 = checkBoxManagement.getCheckField();
            writer.addAnnotation(checkBox9);

            PdfFormField checkBox10 = checkBoxPolicy.getCheckField();
            writer.addAnnotation(checkBox10);

            PdfFormField checkBox11 = checkBoxOthers.getCheckField();
            writer.addAnnotation(checkBox11);

            // CourseDescription
            for (CourseAttendance courseDescription : export) {
                PdfPCell courseName = new PdfPCell(
                        new Paragraph("Course Title\n " + "                                 "
                                + courseDescription.getCourseName(), fontHeader));
                courseName.setColspan(3);
                courseName.setRowspan(0);
                courseName.setBorderColor(BaseColor.BLACK);
                courseName.setPaddingLeft(5);
                courseName.setHorizontalAlignment(Element.ALIGN_LEFT);
                courseName.setVerticalAlignment(Element.ALIGN_CENTER);
                courseName.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(courseName);

                PdfPCell duration = new PdfPCell(new Paragraph(
                        "DURATION (in HRS)\n" + "                         " + courseDescription.getDuration(),
                        fontHeader));
                duration.setBorderColor(BaseColor.BLACK);
                duration.setPaddingLeft(5);
                duration.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(duration);

                PdfPCell inclusiveDatesLabel = new PdfPCell(new Paragraph("INCLUSIVE DATES", fontHeader));
                inclusiveDatesLabel.setBorderColor(BaseColor.BLACK);
                inclusiveDatesLabel.setPaddingLeft(5);
                inclusiveDatesLabel.setHorizontalAlignment(Element.ALIGN_LEFT);
                inclusiveDatesLabel.setVerticalAlignment(Element.ALIGN_CENTER);
                inclusiveDatesLabel.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(inclusiveDatesLabel);

                PdfPCell startDate = new PdfPCell(new Paragraph(
                        "START DATE\n" + "  "
                                + courseDescription.getScheduleStartDateTime().format(formatterDate),
                        fontHeader));
                startDate.setBorderColor(BaseColor.BLACK);
                startDate.setPaddingLeft(5);
                startDate.setHorizontalAlignment(Element.ALIGN_LEFT);
                startDate.setVerticalAlignment(Element.ALIGN_CENTER);
                startDate.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(startDate);

                PdfPCell endDate = new PdfPCell(new Paragraph(
                        "END DATE\n" + "  "
                                + courseDescription.getScheduleEndDateTime().format(formatterDate),
                        fontHeader));
                endDate.setBorderColor(BaseColor.BLACK);
                endDate.setPaddingLeft(5);
                endDate.setHorizontalAlignment(Element.ALIGN_LEFT);
                endDate.setVerticalAlignment(Element.ALIGN_CENTER);
                endDate.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(endDate);

                PdfPCell venue = new PdfPCell(new Paragraph(
                        "VENUE\n " + "                       " + courseDescription.getVenueName(),
                        fontHeader));
                venue.setBorderColor(BaseColor.BLACK);
                venue.setPaddingLeft(5);
                venue.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(venue);

                PdfPCell sessionLabel = new PdfPCell(new Paragraph("SESSION  1 OF 5", fontHeader));
                sessionLabel.setBorderColor(BaseColor.BLACK);
                sessionLabel.setPaddingLeft(5);
                sessionLabel.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(sessionLabel);

                PdfPCell startTime = new PdfPCell(new Paragraph(
                        "START TIME\n        "
                                + courseDescription.getScheduleStartDateTime().format(formatterTime),
                        fontHeader));
                startTime.setBorderColor(BaseColor.BLACK);
                startTime.setPaddingLeft(5);
                startTime.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(startTime);

                PdfPCell endTime = new PdfPCell(new Paragraph(
                        "END TIME\n       "
                                + courseDescription.getScheduleEndDateTime().format(formatterTime),
                        fontHeader));
                endTime.setBorderColor(BaseColor.BLACK);
                endTime.setPaddingLeft(15);
                endTime.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(endTime);

                PdfPCell instructor = new PdfPCell(new Paragraph("\nINSTRUCTOR\n\n\n\n " + "          "
                        + courseDescription.getInstructorName() + "\n\n\n ________________________________\n "
                        + "(SIGNATURE OVER PRINTED NAME)\n\n", fontHeader));
                instructor.setColspan(0);
                instructor.setRowspan(2);
                instructor.setBorderColor(BaseColor.BLACK);
                instructor.setPaddingLeft(2);
                instructor.setHorizontalAlignment(Element.ALIGN_LEFT);
                instructor.setVerticalAlignment(Element.ALIGN_LEFT);
                instructor.setBackgroundColor(BaseColor.WHITE);
                instructor.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(instructor);

                PdfPCell trainingType = new PdfPCell(new Paragraph("TRAINING TYPE\n\n"
                        + "      INDUCTION       IT-TECHNICAL(SOFTWARE)       SOFT SKILLS/BEHAVIORAL\n\n"
                        + "      LANGUAGE      IT-TECHNICAL(HARDWARE)       MANAGEMENT/LEADERSHIP\n\n"
                        + "      TEAM BUILDING       IT-TECHNICAL(PROCESS)         POLICY ORIENTATION\n\n"
                        + "                                          STANDARD COMPLIANCE        OTHER",
                        trainingTypeFont));
                trainingType.setColspan(3);
                trainingType.setRowspan(0);
                trainingType.setBorderColor(BaseColor.BLACK);
                trainingType.setPaddingLeft(3);
                trainingType.setHorizontalAlignment(Element.ALIGN_LEFT);
                trainingType.setExtraParagraphSpace(5f);
                tableCourseDescription.addCell(trainingType);
                break;
            }

            PdfPCell employeeId = new PdfPCell(new Paragraph("8-Digit EMPLOYEE ID NUMBER", tableHeader));
            employeeId.setBorderColor(BaseColor.BLACK);
            employeeId.setPaddingLeft(5);
            employeeId.setHorizontalAlignment(Element.ALIGN_CENTER);
            employeeId.setVerticalAlignment(Element.ALIGN_CENTER);
            employeeId.setExtraParagraphSpace(5f);
            tableList.addCell(employeeId);

            PdfPCell participantsName = new PdfPCell(new Paragraph("PARTICIPANT'S NAME", tableHeader));
            participantsName.setBorderColor(BaseColor.BLACK);
            participantsName.setPaddingLeft(5);
            participantsName.setHorizontalAlignment(Element.ALIGN_CENTER);
            participantsName.setVerticalAlignment(Element.ALIGN_CENTER);
            participantsName.setExtraParagraphSpace(5f);
            tableList.addCell(participantsName);

            PdfPCell department = new PdfPCell(new Paragraph("COMPANY/BU/DEPT", tableHeader));
            department.setBorderColor(BaseColor.BLACK);
            department.setPaddingLeft(5);
            department.setHorizontalAlignment(Element.ALIGN_CENTER);
            department.setVerticalAlignment(Element.ALIGN_CENTER);
            department.setExtraParagraphSpace(5f);
            tableList.addCell(department);

            PdfPCell timeIn = new PdfPCell(new Paragraph("TIME-IN", tableHeader));
            timeIn.setBorderColor(BaseColor.BLACK);
            timeIn.setPaddingLeft(5);
            timeIn.setHorizontalAlignment(Element.ALIGN_CENTER);
            timeIn.setVerticalAlignment(Element.ALIGN_CENTER);
            timeIn.setExtraParagraphSpace(5f);
            tableList.addCell(timeIn);

            PdfPCell timeOut = new PdfPCell(new Paragraph("TIME-OUT", tableHeader));
            timeOut.setBorderColor(BaseColor.BLACK);
            timeOut.setPaddingLeft(5);
            timeOut.setHorizontalAlignment(Element.ALIGN_CENTER);
            timeOut.setVerticalAlignment(Element.ALIGN_CENTER);
            timeOut.setExtraParagraphSpace(5f);
            tableList.addCell(timeOut);

            PdfPCell signature = new PdfPCell(new Paragraph("SIGNATURE", tableHeader));
            signature.setBorderColor(BaseColor.BLACK);
            signature.setPaddingLeft(5);
            signature.setHorizontalAlignment(Element.ALIGN_CENTER);
            signature.setVerticalAlignment(Element.ALIGN_CENTER);
            signature.setExtraParagraphSpace(5f);
            tableList.addCell(signature);

            for (CourseAttendance employee : export.stream()
                    .sorted((e1, e2) -> e1.getParticipantName().compareTo(e2.getParticipantName()))
                    .collect(Collectors.toList())) {

                ZonedDateTime logintDateTime = employee.getLoginDateTime();
                ZonedDateTime logoutDateTime = employee.getLogoutDateTime();
                String login = (logintDateTime == null) ? ""
                        : employee.getLoginDateTime().format(formatterTime);
                String logout = (logoutDateTime == null) ? ""
                        : employee.getLogoutDateTime().format(formatterTime);

                PdfPCell employeeIdValue = new PdfPCell(
                        new Paragraph(employee.getEmployeeNumber(), tableBody));
                employeeIdValue.setBorderColor(BaseColor.BLACK);
                employeeIdValue.setPaddingLeft(5);
                employeeIdValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                employeeIdValue.setVerticalAlignment(Element.ALIGN_CENTER);
                employeeIdValue.setBackgroundColor(BaseColor.WHITE);
                employeeIdValue.setExtraParagraphSpace(5f);
                tableList.addCell(employeeIdValue);

                PdfPCell participantsNameValue = new PdfPCell(
                        new Paragraph(employee.getParticipantName(), tableBody));
                participantsNameValue.setBorderColor(BaseColor.BLACK);
                participantsNameValue.setPaddingLeft(5);
                participantsNameValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                participantsNameValue.setVerticalAlignment(Element.ALIGN_CENTER);
                participantsNameValue.setBackgroundColor(BaseColor.WHITE);
                participantsNameValue.setExtraParagraphSpace(5f);
                tableList.addCell(participantsNameValue);

                PdfPCell departmentValue = new PdfPCell(
                        new Paragraph(employee.getDepartmentName(), tableBody));
                departmentValue.setBorderColor(BaseColor.BLACK);
                departmentValue.setPaddingLeft(5);
                departmentValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                departmentValue.setVerticalAlignment(Element.ALIGN_CENTER);
                departmentValue.setBackgroundColor(BaseColor.WHITE);
                departmentValue.setExtraParagraphSpace(5f);
                tableList.addCell(departmentValue);

                PdfPCell timeInValue = new PdfPCell(new Paragraph(login, tableBody));
                timeInValue.setBorderColor(BaseColor.BLACK);
                timeInValue.setPaddingLeft(5);
                timeInValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                timeInValue.setVerticalAlignment(Element.ALIGN_CENTER);
                timeInValue.setBackgroundColor(BaseColor.WHITE);
                timeInValue.setExtraParagraphSpace(5f);
                tableList.addCell(timeInValue);

                PdfPCell timeOutValue = new PdfPCell(new Paragraph(logout, tableBody));
                timeOutValue.setBorderColor(BaseColor.BLACK);
                timeOutValue.setPaddingLeft(5);
                timeOutValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                timeOutValue.setVerticalAlignment(Element.ALIGN_CENTER);
                timeOutValue.setBackgroundColor(BaseColor.WHITE);
                timeOutValue.setExtraParagraphSpace(5f);
                tableList.addCell(timeOutValue);

                PdfPCell signatureValue = new PdfPCell(new Paragraph("", tableBody));
                signatureValue.setBorderColor(BaseColor.BLACK);
                signatureValue.setPaddingLeft(5);
                signatureValue.setHorizontalAlignment(Element.ALIGN_CENTER);
                signatureValue.setVerticalAlignment(Element.ALIGN_CENTER);
                signatureValue.setBackgroundColor(BaseColor.WHITE);
                signatureValue.setExtraParagraphSpace(5f);
                tableList.addCell(signatureValue);
            }

            document.add(tableCourseDescription);
            document.add(tableList);
            document.close();
            return true;
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    /**
     * <pre>
     * Download the Created PDF Template of Attendance Absent and Present, Using the parameter of fullPath,
     * response and fileName.
     * 
     * <pre>
     * 
     * @param fullPath
     * @param response
     * @param fileName
     * @return
     */
    @Override
    public boolean fileDownload(String fullPath, HttpServletResponse response, ServletContext context,
            String fileName) {
        File file = new File(fullPath);
        final int BUFFER_SIZE = 4096;
        if (file.exists()) {
            try {
                FileInputStream inputStream = new FileInputStream(file);
                String mimeType = context.getMimeType(fullPath);
                response.setContentType(mimeType);
                response.setHeader("content-disposition", "attachment; filename=" + fileName);

                OutputStream outputStream = response.getOutputStream();
                byte[] buffer = new byte[BUFFER_SIZE];
                int bytesRead = -1;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                outputStream.close();
                file.delete();
                return true;
            } catch (Exception e) {
                System.out.println(e);
            }
            return false;
        }
        return false;
    }
}

/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.roletype.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.roletype.dao.RoleTypeDao;
import com.fujitsu.ph.tsup.roletype.domain.RoleType;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Role Type Management
// Class Name : RoleTypeServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/02/05 | WS) rl.naval          | Initial Version
//0.02    | 2021/02/15 | WS) rl.naval          | Updated
//0.03    | 2021/02/17 | WS) j.sayaboc         | Updated
//0.04    | 2021/02/18 | WS) i.fajardo         | Updated
//0.05    | 2021/02/22 | WS) s.sayaboc         | Updated
//0.06    | 2021/02/23 | WS) s.labador         | Updated
//0.07    | 2021/02/24 | WS) p.cui             | Updated
//0.08    | 2021/02/26 | WS) c.sinda           | Updated
//0.09    | 2021/03/11 | WS) p.cui             | Updated
//0.10    | 2021/03/18 | WS) rl.naval          | Updated
//0.11	  | 2021/07/12 | WS) r.gaquit		   | Updated
//0.12    | 2021/08/31 | WS) dw.cardenas       | Updated
//0.12    | 2021/09/09 | WS) d.dinglasan       | Updated
// ==================================================================================================
/**
 * <pre>
 * JavaBean for RoleTypeServiceImpl
 * 
 * <pre>
 * 
 * @version 0.12
 * @author rl.naval
 * @author j.sayaboc
 * @author i.fajardo
 * @author s.labador
 * @author p.cui
 * @author c.sinda
 * @author r.gaquit
 * @author d.dinglasan
 */
@Service
public class RoleTypeServiceImpl implements RoleTypeService {
    @Autowired
    private RoleTypeDao roleTypeDao;

    /**
     * Finds Role Type by id
     * 
     * @param id Role Type id
     * @return roleTypeResult
     */
    @Override
    public RoleType findRoleById(Long id) {
        RoleType roleTypeResult = roleTypeDao.findRoleById(id);
        return roleTypeResult;
    }

    /**
     * Finds Role Type by name
     * 
     * @param rolename Role name
     * @return roleFormList
     */
    @Override
    public Set<RoleType> findRoleTypeByName(String rolename) {
        Set<RoleType> roleFormList = roleTypeDao.findRoleTypeByName(rolename);
        try {
            if (CollectionUtils.isEmpty(roleFormList)) {
                return null;
            } else {
                return roleFormList;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return roleFormList;

    }

    /**
     * Find if Role name is already existing
     * 
     * @param rolename Role name
     * @param id Role id
     * @return isRoleExisting
     */
    @Override
    public boolean findIfRoleNameExists(String rolename, Long id) {
        Set<RoleType> roleList = roleTypeDao.findIfRoleNameExists(rolename, id);
        boolean isRoleExisting = false;
        try {
            if (!roleList.isEmpty()) {
                isRoleExisting = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isRoleExisting;
    }

    /**
     * Loads all role types
     * 
     * @return roleTypeDao.loadAllRoleType
     */
    @Override
    public Set<RoleType> loadAllRoleType() {
        return roleTypeDao.loadAllRoleType();
    }

    /**
     * Loads all role types with pagination
     * 
     * @return roleTypeDao.loadAllRoleType
     */
    @Override
    public Page<RoleType> loadAllRoleType(Pageable pagable) {
        List<RoleType> roleType = roleTypeDao.loadAllRoleType(pagable).stream().collect(Collectors.toList());

        int countRoleType = roleTypeDao.countRoleType();
        return new PageImpl<>(roleType, pagable, countRoleType);
    }

    // Delete role type by id
    @Override
    public void deleteRoleTypeById(Long id) {
        roleTypeDao.deleteRoleTypeById(id);
    }

    // Create role type
    @Override
    public void createRoleType(RoleType role) {
        roleTypeDao.createRoleType(role);
    }

    /**
     * Method for updating Role Type
     * 
     * @param id Role id
     * @param roleType RoleType
     */
    @Override
    public void updateRoleType(Long id, RoleType roleType) {
        roleTypeDao.updateRoleType(id, roleType);
    }

    /**
     * Method for searching Role Type
     * 
     * @param keyword search keyword
     */
    @Override
    public Set<RoleType> findRoleTypeByKeyword(String keyword) {
        Set<RoleType> roleFormList = roleTypeDao.findRoleTypeByKeyword(keyword);
        return roleFormList;

    }

    /* (non-Javadoc)
     * @see com.fujitsu.ph.tsup.roletype.service.RoleTypeService#loadRoleType(java.lang.String, org.springframework.data.domain.Pageable)
     * 
     * Method for loading and searching role type
     * @param String    byKeyword
     * @param Pageable  pageable
     */
    @Override
    public Paged<RoleType> loadRoleType(String byKeyword, Pageable pageable) {
        List<RoleType> roleTypeList = roleTypeDao.loadRoleType(byKeyword, pageable);
        int countRoleType = roleTypeDao.countRoleType(byKeyword);

        Page<RoleType> pageRoleType = new PageImpl<>(roleTypeList, pageable, countRoleType);
        return new Paged<>(pageRoleType, Paging.of(pageRoleType.getTotalPages(), pageable.getPageNumber() + 1,
                pageable.getPageSize()));
    }

    /**
     * Filters role type based on keyword and pageable.
     * 
     * @param keyword
     * @param pageable
     */
    @Override
    public Page<RoleType> findRoleTypeByKeyword(String keyword, Pageable pageable) {
        List<RoleType> roleTypeList = roleTypeDao.findRoleTypeByKeyword(keyword, pageable).stream()
                .collect(Collectors.toList());
        return new PageImpl<>(roleTypeList, pageable, roleTypeDao.countFilteredRoleTypes(keyword));
    }

}

package com.fujitsu.ph.tsup.scheduling.model;

//=======================================================
//$Id: PR02$
//Project Name: Training Sign Up
//Class Name: DepartmentForm.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 07/08/2021 | WS) L.Celoso    | New Creation
//=======================================================

/**
 * <pre>
 * It is a JavaBean for DepartmentForm.
 * <pre>
 * @version 0.01
 * @author L.Celoso
 *
 */

public class DepartmentForm {
    
    /**
     * Venue Id
     */
    private Long id;
    
    /**
     * Department Name
     */
    private String name;
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Long getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
        
	@Override
    public String toString() {
        return "VenueForm [id = " + id + ", name = " + name + "]";
    }
}

//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : MandatoryCoursesDaoImpl                                                                                                                                                               
// Class Name   : MandatoryCoursesDaoImpl.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 1.0.0   | 2021/04/21 | WS)J.Barbadillo       | New Creation      
// 1.0.1   | 2021/05/05 | WS)J.Barbadillo       | Updated
// 1.0.2   | 2021/07/12 | WS)RL.Naval           | Updated
// 1.0.3   | 2021/08/13 | WS)RL.Naval           | Updated
// 1.0.4   | 2021/10/13 | WS)R.Buot             | Updated
// 1.0.5   | 2021/10/14 | WS)D.Dinglasan        | Updated
// 1.0.6   | 2021/10/13 | WS)DW.Cardenas        | Updated query for total number of enrolled
// 1.0.6   | 2021/10/21 | WS)DW.Cardenas        | Updated
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.report.summary.model.MandatoryCourses;

/**
 * <pre>
 * The Dao Implementation for the MandatoryCourses
 * </pre>
 * 
 * @author j.barbadillo
 * @author rl.naval
 * @author r.buot
 * @author d.dinglasan
 * @version 1.0.4
 */

@Repository
public class MandatoryCoursesDaoImpl implements MandatoryCoursesDao{
    
    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(MandatoryCoursesDaoImpl .class);
    
    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;

    /**
     *  Find the total number of  JDU based on the given date range
     * @param selectedReportDate
     * @return mandatoryCourses
     */
    public Set<MandatoryCourses> findMandatoryCourses(LocalDateTime selectedReportDate) {
        String query = "SELECT "
                    + "     DISTINCT C.ID AS ID, "
                    + "     C.NAME AS COURSE_NAME "
                    + "FROM TSUP.COURSE_SCHEDULE AS CSCHED "
                    + "INNER JOIN TSUP.COURSE_SCHEDULE_DETAIL AS CSD "
                    + "     ON CSCHED.ID = CSD.COURSE_SCHEDULE_ID "
                    + "INNER JOIN TSUP.COURSE AS C "
                    + "     ON CSCHED.COURSE_ID = C.ID "
                    + "WHERE (CSD.RESCHEDULED_START_DATETIME <= date_trunc('week', :reportDate - interval '1 week')"
                    + "OR CSD.SCHEDULED_START_DATETIME <= date_trunc('week', :reportDate - interval '1 week')) "
                    + "AND C.MANDATORY = 'Yes'";

        SqlParameterSource mandatoryCoursesParameters = new MapSqlParameterSource()
                .addValue("reportDate", selectedReportDate);

        List<MandatoryCourses> mandatoryCoursesList = template.query(query, mandatoryCoursesParameters,
                new MandatoryCoursesRowMapper());

        Set<MandatoryCourses> mandatoryCourses = new HashSet<>(mandatoryCoursesList);

        logger.debug("Result: {}", mandatoryCoursesList);

        return mandatoryCourses;
    }

    /**
     *  Count the total number of JDU
     * @return Long
     */
    public Long findTotalNumberOfJdu() {
       try {
           String query = "SELECT "
                       + "   COUNT(*) AS TOTAL_NUMBER_OF_JDU "
                       + "FROM TSUP.EMPLOYEE AS E "
                       + "INNER JOIN TSUP.DEPARTMENT D "
                       + "   ON D.ID = E.DEPARTMENT_ID "
                       + "WHERE  D.DEPARTMENT_NAME = :DEPARTMENT_NAME;";  

            SqlParameterSource mandatoryCoursesParameters = new MapSqlParameterSource()
                    .addValue("DEPARTMENT_NAME", "FDC-G3CC");
            return template.queryForObject(query, mandatoryCoursesParameters, Long.class);
        } catch (NullPointerException e) {
            return 0L;
        }
    }
    
    /**
     * Find the total number of JDU who finished training based on the courses
     * 
     * @param mandatoryCourses
     * @param reportDate
     * @return Long
     */
    public Long findTotalNumberOfJduWhoFinishedTraining(String mandatoryCourses, LocalDateTime reportDate) {
        try {
            String query = "SELECT COUNT(DISTINCT CA.PARTICIPANT_ID) "
                + "FROM TSUP.COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN TSUP.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "     ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID "
                + "INNER JOIN TSUP.COURSE_ATTENDANCE AS CA "
                + "     ON CA.COURSE_SCHEDULE_DETAIL_ID = CSCHEDDET.ID "
                + "INNER JOIN tsup.COURSE AS C "
                + "     ON CSCHED.COURSE_ID = C.ID "
                + "WHERE C.NAME = :name "
                + "AND C.MANDATORY = 'Yes' "
                + "AND CA.LOG_OUT_DATETIME <= :reportDate";

            SqlParameterSource mandatoryCoursesParameters = new MapSqlParameterSource()
                    .addValue("name", mandatoryCourses)
                    .addValue("reportDate", reportDate);

            return template.queryForObject(query, mandatoryCoursesParameters, Long.class);
        } catch (NullPointerException e) {
            return 0L;
        }
    }

    /**
     * Find the total number of JDU who finished training lastweek based on course
     * 
     * @param mandatoryCourses
     * @param reportDate
     * @return Long
     */
    public Long findTotalNumberOfJduWhoFinishedTrainingLastWeek(String mandatoryCourses,
            LocalDateTime reportDate) {
        try {
            String query = "SELECT COUNT(DISTINCT CA.PARTICIPANT_ID) "
                    + "FROM TSUP.COURSE_SCHEDULE AS CSCHED "
                    + "INNER JOIN TSUP.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                    + "     ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID "
                    + "INNER JOIN TSUP.COURSE_ATTENDANCE AS CA "
                    + "     ON CA.COURSE_SCHEDULE_DETAIL_ID = CSCHEDDET.ID "
                    + "INNER JOIN tsup.COURSE AS C "
                    + "     ON CSCHED.COURSE_ID = C.ID "
                    + "WHERE C.NAME = :name "
                    + "AND C.MANDATORY = 'Yes' "
                    + "AND CA.LOG_OUT_DATETIME <= date_trunc('week', :reportDate - interval '1 week')";

            SqlParameterSource mandatoryCoursesParameters = new MapSqlParameterSource()
                    .addValue("name", mandatoryCourses)
                    .addValue("reportDate", reportDate);

            return template.queryForObject(query, mandatoryCoursesParameters, Long.class);
        } catch (NullPointerException e) {
            return 0L;
        }
    }

    /**
     *  Find the all the mandatory courses
     * @return mandatoryCourses
     */

    @Override
    public Set<MandatoryCourses> findMandatoryCourses() {
        String query = "SELECT DISTINCT C.ID AS ID, C.NAME AS COURSE_NAME "
                + "FROM TSUP.COURSE C "
                + "WHERE C.MANDATORY = 'Yes'";
        List<MandatoryCourses> mandatoryCoursesList = template.query(query, new MandatoryCoursesRowMapper());

        Set<MandatoryCourses> mandatoryCourses = new HashSet<>(mandatoryCoursesList);

        logger.debug("Result: {}", mandatoryCoursesList);

        return mandatoryCourses;
    }

    @Override
    public Long findTotalNumberOfEnrolledJdu(String course) {
        final String DEPARTMENT_NAME = "FDC-G3CC";
        String query = "SELECT COUNT(*)"
                     + "FROM ("
                     + "    SELECT DISTINCT E.ID"
                     + "    FROM TSUP.EMPLOYEE AS E"
                     + "    INNER JOIN TSUP.DEPARTMENT D ON D.ID = E.DEPARTMENT_ID"
                     + "    INNER JOIN TSUP.COURSE_PARTICIPANT CP ON CP.PARTICIPANT_ID = E.ID"
                     + "    INNER JOIN TSUP.COURSE_SCHEDULE CSCHED ON CSCHED.ID = CP.COURSE_SCHEDULE_ID"
                     + "    INNER JOIN TSUP.COURSE C ON C.ID = CSCHED.COURSE_ID"
                     + "    WHERE D.DEPARTMENT_NAME = :department_name AND C.NAME = :course_name) "
                     + "as TOTAL_NUMBER_OF_JDU";

         SqlParameterSource mandatoryCoursesParameters = new MapSqlParameterSource()
                 .addValue("department_name", DEPARTMENT_NAME)
                 .addValue("course_name", course);
         return template.queryForObject(query, mandatoryCoursesParameters, Long.class);
    }

}
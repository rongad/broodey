/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.jdu.service;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.jdu.domain.Jdu;
import com.fujitsu.ph.tsup.pagination.Paged;

//=======================================================
//Project Name: Training Sign Up
//Class Name: JduService.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 28/06/2021 | WS) dw.cardenas  | Created
//0.02    | 07/07/2021 | WS) dw.cardenas  | Overload findAllJdus for Pagination
//0.02    | 03/08/2021 | WS) dw.cardenas  | Update
//0.02    | 10/09/2021 | WS) r.delacruz   | Update
//=======================================================

/**
 *
 * @author dw.cardenas
 *
 */
public interface JduService {

	/**
	 * <pre>
	 * Finds all JDUs
	 * <pre>
	 *
	 * @return Set of JDUs
	 */
	Set<Jdu> findAllJdus();

	/**
	 * <pre>
	 * Finds all JDUs based on Pageable
	 * <pre>
	 *
	 * @param pageable
	 * @return List of JDUs based on size and page number
	 */
	Page<Jdu> findAllJdus(Pageable pageable);

	/**
	 * <pre>
	 * Finds all JDUs with specific string in name
	 * <pre>
	 *
	 * @param jduName
	 * @return Set of JDUs with specific string
	 */
	Set<Jdu> findJduByName(String jduName);
	
	/**
	 * <pre>
	 * Finds all JDUs based on Pageable as Paged
	 * <pre>
	 *
	 * @param pageable
	 * @return List of JDUs based on size and page number
	 */
	Paged<Jdu> findAllJdusAsPaged(Pageable pageable);

	/**
	 * <pre>
	 * Creates a new JDU
	 * <pre>
	 *
	 * @param newJdu
	 */
	void createJdu(Jdu newJdu);

	/**
	 * <pre>
	 * Updates an existing JDU
	 * <pre>
	 *
	 * @param updatedJdu
	 */
	void updateJdu(Jdu updatedJdu);

	/**
	 * <pre>
	 * Deletes an existing JDU
	 * <pre>
	 *
	 * @param id
	 */
	void deleteDepartment(Long id);

	/**
	 * <pre>
	 * Find JDU with specific string in name
	 * <pre>
	 *
	 * @param searchKey
	 * @param pageable
	 * @return
	 */
	Page<Jdu> findJduByName(String searchKey, Pageable pageable);
	
	/**
	 * <pre>
	 * Find JDU with specific string in name as Paged
	 * <pre>
	 *
	 * @param searchKey
	 * @param pageable
	 * @return
	 */
	Paged<Jdu> findJduByNameAsPaged(String searchKey, Pageable pageable);
}

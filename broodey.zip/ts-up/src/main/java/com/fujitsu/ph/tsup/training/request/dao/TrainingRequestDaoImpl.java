package com.fujitsu.ph.tsup.training.request.dao;

import java.time.ZoneId;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestForm;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

//=======================================================
//Project Name: Training Sign Up
//Class Name: TrainingRequestDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 07/12/2021 | WS) L.Celoso    | New Creation
//0.02    | 08/06/2021 | WS) L.Celoso    | Update
//0.03    | 08/20/2021 | WS) L.Celoso    | Added requester as filter search
//0.03    | 08/16/2021 | WS) D.Dinglasan | Update
//0.04    | 09/07/2021 | WS) L.Celoso    | Added alias to [Status]
//=======================================================

/**
* <pre>
* Implementation of the Training Request Dao
* 
* <pre>
* 
* @version 0.01
* @author L.Celoso
*/
@Repository
public class TrainingRequestDaoImpl implements TrainingRequestDao {


    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;
    
    /**
     * <pre>
     * Saves the training request
     * 
     * <pre>
     * 
     * @param CourseSchedule courseSchedule
     */
    @Override
    public void saveTrainingRequest(TrainingRequestForm trainingRequestForm) {
       
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
    	String trainingRequestSql = "INSERT INTO TRAINING_REQUEST"
                + "(EMPLOYEE_ID, "
                + "	COURSE_NAME, "
                + "	MIN_REQUIRED, "
                + "	MAX_ALLOWED, "
                + "	SCHEDULED_START_DATETIME, "
                + "	SCHEDULED_END_DATETIME, "
                + "	DURATION, "
                + "	STATUS, "
                + "	REMARKS, "
                + " APPROVER_REMARKS) "
                + "VALUES ("
                + "	:employee_id, "
                + "	:course_name, "
                + "	:min_req, "
                + "	:max_req,"
                + " :start_datetime, "
                + " :end_datetime, "
                + " :duration, "
                + " :status, "
                + " :remarks,"
                + " '-')";
        
        SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
                .addValue("employee_id", user.getId())
                .addValue("course_name", trainingRequestForm.getCourseName())
                .addValue("min_req", trainingRequestForm.getMinRequired())
                .addValue("max_req", trainingRequestForm.getMaxRequired())
                .addValue("start_datetime", trainingRequestForm.getStartDateTime().toOffsetDateTime())
                .addValue("end_datetime", trainingRequestForm.getEndDateTime().toOffsetDateTime())
                .addValue("duration", trainingRequestForm.getDuration())
                .addValue("status", "Pending")
                .addValue("remarks", trainingRequestForm.getCourseDetails());
        
        template.update(trainingRequestSql, trainingRequestParameters);
    }

    /**
     * <pre>
     * Get all training request
     * 
     * <pre>
     * 
     * @param CourseSchedule courseSchedule
     */
    @Override
    public Set<TrainingRequest> getAllTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm, Pageable pageable) {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
    	String trainingRequestSql = "SELECT TR.id As TR_ID, "
    								+ "	TR.employee_id AS EMPLOYEE_ID,"
    								+ " TR.course_name AS COURSE_NAME,"
    								+ " TR.min_required AS MIN_PARTICIPANTS,"
    								+ " TR.max_allowed AS MAX_PARTICIPANTS,"
    								+ " TR.scheduled_start_datetime AS START_DATETIME,"
    								+ " TR.scheduled_end_datetime AS END_DATETIME,"
    								+ " TR.duration AS DURATION,"
    								+ " TR.status AS REQUEST_STATUS,"
    								+ " TR.remarks AS COURSE_DETAILS, "
    								+ " CONCAT(E.LAST_NAME,', ',E.FIRST_NAME) AS REQUESTER_NAME, "
    								+ " CASE WHEN (TR.APPROVER_ID is NULL) THEN '-' ELSE CONCAT(A.LAST_NAME,', ',A.FIRST_NAME) END AS APPROVER_NAME, "
    								+ " TR.approver_remarks AS APPROVER_REMARKS "
    								+ "FROM TRAINING_REQUEST TR "
    								+ " INNER JOIN EMPLOYEE E ON E.id = TR.employee_id "
    								+ " LEFT JOIN EMPLOYEE A ON A.id = TR.approver_id "
    								+ "WHERE COALESCE(TR.scheduled_start_datetime, TR.scheduled_end_datetime) "
    								+ " BETWEEN :fromDateTime AND :toDateTime"
    								+ " AND TR.status LIKE (:status) ";
    	
    								if (user.getRoles().contains("Member")) {
    									trainingRequestSql += " AND TR.EMPLOYEE_ID = :employeeId ";
    								} else if (user.getRoles().contains("PMO")) {
    									trainingRequestSql += " AND LOWER(CONCAT(E.LAST_NAME,', ',E.FIRST_NAME)) LIKE :requester ";
    								}
    								
    	Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0) : Order.asc("scheduled_start_datetime");
    	String orderProperty = getOrderProperty(order);
    	
		trainingRequestSql += "ORDER BY " + orderProperty
				+ " " + order.getDirection() + ", TR_ID"
				+ " LIMIT " + pageable.getPageSize()
                + " OFFSET " + pageable.getOffset();
    	
    	SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
    								.addValue("employeeId", user.getId())
    								.addValue("fromDateTime", trainingRequestSearchForm.getSearchStartDateTimeZone()
    											.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
    								.addValue("toDateTime", trainingRequestSearchForm.getSearchEndDateTimeZone()
												.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
    								.addValue("status", trainingRequestSearchForm.getStatus())
    								.addValue("requester", "%" + trainingRequestSearchForm.getRequester().toLowerCase() + "%");
    	
    	List<TrainingRequest> trainingRequest = template.query(trainingRequestSql, trainingRequestParameters, new TrainingRequestRowMapper());
    	return new LinkedHashSet<>(trainingRequest);    	
    }

    /**
     * @param order
     * @return String
     */
    private String getOrderProperty(Order order) {
		switch (order.getProperty()) {
		case "id":
			return "TR_ID";
		case "course_name":
			return "COURSE_NAME";
		case "scheduled_start_datetime":
			return "START_DATETIME";
		case "scheduled_end_datetime":
			return "END_DATETIME";
		case "status":
			return "REQUEST_STATUS";
		case "approver_name":
			return "APPROVER_NAME";
		case "requester_name":
			return "REQUESTER_NAME";
		case "duration":
			return "DURATION";
		case "min_required":
			return "MIN_PARTICIPANTS";
		case "max_allowed":
			return "MAX_PARTICIPANTS";
		default:
			return "";
		}
	}

	@Override
    public int checkToCancelTrainingRequest(Long id) {
    	try {
	    	String checkSql = "SELECT COUNT(*) "
	                + " FROM TRAINING_REQUEST "
	                + " WHERE id = :requestId "
	                + " AND status = 'Pending'";
	        
	    	SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
	                .addValue("requestId", id);
	    	
	    	return template.queryForObject(checkSql, trainingRequestParameters, Integer.class);
    	} catch(NullPointerException e) {
    		return 0;
    	}
    }

    @Override
    public void cancelTrainingRequest(Long id) {
    	
    	String trainingRequestSql = "UPDATE TRAINING_REQUEST "
    			+ " SET STATUS = 'Cancelled' "
                + " WHERE id = :requestId ";
    	
       	SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
                .addValue("requestId", id);
        
        template.update(trainingRequestSql, trainingRequestParameters);
    }
    
    @Override
    public void moveToArchive(Long id) {
    	
    	//Moving to the TRAINING_REQUEST_ARCHIVE
    	String trainingRequestSql = "INSERT INTO TRAINING_REQUEST_ARCHIVE "
    			+ " (TRAINING_REQUEST_ID,"
    			+ "  EMPLOYEE_ID,"
    			+ "  COURSE_NAME,"
    			+ "  MIN_REQUIRED,"
    			+ "  MAX_ALLOWED,"
    			+ "  SCHEDULED_START_DATETIME,"
    			+ "  SCHEDULED_END_DATETIME,"
    			+ "  DURATION,"
    			+ "  STATUS,"
    			+ "  REMARKS,"
    			+ "  APPROVER_ID,"
    			+ "  APPROVER_REMARKS ) "
                + " SELECT * "
                + " FROM TRAINING_REQUEST "
                + " WHERE id = :requestId ";

    	SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
                .addValue("requestId", id);
        
        template.update(trainingRequestSql, trainingRequestParameters);
        
        //Removing the TRAINING_REQUEST record
        String deteleTrainingRequestSql = "DELETE "
                + " FROM TRAINING_REQUEST "
                + " WHERE id = :requestId ";
    	
       	SqlParameterSource deleteTrainingRequestParameters = new MapSqlParameterSource()
                .addValue("requestId", id);
        
        template.update(deteleTrainingRequestSql, deleteTrainingRequestParameters);
    }
    
    /**
     * <pre>
     * Saves the training request
     * 
     * <pre>
     * 
     * @param CourseSchedule courseSchedule
     */
    @Override
    public void updateTrainingRequest(TrainingRequestForm trainingRequestForm) {
       
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
    	String trainingRequestSql = "UPDATE TRAINING_REQUEST"
                + " SET COURSE_NAME = :course_name ,  "
                + " MIN_REQUIRED = :min_req ,"
                + " MAX_ALLOWED = :max_req ,"
                + " SCHEDULED_START_DATETIME = :start_datetime ,"
                + " SCHEDULED_END_DATETIME = :end_datetime ,"
                + " DURATION = :duration ,"
                + " REMARKS = :remarks "
                + " WHERE EMPLOYEE_ID = :employee_id AND id = :request_id AND status = 'Pending' ";
        
        SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
                .addValue("employee_id", user.getId())
                .addValue("request_id", trainingRequestForm.getId())
                .addValue("course_name", trainingRequestForm.getCourseName())
                .addValue("min_req", trainingRequestForm.getMinRequired())
                .addValue("max_req", trainingRequestForm.getMaxRequired())
                .addValue("start_datetime", trainingRequestForm.getStartDateTime().toOffsetDateTime())
                .addValue("end_datetime", trainingRequestForm.getEndDateTime().toOffsetDateTime())
                .addValue("duration", trainingRequestForm.getDuration())
                .addValue("remarks", trainingRequestForm.getCourseDetails());
        
        template.update(trainingRequestSql, trainingRequestParameters);
    }
    
    @Override
    public void changeTrainingRequestStatus(Long id, String status, String remarks) {
    	
    	FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	
    	
    	String trainingRequestSql = "UPDATE TRAINING_REQUEST "
    			+ " SET STATUS = :status,"
                + " APPROVER_ID = :approverId, "
                + " APPROVER_REMARKS = :remarks "
                + " WHERE id = :requestId ";
    	
       	SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
                .addValue("status", status)
                .addValue("approverId", user.getId())
                .addValue("remarks", remarks)
                .addValue("requestId", id);
        
        template.update(trainingRequestSql, trainingRequestParameters);
    }
    
    public int countTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm) {

    	try {
	    	FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        	String trainingRequestSql = "SELECT COUNT(*) "
        								+ "FROM TRAINING_REQUEST TR "
        								+ " INNER JOIN EMPLOYEE E ON E.id = TR.employee_id "
        								+ " LEFT JOIN EMPLOYEE A ON A.id = TR.approver_id "
        								+ "WHERE COALESCE(TR.scheduled_start_datetime, TR.scheduled_end_datetime) "
        								+ " BETWEEN :fromDateTime AND :toDateTime "
        								+ " AND TR.status LIKE (:status) ";
        	
        								if (user.getRoles().contains("Member")) {
        									trainingRequestSql += " AND EMPLOYEE_ID = :employeeId ";
        								} else if (user.getRoles().contains("PMO")) {
        									trainingRequestSql += " AND LOWER(CONCAT(E.LAST_NAME,', ',E.FIRST_NAME)) LIKE :requester ";
        								}
        	
        	SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
        								.addValue("employeeId", user.getId())
        								.addValue("fromDateTime", trainingRequestSearchForm.getSearchStartDateTimeZone()
        											.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
        								.addValue("toDateTime", trainingRequestSearchForm.getSearchEndDateTimeZone()
    												.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
        								.addValue("status", trainingRequestSearchForm.getStatus())
        								.addValue("requester", "%" + trainingRequestSearchForm.getRequester().toLowerCase() + "%");
        	
        	return template.queryForObject(trainingRequestSql, trainingRequestParameters, Integer.class);
    	} catch(NullPointerException e) {
    		return 0;
    	}
    }
}
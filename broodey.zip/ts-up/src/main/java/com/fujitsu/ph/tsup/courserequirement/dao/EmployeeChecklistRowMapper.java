package com.fujitsu.ph.tsup.courserequirement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.Employee;
import com.fujitsu.ph.tsup.courserequirement.model.EmployeeChecklist;

import org.springframework.jdbc.core.RowMapper;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Course Checklist
//Class Name   : EmployeeChecklistRowMapper.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+-----------------------------------------------------
//0.01    | 2021/10/28 | WS) e.delosreyes      | Initial Version
//0.02    | 2021/10/28 | WS) je.subelario      | Revised Comments
//===================================================================================================

/**
 * <pre>
 * The Row Mapper for Employee Checklist
 * </pre>
 * 
 * @author je.subelario 
 * @version 0.02
 */

public class EmployeeChecklistRowMapper implements RowMapper<EmployeeChecklist> {

    @Override
    public EmployeeChecklist mapRow(ResultSet rs, int rowNum) throws SQLException {
        
        CourseParticipant courseParticipant = new CourseParticipant();
        courseParticipant.setId(rs.getInt("course_participant_id"));

        CourseChecklist courseChecklist = new CourseChecklist(
            rs.getInt("course_checklist_ID"),
            rs.getString("requirement"),
            new Course()
        );

        Employee employee = new Employee(
            rs.getInt("employee_id"),
            rs.getString("last_name"),
            rs.getString("first_name")
        );

        EmployeeChecklist employeeChecklist = new EmployeeChecklist();
        employeeChecklist.setEmployee(employee);
        employeeChecklist.setCourseParticipant(courseParticipant);
        employeeChecklist.setCourseChecklist(courseChecklist);
        employeeChecklist.setId(rs.getInt("checklist_id"));
        employeeChecklist.setIs_Accomplished(rs.getBoolean("is_Accomplished"));
        
        return employeeChecklist;
    }

}

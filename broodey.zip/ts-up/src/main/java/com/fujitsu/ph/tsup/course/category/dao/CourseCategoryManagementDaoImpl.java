/**
 * 
 */
package com.fujitsu.ph.tsup.course.category.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;

//=======================================================
//$Id: PR10$
//Project Name: Training Sign Up
//System Name : Course Category Management Process
//Class Name: CourseCategoryManagementDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by          | Content
//--------+------------+---------------------+---------------
//0.01    | 02/08/2020 | WS) A.Batongbacal   | New Creation
//0.02    | 02/15/2020 | WS) A.Batongbacal   | Update
//0.03    | 02/24/2020 | WS) R.Rivero        | Update
//0.04    | 02/24/2020 | WS) J.ira           | Update
//0.05    | 02/24/2020 | WS) R.Piloto        | Update
//0.06    | 06/16/2021 | WS) M.Aguinaldo     | Removed unnecessary imports
//0.07	  | 07/09/2021 | WS) R.Gaquit		 | Update
//0.08    | 09/02/2021 | WS) DW.Cardenas     | Update
//0.08    | 09/07/2021 | WS) MI.Aguinaldo    | Update
//0.08    | 09/09/2021 | WS) D.Dinglasan     | Update
//=======================================================
/**
 * <pre>
 * The implementation of Course Category Management Dao
 * 
 * <pre>
 * 
 * @version 0.06
 * @author a.batongbacal
 * @author r.rivero
 * @author j.lira
 * @author r.piloto
 * @author mi.aguinaldo
 * @author r.gaquit
 *
 */
@Repository
public class CourseCategoryManagementDaoImpl implements CourseCategoryManagementDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(CourseCategoryManagementDaoImpl.class);
    // Call NamedParameterJdbcTemplate
    
    @Autowired
    private NamedParameterJdbcTemplate template;
    
    @Autowired
	private JdbcTemplate jdbcTemplate;

    @Override
    public void updateCourseCategory(CourseCategory courseCategory) {
        String query = "UPDATE COURSE_CATEGORY SET category=:category, detail=:detail WHERE ID =:id";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("id", courseCategory.getId()).addValue("category", courseCategory.getCategory())
                .addValue("detail", courseCategory.getDetail());
        int result = template.update(query, sqlParameterSource);
        if (result > 0) {
            LOGGER.debug("Successfully updated course category ID: " + courseCategory.getId());
        } else {
            LOGGER.debug("Unable to update course category");
        }
    }

    // Method for searching course categories by category
    @Override
    public Set<CourseCategory> findCourseCategoryByName(String category) {
        String query = "SELECT * FROM COURSE_CATEGORY  WHERE LOWER(category) LIKE LOWER('%" + category + "%') ORDER BY category";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("category", category);

        List<CourseCategory> courseCategoryList = template.query(query, sqlParameterSource,
                new CourseCategoryRowMapper());
        return new LinkedHashSet<>(courseCategoryList);
    }
    
    

    // Method for creating course categories
    @Override
    public void createCourseCategory(CourseCategory courseCategory) {
        String query = "INSERT INTO course_category" + "(category, detail)"
                + " VALUES(:category, :detail)";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("category", courseCategory.getCategory())
                .addValue("detail", courseCategory.getDetail());

        template.update(query, sqlParameterSource);
     }
    
    @Override
    public Set<CourseCategory> findAllCourseCategory() {
        String query = "SELECT * FROM COURSE_CATEGORY ORDER BY category";

        List<CourseCategory> courseCategoryList = template.query(query, new CourseCategoryRowMapper());
        return new LinkedHashSet<>(courseCategoryList);
    }
    
    @Override
    public Set<CourseCategory> findAllCourseCategory(Pageable pageable){
    	String orderProperty = "category";
    	Order order =  !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0) : Order.asc(orderProperty);
    	String query = "SELECT * " +
	    		 "FROM COURSE_CATEGORY " +
	    		 "ORDER BY " + orderProperty + " " + order.getDirection() + " " +
	    		 "LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset();
    	
    	 List<CourseCategory> courseCategoryList = template.query(query, new CourseCategoryRowMapper());
    	 return courseCategoryList.isEmpty() ? Collections.emptySet() :new LinkedHashSet<>(courseCategoryList);
    }
    
    @Override
    public List<CourseCategory> findCourseCategory(String byKeyword, Pageable pageable) {
        String query = "SELECT * FROM COURSE_CATEGORY ";
        if (!byKeyword.isEmpty()) {
            query += "WHERE LOWER(category) LIKE '%" + byKeyword.toLowerCase() + "%' ";
        }

        String orderProperty = "category";
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc(orderProperty);
        query += "ORDER BY " + orderProperty + " " + order.getDirection() + " " + "LIMIT "
                + pageable.getPageSize() + " OFFSET " + pageable.getOffset();

        return template.query(query, new CourseCategoryRowMapper());
    }
    
    @Override
	public int countCourseCategory() {
    	try {
    		return jdbcTemplate.queryForObject("SELECT count(id) FROM COURSE_CATEGORY", Integer.class);
    	}catch(NullPointerException e) {
    		return 0;
    	}
	}

    /**
     * Method for finding Course Category by Id
     */
    @Override
    public CourseCategory findCourseCategoryById(Long id) {

        String query = "SELECT * FROM COURSE_CATEGORY WHERE ID =" + id;
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("id", id);
        List<CourseCategory> courseCategoryList = template.query(query, sqlParameterSource,
                new CourseCategoryRowMapper());

        if (!courseCategoryList.isEmpty()) {
            return courseCategoryList.get(0);
        } else {
            return null;
        }
        
    }

    /**
     * Method for deleting Course Category by Id
     */
    @Override
    public void deleteCourseCategoryById(Long id) {
        String query = "DELETE FROM COURSE_CATEGORY WHERE ID =" + id;
        SqlParameterSource namedParameters = new MapSqlParameterSource("id", id);
        template.update(query, namedParameters);
    }

    /* (non-Javadoc)
     * @see com.fujitsu.ph.tsup.course.category.dao.CourseCategoryManagementDao#countCourseCategory(java.lang.String)
     */
    @Override
    public int countCourseCategory(String byKeyword) {
        try {
            String query = "SELECT COUNT(*) FROM COURSE_CATEGORY";
            if (!byKeyword.isEmpty()) {
                query += " WHERE LOWER(category) LIKE '%" + byKeyword.toLowerCase() + "%' ";
            }

            return jdbcTemplate.queryForObject(query, Integer.class);
        }
        catch (DataAccessException dataAccessExeption) {
            // nothing to do here
            // return 0 when exception occurs
            LOGGER.error(dataAccessExeption.getMessage(), "(param)[byKeyword]=" + byKeyword);
            return 0;
        }
        catch (NullPointerException nullPointerException) {
            // nothing to do here
            // return 0 when exception occurs
            LOGGER.error(nullPointerException.getMessage(), "(param)[byKeyword]=" + byKeyword);
            return 0;
        }
    }

    /**
     * Finds course category based on name using searchkey and pageable
     * 
     * @param searchKey
     * @param pageable
     */
    @Override
    public List<CourseCategory> findCourseCategoryByName(String searchKey, Pageable pageable) {
        Order order = pageable.getSort().toList().get(0);
        String columnName;
        switch (order.getProperty()) {
            case "courseCategory":
                columnName = "category";
                break;
                
            default:
                columnName = "category";
        }

        String query = "SELECT * FROM COURSE_CATEGORY "
                + "WHERE LOWER(category) LIKE LOWER('%" + searchKey + "%') "
                + "ORDER BY " + columnName + " " + order.getDirection() + " "
                + "LIMIT :pageSize OFFSET :pageOffset";
        SqlParameterSource sqlParamSource = new MapSqlParameterSource()
                .addValue("pageSize", pageable.getPageSize())
                .addValue("pageOffset", pageable.getOffset());

        return template.query(query, sqlParamSource, new CourseCategoryRowMapper());
    }

    /**
     * Counts number of course categories queried using search key
     * 
     * @param searchKey
     */
    @Override
    public int countFilteredCourseCategories(String searchKey) {
        try {
            String query = "SELECT count(id) FROM COURSE_CATEGORY "
                    + "WHERE LOWER(category) LIKE LOWER('%" + searchKey + "%')";
            return jdbcTemplate.queryForObject(query, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }
    
    /**
     * Method for batch creating course categories
     */
    @Transactional
    @Override
    public int[] batchCreateCourseCategory(List<CourseCategory> categories) {
        String query = "INSERT INTO course_category"
                + " (category, detail)"
                + " VALUES(?, ?)";
        return jdbcTemplate.batchUpdate(query,
                new BatchPreparedStatementSetter() {

                    public void setValues(PreparedStatement ps, int i) 
                        throws SQLException {
                        ps.setString(1, categories.get(i).getCategory());
                        ps.setString(2, categories.get(i).getDetail());
           
                    }

                    public int getBatchSize() {
                        return categories.size();
                    }

                });
    }
}
/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.fujitsu.ph.tsup.common.domain.MemberRole;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Common
// Class Name : MemberRoleRowMapper.java
//
// <<Modification History>>
// Version | Date       | Updated By            | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2020/10/06 | WS) l.celoso          | Initial Version
// ==================================================================================================

public class MemberRoleRowMapper implements RowMapper<MemberRole> {

    @Override
    public MemberRole mapRow(ResultSet rs, int rowNum) throws SQLException {

        Long id = rs.getLong("ID");
        String name = rs.getString("NAME");
        String detail = rs.getString("DESC");

        return new MemberRole.Builder(id,name,detail).build();    
    }
}

package com.fujitsu.ph.tsup.tms.model;

import java.io.Serializable;

public class SummaryReport {
	
	private String manager;
	private long cntCompleted;
	private long cntIncomplete;
	private long cntNotRegistered;
	private String Status;	
	
	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public long getCompleted() {
		return cntCompleted;
	}

	public void setCompleted(long cntCompleted) {
		this.cntCompleted = cntCompleted;
	}

	public long getIncomplete() {
		return cntIncomplete;
	}

	public void setIncomplete(long cntIncomplete) {
		this.cntIncomplete = cntIncomplete;
	}

	public long getNotRegistered() {
		return cntNotRegistered;
	}

	public void setNotRegistered(long cntNotRegistered) {
		this.cntNotRegistered = cntNotRegistered;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
	
	
	public SummaryReport() {
	}
	
	public SummaryReport(String manager, int cntCompleted, int cntIncomplete, int cntNotRegistered, String status) {
		this.manager = manager;
		this.cntCompleted = cntCompleted;
		this.cntIncomplete = cntIncomplete;
		this.cntNotRegistered = cntNotRegistered;
		this.Status = status;
	}
	@Override
	public String toString() {
		return "SummaryReport [manager=" + manager + ", cntCompleted=" + cntCompleted + ", cntIncomplete="
				+ cntIncomplete + ", cntNotRegistered=" + cntNotRegistered + ", Status=" + Status + "]";
	}
	
	
}

package com.fujitsu.ph.tsup.enrollment.certificate.web;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.enrollment.certificate.model.ManageCertificate;
import com.fujitsu.ph.tsup.enrollment.certificate.service.ManageCertificateService;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;
import com.fujitsu.ph.tsup.enrollment.model.CertificateForm;
import com.fujitsu.ph.tsup.enrollment.model.FileStorageProperties;
import com.fujitsu.ph.tsup.enrollment.service.EnrollmentService;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Manage Certificate
// Class Name : ManageCertificateController.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/08/11 | WS) hl.berja | Initial Version
// ==================================================================================================

/**
 * <pre>
* It is the controller of manage certificate
* In this class, it implements the ManageCertificateService class for the initial setting of the database
 * </pre>
 * 
 * @author WS) hl.berja
 */

@Controller
@RequestMapping("/certificate")
public class ManageCertificateController {

    /*
     * <pre> It is the interface of manage certificate service <pre>
     */

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    ManageCertificateService manageCertificateService;

    /**
     * <pre>
     * URL Value = /load, method = GET Call manageCertificateService.loadAllCertificates using the Pageable
     * object and return the result. If the result is null return a message "No certificates Found" , else
     * return the list of paginated certificates via model attribute.
     * 
     * <pre>
     * 
     * @param page Optional<Integer> @RequestParam("page") * @param size
     *        Optional<Integer> @RequestParam("size")
     * @param model Model
     * @return enrollment/manageCertificates view
     */

    @GetMapping("/load")
    public String loadCertificates(Model model, @RequestParam("page") Optional<Integer> page,
            @RequestParam("size") Optional<Integer> size) {

        int currentPage = page.orElse(1);
        int pageSize = size.orElse(10);

        Pageable pageable = PageRequest.of(currentPage - 1, pageSize);
        Page<ManageCertificate> paginatedCertificates = manageCertificateService
                .loadAllCertificates(pageable);

        if (paginatedCertificates.isEmpty()) {
            model.addAttribute("nullMessage", "No certificates Found");
        } else {
            model.addAttribute("paginatedCertificates", paginatedCertificates);
            model.addAttribute("currentPage", currentPage);
        }
        return "enrollment/manageCertificates";
    }

    /**
     * <pre>
     * URL Value = /{certificateId}/delete, method = POST Call manageCertificateService.deleteCertificateById
     * using the certificate id and return the result. If the result is false throw an
     * IllegalArgumentException , else call redirectAttributes.addFlashAttribute with the message "You have
     * successfully delete this certificate"
     * 
     * <pre>
     * 
     * @param id @PathVariable("certificateId") Long
     ** @param redirectAttributes RedirectAttributes
     * @param model Model
     * @return redirect:/certificate/load#successModal view
     */

    @PostMapping("/{certificateId}/delete")
    public String deleteCertificate(@PathVariable("certificateId") Long id,
            RedirectAttributes redirectAttributes, Model model) {
        Boolean isCertificateDeleted = manageCertificateService.deleteCertificateById(id);

        if (isCertificateDeleted) {
            redirectAttributes.addFlashAttribute("successMessage",
                    "You have successfully delete this certificate");
        } else {
            throw new IllegalArgumentException("There's a problem deleting the certificate.");
        }
        return "redirect:/certificate/load#successModal";
    }

    /**
     * <pre>
     * URL Value = /{courseId1}/update, method = GET Set the course id via form.setCourseId
     * 
     * <pre>
     * 
     * @param courseId @RequestParam("courseId1") Long
     ** @param form CertificateForm
     * @param model Model
     * @return redirect:/certificate/load
     */

    @GetMapping("/{courseId1}/update")
    public String getCourseId(@RequestParam(value = "courseId1") Long courseId, CertificateForm form,
            Model model) {
        form.setCourseId(courseId);

        return "redirect:/certificate/load";
    }

    /**
     * <pre>
     * URL Value = /{courseId1}/update, method = POST Call manageCertificateService.storeFile with the given
     * file, id, fileStorageProperties employeeId and return the result as a string Initialize a new
     * Certificate object via Builder passing the certificate details after that call
     * manageCertificateService.updateCertificate and pass the certificate object and return the result. If
     * the result is false throw an IllegalArgumentException , else redirect to manageCertificate view
     * 
     * <pre>
     * 
     * @param id @RequestParam("courseId1") Long
     * @param form CertificateForm
     * @param model Model
     * @param file @RequestParam("file") MultipartFile
     * @return redirect:/certificate/load view
     */

    @PostMapping("/{courseId1}/update")
    public String updateCertificate(@RequestParam(value = "courseId1") Long id, CertificateForm form,
            Model model, @RequestParam("file") MultipartFile file) {
        FileStorageProperties fileStorageProperties = new FileStorageProperties();

        fileStorageProperties.setUploadDir("/tsup/certificate");
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        String fileName = manageCertificateService.storeFile(file, id, fileStorageProperties, user.getId());
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
                .path(fileName).toUriString();

        Certificate certificateDetails = new Certificate.Builder(id, file.getOriginalFilename(), user.getId(),
                ZonedDateTime.now(), fileDownloadUri).build();

        Boolean isCertificateUpdated = manageCertificateService.updateCertificate(certificateDetails);

        if (isCertificateUpdated) {
            return "redirect:/certificate/load";
        } else {
            throw new IllegalArgumentException("There's a problem updating the certificate.");
        }
    }

    /**
     * <pre>
     * URL Value = /{courseIdHidden}/downloadFile, method = GET Call
     * manageCertificateService.getCertificateDownloadUri with the given employeeId , course id After that
     * call the manageCertificateService.loadFileAsResource passing the fileName and fileStorageProperties and
     * return the result as a Resource object
     * 
     * <pre>
     * 
     * @param request HttpServletRequest
     * @param courseId @RequestParam("courseIdHidden") Long
     * @return Response Entity of Resource with the certificate file for downloading
     */

    @GetMapping("/{courseIdHidden}/downloadFile")
    public ResponseEntity<Resource> downloadCertificate(HttpServletRequest request,
            @RequestParam("courseIdHidden") Long courseId) {

        // Load file as Resource
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        FileStorageProperties fileStorageProperties = new FileStorageProperties();
        fileStorageProperties.setUploadDir("/tsup/certificate");
        String fileName = enrollmentService.findCertificateName(user.getId(), courseId);
        if (StringUtils.isEmpty(fileName)) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/certificate/load");
            return new ResponseEntity<>(headers, HttpStatus.FOUND);
        }

        Resource resource = enrollmentService.loadFileAsResource(fileName, fileStorageProperties);

        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            throw new IllegalArgumentException("Could not determine file type.");
        }

        // Fallback to the default content type if type could not be determined
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    /**
     * <pre>
     * URL Value = /{courseIdHidden2}/viewCertificate, method = GET Call
     * manageCertificateService.getCertificateDownloadUri with the given employeeId , course id After that
     * call the manageCertificateService.loadFileAsResource passing the fileName and fileStorageProperties and
     * return the result as a Resource object
     * 
     * <pre>
     * 
     * @param request HttpServletRequest
     * @param courseId @RequestParam("courseIdHidden2") Long
     * @return Response Entity of Resource with the certificate file for viewing
     */

    @GetMapping("/{courseIdHidden2}/viewCertificate")
    public ResponseEntity<Resource> viewCertificate(HttpServletRequest request,
            @RequestParam("courseIdHidden2") Long courseId) {
        // Load file as Resource
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        FileStorageProperties fileStorageProperties = new FileStorageProperties();
        fileStorageProperties.setUploadDir("/tsup/certificate");
        String fileName = enrollmentService.findCertificateName(user.getId(), courseId);
        if (StringUtils.isEmpty(fileName)) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/certificate/load");
            return new ResponseEntity<>(headers, HttpStatus.FOUND);
        }

        Resource resource = enrollmentService.loadFileAsResource(fileName, fileStorageProperties);

        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            throw new IllegalArgumentException("Could not determine file type.");
        }

        // Fallback to the default content type if type could not be determined
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
}

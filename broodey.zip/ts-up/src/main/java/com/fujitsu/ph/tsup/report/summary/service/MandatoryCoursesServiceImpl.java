//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : MandatoryCoursesServiceImpl                                                                                                                                                               
// Class Name   : MandatoryCoursesServiceImpl.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 1.0.0   | 2021/04/21 | WS)C.Fuerzas          | New Creation      
// 1.0.1   | 2021/05/05 | WS)C.Fuerzas          | Updated
// 1.0.2   | 2021/07/12 | WS)RL.Naval           | Updated
// 1.0.3   | 2021/10/13 | WS)R.Buot             | Updated
// 1.0.4   | 2021/10/14 | WS)D.Dinglasan        | Updated
// 1.0.5   | 2021/10/21 | WS)DW.Cardenas        | Updated
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.report.summary.dao.MandatoryCoursesDao;
import com.fujitsu.ph.tsup.report.summary.model.MandatoryCourses;
import com.fujitsu.ph.tsup.report.summary.model.MandatoryCoursesForm;

/**
 * <pre>
 * The implementation of mandatory courses services
 * </pre>
 * 
 * @author c.fuerzas
 * @author rl.naval
 * @author r.buot
 * @author d.dinglasan
 * @version 1.0.4
 */
@Service
public class MandatoryCoursesServiceImpl implements MandatoryCoursesService {

    @Autowired
    private MandatoryCoursesDao mandatoryCoursesDao;
    private MandatoryCoursesForm mandatoryCoursesForm = new MandatoryCoursesForm();

    private static Logger logger = LoggerFactory.getLogger(MandatoryCoursesServiceImpl.class);

    /**
     * Finds all mandatory courses based on the given date
     * @param selectedReportDate
     * @return mandatoryCourses
     *
     */
    @Override
    public Set<MandatoryCourses> getMandatoryCourses(LocalDateTime selectedReportDate) {

        Set<MandatoryCourses> mandatoryCourses = mandatoryCoursesDao
                .findMandatoryCourses(selectedReportDate);

        if (mandatoryCourses.isEmpty()) {
            return null;
        } else {
            return mandatoryCourses;

        }
    }

    /**
     * Acquires the total number of JDU members
     * @return long
     */
    @Override
    public long getTotalNumberOfJduMembers() {

        mandatoryCoursesForm.setTotalNoOfJDUMem(mandatoryCoursesDao.findTotalNumberOfJdu());

        if (mandatoryCoursesForm.getTotalNoOfJDUMem() <= 0) {
            return 0;
        } else {
            return mandatoryCoursesForm.getTotalNoOfJDUMem();
        }
    }

    /**
     * Acquires the total number of enrolled JDU members
     * @return long
     */
    @Override
    public long getTotalNumberOfEnrolledJdu(String course) {
        try {
            Long totalNumberOfEnrolledJDU = mandatoryCoursesDao.findTotalNumberOfEnrolledJdu(course);
            mandatoryCoursesForm.setTotalNoOfJDUMem(totalNumberOfEnrolledJDU);

            return totalNumberOfEnrolledJDU;
        } catch (DataAccessException dataAccessException) {
            logger.error("Error: {}", dataAccessException.getMessage());
            return 0L;
        }
    }

    /**
     * Acquires the total number of completion for the specified course.
     * 
     * @param mandatoryCourse
     * @param reportDate
     * @return long
     */
    @Override
    public long getTotalNumberOfCompletion(String mandatoryCourse, LocalDateTime reportDate) {

        mandatoryCoursesForm.setTotalNoOfJDUMemFin(
                mandatoryCoursesDao.findTotalNumberOfJduWhoFinishedTraining(mandatoryCourse,
                        reportDate));

        if (mandatoryCoursesForm.getTotalNoOfJDUMemFin() < 0) {
            return 0;
        } else {
            return mandatoryCoursesForm.getTotalNoOfJDUMemFin();
        }
    }

    /**
     * Acquires the total number of completion for the specified course within last week.
     * 
     * @param mandatoryCourse
     * @param reportDate
     * @return long
     */
    @Override
    public long getTotalNumberOfCompletionLastWeek(String mandatoryCourse, LocalDateTime reportDate) {

        mandatoryCoursesForm.setTotalNoOfJDUMemFinLastWk(mandatoryCoursesDao
                .findTotalNumberOfJduWhoFinishedTrainingLastWeek(mandatoryCourse, reportDate));

        if (mandatoryCoursesForm.getTotalNoOfJDUMemFinLastWk() <= 0) {
            return 0;
        } else {
            return mandatoryCoursesForm.getTotalNoOfJDUMemFinLastWk();
        }
    }

    @Override
    public Set<MandatoryCourses> getMandatoryCourses() {
        Set<MandatoryCourses> findMandatoryCourse = mandatoryCoursesDao.findMandatoryCourses();
        return findMandatoryCourse;
    }

    @Override
    public BigDecimal getCompletionPercentage(String when) {
        Long membersFinished = 0L;

        if (when.equals("TODAY")) {
            membersFinished = mandatoryCoursesForm.getTotalNoOfJDUMemFin();
        } else if (when.equals("LAST WEEK")) {
            membersFinished = mandatoryCoursesForm.getTotalNoOfJDUMemFinLastWk();
        }

        return ReportUtils.calculateCompletionPercentage(membersFinished,
                mandatoryCoursesForm.getTotalNoOfJDUMem());
    }

}

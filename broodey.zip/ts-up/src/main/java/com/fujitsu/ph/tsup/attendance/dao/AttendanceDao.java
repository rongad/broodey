//AttendanceDao

package com.fujitsu.ph.tsup.attendance.dao;

import java.time.ZonedDateTime;
import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.attendance.domain.CourseParticipant;
import com.fujitsu.ph.tsup.attendance.domain.CourseSchedule;
import com.fujitsu.ph.tsup.attendance.model.CourseScheduleListForm;

// ==================================================================================================
// $Id:PR03$
// Project Name :Training Sign Up
// System Name :Attendance process
// Class Name :AttendanceDao.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+---------------------------------------------+-------------------------------
// 0.01 | 06/23/2020 | WS) J. Iwarat | New Creation
// 0.02 | 06/23/2020 | WS) J. Iwarat | Update
// 0.03 | 07/30/2020 | WS) R.Ramos | Update
// 0.04 | 08/26/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.05 | 09/02/2021 | WS) CJ.Zamora | Update
// 0.06 | 10/013/2021 | WS) Mj.liwag | Updated
// ==================================================================================================
/**
 * <pre>
 * The data access interface for attendance related database access
 * 
 * <pre>
 * 
 * @version 0.04
 * @author k.abad
 * @author j.iwarat
 * @author r.ramos
 */
public interface AttendanceDao {

    /**
     * Finds the scheduled courses starting from today onwards
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param instructorId
     * @return
     */
    Set<CourseSchedule> findAllScheduledCourses(ZonedDateTime fromDateTime, ZonedDateTime toDateTime,
            Long instructorId);

    /**
     * Finds the course schedule by id
     * 
     * @param id
     * @return
     */
    Set<CourseParticipant> findCourseScheduleById(Long id);

    /**
     * Finds the course participants by course schedule detail id
     * 
     * @param id
     * @return
     */
    Set<CourseAttendance> findCourseScheduleDetailParticipantsById(Long id);

    /**
     * Finds the course schedule by id
     * 
     * @param id
     * @return
     */
    Set<CourseAttendance> findCourseAttendanceByCourseScheduleDetailId(Long id);

    /**
     * Creates the course attendance
     * 
     * @param courseAttendance
     * @return
     */
    void saveAttendance(CourseAttendance courseAttendance);

    /**
     * Updates the course attendance
     * 
     * @param courseAttendance
     * @return
     */
    void updateAttendance(CourseAttendance courseAttendance);

    /**
     * Updates the course attendance
     * 
     * @param courseAttendance
     * @return
     */
    void updateLogout(CourseAttendance courseAttendance);

    /**
     * Finds the course participants by course schedule detail id
     * 
     * @param id
     * @return
     */
    Set<CourseAttendance> findCourseScheduleDetailById(Long id);

    /**
     * Finds the scheduled courses starting from today onwards
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param participantId
     * @return
     */
    Set<CourseParticipant> findAllScheduledCoursesByParticipant(CourseScheduleListForm courseScheduleListForm, Pageable pageable);

    // for pagination =========================================
    /**
     * <pre>
     * Method for counting the number of available course
     * 
     * @author m.yanoyan
     *
     *         <pre>
     */
    int countCourse(CourseScheduleListForm courseScheduleListForm);
    // for pagination end ======================================
}

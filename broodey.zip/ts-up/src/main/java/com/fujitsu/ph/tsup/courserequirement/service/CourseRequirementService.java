package com.fujitsu.ph.tsup.courserequirement.service;

import java.util.List;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.CourseScheduleDetail;
import com.fujitsu.ph.tsup.courserequirement.model.EmployeeChecklist;

//===============================================================
//$Id: PR30$
//Project Name: Training Sign Up
//System Name : Course Checklist
//Class Name: CourseRequirementService.java
//
//<<Modification History>>
//Version | Date       | Updated by          | Content
//--------+------------+---------------------+-----------------
//0.01    | 10/18/2021 | WS) a.abellanosa    | Initial Creation
//0.02    | 10/19/2021 | WS) a.abellanosa    | Updated parameter for getAttendeeChecklist
//0.03    | 10/29/2021 | WS) e.delosreyes    | Added updateCourseRequirement
//0.04    | 11/05/2021 | WS) a.abellanosa    | remove getAttendeeChecklist
//===============================================================
/**
 * <pre>
 *The interface of course requirement service
 * 
 * </pre>
 *
 * @version 0.04
 * @author  a.abellanosa
 *
 */
public interface CourseRequirementService {

	// Get all courses from List of courses from database
	List<Course> getCourses();

	/**
	 * <pre>
	 * Get all course requirement of specific course
	 * </pre>
	 * 
	 * @param courseId
	 * @return
	 */
	List<CourseChecklist> getCourseRequirements(Integer courseId);

	/**
	 * <pre>
	 * Create the course requirement
	 * </pre>
	 * 
	 * @param courseRequirement
	 */
	void createCourseRequirement(CourseChecklist courseRequirement);

	/**
	 * <pre>
	 * Delete course requirement
	 * </pre>
	 * 
	 * @param courseRequirementId
	 */
	void deleteCourseRequirement(Integer courseRequirementId);

	/**
	 * <pre>
	 * Update status of Attendee's checklist
	 * </pre>
	 * 
	 * @param employeeChecklists
	 */
	void updateAttendeeChecklist(List<EmployeeChecklist> employeeChecklists);

		/**
	 * <pre>
	 * Update course checklist
	 * </pre>
	 * 
	 * @param employeeChecklists
	 */
	void updateCourseRequirement(CourseChecklist courseChecklist);

	/**
	 * <pre>
	 * This method will creturn the list of CourseScheduleDetail
	 * </pre>
	 * 
	 * @param courseId
	 */
	List<CourseScheduleDetail> getCourseScheduleDetails(Integer courseId);

	/**
	 * <pre>
	 * This method will return the list of participants of the course schedule
	 * <pre>
	 * @param courseScheduleId
	 * @return List<CourseParticipant>
	 */
	List<CourseParticipant> getCourseParticipants(Integer courseScheduleId);

		/**
	 * <pre>
	 * This method will return the list of participants of the course schedule
	 * <pre>
	 * @param participantId
	 * @return List<EmployeeChecklist>
	 */
	List<EmployeeChecklist> getParticipantChecklist(Integer participantId, Integer courseId);
}

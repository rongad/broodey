//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : Reports                                                                                                                                                             
// Class Name   : ReportForTrainingRequestDao.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.1     | 2021/08/19 | WS)L.Celoso           | New Creation   
//==================================================================================================     
package com.fujitsu.ph.tsup.report.summary.dao;

import java.util.Set;

import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

public interface ReportForTrainingRequestDao {
	
	 /**
     *  Find all training requests
     * @return Set of Training Request
     */
    Set<TrainingRequest> findAllTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm);
    
}

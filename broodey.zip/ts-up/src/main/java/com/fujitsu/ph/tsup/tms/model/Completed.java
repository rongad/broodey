package com.fujitsu.ph.tsup.tms.model;

import java.io.Serializable;
import java.util.Date;

public class Completed{
	
	private String employeeName;
	private String employeeStatus;
	private String manager;
	private String courseTitle;
	private Date targetCompletion;
	private Date actualCompletion;
	private String sourceLearning;

	public String getSourceLearning() {
		return sourceLearning;
	}

	public void setSourceLearning(String sourceLearning) {
		this.sourceLearning = sourceLearning;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeStatus() {
		return employeeStatus;
	}
	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
	public String getManager() {
		return manager;
		
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getCourseTitle() {
		return courseTitle;
	}
	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}
	public Date getTargetCompletion() {
		return targetCompletion;
	}
	public void setTargetCompletion(Date TargetCompletion) {
		this.targetCompletion = TargetCompletion;
	}
	public Date getActualCompletion() {
		return actualCompletion;
	}
	public void setActualCompletion(Date ActualCompletion) {
		this.actualCompletion = ActualCompletion;
	}
	
	
	@Override
	public String toString() {
		return "Completed [employeeName=" + employeeName + ", employeeStatus=" + employeeStatus + ", manager="
				+ manager + ", courseTitle=" + courseTitle + ", targetCompletion=" + targetCompletion.toString()
				+ ", actualCompletion=" + actualCompletion.toString()+"]";
	}
	
	
	
}

package com.fujitsu.ph.tsup.training.request.domain;

import java.time.ZonedDateTime;

//==================================================================================================
//Project Name :Training Sign Up
//System Name  :Training Request
//Class Name   :TrainingRequest.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 07/13/2021 | WS) L.Celoso          | New Creation
//==================================================================================================

/**
* <pre>
* Training Request Model
* 
* <pre>
* 
* @version 0.01
* @author L.Celoso
*/

public class TrainingRequest {

	/** id **/
	private Long id;

	/** courseScheduleId **/
	private Long employeeId;

	/** courseName **/
	private String courseName;

	/** courseDetails **/
	private String courseDetails;

	/** status **/
	private String requestStatus;

	/** start date time**/
	private ZonedDateTime startDateTime;

	/** end date time**/
	private ZonedDateTime endDateTime;
	
	/** duration**/
	private float duration;
	
	/** minParticipants**/
	private int minParticipants;	
	
	/** maxParticipants**/
	private int maxParticipants;
    
	/** requester **/
	private String requesterName;

	/** approver **/
	private String approverName;

	/** approverRemarks **/
	private String approverRemarks;
	
	protected TrainingRequest() {

	}

	private TrainingRequest(Builder builder) {
		this.id = builder.id;
		this.employeeId = builder.employeeId;
		this.courseName = builder.courseName;
		this.courseDetails = builder.courseDetails;
		this.requestStatus = builder.requestStatus;
		this.startDateTime = builder.startDateTime;
		this.endDateTime = builder.endDateTime;
		this.duration = builder.duration;
		this.minParticipants = builder.minParticipants;
		this.maxParticipants = builder.maxParticipants;
		this.requesterName = builder.requesterName;
		this.approverName = builder.approverName;
		this.approverRemarks = builder.approverRemarks;

	}

	public Long getId() {
		return id;
	}
	
	public Long getEmployeeId() {
		return employeeId;
	}

	public String getCourseName() {
		return courseName;
	}

	public String getCourseDetails() {
		return courseDetails;
	}
	
	public String getRequestStatus() {
		return requestStatus;
	}
	
	public ZonedDateTime getStartDateTime() {
		return startDateTime;
	}
	
	public ZonedDateTime getEndDateTime() {
		return endDateTime;
	} 
	
	public float getDuration() {
		return duration;
	} 
	
	public int getMinParticipants() {
		return minParticipants;
	} 
	
	public int getMaxParticipants() {
		return maxParticipants;
	} 
	
	public String getRequesterName() {
		return requesterName;
	} 
	
	public String getApproverName() {
		return approverName;
	} 
	
	public String getApproverRemarks() {
		return approverRemarks;
	} 
	
	/**
	 * <pre>
	 * The builder class of the course participant The builder is a public static
	 * member class of
	 * 
	 * <pre>
	 * 
	 * @author K.Freo
	 *
	 */

	public static class Builder {

		/** id **/
		private Long id;

		/** courseScheduleId **/
		private Long employeeId;

		/** courseName **/
		private String courseName;

		/** courseDetails **/
		private String courseDetails;

		/** status **/
		private String requestStatus;

		/** start date time**/
		private ZonedDateTime startDateTime;

		/** end date time**/
		private ZonedDateTime endDateTime;
		
		/** duration**/
		private float duration;

		/** minParticipants **/
		private int minParticipants;

		/** maxParticipants **/
		private int maxParticipants;

		/** requesterName **/
		private String requesterName;

		/** approverName **/
		private String approverName;

		/** approverRemarks **/
		private String approverRemarks;
		
		/**
		 * Creates a new instance of the course schedule detail.
		 * 
		 * @return new CourseParticipant(this)
		 */

		public Builder(Long id, Long employeeId, String courseName, 
						String courseDetails, String requestStatus, 
						ZonedDateTime startDateTime, ZonedDateTime endDateTime, float duration, 
						int minParticipants, int maxParticipants, String requesterName, String approverName, String approverRemarks) {
		
			this.id = id;
			this.employeeId = employeeId;
			this.courseName = courseName;
			this.courseDetails = courseDetails;
			this.requestStatus = requestStatus;
			this.startDateTime = startDateTime;
			this.endDateTime = endDateTime;
			this.duration = duration;
			this.minParticipants = minParticipants;
			this.maxParticipants = maxParticipants;
			this.requesterName = requesterName;
			this.approverName = approverName;
			this.approverRemarks = approverRemarks;
			
		}
		
		public TrainingRequest build() {

			return new TrainingRequest(this);
		}

	}
	
}


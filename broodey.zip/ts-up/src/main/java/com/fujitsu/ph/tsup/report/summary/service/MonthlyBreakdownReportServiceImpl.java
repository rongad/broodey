//==================================================================================================
// Project Name : Training Sign-Up
// System Name  : MonthlyBreakdownReportServiceImpl
// Class Name   : MonthlyBreakdownReportServiceImpl.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/10/26 | WS) d.dinglasan       | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.time.DateTimeException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.course.model.CoursesConducted;
import com.fujitsu.ph.tsup.report.summary.dao.MonthlyBreakdownReportDao;

/**
  *<pre>
  * Service implementation for monthly breakdown report of conducted courses
  *</pre>
  *
  * @version 0.01
  * @author WS) d.dinglasan 
  */
@Service
public class MonthlyBreakdownReportServiceImpl implements MonthlyBreakdownReportService {
    
    @Autowired
    private MonthlyBreakdownReportDao monthlyBreakdownReportDao;
    
    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(MonthlyBreakdownReportServiceImpl.class);
            
    /* (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.service.MonthlyBreakdownReportService#findAllConductedCoursesWithinPeriod(java.lang.String, java.lang.String)
     */
    @Override
    public Set<CoursesConducted> findAllConductedCoursesWithinPeriod(int monthValue, int yearValue) {
        Set<CoursesConducted> conductedCourseSet = new LinkedHashSet<>();

        try {
            // Create start date and end date of the month
            ZonedDateTime startDateTime = ZonedDateTime.of(yearValue, monthValue, 1, 0, 0, 0, 0,
                    ZoneId.systemDefault());
            ZonedDateTime endDateTime = startDateTime.plusMonths(1).minusMinutes(1);

            conductedCourseSet = monthlyBreakdownReportDao.findAllConductedCoursesWithinPeriod(startDateTime,
                    endDateTime);

        } catch (DateTimeException | DataAccessException | IllegalArgumentException exception) {
            logger.error("Error: {}", exception.getMessage());
        }

        return conductedCourseSet;
    }

    /* (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.service.MonthlyBreakdownReportService#getStartYear()
     */
    @Override
    public int getStartYear() {
        
        try {
            return monthlyBreakdownReportDao.getStartYear();
        } catch (DataAccessException dataAccessException) {
            logger.error("Error: {}", dataAccessException.getMessage());
            return 0;
        }
    }

}

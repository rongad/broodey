/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */    
package com.fujitsu.ph.tsup.viewsurveyrate.dao;

import java.time.ZonedDateTime;
import java.util.Set;

import com.fujitsu.ph.tsup.viewsurveyrate.domain.SurveyRateForm;
//==================================================================================================                                                                                                                                                                            
//Project Name : Training Sign Up
//System Name  : SurveyRateDao                                                                                                                                                               
//Class Name   : SurveyRateDao.java                                                                                                                                                                          
//                                                                                                                                                                       
//<<Modification History>>                                                                                                                                                                             
//Version  | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
//0.01     | 2021/08/16 | WS)E.Juan             | New Creation    
//0.02     | 2021/10/12 | WS)MI.Aguinaldo       | Added findSurveyResponses 
//0.03     | 2021/10/27 | WS)L.Celoso           | Added findSurveyResponses using course schedule ID
//==================================================================================================  

public interface SurveyRateDao {
    

    /**
     * Finds the survey assigned to course
     * @param surveyId
     * @return Set<SurveyRateForm>
     */
    Set<SurveyRateForm> findSurvey(String courseTitle,String instructorName,ZonedDateTime courseDateTime);
    
    /**
     * Find survey responses.
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return the Set<SurveyResponse>
     */
    Set<SurveyResponse> findSurveyResponses(String courseTitle,String instructorName,ZonedDateTime courseDateTime);

    /**
     * Find survey responses by course schedule Id
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return the Set<SurveyResponse>
     */
    Set<SurveyResponse> findSurveyResponses(Long courseScheduleId);

}

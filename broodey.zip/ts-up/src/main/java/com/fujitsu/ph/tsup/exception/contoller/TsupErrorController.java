package com.fujitsu.ph.tsup.exception.contoller;

import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name   : TsupErrorController.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/07/16 | WS) mi.aguinaldo       | Initial Version
//==================================================================================================

@Controller
@ConditionalOnExpression("${enabled.custom.error:false}")
public class TsupErrorController  implements ErrorController {
    private static final Logger LOGGER = LoggerFactory.getLogger("TS-UP");

    @GetMapping(value = "/error")
    public String handleError(HttpServletRequest request, Model model) {
	UUID uuid = UUID.randomUUID();
        
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String errorMsg="";
        Integer statusCode = Integer.valueOf(status.toString());
        
        if(statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
          Throwable throwable = (Throwable) request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
          
          LOGGER.error("TRACE ID:[" + uuid.toString() +"]: "+throwable.getMessage(),throwable);
          
          errorMsg = throwable.getCause().getMessage();
          
          model.addAttribute("traceId", uuid.toString());
        }
        
        if(statusCode == HttpStatus.NOT_FOUND.value()) {
            errorMsg = "page not found";
        } else if (statusCode == HttpStatus.FORBIDDEN.value()) {
            errorMsg = "Sorry, You have no permission to access this page"; 
        }


        model.addAttribute("status", statusCode);
        model.addAttribute("msg", errorMsg.toUpperCase());
        
        return "error-page";
    }
    
    
    @Override
    public String getErrorPath() {
	return null;
    }

}
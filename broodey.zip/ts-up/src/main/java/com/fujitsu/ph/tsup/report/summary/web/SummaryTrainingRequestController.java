//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Report For Non Attendees Controller
//Class Name   : ReportForNonAttendeesController.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/08/17 | WS) L.Celoso          | Initial Version
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.web;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fujitsu.ph.tsup.report.summary.service.ReportForTrainingRequest;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

/**
 * The controller of JDU/GDC Mandatory courses report
 * 
 * @author l.celoso
 */
@Controller
@RequestMapping("/report/summary")
public class SummaryTrainingRequestController {
	
	public static final String NO_RECORDS_FOUND = "No Training Request Records Found";
	
	@Autowired
    private ReportForTrainingRequest reportForTrainingRequest;

	@GetMapping("/trainingRequest")
    public String loadInitialReportScreen(@Valid @ModelAttribute("trainingRequestSearchForm") TrainingRequestSearchForm form, Model model) {
    	
		form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
		form.setSearchEndDateTimeZone(ZonedDateTime.now().plusDays(5));
		form.setStatus("%");
     
		Set<TrainingRequest> trainingRequest = reportForTrainingRequest.getTrainingRequest(form);
        List<TrainingRequest> trainingRequestList = trainingRequest.stream().collect(Collectors.toList());
		
        if(trainingRequestList.isEmpty()) {
        	model.addAttribute("nullMessage", NO_RECORDS_FOUND);
        }
        
        model.addAttribute("trainingRequestSearchForm", form);
        model.addAttribute("trainingRequestSet", trainingRequestList);
        return "reports/summaryTrainingRequest";

    }
	
    @PostMapping("/trainingRequest/view")
    public String getReportData(@Valid @ModelAttribute("trainingRequestSearchForm") TrainingRequestSearchForm form, Model model) {
    
    	LocalDateTime startDateTime = form.getSearchStartDateTime();
		LocalDateTime endDateTime = form.getSearchEndDateTime();
    	
    	if (form.getSearchStartDateTime() == null) {
			form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
		} else {
			form.setSearchStartDateTimeZone(startDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
		}
		if (form.getSearchEndDateTime() == null) {
			form.setSearchEndDateTimeZone(ZonedDateTime.now().plusDays(5));
		} else {
			form.setSearchEndDateTimeZone(endDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
		}

		form.setStatus(checkFilterId(form.getStatus()));
		
    	Set<TrainingRequest> trainingRequest = reportForTrainingRequest.getTrainingRequest(form);
        List<TrainingRequest> trainingRequestList = trainingRequest.stream().collect(Collectors.toList());

        if(trainingRequestList.isEmpty()) {
        	model.addAttribute("nullMessage", NO_RECORDS_FOUND);
        }
        
        model.addAttribute("trainingRequestSearchForm", form);
        model.addAttribute("trainingRequestSet", trainingRequestList);
        return "reports/summaryTrainingRequest";

    }
    
    /**
	 * Check if filter Id is null, empty or undefined
	 * 
	 * @return
	 * 
	 */
	private String checkFilterId(String filterId) {

		if (filterId == null || filterId.isEmpty() || filterId.equals("undefined") || filterId.equals("All")) {
			return "%";
		}

		return filterId;
	}
}

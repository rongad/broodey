/*
 *Copyright (C) 2020 FUJITSU LIMITED All rights reserved. 
 */

package com.fujitsu.ph.tsup.courserequirement.model;
/*==================================================================================================
*Project Name : Training Sign Up
*System Name  : CourseChecklist
*Class Name   : EmployeeEmployee.java
*
*<<Modification History>>
*Version | Date       | Updated By            | Content
*--------+------------+-----------------------+-----------------------------------------------------
*0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
*0.02    | 2021/11/10 | WS) je.subelario      | Revised Comments
*0.03    | 2021/11/10 | WS) v.tallo           | Revised Comments
*===================================================================================================
*/

/**
 * <pre>
 * The model for Employee
 * 
 * <pre>
 * 
 * @version 0.03
 * @author v.tallo
 */

public class Employee {
	private Integer id;
	
	private String lastName;
	
	private String firstName;
	
	
	
	/**
	 * @param id
	 * @param lastName
	 * @param firstName
	 */
	public Employee(Integer id, String lastName, String firstName) {
		this.id = id;
		this.lastName = lastName;
		this.firstName = firstName;
	}
	
	

	/**
	 * Default constructor
	 */
	public Employee() {
	}



	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
}

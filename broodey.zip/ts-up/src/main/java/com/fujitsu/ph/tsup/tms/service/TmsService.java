package com.fujitsu.ph.tsup.tms.service;

import java.io.BufferedReader;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.fujitsu.ph.tsup.tms.model.IncompleteTraining;
import com.fujitsu.ph.tsup.tms.model.Masterlist;
import com.fujitsu.ph.tsup.tms.model.NotRegistered;
import com.fujitsu.ph.tsup.tms.model.OverallSummaryReport;
import com.fujitsu.ph.tsup.tms.model.PullDownOptions;
import com.fujitsu.ph.tsup.tms.model.Completed;
import com.fujitsu.ph.tsup.tms.model.CourseDetails;
import com.fujitsu.ph.tsup.tms.model.CourseStatus;
import com.fujitsu.ph.tsup.tms.model.CourseStatusDetails;
import com.fujitsu.ph.tsup.tms.model.Course;
import com.fujitsu.ph.tsup.tms.model.Employee;
import com.fujitsu.ph.tsup.tms.model.SummaryReport;
import com.fujitsu.ph.tsup.tms.model.CheckFiles;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class TmsService<OverallSummary> {

	private boolean recordExist = false;
	private List<List<Object>> employeeDetails = null;

	private List<List<Object>> employeeLinkedInNR = null;
	private List<List<Object>> employeeLinkedInNRFiltered = null;

	private List<List<Object>> employeeNRSaba = null;
	private List<List<Object>> employeeNRSabaFiltered = null;
	private List<List<Object>> filteredEmployees = null;
	private List<List<Object>> coursesLists = null;
	private List<List<Object>> coursesSaba = null;
	private List<List<Object>> coursesLnkdIn = null;

	/*
	 * MasterLists
	 */
	private List<List<Object>> masterEmployeeDetailsFrmFileLists = null;
	private List<List<Object>> masterCoursesListsFrmFileLists = null;
	private List<List<Object>> lnkdInFrmFileLists = null;
	private List<List<Object>> sabaFrmFileLists = null;
	private List<Course> masterCoursesLists = null;
	private List<Course> masterEmpoloyeeCourseLists = null;

	public List<Employee> masterEmployeeDetails = null;
	/*
	 * MasterLists not registered,completed,incomplete LinkedIn
	 */
	private List<Course> masterListsLnkdIn = null;
	private List<Course> masterListsSaba = null;

	/*
	 * MasterLists not registered,completed,incomplete SABA
	 */

	public List<Course> readMasterlist() throws Exception {

		String parentPath = "C:\\tms\\";
		List<String> fileLocations = new ArrayList<>();
		fileLocations.add("Course_List.xlsx");
		fileLocations.add("Employee_Details.xlsx");
		fileLocations.add("Employee_Details_JML.xlsx");
		fileLocations.add("SABA_Courses_per_Employee.csv");
		fileLocations.add("LinkedIn_Courses_per_Employee.csv");

		if (masterCoursesListsFrmFileLists == null) {
			masterCoursesListsFrmFileLists = readDataFile(String.format("%s%s", parentPath, fileLocations.get(0)), 3,
					1);
		}

		if (masterEmpoloyeeCourseLists == null) {
			masterEmpoloyeeCourseLists = new ArrayList<>();
		}

		if (masterCoursesLists == null) {
			masterCoursesLists = new ArrayList<>();

			for (List<Object> innerList : masterCoursesListsFrmFileLists) {
				if (innerList.get(0).toString().length() > 0 && innerList.get(1).toString().length() > 0) {
					// Create a new Course object using the values from the inner list
					Course course = new Course();
					// No need to set since, this is just to make a lists of courses
					course.setCourseAcquiredDate(null);
					course.setCourseStartedDate(null);
					;
					course.setCourseCompletedDate(null);
					course.setCourseEmployeeAssigned(null);
					course.setCourseStatus(null);

					// Needed for the lists courses
					String courseIDWithoutDecimal = decimalStrToWhole(innerList.get(0).toString());
					course.setCourseID(courseIDWithoutDecimal);
					course.setCourseName(innerList.get(1).toString());
					course.setCourseOrigin(innerList.get(2).toString());
					masterCoursesLists.add(course);
				}
			}
		}

		/*
		 * Reads employee details
		 */
		if (masterEmployeeDetails == null) {
			masterEmployeeDetails = new ArrayList<>();
			masterEmployeeDetailsFrmFileLists = readDataFile(String.format("%s%s", parentPath, fileLocations.get(2)), 9,
					1);

			for (List<Object> employeeObj : masterEmployeeDetailsFrmFileLists) {

				if (employeeObj.get(0).toString().length() > 0 && employeeObj.get(1).toString().length() > 0) {
					Employee empObj = new Employee();
					empObj.setEmployeeStatus("Active");
					empObj.setEmployeeID(employeeObj.get(1).toString());
					empObj.setEmployeeName(employeeObj.get(2).toString());
					empObj.setEmployeeEmail(employeeObj.get(3).toString());
					empObj.setEmployeeRole(employeeObj.get(4).toString());
					Date hiredDate = new Date();
					empObj.setEmployeeHiredDate(hiredDate);
					Date joinDate = new Date();
					empObj.setEmployeeJoinDate(joinDate);
					empObj.setEmployeeOnboardProjectName(employeeObj.get(7).toString());
					empObj.setEmployeeManager(employeeObj.get(8).toString());

					masterEmployeeDetails.add(empObj);
				}

			}

		}

		/*
		 * Reads linkdin file
		 */
		if (lnkdInFrmFileLists == null) {
			masterListsLnkdIn = new ArrayList<>();
			lnkdInFrmFileLists = readDataFile(String.format("%s%s", parentPath, fileLocations.get(4)), 26, 1);
			for (Employee employee : masterEmployeeDetails) {
				for (List<Object> courseObjEmp : lnkdInFrmFileLists) {
					for (Course courseItem : masterCoursesLists) {
						if (courseItem.getCourseID().equals(courseObjEmp.get(6).toString())) {
							if (employee.getEmployeeID().equals(courseObjEmp.get(2).toString())
									&& courseObjEmp.get(0).toString().length() > 0) {

								Course course = null;

								String formatOriginal = "MM/dd/yy";
								Date dateAcquired = new Date();
								Date dateStarted = new Date();
								Date dateCompleted = new Date();

								if (courseObjEmp.get(9).toString().length() > 0
										&& courseObjEmp.get(9).toString().contains("/")) {
									dateAcquired = parseStringToDate(courseObjEmp.get(9).toString(), formatOriginal);
								}
								if (courseObjEmp.get(9).toString().length() > 0
										&& courseObjEmp.get(9).toString().contains("/")) {
									dateStarted = parseStringToDate(courseObjEmp.get(9).toString(), formatOriginal);
								}
								if (courseObjEmp.get(11).toString().length() > 0
										&& courseObjEmp.get(11).toString().contains("/")) {
									dateCompleted = parseStringToDate(courseObjEmp.get(11).toString(), formatOriginal);
								}

								if (courseObjEmp.get(8).equals("0%") && courseObjEmp.get(9).toString().length() <= 0) {
									course = new Course();
									course.setCourseAcquiredDate(dateAcquired);
									course.setCourseStartedDate(dateStarted);
									course.setCourseCompletedDate(dateCompleted);
									course.setCourseStatus("not registered");

									course.setCourseID(courseObjEmp.get(6).toString());
									course.setCourseName(courseObjEmp.get(3).toString());
									course.setCourseOrigin(courseObjEmp.get(4).toString());
									course.setCourseEmployeeAssigned(employee);
								} else if (courseObjEmp.get(8).equals("100%")
										&& courseObjEmp.get(11).toString().length() > 0) {
									course = new Course();
									course.setCourseAcquiredDate(dateAcquired);
									course.setCourseStartedDate(dateStarted);
									course.setCourseCompletedDate(dateCompleted);
									course.setCourseStatus("completed");

									course.setCourseID(courseObjEmp.get(6).toString());
									course.setCourseName(courseObjEmp.get(3).toString());
									course.setCourseOrigin(courseObjEmp.get(4).toString());
									course.setCourseEmployeeAssigned(employee);

								} else if (!courseObjEmp.get(8).equals("0%") && !courseObjEmp.get(8).equals("100%")
										&& courseObjEmp.get(8).toString().length() > 0) {
									course = new Course();
									course.setCourseAcquiredDate(dateAcquired);
									course.setCourseStartedDate(dateStarted);
									course.setCourseCompletedDate(dateCompleted);
									course.setCourseStatus("incomplete");

									course.setCourseID(courseObjEmp.get(6).toString());
									course.setCourseName(courseObjEmp.get(3).toString());
									course.setCourseOrigin(courseObjEmp.get(4).toString());
									course.setCourseEmployeeAssigned(employee);
								}
								if (course != null) {
									masterListsLnkdIn.add(course);
								}

							}
						}
					}

				}
			}

		}

		/*
		 * Reads saba file
		 */
		if (sabaFrmFileLists == null) {
			masterListsSaba = new ArrayList<>();
			sabaFrmFileLists = readDataFile(String.format("%s%s", parentPath, fileLocations.get(3)), 30, 17);
			for (Employee employee : masterEmployeeDetails) {
				for (List<Object> courseObjEmp : sabaFrmFileLists) {
					for (Course courseItem : masterCoursesLists) {
						if (courseItem.getCourseID().equals(courseObjEmp.get(19).toString())) {
							if (employee.getEmployeeID().equals(courseObjEmp.get(0).toString())
									&& courseObjEmp.get(0).toString().length() > 0) {

								Course course = null;

								String formatOriginal = "dd-MMM-yy";
								Date dateAssigned = new Date();
								/*
								 * assigned && (blank || not evaluated) = not registered acquired && 100 &&
								 * acquiredon not empty && successful && markedcompleted not empty = completed
								 * else incomplete
								 * 
								 */
								if ((courseObjEmp.get(16).toString().toLowerCase().equals("assigned")
										&& (courseObjEmp.get(23).toString().toLowerCase().equals("not evaluated"))
										|| (courseObjEmp.get(23).toString().length() <= 0))) {

									course = new Course();
									course.setCourseAssignedDate(dateAssigned);

									// to set null
									course.setCourseAcquiredDate(null);
									course.setCourseStartedDate(null);
									course.setCourseCompletedDate(null);

									course.setCourseStatus("not registered");

									course.setCourseID(courseObjEmp.get(19).toString());
									course.setCourseName(courseObjEmp.get(20).toString());
									course.setCourseEmployeeAssigned(employee);
								} else if ((courseObjEmp.get(16).toString().toLowerCase().equals("acquired")
										|| courseObjEmp.get(16).toString().toLowerCase().equals("in progress"))
//								&& courseObjEmp.get(17).toString().toLowerCase().equals("100")
										&& courseObjEmp.get(21).toString().length() > 0
										&& courseObjEmp.get(23).toString().toLowerCase().equals("successful")
										&& courseObjEmp.get(25).toString().length() > 0) {

									Date dateAcquired = new Date();
									Date dateCompleted = new Date();

									course = new Course();
									course.setCourseCompletedDate(dateCompleted);
									course.setCourseStatus("completed");

									if (courseObjEmp.get(21).toString().contains("/")) {
										dateAcquired = parseStringToDate(courseObjEmp.get(21).toString(),
												formatOriginal);
									}
									if (courseObjEmp.get(25).toString().contains("/")) {
										dateCompleted = parseStringToDate(courseObjEmp.get(25).toString(),
												formatOriginal);
									}

									course.setCourseAssignedDate(dateAssigned);
									course.setCourseCompletedDate(dateCompleted);
									course.setCourseAcquiredDate(dateAcquired);

									// to set null
									course.setCourseStartedDate(null);

									course.setCourseID(courseObjEmp.get(19).toString());
									course.setCourseName(courseObjEmp.get(20).toString());
									course.setCourseEmployeeAssigned(employee);

								} else {
									course = new Course();

									course.setCourseAssignedDate(dateAssigned);

									course.setCourseAcquiredDate(null);
									course.setCourseStartedDate(null);
									course.setCourseCompletedDate(null);
									course.setCourseStatus("incomplete");

									course.setCourseID(courseObjEmp.get(19).toString());
									course.setCourseName(courseObjEmp.get(20).toString());
									course.setCourseEmployeeAssigned(employee);
								}
								if (course != null) {
									course.setCourseOrigin("SABA");
									masterListsSaba.add(course);
								}
							}
						}
					}
				}
			}

		}
		masterEmpoloyeeCourseLists.addAll(masterListsLnkdIn);
		masterEmpoloyeeCourseLists.addAll(masterListsSaba);

		return masterEmpoloyeeCourseLists;

	}

	public String decimalStrToWhole(String decimalNumber) {
		try {
			DecimalFormat df = new DecimalFormat("#");
			String wholeNumberString = df.format(Double.parseDouble(decimalNumber));
			return wholeNumberString;
		} catch (Exception e) {
			return decimalNumber;
		}
	}

	public Date parseStringToDate(String dateStr, String formatDate) throws ParseException {
		Date dateAcquired = new Date();
		if (dateStr.length() > 0) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate, Locale.ENGLISH);
			try {
				dateAcquired = dateFormat.parse(dateStr);
			} catch (ParseException e) {
				System.out.println(dateStr + "Invalid date");
			}
		}
		return dateAcquired;
	}

	public List<NotRegistered> readNotRegistered() throws Exception {
		String parentPath = "C:\\tms\\";
		List<String> fileLocations = new ArrayList<>();
		fileLocations.add("Course_List.xlsx");
		fileLocations.add("Employee_Details.xlsx");
		fileLocations.add("SABA_Courses_per_Employee.csv");
		fileLocations.add("LinkedIn_Courses_per_Employee.csv");

		List<List<Object>> employeeDetails = readDataFile(String.format("%s%s", parentPath, fileLocations.get(1)), 8,
				1);
		/**
		 * uncomment to test for linkedin entries, commented because it causes lag on
		 * the screen List<List<Object>> employeeLinkedInNR =
		 * readDataFile(String.format("%s%s", parentPath, fileLocations.get(3)), 26, 1);
		 **/
		List<List<Object>> employeeNRSaba = readDataFile(String.format("%s%s", parentPath, fileLocations.get(2)), 30,
				17);

		if (coursesLists == null) {
			coursesLists = readDataFile(String.format("%s%s", parentPath, fileLocations.get(0)), 3, 1);
			coursesSaba = coursesLists.parallelStream()
					.filter(obj -> obj.get(2).toString().toLowerCase().equals("saba")).collect(Collectors.toList());
			coursesLnkdIn = coursesLists.parallelStream()
					.filter(obj -> obj.get(2).toString().toLowerCase().equals("linkedin")).collect(Collectors.toList());
		}

		if (employeeDetails == null) {
			employeeDetails = readDataFile(String.format("%s%s", parentPath, fileLocations.get(1)), 8, 1);
			filteredEmployees = employeeDetails.parallelStream()
					.filter(obj -> obj.get(7).toString().toLowerCase().equals("active")).collect(Collectors.toList());
		}

		if (employeeLinkedInNR == null) {
			employeeLinkedInNR = readDataFile(String.format("%s%s", parentPath, fileLocations.get(3)), 26, 1);
			employeeLinkedInNRFiltered = employeeLinkedInNR.parallelStream()
					.filter(obj -> obj.get(0).toString().length() > 0 && obj.get(8).equals("0%")
							&& obj.get(9).toString().length() <= 0)
					.collect(Collectors.toList());
		}

		if (employeeNRSaba == null) {
			employeeNRSaba = readDataFile(String.format("%s%s", parentPath, fileLocations.get(2)), 30, 17);
			employeeNRSabaFiltered = employeeNRSaba.parallelStream()
					.filter(obj -> ((obj.get(16).toString().toLowerCase().equals("in progress")
							|| obj.get(16).toString().toLowerCase().equals("assigned"))
							&& obj.get(23).toString().toLowerCase().equals("")))
					.collect(Collectors.toList());
		}

		List<NotRegistered> nrEmployees = new ArrayList<>();

		for (List<Object> employee : filteredEmployees) {
			for (int i = 0; i < employeeNRSabaFiltered.size(); i++) {
				List<Object> nrObjSaba = employeeNRSabaFiltered.get(i);
				boolean found = coursesSaba.stream()
						.anyMatch(course -> course.get(1).equals(nrObjSaba.get(20).toString()));
				if (found && employee.get(0).toString().equals(nrObjSaba.get(0).toString())) {
					NotRegistered object = new NotRegistered();
					object.setEmployeeName(nrObjSaba.get(1).toString() + " " + nrObjSaba.get(2).toString());
					object.setEmployeeStatus(employee.get(7).toString());
					object.setManager(nrObjSaba.get(10).toString());
					object.setCourseTitle(nrObjSaba.get(20).toString());
					object.setSourceLearning("SABA");
					object.setTargetCompletion(convertDateFormat(nrObjSaba.get(18).toString()));
					object.setActualCompletion(convertDateFormat(nrObjSaba.get(25).toString()));
					object.setStatus(nrObjSaba.get(16).toString());
					nrEmployees.add(object);
				}

			}

			/**
			 * uncomment to test for linkedin entries, commented because it causes lag on
			 * the screen List<NotRegistered> objEmployeeNotOnList = new ArrayList<>(); for
			 * (int i = 0; i < employeeLinkedInNR.size(); i++) { List<Object> nrObjLnkdin =
			 * employeeLinkedInNR.get(i); if
			 * (employee.get(0).toString().equals(nrObjLnkdin.get(2).toString()) &&
			 * employee.get(7).toString().toLowerCase().equals("active")) { continue; } else
			 * if (i >= employeeLinkedInNR.size() - 1) { NotRegistered object = new
			 * NotRegistered(); object.setEmployeeName(nrObjLnkdin.get(0).toString());
			 * object.setEmployeeStatus(employee.get(7).toString());
			 * object.setManager(employee.get(3).toString());
			 * object.setCourseTitle(nrObjLnkdin.get(15).toString());
			 * 
			 * object.setTargetCompletion(convertDateFormat("7-May-23"));
			 * object.setActualCompletion(convertDateFormat("7-May-23"));
			 * 
			 * object.setStatus("N/A"); objEmployeeNotOnList.add(object); }
			 * 
			 * } for (NotRegistered nrNotFound : objEmployeeNotOnList) { if (nrNotFound !=
			 * null) nrEmployees.add(nrNotFound); }
			 **/

			for (int i = 0; i < employeeLinkedInNRFiltered.size(); i++) {
				List<Object> nrObjLnkdin = employeeLinkedInNRFiltered.get(i);
				boolean found = coursesLnkdIn.stream()
						.anyMatch(course -> course.get(1).equals(nrObjLnkdin.get(3).toString()));
				if (found) {
					if (employee.get(0).toString().equals(nrObjLnkdin.get(2).toString())) {
						NotRegistered object = new NotRegistered();
						object.setEmployeeName(nrObjLnkdin.get(0).toString());
						object.setEmployeeStatus(employee.get(7).toString());
						object.setManager(employee.get(3).toString());
						object.setCourseTitle(nrObjLnkdin.get(3).toString());
						object.setSourceLearning("LinkedIn");
						object.setTargetCompletion(convertDateFormat(nrObjLnkdin.get(9).toString()));
						object.setActualCompletion(convertDateFormat(nrObjLnkdin.get(9).toString()));
						object.setStatus("N/A");
						nrEmployees.add(object);
					}
				}

			}

		}

		return nrEmployees;
	}

	public int extractNumberFrmPercent(String percentage) {
		if (percentage == null || percentage.isEmpty() || percentage.length() <= 0) {
			return -1;
		}
		Pattern pattern = Pattern.compile("\\d+");
		Matcher matcher = pattern.matcher(percentage);
		StringBuilder numbersOnly = new StringBuilder();
		while (matcher.find()) {
			numbersOnly.append(matcher.group());
		}
		return Integer.parseInt(numbersOnly.toString());
	}

	public static List<List<Object>> readDataFile(String fileLocation, int cols, int rowStart) throws Exception {
		if (fileLocation.endsWith(".xlsx")) {
			return readXlsxFiles(fileLocation, cols, rowStart);
		} else if (fileLocation.endsWith(".csv") && fileLocation.contains("SABA")) {
			return readCsvFile(fileLocation, cols, rowStart, true);
		} else if (fileLocation.endsWith(".csv") && fileLocation.contains("LinkedIn")) {
			return readCsvFile(fileLocation, cols, rowStart, false);
		} else {
			throw new IllegalArgumentException("Unsupported file type : " + fileLocation);
		}
	}

	public static List<List<Object>> readCsvFile(String fileLocation, int cols, int rowStart, boolean saba)
			throws IOException {
		List<List<Object>> objectValues = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(fileLocation))) {
			String line;
			int currentRow = 0;
			while ((line = br.readLine()) != null) {
				if (currentRow < rowStart) {
					currentRow++;
					continue;
				}
				String[] values = line.split(",");
				List<Object> rowValues = new ArrayList<>();
				for (int i = 0; i < cols; i++) {
					values[i] = values[i].replace("\"", "");
					if (i < values.length) {
						rowValues.add(values[i]);
					} else {
						rowValues.add("Empty");
					}
				}
				objectValues.add(rowValues);
				currentRow++;
			}
		}
		return objectValues;
	}

	public static List<List<Object>> readXlsxFiles(String fileLocation, int cols, int rowStart) throws Exception {
		FileInputStream file = new FileInputStream(fileLocation);
		Workbook workbook = WorkbookFactory.create(file);
		boolean startedIndex = false;
		List<List<Object>> objectValues = new ArrayList<List<Object>>();

		try {
			Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				int rowNum = row.getRowNum();
				if (rowNum != rowStart && !startedIndex) {
					startedIndex = true;
					continue;
				}
				List<Object> values = new ArrayList<>();
				for (int i = 0; i < cols; i++) {
					Cell cell = row.getCell(i);
					if (cell.getCellType() == CellType.STRING) {
						values.add(cell.getStringCellValue());
					} else if (cell.getCellType() == CellType.NUMERIC) {
						values.add(BigDecimal.valueOf(cell.getNumericCellValue()));
					} else {
						values.add(cell.getErrorCellValue());
					}
				}
				objectValues.add(values);
			}
		} finally {
			workbook.close();
		}

		return objectValues;
	}

	public String convertDateFormat(String dateStr) {
		if (dateStr == null || dateStr.isEmpty() || dateStr.length() <= 0) {
			return "N/A";
		}
		try {
			Date date;
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy", Locale.ENGLISH);
			date = dateFormat.parse(dateStr);
			SimpleDateFormat dateFormatOutput = new SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH);
			dateStr = dateFormatOutput.format(date);
			return dateStr;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public List<Completed> readCompletedlist() throws Exception {

		String parentPath = "C:\\tms\\";
		List<String> fileLocations = new ArrayList<>();
		fileLocations.add("Course_List.xlsx");
		fileLocations.add("Employee_Details.xlsx");
		fileLocations.add("SABA_Courses_per_Employee.csv");
		fileLocations.add("LinkedIn_Courses_per_Employee.csv");

		if (coursesLists == null) {
			coursesLists = readDataFile(String.format("%s%s", parentPath, fileLocations.get(0)), 3, 1);
			coursesSaba = coursesLists.parallelStream()
					.filter(obj -> obj.get(2).toString().toLowerCase().equals("saba")).collect(Collectors.toList());
			coursesLnkdIn = coursesLists.parallelStream()
					.filter(obj -> obj.get(2).toString().toLowerCase().equals("linkedin")).collect(Collectors.toList());
		}

		if (employeeDetails == null) {
			employeeDetails = readDataFile(String.format("%s%s", parentPath, fileLocations.get(1)), 8, 1);
			filteredEmployees = employeeDetails.parallelStream()
					.filter(obj -> obj.get(7).toString().toLowerCase().equals("active")).collect(Collectors.toList());
		}

		if (employeeLinkedInNR == null) {
			employeeLinkedInNR = readDataFile(String.format("%s%s", parentPath, fileLocations.get(3)), 26, 1);
			employeeLinkedInNRFiltered = employeeLinkedInNR.parallelStream()
					.filter(obj -> obj.get(0).toString().length() > 0 && obj.get(8).equals("100%")
							&& obj.get(9).toString().length() <= 0)
					.collect(Collectors.toList());
		}

		if (employeeNRSaba == null) {
			employeeNRSaba = readDataFile(String.format("%s%s", parentPath, fileLocations.get(2)), 30, 17);
			employeeNRSabaFiltered = employeeNRSaba.parallelStream()
					.filter(obj -> ((obj.get(16).toString().toLowerCase().equals("acquired")
							&& obj.get(17).toString().toLowerCase().equals("100"))))
					.collect(Collectors.toList());
		}

		List<Completed> cEmployees = new ArrayList<>();

		for (List<Object> employee : filteredEmployees) {
			for (int i = 0; i < employeeNRSabaFiltered.size(); i++) {
				List<Object> nrObjSaba = employeeNRSabaFiltered.get(i);
				boolean found = coursesSaba.stream()
						.anyMatch(course -> course.get(1).equals(nrObjSaba.get(20).toString()));

				if (found && employee.get(0).toString().equals(nrObjSaba.get(0).toString())) {
					Date dateCompleted = new Date();
					Completed object = new Completed();
					object.setEmployeeName(nrObjSaba.get(1).toString() + " " + nrObjSaba.get(2).toString());
					object.setEmployeeStatus(employee.get(7).toString());
					object.setManager(nrObjSaba.get(10).toString());
					object.setCourseTitle(nrObjSaba.get(20).toString());
					object.setSourceLearning("SABA");
					object.setTargetCompletion(new Date());
					System.out.print("error date " + nrObjSaba.get(25).toString());
					if (nrObjSaba.get(25).toString().contains("/")) {
						dateCompleted = parseStringToDate(nrObjSaba.get(25).toString(), "dd-MMM-yy");
					}
					object.setActualCompletion((dateCompleted));
					cEmployees.add(object);
				}

			}
			for (int i = 0; i < employeeLinkedInNRFiltered.size(); i++) {
				List<Object> nrObjLnkdin = employeeLinkedInNRFiltered.get(i);
				boolean found = coursesLnkdIn.stream()
						.anyMatch(course -> course.get(1).equals(nrObjLnkdin.get(3).toString()));
				if (found) {
					Date dateCompleted = new Date();

					if (employee.get(0).toString().equals(nrObjLnkdin.get(2).toString())) {
						Completed object = new Completed();
						object.setEmployeeName(nrObjLnkdin.get(0).toString());
						object.setEmployeeStatus(employee.get(7).toString());
						object.setManager(employee.get(3).toString());
						object.setCourseTitle(nrObjLnkdin.get(3).toString());
						object.setSourceLearning("LinkedIn");
						object.setTargetCompletion(new Date());
						if (nrObjLnkdin.get(11).toString().contains("/")) {
							dateCompleted = parseStringToDate(nrObjLnkdin.get(11).toString(), "MM/dd/yy");
						}
						object.setActualCompletion((dateCompleted));

						cEmployees.add(object);
					}
				}

			}

		}

		return cEmployees;
	}

	private List<List<Object>> readSabaCsvData() throws Exception {
		List<List<Object>> csvData = readDataFile(String.format("%s%s", "c:\\tms\\", "SABA_Courses_per_Employee.csv"),
				30, 16);
		csvData.parallelStream().collect(Collectors.toList());

		return csvData;
	}

	public OverallSummaryReport readSummaryReport() throws Exception {

		List<SummaryReport> summaryReportList = new ArrayList<SummaryReport>();
		List<CourseDetails> listCourseDetails = new ArrayList<CourseDetails>();
		
		List<List<Object>> csvData = readSabaCsvData();
		List<Object> courseNames = csvData.parallelStream().map(d -> d.get(20)).distinct().collect(Collectors.toList());	
		
		
		List<Object> listManagers = csvData.parallelStream().map(d -> d.get(10)).distinct()
				.collect(Collectors.toList());
		
		csvData.forEach(row -> {
			listCourseDetails.add(new CourseDetails(row.get(10).toString(), row.get(20).toString(), row.get(23).toString()));
		});	
		
		listManagers.forEach(manager -> {
			long cntCompleted = csvData.parallelStream().filter(d -> d.get(23).toString().equals("Successful") && d.get(10).toString().equals(manager.toString())).count();
			long cntIncomplete = csvData.parallelStream().filter(d -> d.get(23).toString().equals("Not Evaluated") && d.get(10).toString().equals(manager.toString())).count();
			long cntNotRegistered = csvData.parallelStream().filter(d -> d.get(23).toString().equals("") && d.get(10).toString().equals(manager.toString())).count();
			
			addToSummaryReport(summaryReportList, cntCompleted, cntIncomplete, cntNotRegistered, manager.toString(),0);
		});	

		List<CourseStatus> listCourseStatus = getListCourseStatus(listCourseDetails, courseNames);

		OverallSummaryReport overallSummary = new OverallSummaryReport();
		overallSummary.setSummaryReportList(summaryReportList);
		overallSummary.setListCourseStatus(listCourseStatus);

		return overallSummary;
	}	

	private List<CourseStatus> getListCourseStatus(List<CourseDetails> listCourseDetails, List<Object> courses) {
		List<CourseStatus> listCourseStatus = new ArrayList<CourseStatus>();
		long cnt;

		String manager = "All";
		for (Object course : courses) {

			cnt = listCourseDetails.stream().filter(o -> o.getCourse().equals(course.toString()))
					.filter(o -> o.getStatus().equals("Successful")).count();
			listCourseStatus.add(new CourseStatus(course.toString(), "Completed", cnt, manager));

			cnt = listCourseDetails.stream().filter(o -> o.getCourse().equals(course.toString()))
					.filter(o -> o.getStatus().equals("Not Evaluated")).count();
			listCourseStatus.add(new CourseStatus(course.toString(), "Not Evaluated", cnt, manager));

			cnt = listCourseDetails.stream().filter(o -> o.getCourse().equals(course.toString()))
					.filter(o -> !o.getStatus().equals("Successful") && !o.getStatus().equals("Not Evaluated"))
					.count();
			listCourseStatus.add(new CourseStatus(course.toString(), "Not Registered", cnt, manager));

		}
		return listCourseStatus;
	}

	public List<CourseStatusDetails> getFilteredData(String manager_param, String course_param) throws Exception {
		List<CourseStatusDetails> listCourseStatusDetails = new ArrayList<CourseStatusDetails>();
		List<CourseDetails> listCourseDetails = new ArrayList<CourseDetails>();

		List<List<Object>> csvData = readSabaCsvData();
		List<Object> courseNames = csvData.parallelStream().map(d -> d.get(20)).distinct().collect(Collectors.toList());
		csvData.forEach(row -> {
			listCourseDetails.add(new CourseDetails(row.get(10).toString(), row.get(20).toString(), row.get(23).toString()));
		});		

		if (!manager_param.equals("ALL") && course_param.equals("ALL")) {
			listCourseStatusDetails = getFilteredDataByManager(manager_param, listCourseDetails, courseNames);
		} else if (manager_param.equals("ALL") && !course_param.equals("ALL")) {
			listCourseStatusDetails = getFilteredDataByCourse(course_param, listCourseDetails);
		} else if (!manager_param.equals("ALL") && !course_param.equals("ALL")) {
			listCourseStatusDetails = getFilteredDataByManagerAndCourse(manager_param, course_param, listCourseDetails);
		}

		return listCourseStatusDetails;
	}

	private List<CourseStatusDetails> getFilteredDataByManagerAndCourse(String manager_param, String course_param,
			List<CourseDetails> listCourseDetails) {
		List<CourseStatusDetails> listCourseStatusDetails = new ArrayList<CourseStatusDetails>();
		CourseStatusDetails courseStatusDetails;
		long cntCompleted, cntIncomplete, cntNotRegistered;
		cntCompleted = listCourseDetails.stream()
				.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course_param))
				.filter(o -> Objects.nonNull(o.getStatus()) && o.getStatus().equals("Successful"))
				.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager_param)).count();
		cntIncomplete = listCourseDetails.stream()
				.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course_param))
				.filter(o -> Objects.nonNull(o.getStatus()) && o.getStatus().equals("Not Evaluated"))
				.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager_param)).count();
		cntNotRegistered = listCourseDetails.stream()
				.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course_param))
				.filter(o -> Objects.nonNull(o.getStatus())
						&& (!o.getStatus().equals("Successful") && !o.getStatus().equals("Not Evaluated")))
				.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager_param)).count();

		courseStatusDetails = new CourseStatusDetails();
		courseStatusDetails.setManager(manager_param);
		courseStatusDetails.setCourseName(course_param);
		courseStatusDetails.setCntCompleted(cntCompleted);
		courseStatusDetails.setCntIncomplete(cntIncomplete);
		courseStatusDetails.setCntNotRegistered(cntNotRegistered);

		listCourseStatusDetails.add(courseStatusDetails);

		return listCourseStatusDetails;
	}

	private List<CourseStatusDetails> getFilteredDataByManager(String manager_param,
			List<CourseDetails> listCourseDetails, List<Object> courseNames) {
		List<CourseStatusDetails> listCourseStatusDetails = new ArrayList<CourseStatusDetails>();
		CourseStatusDetails courseStatusDetails;
		long cntCompleted, cntIncomplete, cntNotRegistered;
		for (Object course : courseNames) {
			cntCompleted = listCourseDetails.stream()
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course.toString()))
					.filter(o -> Objects.nonNull(o.getStatus()) && o.getStatus().equals("Successful"))
					.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager_param)).count();
			cntIncomplete = listCourseDetails.stream()
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course.toString()))
					.filter(o -> Objects.nonNull(o.getStatus()) && o.getStatus().equals("Not Evaluated"))
					.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager_param)).count();
			cntNotRegistered = listCourseDetails.stream()
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course.toString()))
					.filter(o -> Objects.nonNull(o.getStatus())
							&& (!o.getStatus().equals("Successful") && !o.getStatus().equals("Not Evaluated")))
					.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager_param)).count();

			courseStatusDetails = new CourseStatusDetails();
			courseStatusDetails.setManager(manager_param);
			courseStatusDetails.setCourseName(course.toString());
			courseStatusDetails.setCntCompleted(cntCompleted);
			courseStatusDetails.setCntIncomplete(cntIncomplete);
			courseStatusDetails.setCntNotRegistered(cntNotRegistered);

			listCourseStatusDetails.add(courseStatusDetails);
		}

		return listCourseStatusDetails;
	}

	private List<CourseStatusDetails> getFilteredDataByCourse(String course_param,
			List<CourseDetails> listCourseDetails) throws Exception {
		List<CourseStatusDetails> listCourseStatusDetails = new ArrayList<CourseStatusDetails>();
		CourseStatusDetails courseStatusDetails;
		long cntCompleted, cntIncomplete, cntNotRegistered;
		List<Object> managers = getPullDownOptions().getListManagers();

		for (Object manager : managers) {
			cntCompleted = listCourseDetails.stream()
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course_param))
					.filter(o -> Objects.nonNull(o.getStatus()) && o.getStatus().equals("Successful"))
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getManager().equals(manager)).count();
			cntIncomplete = listCourseDetails.stream()
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course_param))
					.filter(o -> Objects.nonNull(o.getStatus()) && o.getStatus().equals("Not Evaluated"))
					.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager)).count();
			cntNotRegistered = listCourseDetails.stream()
					.filter(o -> Objects.nonNull(o.getCourse()) && o.getCourse().equals(course_param))
					.filter(o -> Objects.nonNull(o.getStatus())
							&& (!o.getStatus().equals("Successful") && !o.getStatus().equals("Not Evaluated")))
					.filter(o -> Objects.nonNull(o.getManager()) && o.getManager().equals(manager)).count();

			courseStatusDetails = new CourseStatusDetails();
			courseStatusDetails.setManager(manager.toString());
			courseStatusDetails.setCourseName(course_param);
			courseStatusDetails.setCntCompleted(cntCompleted);
			courseStatusDetails.setCntIncomplete(cntIncomplete);
			courseStatusDetails.setCntNotRegistered(cntNotRegistered);

			listCourseStatusDetails.add(courseStatusDetails);
		}

		return listCourseStatusDetails;
	}

	public PullDownOptions getPullDownOptions() throws Exception {
		PullDownOptions pullDownOptions = new PullDownOptions();
		List<List<Object>> csvData = readSabaCsvData();

		List<Object> listManagers = csvData.parallelStream().map(d -> d.get(10)).distinct()
				.collect(Collectors.toList());
		List<Object> courseNames = csvData.parallelStream().map(d -> d.get(20)).distinct().collect(Collectors.toList());

		pullDownOptions.setListCourses(courseNames);
		pullDownOptions.setListManagers(listManagers);

		return pullDownOptions;
	}

	public boolean containsManager(final List<SummaryReport> list, final String manager) {
		return list.stream().anyMatch(o -> manager.equals(o.getManager()));
	}

	public void addToSummaryReport(List<SummaryReport> list, long cntCompleted, long cntIncomplete, long cntNotRegistered,
			String manager, int managerIndex) {
		SummaryReport summaryReport = new SummaryReport();
		summaryReport.setCompleted(cntCompleted);
		summaryReport.setIncomplete(cntIncomplete);
		summaryReport.setNotRegistered(cntNotRegistered);
		summaryReport.setManager(manager);
		if (recordExist) {
			list.set(managerIndex, summaryReport);
			recordExist = false;
		} else {
			list.add(summaryReport);
		}
	}

	public ArrayNode summaryReportDataFormatter(OverallSummaryReport list) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode jsonArray = objectMapper.createArrayNode();
		for (SummaryReport record : list.getSummaryReportList()) {
			ObjectNode jsonNode = objectMapper.createObjectNode();
			jsonNode.put("manager", record.getManager());
			jsonNode.put("completed", record.getCompleted());
			jsonNode.put("incomplete", record.getIncomplete());
			jsonNode.put("notRegistered", record.getNotRegistered());
			jsonArray.add(jsonNode);
		}

		for (CourseStatus record : list.getListCourseStatus()) {
			ObjectNode jsonNode = objectMapper.createObjectNode();
			jsonNode.put("manager", record.getManager());
			jsonNode.put("coursename", record.getCourseName());
			jsonNode.put("status", record.getStatus());
			jsonNode.put("count", record.getCount());
			jsonArray.add(jsonNode);
		}

		return jsonArray;
	}

	public ArrayNode filteredtDataFormatter(List<CourseStatusDetails> list) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode jsonArray = objectMapper.createArrayNode();
		for (CourseStatusDetails record : list) {
			ObjectNode jsonNode = objectMapper.createObjectNode();
			jsonNode.put("manager", record.getManager());
			jsonNode.put("coursename", record.getCourseName());
			jsonNode.put("completed", record.getCntCompleted());
			jsonNode.put("incomplete", record.getCntIncomplete());
			jsonNode.put("notregistered", record.getCntNotRegistered());
			jsonArray.add(jsonNode);
		}

		return jsonArray;
	}

	public ArrayNode pullDownDataFormatter(PullDownOptions options) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode jsonArray = objectMapper.createArrayNode();

		for (Object record : options.getListCourses()) {
			ObjectNode jsonNode = objectMapper.createObjectNode();
			jsonNode.put("course", record.toString());
			jsonArray.add(jsonNode);
		}

		for (Object record : options.getListManagers()) {
			ObjectNode jsonNode = objectMapper.createObjectNode();
			jsonNode.put("manager", record.toString());
			jsonArray.add(jsonNode);
		}

		return jsonArray;
	}

	private static Class<?>[] getParameterTypes(List<Object> values) {
		Class<?>[] types = new Class[values.size()];
		for (int i = 0; i < values.size(); i++) {
			Object value = values.get(i);
			if (value instanceof String) {
				types[i] = String.class;
			} else {
				types[i] = String.class;
			}
		}
		return types;
	}

	public List<IncompleteTraining> readIncompleteTraining() throws Exception {
		String parentPath = "C:\\tms\\";
		List<String> fileLocations = new ArrayList<>();
		fileLocations.add("Course_List.xlsx");
		fileLocations.add("Employee_Details.xlsx");
		fileLocations.add("SABA_Courses_per_Employee.csv");
		fileLocations.add("LinkedIn_Courses_per_Employee.csv");

		List<List<Object>> employeeDetails = readDataInc(String.format("%s%s", parentPath, fileLocations.get(1)), 8, 1);
		/**
		 * uncomment to test for linkedin entries, commented because it causes lag on
		 * the screen List<List<Object>> employeeLinkedInINC =
		 * readDataFile(String.format("%s%s", parentPath, fileLocations.get(3)), 26, 1);
		 **/
		List<List<Object>> employeeINCSaba = readDataInc(String.format("%s%s", parentPath, fileLocations.get(2)), 30,
				17);

		List<IncompleteTraining> incEmployees = new ArrayList<>();
		for (List<Object> employee : employeeDetails) {
			for (List<Object> incObj : employeeINCSaba) {
				if (employee.get(0).toString().equals(incObj.get(0).toString())
						&& employee.get(7).toString().toLowerCase().equals("active")) {
					IncompleteTraining object = new IncompleteTraining();
					object.setEmployeeName(incObj.get(1).toString() + " " + incObj.get(2).toString());
					object.setEmployeeStatus(employee.get(7).toString());
					object.setManager(incObj.get(10).toString());
					object.setCourseTitle(incObj.get(20).toString());
					object.setTargetCompletion(convertDateFormat(incObj.get(18).toString()));

					incEmployees.add(object);
				}

			}
			/**
			 * uncomment to test for linkedin entries, commented because it causes lag on
			 * the screen List<IncompleteTraining> objEmployeeNotOnList = new ArrayList<>();
			 * for (int i = 0; i < employeeLinkedInINC.size(); i++) { List<Object>
			 * nrObjLnkdin = employeeLinkedInINC.get(i); if
			 * (employee.get(0).toString().equals(nrObjLnkdin.get(2).toString()) &&
			 * employee.get(7).toString().toLowerCase().equals("active")) { continue; } else
			 * if (i >= employeeLinkedInINC.size() - 1) { IncompleteTraining object = new
			 * IncompleteTraining(); object.setEmployeeName(nrObjLnkdin.get(0).toString());
			 * object.setEmployeeStatus(employee.get(7).toString());
			 * object.setManager(employee.get(3).toString());
			 * object.setCourseTitle(nrObjLnkdin.get(15).toString());
			 * 
			 * object.setTargetCompletion(convertDateFormat("7-May-23"));
			 * object.setActualCompletion(convertDateFormat("7-May-23"));
			 * 
			 * object.setStatus("N/A"); objEmployeeNotOnList.add(object); }
			 * 
			 * } for (IncompleteTraining nrNotFound : objEmployeeNotOnList) { if (nrNotFound
			 * != null) incEmployees.add(nrNotFound); }
			 **/

		}

		return incEmployees;
	}

	public static List<List<Object>> readDataInc(String fileLocation, int cols, int rowStart) throws Exception {
		if (fileLocation.endsWith(".xlsx")) {
			return readXlsxFiles(fileLocation, cols, rowStart);
		} else if (fileLocation.endsWith(".csv") && fileLocation.contains("SABA")) {
			return readCsvInc(fileLocation, cols, rowStart, true);
		} else if (fileLocation.endsWith(".csv") && fileLocation.contains("LinkedIn")) {
			return readCsvInc(fileLocation, cols, rowStart, false);
		} else {
			throw new IllegalArgumentException("Unsupported file type : " + fileLocation);
		}
	}

	public static List<List<Object>> readCsvInc(String fileLocation, int cols, int rowStart, boolean saba)
			throws IOException {
		List<List<Object>> objectValues = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(fileLocation))) {
			String line;
			int currentRow = 0;
			while ((line = br.readLine()) != null) {
				if (currentRow < rowStart) {
					currentRow++;
					continue;
				}
				String[] values = line.split(",");
				List<Object> rowValues = new ArrayList<>();
				boolean validEntry = false;
				for (int i = 0; i < cols; i++) {
					values[i] = values[i].replace("\"", "");
					if (i < values.length) {
						if (saba) {
							if (i == 23
									&& (values[16].toLowerCase().equals("in progress")
											|| values[16].toLowerCase().equals("acquired"))
									&& values[i].toLowerCase().equals("not evaluated")) {
								validEntry = true;
							}
						} else {
							validEntry = true;
						}
						rowValues.add(values[i]);
					} else {
						rowValues.add("Empty");
					}
				}
				if (validEntry) {
					objectValues.add(rowValues);
					currentRow++;
				}
			}
		}
		return objectValues;
	}

	public CheckFiles checkRequiredFiles() throws IOException {

		CheckFiles chkFiles = new CheckFiles();

		File tmsDir = new File("C:\\tms");
		chkFiles.setTmsDirectoryExist(tmsDir.exists());

		File employeeFile = new File("C:\\tms\\Employee_Details.xlsx");
		chkFiles.setEmployeeListFileExist(employeeFile.exists());

		File courseFile = new File("C:\\tms\\Course_List.xlsx");
		chkFiles.setCourseListFileExist(courseFile.exists());

		File linkedInFIle = new File("C:\\tms\\LinkedIn_Courses_per_Employee.csv");
		chkFiles.setLinkedInFileExist(linkedInFIle.exists());

		File sabaFile = new File("C:\\tms\\SABA_Courses_per_Employee.csv");
		chkFiles.setSabaFileExist(sabaFile.exists());

		List<String> errorList = new ArrayList<String>();

		if (!chkFiles.isTmsDirectoryExist()) {
			chkFiles.setMessage("Required Directory not found! Please create directory [C:\\tms]");
			chkFiles.setDisableMenu(true);
			return chkFiles;
		}

		if (!chkFiles.isEmployeeListFileExist()) {
			errorList.add("[C:\\tms\\Employee_Details.xlsx]");
		}

		if (!chkFiles.isCourseListFileExist()) {
			errorList.add("[C:\\tms\\Course_List.xlsx]");
		}

		if (!chkFiles.isLinkedInFileExist()) {
			errorList.add("[C:\\tms\\LinkedIn_Courses_per_Employee.csv]");
		}

		if (!chkFiles.isSabaFileExist()) {
			errorList.add("[C:\\tms\\SABA_Courses_per_Employee.csv]");
		}

		if (errorList.isEmpty()) {
			chkFiles.setMessage("All Required Files found. Please select report on menu.");
		} else {
			chkFiles.setMessage("Required File(s) Not Found!");
			chkFiles.setRequiredFiles(errorList);
			chkFiles.setDisableMenu(true);
		}

		return chkFiles;
	}

}

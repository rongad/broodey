/**
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.importing.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fujitsu.ph.tsup.course.category.dao.CourseCategoryManagementDao;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.dao.CourseManagementDao;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.course.model.Course.Builder;
import com.fujitsu.ph.tsup.exception.ImportDataException;
import com.fujitsu.ph.tsup.importing.dao.DataImportDao;
import com.fujitsu.ph.tsup.importing.dao.DataImportDaoImpl;
import com.fujitsu.ph.tsup.importing.model.SabaDTO;
import com.fujitsu.ph.tsup.importing.model.TraineeInfo;
import com.github.pjfanning.xlsx.StreamingReader;

// ==================================================================================================
// Project Name : Training Sign Up
// Class Name : ImportingDataServiceImpl.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/08/19 | WS) mi.aguinaldo | Initial Version
// 0.02 | 2021/09/07 | WS) mi.aguinaldo | Update
// 0.03 | 2021/09/28 | WS) j.lugtu      | Removed CSV methods
// 0.04 | 2021/09/28 | WS) j.lazo       | Removed new instance inside loops
// 0.05 | 2021/10/14 | WS) j.lazo       | Added processing of timeSpent
// 0.06 | 2021/10/14 | WS) j.lugtu      | Added methods for trainee info import
// 0.07 | 2021/10/14 | WS) j.lazo       | Added importData
// ==================================================================================================

@Service
public class ImportingDataServiceImpl implements ImportingDataService {
    
    private static Logger logger = LoggerFactory.getLogger(ImportingDataServiceImpl.class);
    
    public static final String NEW_DATA = "newData";
    public static final String EXISTING_DATA = "existingData";

    @Autowired
    private CourseManagementDao courseManagementDao;

    @Autowired
    private CourseCategoryManagementDao categoryManagementDao;
    
    @Autowired
    private DataImportDao dataImportDao;

    /**
     * Check if the file is in excel format
     *
     * @param file the file
     * @return true, if successful
     */
    @Override
    public boolean hasExcelFormat(MultipartFile file) {
        Objects.requireNonNull(file);

        final String excellFileFormat = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        return excellFileFormat.equals(file.getContentType());
    }

    /**
     * Convert the excel file to a SabaDTO list.
     *
     * @param file the file
     * @return SabaDTO list
     */
    @Override
    public List<SabaDTO> excellToSabaDTOs(MultipartFile file) {
        if (!hasExcelFormat(file)) {
            throw new ImportDataException("File is not a excel file");
        }

        List<SabaDTO> sabaDTOs = new ArrayList<>();

        try (InputStream is = file.getInputStream();
                Workbook workbook = StreamingReader.builder().rowCacheSize(10) // number of rows to keep in
                                                                               // memory
                        .bufferSize(1024) // buffer size (in bytes) to use when
                                          // reading
                                          // InputStream to file
                        .open(is); // InputStream or File for XLSX file
        ) {
            Iterator<Sheet> sheetIterator = workbook.iterator();
            SabaDTO sabaDTO = new SabaDTO();

            while (sheetIterator.hasNext()) {
                Sheet trainingSheet = sheetIterator.next();

                Iterator<Row> rows = trainingSheet.iterator();

                sabaDTO = new SabaDTO();
                while (rows.hasNext()) {
                    Row currentRow = rows.next();

                    // skip header or rows are empty
                    if (currentRow.getRowNum() == 3 || isRowEmpty(currentRow)) {
                        continue;
                    }

                    Iterator<Cell> cellsInRow = currentRow.iterator();

                    TraineeInfo traineeInfo = parseRawDataToTraineeInfo(sabaDTO, currentRow, cellsInRow);

                    sabaDTO.addTraineeInfo(traineeInfo);
                }
                sabaDTOs.add(sabaDTO);
            }
        } catch (IOException e) {
            throw new ImportDataException("Fail to parse excel file due to " + e.getMessage(), e.getCause());
        }

        return sabaDTOs;
    }

    /**
     * Extract the trainee info emails from imported file
     *
     * @param file the file
     * @return traineeInfoEmail list
     */
    @Override
    public List<String> extractTraineeInfoEmail(MultipartFile file) {
        if (!hasExcelFormat(file)) {
            throw new ImportDataException("File is not a excel file");
        }

        List<String> traineeInfoEmail = new ArrayList<>();

        try (InputStream is = file.getInputStream();
                Workbook workbook = StreamingReader.builder().rowCacheSize(10) // number of rows to keep in
                                                                               // memory
                        .bufferSize(1024) // buffer size (in bytes) to use when
                                          // reading
                                          // InputStream to file
                        .open(is); // InputStream or File for XLSX file
        ) {
            Iterator<Sheet> sheetIterator = workbook.iterator();
            SabaDTO sabaDTO = new SabaDTO();

            while (sheetIterator.hasNext()) {
                Sheet trainingSheet = sheetIterator.next();

                Iterator<Row> rows = trainingSheet.iterator();

                sabaDTO = new SabaDTO();
                while (rows.hasNext()) {
                    Row currentRow = rows.next();

                    // skip header or rows are empty
                    if (currentRow.getRowNum() == 4 || isRowEmpty(currentRow)) {
                        continue;
                    }

                    Iterator<Cell> cellsInRow = currentRow.iterator();

                    String traineeInfoEmails = parseRawDataToTraineeInfoEmail(sabaDTO, currentRow,
                            cellsInRow);

                    if (!traineeInfoEmail.contains(traineeInfoEmails)
                            && StringUtils.isNotBlank(traineeInfoEmails)) {
                        traineeInfoEmail.add(traineeInfoEmails);
                    }
                }
            }
        } catch (IOException e) {
            throw new ImportDataException("Fail to parse excel file due to " + e.getMessage(), e.getCause());
        }

        return traineeInfoEmail;
    }

    /**
     * Segregate existing and non existing courses
     * 
     * @param dtos list of SabaDTO
     * @return results
     */
    @Override
    public Map<String, List<SabaDTO>> segregateExistingAndNewOfCourses(List<SabaDTO> dtos) {
        Objects.requireNonNull(dtos);

        Map<String, List<SabaDTO>> results = new HashedMap<>();

        Set<String> existingCourseNames = courseManagementDao.loadAllCourseName();

        List<SabaDTO> existingData = dtos.stream()
                .filter(dto -> existingCourseNames.contains(dto.getCourseTitle()))
                .collect(Collectors.toList());

        List<SabaDTO> newData = dtos.stream()
                .filter(dto -> !existingCourseNames.contains(dto.getCourseTitle()))
                .sorted(Comparator.comparing(SabaDTO::getCourseTitle)).collect(Collectors.toList());

        results.put(EXISTING_DATA, existingData);
        results.put(NEW_DATA, newData);
        return results;
    }

    /**
     * Identify the number of new users from imported file
     * 
     * @param traineeInfoEmail list of trainee info emails
     * @return results.size number of new users
     */
    @Override
    public int getNumberOfNewUsers(List<String> traineeInfoEmail) {
        Objects.requireNonNull(traineeInfoEmail);

        if (traineeInfoEmail.isEmpty()) {
            return 0;
        }

        List<String> results = new ArrayList<String>();

        Set<String> existingUsers = dataImportDao.loadAllUserEmail();

        try {
            List<String> nonExistingUserEmail = traineeInfoEmail.stream()
                    .filter(email -> !existingUsers.contains(email)).collect(Collectors.toList());
            results.addAll(nonExistingUserEmail);
            return results.size();
        } catch (DataAccessException e) {
            throw new ImportDataException("Fail to Update course", e.getCause());
        }
    }

    /**
     * Update courses that do not have course codes
     * 
     * @param dataForUpdate list of SabaDTO
     * @return sum of total updates done
     */
    @Override
    public int updateCoursesWithoutCourseCode(List<SabaDTO> dataForUpdate) {
        Objects.requireNonNull(dataForUpdate);
        if (dataForUpdate.isEmpty()) {
            return 0;
        }

        List<String> courseNames = dataForUpdate.stream().map(SabaDTO::getCourseTitle)
                .collect(Collectors.toList());

        List<Course> coursesToUpdate = courseManagementDao.findCourseByCourseNames(courseNames).stream()
                .filter(course -> StringUtils.isBlank(course.getCourseCode())).collect(Collectors.toList());
        if (coursesToUpdate.isEmpty()) {
            return 0;
        }

        for (SabaDTO sabaDTO : dataForUpdate) {
            for (Course course : coursesToUpdate) {
                if (Objects.equals(sabaDTO.getCourseTitle(), course.getName())) {
                    course.setCourseCode(sabaDTO.getCourseId());
                }
            }
        }

        try {
            int[] totalUpdated = courseManagementDao.batchCourseCodeUpdate(coursesToUpdate);
            return Arrays.stream(totalUpdated).sum();
        } catch (DataAccessException e) {
            throw new ImportDataException("Fail to Update course", e.getCause());
        }
    }

    /**
     * Create new courses
     * 
     * @param newData list of SabaDTO
     * @return sum of total creation done
     */
    @Override
    public int createCourses(List<SabaDTO> newData) {
        Objects.requireNonNull(newData);
        if (newData.isEmpty()) {
            return 0;
        }

        List<Course> newCourses = newData.stream().map(this::sabaDTOToCourse).collect(Collectors.toList());

        try {
            int[] totalCreated = courseManagementDao.batchCreateCourse(newCourses);
            return Arrays.stream(totalCreated).sum();
        } catch (DataAccessException e) {
            throw new ImportDataException("Fail to Create course", e.getCause());
        }

    }

    /**
     * Create new course categories
     * 
     * @param newData list of SabaDTO
     * @return sum of total creation done
     */
    @Override
    public int createCourseCategories(List<SabaDTO> sabaDTOs) {
        Objects.requireNonNull(sabaDTOs);

        Set<SabaDTO> noDuplicateCourseCategoryNames = sabaDTOs.stream().collect(Collectors
                .toCollection(() -> new TreeSet<>(Comparator.comparing(SabaDTO::getCourseCategoryName))));

        List<CourseCategory> newCategories = noDuplicateCourseCategoryNames.stream()
                .filter(saba -> Objects.isNull(saba.getCourseCategoryId())).map(this::sabaDTOToCourseCategory)
                .collect(Collectors.toList());
        if (newCategories.isEmpty()) {
            return 0;
        }

        try {
            int[] totalCreated = categoryManagementDao.batchCreateCourseCategory(newCategories);
            return Arrays.stream(totalCreated).sum();
        } catch (DataAccessException e) {
            throw new ImportDataException("Fail to Create course categories", e.getCause());
        }
    }

    /*
     * Parses the raw data to trainee info.
     * @param sabaDTO the saba DTO
     * @param currentRow the current row
     * @param cellsInRow the cells in row
     * @return the trainee info
     */
    private TraineeInfo parseRawDataToTraineeInfo(SabaDTO sabaDTO, Row currentRow,
            Iterator<Cell> cellsInRow) {
        TraineeInfo traineeInfo = new TraineeInfo();
        while (cellsInRow.hasNext()) {
            Cell currentCell = cellsInRow.next();

            String columnAddress = CellReference.convertNumToColString(currentCell.getColumnIndex());
            String extactColumnValue = columnAddress + currentRow.getRowNum();
            if (extactColumnValue.equals("B0") || extactColumnValue.equals("B1")) {
                continue;
            }

            if (extactColumnValue.equals("C0")) {
                sabaDTO.setCourseTitle(currentCell.getStringCellValue());
            } else if (extactColumnValue.equals("C1")) {
                sabaDTO.setCourseId(currentCell.getStringCellValue());
            } else {
                switch (columnAddress) {
                    case "B":
                        traineeInfo.setLastName(currentCell.getStringCellValue());
                        break;
                    case "C":
                        traineeInfo.setFirstName(currentCell.getStringCellValue());
                        break;
                    case "D":
                        traineeInfo.setEmail(currentCell.getStringCellValue());
                        break;
                    case "E":
                        traineeInfo.setCompletionDate(currentCell.getStringCellValue());
                        break;
                    case "F":
                        traineeInfo.setTimeSpent(currentCell.getStringCellValue());
                        break;
                    default:
                        break;
                }
            }

        }
        return traineeInfo;
    }
    
    /*
     * Parses the raw data to trainee info email.
     * @param sabaDTO the saba DTO
     * @param currentRow the current row
     * @param cellsInRow the cells in row
     * @return the trainee info email
     */
    private String parseRawDataToTraineeInfoEmail(SabaDTO sabaDTO, Row currentRow,
            Iterator<Cell> cellsInRow) {
        String traineeInfoEmail = StringUtils.EMPTY;
        while (cellsInRow.hasNext()) {
            Cell currentCell = cellsInRow.next();

            String columnAddress = CellReference.convertNumToColString(currentCell.getColumnIndex());

            if (StringUtils.equals(columnAddress, "D") && !isRowEmpty(currentRow)) {
                if (StringUtils.isNotBlank(currentCell.getStringCellValue()))
                    traineeInfoEmail = currentCell.getStringCellValue();
            }

        }
        return traineeInfoEmail;
    }

    /*
     * Saba DTO to course.
     * @param sabaDTO the saba DTO
     * @return course
     */
    private Course sabaDTOToCourse(SabaDTO sabaDTO) {

        // Removed special character from start and end of course name
        String courseName = sabaDTO.getCourseTitle().replaceAll("[^\na-zA-Z0-9-( )]", "");
        // Other details are set via default value
        Builder courseBuilder = Course.builder().withName(courseName).withCourseCode(sabaDTO.getCourseId())
                .withDetail("A SABA imported course.").withDepartmentId(1L).withIsMandatory("No")
                .withMandatoryType("-").withDeadline("-");

        if (Objects.isNull(sabaDTO.getCourseCategoryId())) {
            List<CourseCategory> courseCategories = categoryManagementDao
                    .findCourseCategoryByName(sabaDTO.getCourseCategoryName()).stream()
                    .collect(Collectors.toList());

            courseBuilder.withCourseCategoryId(courseCategories.get(0).getId());
        } else {
            courseBuilder.withCourseCategoryId(sabaDTO.getCourseCategoryId());
        }

        return courseBuilder.build();
    }

    /*
     * Saba DTO to course category.
     * @param sabaDTO the saba DTO
     * @return the course category
     */
    private CourseCategory sabaDTOToCourseCategory(SabaDTO sabaDTO) {
        return CourseCategory.builder()
                .addCategory(sabaDTO.getCourseCategoryName())
                .addDetail(sabaDTO.getCourseCategoryName())
                .build();
    }

    /*
     * Checks if is row empty.
     * @param row the row
     * @return true, if is row empty
     */
    private static boolean isRowEmpty(Row row) {
        boolean isEmpty = true;
        DataFormatter dataFormatter = new DataFormatter();
        if (row != null) {
            for (Cell cell : row) {
                if (dataFormatter.formatCellValue(cell).trim().length() > 0) {
                    isEmpty = false;
                    break;
                }
            }
        }
        return isEmpty;
    }

    /**
     * Create new course attendance, participant, schedule and schedule details
     * 
     * @param sabaDTOs list of SabaDTO
     * @return sum of total creation done
     */
    @Override
    public void importData(List<SabaDTO> sabaDTOs) {
        Objects.requireNonNull(sabaDTOs);

        try {
            for(SabaDTO dto : sabaDTOs) {
                dataImportDao.saveSabaImport(dto);
            }

        } catch (DataAccessException e) {
            logger.debug("EXCEPTION message: {} ", e.getMessage());
            throw new ImportDataException("Fail to Import SABA data.", e.getCause());
        }
    }
}

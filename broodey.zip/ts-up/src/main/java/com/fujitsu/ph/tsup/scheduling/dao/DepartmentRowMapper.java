package com.fujitsu.ph.tsup.scheduling.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fujitsu.ph.tsup.scheduling.model.DepartmentForm;

public class DepartmentRowMapper implements RowMapper<DepartmentForm> {

	/**
     * <pre>
     * Maps the Rows returned by ResultSet
     * <pre>
     * @param ResultSet rs
     * @param int rowNum
     * @throws SQLException
     */
	@Override
	public DepartmentForm mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		DepartmentForm departmentForm = new DepartmentForm();
		
		Long departmentId = rs.getLong("ID");
		String departmentName = rs.getString("DEPARTMENT_NAME");
		departmentForm.setId(departmentId);
		departmentForm.setName(departmentName);
		
		
		return departmentForm;
	}

}

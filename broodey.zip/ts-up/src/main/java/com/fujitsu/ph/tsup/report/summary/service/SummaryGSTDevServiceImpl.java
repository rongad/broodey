/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.service;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fujitsu.ph.tsup.report.summary.dao.SummaryGSTDevDao;
import com.fujitsu.ph.tsup.report.summary.model.SummaryGSTDevForm;


//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for Dev
//Class Name   : SummaryGSTDevServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | ----/--/-- | WS) n.dejesus         | Initial Version
//0.02    | ----/--/-- | WS) a.batongbacal     | Updated
//0.03    | 2021/06/14 | WS) m.padaca          | Updated
//0.04    | 2021/10/15 | WS) r.buot            | Updated
//0.05    | 2021/10/20 | WS) dw.cardenas       | Updated
//==================================================================================================

/**
 * <pre>
 * The implementation of G3CC standardization training for dev service
 * </pre>
 * 
 * @version 0.03
 * @author n.dejesus
 * @author a.batongbacal
 * @author m.padaca
 */
@Service
public class SummaryGSTDevServiceImpl implements SummaryGSTDevService {

    // Report Summary G3CC Standardization Dev Dao
    @Autowired
    private SummaryGSTDevDao reportSummaryGSTDevDao;

    /**
     * <pre>
     * Find total number of JDU members
     * </pre>
     * 
     * @return SummaryGSTDevForm
     */
    @Override
    public SummaryGSTDevForm getSummary(ZonedDateTime reportDate) {
        Set<Long> employeeList = reportSummaryGSTDevDao.findAllJDUDev();
        Set<Long> courseList = reportSummaryGSTDevDao.findAllCoursesByCategoryId();
        HashMap<Long, Integer> totalCoursePerEmployee = new HashMap<>();

        // for JDU Dev who Finished
        for (Long employee_id : employeeList) {
            int totalCourseCompleted = reportSummaryGSTDevDao.findTotalCoursePerEmployee(courseList,
                    employee_id, reportDate);
            totalCoursePerEmployee.put(employee_id, totalCourseCompleted);
        }

        Long totalDevFin = totalCoursePerEmployee.entrySet().stream()
                .filter(v -> v.getValue().equals(courseList.size())).count();

        // for JDU Dev who Finished Last Week
        totalCoursePerEmployee = new HashMap<>();
        for (Long employee_id : employeeList) {
            int totalCourseCompleted = reportSummaryGSTDevDao.findTotalCoursePerEmployeeLastWeek(reportDate,
                    courseList, employee_id);
            totalCoursePerEmployee.put(employee_id, totalCourseCompleted);
        }

        Long totalDevFinLastWk = totalCoursePerEmployee.entrySet().stream()
                .filter(v -> v.getValue().equals(courseList.size())).count();

        Long employeeCount = Long.valueOf(employeeList.size());
        BigDecimal percentageFinToday = ReportUtils.calculateCompletionPercentage(totalDevFin, employeeCount);
        BigDecimal percentageFinLastWk = ReportUtils.calculateCompletionPercentage(totalDevFinLastWk,
                employeeCount);

        SummaryGSTDevForm summaryGSTDev = new SummaryGSTDevForm();
        summaryGSTDev.setReportDateTime(reportDate);
        summaryGSTDev.setTotalNoJDUDevValue(employeeCount);
        summaryGSTDev.setTotalNoJDUDevLastWeekValue(reportSummaryGSTDevDao.findAllJDUDevLastWeek());
        summaryGSTDev.setTotalNoExistingMemValue(reportSummaryGSTDevDao.findAllJDUExisitingMembers());
        summaryGSTDev.setTotalNoNewMemValue(reportSummaryGSTDevDao.findAllJDUNewMembers());
        summaryGSTDev.setTotalNoJDUDevFinValue(totalDevFin);
        summaryGSTDev.setTotalNoJDUDevLastWkFinValue(totalDevFinLastWk);
        summaryGSTDev.setPercentageFinTodayValue(percentageFinToday);
        summaryGSTDev.setPercentageFinLastWkValue(percentageFinLastWk);
        return summaryGSTDev;
    }
}

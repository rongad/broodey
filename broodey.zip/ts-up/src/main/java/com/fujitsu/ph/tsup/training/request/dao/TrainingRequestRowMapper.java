package com.fujitsu.ph.tsup.training.request.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import org.springframework.jdbc.core.RowMapper;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;

//=================================================================================================
//Project Name :Training Sign Up
//System Name  :Training Request
//Class Name   :TrainingRequestRowMapper.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+--------------------------------------------------
//0.01    | 07/13/2021 | WS) L.Celoso          | New Creation
//=================================================================================================

/**
* <pre>
* Row Mapper Class for the training request
* 
* <pre>
* 
* @version 0.01
* @author L.Celoso
*/
public class TrainingRequestRowMapper implements RowMapper<TrainingRequest> {
    
    @Override
    public TrainingRequest mapRow(ResultSet rs, int rowNum) throws SQLException {
        
    	Long id = rs.getLong("TR_ID");
        Long employeeId = rs.getLong("EMPLOYEE_ID");
        String courseName = rs.getString("COURSE_NAME");
        String courseDetails = rs.getString("COURSE_DETAILS");
        String requestStatus = rs.getString("REQUEST_STATUS");
        int minParticipants = rs.getInt("MIN_PARTICIPANTS");
        int maxParticipants = rs.getInt("MAX_PARTICIPANTS");
        float duration = rs.getFloat("DURATION");
        String requesterName = rs.getString("REQUESTER_NAME");
        String approverName = rs.getString("APPROVER_NAME");
        String approverRemarks = rs.getString("APPROVER_REMARKS");
        
        ZonedDateTime startDateTime = ZonedDateTime.ofInstant(
                rs.getTimestamp("START_DATETIME").toInstant(), ZoneId.systemDefault());
        ZonedDateTime endDateTime = ZonedDateTime.ofInstant(
                rs.getTimestamp("END_DATETIME").toInstant(), ZoneId.systemDefault());   
        
        TrainingRequest trainingRequest = new TrainingRequest.Builder(id, employeeId, courseName, courseDetails, requestStatus,
        										startDateTime, endDateTime, duration,
        										minParticipants, maxParticipants, requesterName,approverName,approverRemarks).build();
        
        return trainingRequest;
    }

}
package com.fujitsu.ph.tsup.common.domain;

import com.fujitsu.ph.tsup.enrollment.domain.CourseScheduleDetail;
import com.fujitsu.ph.tsup.enrollment.domain.CourseParticipant.Builder;

public class MemberRole {
      
      /**
       * Role member Id
       */
      private Long id;
      
      /**
       * Role member Type
       */
      private String name;
      
      /**
       * Role member Type
       */
      private String roleDesc;
      
      public void setId(Long id) {
          this.id = id;
      }
      
      public void setName(String name) {
          this.name = name;
      }
      
      public void setRoleDesc(String roleDesc) {
          this.roleDesc = roleDesc;
      }
      
      public Long getId() {
          return id;
      }
      
      public String getName() {
          return name;
      }
        
      public String getRoleDesc() {
          return roleDesc;
      }
      
      @Override
      public String toString() {
          return "VenueForm [id = " + id + ", name = " + name + ", roleDesc = " + roleDesc + "]";
      }
      
      protected MemberRole() {

      }
      
      private MemberRole(Builder build) {
          this.id = build.id;
          this.name = build.name;
          this.roleDesc = build.roleDesc;
      }

      /**
       * <pre>
       * The builder class of the course participant The builder is a public static
       * member class of Member Role
       * 
       * <pre>
       * 
       * @author L.Celoso
       *
       */

      public static class Builder {

          /** id **/
          private Long id;
          
          /** Member Role Type **/
          private String name;

          /** Member Role Desc **/
          private String roleDesc;
          
          
          public Builder(Long id, String name, String roleDesc) {
              this.id = id;
              this.name = name;
              this.roleDesc = roleDesc;
          }
      
          /**
           * Creates a new instance of the course schedule detail
           * 
           * @return new CourseScheduleDetail(this)
           */
          public MemberRole build() {
              return new MemberRole(this);
          }
      
      }
}

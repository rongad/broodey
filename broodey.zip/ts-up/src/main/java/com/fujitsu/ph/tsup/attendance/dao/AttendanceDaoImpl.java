package com.fujitsu.ph.tsup.attendance.dao;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.attendance.domain.CourseParticipant;
import com.fujitsu.ph.tsup.attendance.domain.CourseSchedule;
import com.fujitsu.ph.tsup.attendance.model.ChangeStatusParticipant;
import com.fujitsu.ph.tsup.attendance.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.enrollment.dao.EnrollmentDaoImpl;

// ==================================================================================================
// $Id:PR03$
// Project Name : Training Sign up
// System Name : Attendance process
// Class Name : AttendanceDaoImpl.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+---------------------------------------------------------+-----------------
// 0.01 | 06/26/2020 | WS) K.Abad, WS) H.Francisco, WS) J.Iwarat, WS) R.Ramos | New Creation
// 0.02 | 06/30/2020 | WS) K.Abad | Update
// 0.03 | 06/30/2020 | WS) J.Iwarat | Update
// 0.04 | 07/08/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.05 | 07/08/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.06 | 07/08/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.07 | 07/30/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.08 | 08/26/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.09 | 09/02/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.10 | 09/03/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.11 | 09/08/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.12 | 09/18/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.13 | 09/30/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.14 | 08/13/2021 | WS) R.Gaquit                          | Update
// 0.15 | 08/17/2021 | WS) D.Dinglasan                       | Update
// 0.15 | 09/02/2021 | WS) CJ.Zamora                         | Update
// 0.16 | 10/08/2021 | WS) MI.Aguinaldo                      | Update
//0.16  | 10/13/2021 | WS) Mj.liwag                          | Updated
// ==================================================================================================
/**
 * <pre>
 * The data access class for attendance related database access
 * </pre>
 * 
 * @version 0.14
 * @author k.abad
 * @author h.francisco
 * @author j.iwarat
 * @author r.ramos
 * @author r.gaquit
 */
@Repository
public class AttendanceDaoImpl implements AttendanceDao {

    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private EnrollmentDaoImpl enrollmentDaoImpl;

    /**
     * <pre>
     * Finds the scheduled courses starting from today onwards
     * 
     * <pre>
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param instructorId
     * @return CourseSchedule
     * @author j.iwarat
     */
    @Override
    public Set<CourseSchedule> findAllScheduledCourses(ZonedDateTime fromDateTime, ZonedDateTime toDateTime,
            Long instructorId) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        String sql = "SELECT " + "CSCHED.ID AS ID, " + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
                + "CSCHED.COURSE_ID AS COURSE_ID," + "C.NAME AS COURSE_NAME,"
                + "CSCHED.INSTRUCTOR_ID AS INSTRUCTOR_ID," + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME,"
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME," + "CSCHED.VENUE_ID AS VENUE_ID,"
                + "V.NAME AS VENUE_NAME," + "CSCHED.MIN_REQUIRED AS MIN_REQUIRED,"
                + "CSCHED.MAX_ALLOWED AS MAX_ALLOWED," + "(" + "SELECT COUNT(PARTICIPANT_ID) "
                + "    FROM COURSE_PARTICIPANT" + "    WHERE COURSE_SCHEDULE_ID = CSCHED.ID"
                + ") AS PARTICIPANT_ID," + "CSCHED.STATUS AS STATUS,"
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + "CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME "
                + "FROM COURSE_SCHEDULE AS CSCHED " + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CSCHED.VENUE_ID = V.ID ";

        if (!user.getRoles().contains("Instructor") || user.getRoles().contains("PMO")) {
            sql += "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                    + "CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                    + "AND CSCHED.STATUS = 'A' " + "ORDER BY CSCHED.ID, CSCHEDDET.SCHEDULED_START_DATETIME ";

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                            fromDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                            toDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("instructorId", instructorId);

            List<CourseSchedule> listCourseSchedule = template.query(sql, courseScheduleParameters,
                    new CourseScheduleRowMapper());
            return new LinkedHashSet<CourseSchedule>(listCourseSchedule);
        } else {

            sql += "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                    + "CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                    + "AND CSCHED.INSTRUCTOR_ID = :instructorId " + "AND CSCHED.STATUS = 'A' "
                    + "ORDER BY CSCHED.ID, CSCHEDDET.SCHEDULED_START_DATETIME ";

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                            fromDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                            toDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("instructorId", instructorId);

            List<CourseSchedule> listCourseSchedule = template.query(sql, courseScheduleParameters,
                    new CourseScheduleRowMapper());
            return new LinkedHashSet<CourseSchedule>(listCourseSchedule);
        }
    }

    /**
     * <pre>
     * Finds the course schedule by id
     * 
     * <pre>
     * 
     * @param id
     * @return CourseParticipant
     * @author k.abad
     */
    @Override
    public Set<CourseParticipant> findCourseScheduleById(Long id) {
        String sql = "SELECT " 
                + "CSCHED.ID AS ID, " 
                + "CSCHEDDET.COURSE_SCHEDULE_ID AS COURSE_SCHEDULE_ID, "
                + "D.ID AS DEPARTMENT_ID, " 
                + "C.NAME AS COURSE_NAME, " 
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME," 
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "V.NAME AS VENUE_NAME, " 
                + "C.MANDATORY AS MANDATORY, " 
                + "C.MANDATORY_TYPE AS MANDATORY_TYPE, " // Added 2021/13/08
                + "CC.CATEGORY AS COURSE_CATEGORY,"// Added 2021/01/09
                + "CPART.PARTICIPANT_ID AS PARTICIPANT_ID, " 
                + "("
                + "SELECT LAST_NAME " 
                + "    FROM EMPLOYEE " 
                + "    WHERE ID = CPART.PARTICIPANT_ID"
                + ") AS PARTICIPANT_LAST_NAME, " 
                + "(" 
                + "    SELECT FIRST_NAME " 
                + "    FROM EMPLOYEE "
                + "    WHERE ID = CPART.PARTICIPANT_ID" 
                + ") AS PARTICIPANT_FIRST_NAME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + "CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSCHEDDET.DURATION AS DURATION, " 
                + "CPART.REGISTRATION_DATE AS REGISTRATION_DATE, " 
                + "("
                + "    SELECT EMAIL_ADDRESS " 
                + "    FROM EMPLOYEE " 
                + "    WHERE ID = CPART.PARTICIPANT_ID"
                + ") AS EMAIL, " 
                + "(" + "    SELECT NUMBER " 
                + "    FROM EMPLOYEE "
                + "    WHERE ID = CPART.PARTICIPANT_ID" 
                + ") AS EMPLOYEE_NUMBER, " + "("
                + "    SELECT DEPT.DEPARTMENT_NAME " 
                + "    FROM DEPARTMENT AS DEPT "
                + "    INNER JOIN EMPLOYEE AS EMP " 
                + "    ON EMP.DEPARTMENT_ID = DEPT.ID "
                + "    WHERE EMP.ID = CPART.PARTICIPANT_ID" 
                + ") AS DEPARTMENT_NAME "
                + "FROM COURSE_SCHEDULE AS CSCHED " 
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " 
                + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " 
                + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID " 
                + "INNER JOIN VENUE AS V " 
                + "ON CSCHED.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_PARTICIPANT AS CPART " 
                + "ON CSCHED.ID = CPART.COURSE_SCHEDULE_ID "
                + "INNER JOIN DEPARTMENT AS D  " 
                + "ON E.DEPARTMENT_ID = D.ID "
                + "INNER JOIN COURSE_CATEGORY AS CC " // Added 2021/01/09
                + "ON C.COURSE_CATEGORY_ID = CC.ID "  // Added 2021/01/09
                + "WHERE CSCHED.ID = :id AND CSCHED.STATUS = 'A'";

        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("id", id);

        List<CourseParticipant> courseList = template.query(sql, namedParameters,
                new CourseParticipantRowMapper());

        Set<CourseParticipant> course = new HashSet<CourseParticipant>(courseList);
        return course;
    }

    /**
     * <pre>
     * Finds the course participants by course schedule detail id
     * </pre>
     * 
     * @param id
     * @return courseAttendanceSet
     * @author r.ramos
     * @author k.abad
     */
    @Override
    public Set<CourseAttendance> findCourseScheduleDetailParticipantsById(Long id) {
        String sql = "SELECT " + "CATTEN.ID AS ID, " + "CSCHEDDET.COURSE_SCHEDULE_ID AS COURSE_SCHEDULE_ID, "
                + "D.ID AS DEPARTMENT_ID, " + "C.NAME AS COURSE_NAME, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "V.NAME AS VENUE_NAME, " + "CATTEN.PARTICIPANT_ID AS PARTICIPANT_ID, " + "("
                + "SELECT LAST_NAME " + "    FROM EMPLOYEE " + "    WHERE ID = CATTEN.PARTICIPANT_ID"
                + ") AS PARTICIPANT_LAST_NAME, " + "(" + "    SELECT FIRST_NAME " + "    FROM EMPLOYEE "
                + "    WHERE ID = CATTEN.PARTICIPANT_ID" + ") AS PARTICIPANT_FIRST_NAME, " + "("
                + "SELECT NUMBER " + "    FROM EMPLOYEE " + "    WHERE ID = CATTEN.PARTICIPANT_ID"
                + ") AS EMPLOYEE_NUMBER, " + "(" + "     SELECT DEPT.DEPARTMENT_NAME "
                + "     FROM DEPARTMENT AS DEPT " + "     INNER JOIN EMPLOYEE AS EMP "
                + "     ON EMP.DEPARTMENT_ID = DEPT.ID " + "     WHERE EMP.ID = CATTEN.PARTICIPANT_ID"
                + ") AS DEPARTMENT_NAME, " + "(" + "    SELECT EMAIL_ADDRESS " + "    FROM EMPLOYEE "
                + "    WHERE ID = CATTEN.PARTICIPANT_ID " + ") AS EMAIL, " + "C.DETAIL AS DETAIL, "
                + "CATTEN.STATUS AS STATUS, " + "CSCHEDDET.DURATION AS DURATION, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + "CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CATTEN.LOG_IN_DATETIME AS LOG_IN_DATETIME, "
                + "CATTEN.LOG_OUT_DATETIME AS LOG_OUT_DATETIME " + "FROM COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CSCHED.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_PARTICIPANT AS CPART " + "ON CSCHED.ID = CPART.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE_ATTENDANCE AS CATTEN "
                + "ON CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID " + "INNER JOIN DEPARTMENT AS D  "
                + "ON E.DEPARTMENT_ID = D.ID " + "WHERE CSCHEDDET.ID = :id AND CSCHED.STATUS = 'A'";

        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("id", id);

        List<CourseAttendance> listCourseAttendance = template.query(sql, namedParameters,
                new CourseAttendanceRowMapper());

        Set<CourseAttendance> courseAttendanceSet = new HashSet<CourseAttendance>(listCourseAttendance);
        return courseAttendanceSet;
    }

    /**
     * <pre>
     * Finds the course attendance by id
     * 
     * <pre>
     * 
     * @param id
     * @return CourseAttendance
     * @author j.iwarat
     */
    @Override
    public Set<CourseAttendance> findCourseAttendanceByCourseScheduleDetailId(Long id) {
        String sql = "SELECT " + "CATTEN.ID AS ID, " + "D.ID AS DEPARTMENT_ID, " + "C.NAME AS COURSE_NAME, "
                + "CSCHEDDET.COURSE_SCHEDULE_ID AS COURSE_SCHEDULE_ID, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "V.NAME AS VENUE_NAME, " + "CATTEN.PARTICIPANT_ID AS PARTICIPANT_ID, " + "("
                + "    SELECT LAST_NAME " + "    FROM EMPLOYEE  " + "    WHERE ID = CATTEN.PARTICIPANT_ID"
                + ") AS PARTICIPANT_LAST_NAME, " + "(" + "     SELECT FIRST_NAME " + "    FROM EMPLOYEE "
                + "    WHERE ID = CATTEN.PARTICIPANT_ID" + ") AS PARTICIPANT_FIRST_NAME, " + "("
                + "    SELECT NUMBER " + "    FROM EMPLOYEE " + "    WHERE ID = CATTEN.PARTICIPANT_ID"
                + ") AS EMPLOYEE_NUMBER, " + "(" + "     SELECT DEPT.DEPARTMENT_NAME "
                + "     FROM DEPARTMENT AS DEPT " + "     INNER JOIN EMPLOYEE AS EMP "
                + "     ON EMP.DEPARTMENT_ID = DEPT.ID " + "     WHERE EMP.ID = CATTEN.PARTICIPANT_ID"
                + ") AS DEPARTMENT_NAME, " + "(" + "    SELECT EMAIL_ADDRESS " + "    FROM EMPLOYEE "
                + "    WHERE ID = CATTEN.PARTICIPANT_ID " + ") AS EMAIL, " + "C.DETAIL AS DETAIL, "
                + "CSCHEDDET.DURATION AS DURATION, " + "CATTEN.STATUS AS STATUS, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + "CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CATTEN.LOG_IN_DATETIME AS LOG_IN_DATETIME, "
                + "CATTEN.LOG_OUT_DATETIME AS LOG_OUT_DATETIME " + "FROM COURSE_SCHEDULE AS CSCHED  "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID  " + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CSCHED.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_ATTENDANCE AS CATTEN "
                + "ON CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID " + "INNER JOIN DEPARTMENT AS D  "
                + "ON E.DEPARTMENT_ID = D.ID " + "WHERE CSCHEDDET.ID = :id " + "AND CSCHED.STATUS = 'A'";

        try {
            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource().addValue("id", id);

            List<CourseAttendance> listCourseAttendance = template.query(sql, courseScheduleParameters,
                    new CourseAttendanceRowMapper());

            Set<CourseAttendance> setCourseAttendance = new HashSet<CourseAttendance>(listCourseAttendance);
            return setCourseAttendance;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }

    }

    /**
     * <pre>
     * Creates the course attendance
     * 
     * <pre>
     * 
     * @param courseAttendance
     * @return CourseAttendance
     * @author h.francisco
     * @author r.ramos
     */
    @Override
    public void saveAttendance(CourseAttendance courseAttendance) {
        String sql = "UPDATE COURSE_ATTENDANCE " + "SET status= 'P', log_in_datetime= 'now()' "
                + "WHERE participant_id = :participantId AND "
                + "course_schedule_detail_id= :courseScheduleDetailId ";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("courseScheduleDetailId", courseAttendance.getCourseScheduleDetailId())
                .addValue("participantId", courseAttendance.getParticipantId())
                .addValue("loginDateTime", courseAttendance.getLoginDateTime()
                        .withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());

        template.update(sql, namedParameters);
    }

    @Override
    public void updateLogout(CourseAttendance courseAttendance) {
        String sql = "UPDATE COURSE_ATTENDANCE SET LOG_OUT_DATETIME = :logoutDateTime "
                + "WHERE participant_id = :participantId AND "
                + "COURSE_SCHEDULE_DETAIL_ID = :courseScheduleDetailId ";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("participantId", courseAttendance.getParticipantId())
                .addValue("courseScheduleDetailId", courseAttendance.getCourseScheduleDetailId())
                .addValue("logoutDateTime", courseAttendance.getLogoutDateTime()
                        .withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());
        template.update(sql, namedParameters);
    }

    /**
     * <pre>
     * Updates the course attendance
     * 
     * <pre>
     * 
     * @param courseAttendance
     * @return CourseAttendance
     * @author h.francisco
     * @author r.ramos
     */
    @Override
    public void updateAttendance(CourseAttendance courseAttendance) {
        String sql = "UPDATE COURSE_ATTENDANCE SET course_schedule_detail_id = :courseScheduleDetailId, "
                + "participant_id = :participantId, " + "status = :status, "
                + "log_in_datetime = :loginDateTime, " + "log_out_datetime = :logoutDateTime, "
                + "email = :email "
                + "WHERE participant_id = :participantId AND course_schedule_detail_id = :courseScheduleDetailId";

        List<ChangeStatusParticipant> participants = courseAttendance.getParticipants();

        for (ChangeStatusParticipant changeStatusParticipant : participants) {

            if (changeStatusParticipant.getStatus() == 'P') {
                SqlParameterSource namedParameters = new MapSqlParameterSource()
                        .addValue("id", courseAttendance.getId())

                        .addValue("courseScheduleDetailId", changeStatusParticipant.getCourseAttendanceId())
                        .addValue("participantId", changeStatusParticipant.getParticipantId())
                        .addValue("status", String.valueOf(changeStatusParticipant.getStatus()))
                        .addValue("loginDateTime",
                                changeStatusParticipant.getLoginDateTime()
                                        .withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                        .addValue("logoutDateTime",
                                changeStatusParticipant.getLogoutDateTime()
                                        .withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                        .addValue("email", changeStatusParticipant.getEmail());
                template.update(sql, namedParameters);
            } else {
                SqlParameterSource namedParameters = new MapSqlParameterSource()
                        .addValue("id", courseAttendance.getId())

                        .addValue("courseScheduleDetailId", changeStatusParticipant.getCourseAttendanceId())
                        .addValue("participantId", changeStatusParticipant.getParticipantId())
                        .addValue("status", String.valueOf(changeStatusParticipant.getStatus()))
                        .addValue("loginDateTime", null).addValue("logoutDateTime", null)
                        .addValue("email", changeStatusParticipant.getEmail());
                template.update(sql, namedParameters);
            }
        }
    }

    /**
     * <pre>
     * Finds the course participants by course schedule detail id
     * 
     * <pre>
     * 
     * @param id
     * @return CourseAttendance
     * @author h.francisco
     * @author k.abad
     */
    @Override
    public Set<CourseAttendance> findCourseScheduleDetailById(Long id) {

        String sql = "SELECT " + "CATTEN.ID AS ID, " + "CSCHEDDET.ID AS COURSE_SCHEDULE_ID, "
                + "D.ID AS DEPARTMENT_ID, " + "C.NAME AS COURSE_NAME, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "V.NAME AS VENUE_NAME, " + "CATTEN.PARTICIPANT_ID AS PARTICIPANT_ID, " + "("
                + "SELECT LAST_NAME " + "    FROM EMPLOYEE " + "    WHERE ID = CATTEN.PARTICIPANT_ID"
                + ") AS PARTICIPANT_LAST_NAME, " + "(" + "    SELECT FIRST_NAME " + "    FROM EMPLOYEE "
                + "    WHERE ID = CATTEN.PARTICIPANT_ID" + ") AS PARTICIPANT_FIRST_NAME, " + "("
                + "    SELECT EMAIL_ADDRESS " + "    FROM EMPLOYEE " + "    WHERE ID = CATTEN.PARTICIPANT_ID "
                + ") AS EMAIL, " + "(" + "    SELECT NUMBER " + "    FROM EMPLOYEE "
                + "    WHERE ID = CATTEN.PARTICIPANT_ID" + ") AS EMPLOYEE_NUMBER, " + "("
                + "    SELECT DEPT.DEPARTMENT_NAME " + "    FROM DEPARTMENT AS DEPT "
                + "    INNER JOIN EMPLOYEE AS EMP " + "    ON EMP.DEPARTMENT_ID = DEPT.ID "
                + "    WHERE EMP.ID = CATTEN.PARTICIPANT_ID " + ") AS DEPARTMENT_NAME, "
                + "C.DETAIL AS DETAIL, " + "CSCHEDDET.DURATION AS DURATION, " + "CATTEN.STATUS AS STATUS, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + "CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CATTEN.LOG_IN_DATETIME AS LOG_IN_DATETIME, "
                + "CATTEN.LOG_OUT_DATETIME AS LOG_OUT_DATETIME "

                + "FROM COURSE_SCHEDULE AS CSCHED " + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CSCHED.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CSCHED.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_ATTENDANCE AS CATTEN "
                + "ON CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID " + "INNER JOIN DEPARTMENT AS D  "
                + "ON E.DEPARTMENT_ID = D.ID " + "WHERE CSCHEDDET.ID = :id AND CSCHED.STATUS = 'A' AND "
                + "CATTEN.PARTICIPANT_ID = :PARTICIPANT_ID";

        try {
            FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            Long participantId = user.getId();
     
            SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("id", id)
                    .addValue("PARTICIPANT_ID", participantId);

            List<CourseAttendance> attendanceList = template.query(sql, namedParameters,
                    new CourseAttendanceRowMapper());

            Set<CourseAttendance> setCourse = new HashSet<CourseAttendance>(attendanceList);
            return setCourse;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * <pre>
     * Finds all the scheduled courses by participants
     * 
     * <pre>
     * 
     * @param id
     * @return CourseParticipant
     * @author r.ramos
     */
    @Override
    public Set<CourseParticipant> findAllScheduledCoursesByParticipant(CourseScheduleListForm courseScheduleListForm, Pageable pageable) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();       
        List<String> conditionList = new LinkedList<>();
        StringBuilder queryBuilder = new StringBuilder();
        boolean withTags = courseScheduleListForm.getMemberRole() != null && !courseScheduleListForm.getMemberRole().isEmpty();
        
        queryBuilder.append("SELECT DISTINCT " + "CPART.ID AS ID, " + "D.ID AS DEPARTMENT_ID, ");
        queryBuilder.append("CSCHEDDET.ID AS COURSE_SCHEDULE_ID, " + "CSCHED.ID AS COURSE_SCHEDULE_ID, ");
        queryBuilder.append("C.NAME AS COURSE_NAME, " + "C.MANDATORY AS MANDATORY, "); // Added 2021/13/08
        queryBuilder.append("C.MANDATORY_TYPE AS MANDATORY_TYPE, "); // Added 2021/13/08
        queryBuilder.append("CC.CATEGORY AS COURSE_CATEGORY, ");// Added 2021/01/09
        queryBuilder.append("E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, ");
        queryBuilder.append("V.NAME AS VENUE_NAME, " + "CPART.PARTICIPANT_ID AS PARTICIPANT_ID, " + "(" );
        queryBuilder.append("   SELECT LAST_NAME " + "   FROM EMPLOYEE " + "   WHERE ID = CPART.PARTICIPANT_ID");
        queryBuilder.append(") AS PARTICIPANT_LAST_NAME, " + "(" + "    SELECT FIRST_NAME " + "    FROM EMPLOYEE ");
        queryBuilder.append("    WHERE ID = CPART.PARTICIPANT_ID" + ") AS PARTICIPANT_FIRST_NAME, " + "(" );
        queryBuilder.append("    SELECT EMAIL_ADDRESS " + "    FROM EMPLOYEE " + "    WHERE ID = CPART.PARTICIPANT_ID ");
        queryBuilder.append(") AS EMAIL, " + "(" + "    SELECT NUMBER " + "    FROM EMPLOYEE ");
        queryBuilder.append("    WHERE ID = CPART.PARTICIPANT_ID" + ") AS EMPLOYEE_NUMBER, " + "(");
        queryBuilder.append("    SELECT DEPT.DEPARTMENT_NAME " + "    FROM DEPARTMENT AS DEPT ");
        queryBuilder.append("    INNER JOIN EMPLOYEE AS EMP " + "    ON EMP.DEPARTMENT_ID = DEPT.ID ");
        queryBuilder.append("    WHERE EMP.ID = CPART.PARTICIPANT_ID " + ") AS DEPARTMENT_NAME, ");
        queryBuilder.append("CSCHEDDET.DURATION AS DURATION, " + "CPART.REGISTRATION_DATE AS REGISTRATION_DATE, ");
        queryBuilder.append("COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
        queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, ");
        queryBuilder.append("COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, ");
        queryBuilder.append("CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME ");
        queryBuilder.append("FROM COURSE_SCHEDULE AS CSCHED " + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        queryBuilder.append("ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID ");
        queryBuilder.append("INNER JOIN tsup.COURSE_PARTICIPANT AS CPART " + "ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID ");
        queryBuilder.append("INNER JOIN tsup.COURSE AS C " + "ON C.ID = CSCHED.COURSE_ID " + "INNER JOIN EMPLOYEE AS E ");
        queryBuilder.append("ON E.ID = CSCHED.INSTRUCTOR_ID " + "INNER JOIN tsup.VENUE AS V ");
        queryBuilder.append("ON V.ID = CSCHED.VENUE_ID \r\n" + "INNER JOIN DEPARTMENT AS D  ");
        queryBuilder.append("ON E.DEPARTMENT_ID = D.ID " + "INNER JOIN COURSE_CATEGORY AS CC "); // Added 2021/01/09
        queryBuilder.append("ON C.COURSE_CATEGORY_ID = CC.ID ");// Added 2021/01/09
        
        if (withTags) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM "); //ADD
            queryBuilder.append("ON CTM.course_id = C.id "); //ADD
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR "); //ADD
            queryBuilder.append("ON MR.id = CTM.tag_id "); //ADD
            enrollmentDaoImpl.addTagsToConditionList(conditionList, courseScheduleListForm.getMemberRole());
        }
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("scheduled_start_datetime");
        String orderProperty = getOrderProperty(order);

        if (!user.getRoles().contains("Instructor") || user.getRoles().contains("PMO")) {
            System.out.println("category id:" + courseScheduleListForm.getCourseCategoryId());
            queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID "); // added for
                                                                                            // filter
            queryBuilder.append("AND TO_CHAR(CSCHED.COURSE_ID, 'FM9999') LIKE :courseNameId "); // added for filter
            queryBuilder.append("AND TO_CHAR(CSCHED.INSTRUCTOR_ID, 'FM9999') LIKE :instructorId "); // added for filter
            queryBuilder.append("AND TO_CHAR(CSCHED.VENUE_ID, 'FM9999') LIKE :venueId "); // added for filter
            queryBuilder.append("AND TO_CHAR(C.DEPARTMENT_ID, 'FM9999') LIKE :departmentId "); // added for filter
            queryBuilder.append("AND C.MANDATORY LIKE :mandatory "); // added for filter
            queryBuilder.append("AND C.MANDATORY_TYPE LIKE :mandatoryType "); // added for filter
            queryBuilder.append("AND C.DEADLINE LIKE :deadline "); // added for filter
            queryBuilder.append("AND CPART.PARTICIPANT_ID = :participantId ");
            queryBuilder.append("AND CSCHED.STATUS = 'A' ");

            if (withTags) {
                queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining()));
            }
            
            queryBuilder.append("ORDER BY ");
            queryBuilder.append(orderProperty);
            queryBuilder.append(", CSCHED.ID "); // added for sorting
            queryBuilder.append("LIMIT ");
            queryBuilder.append(pageable.getPageSize());
            queryBuilder.append(" "); // added for pagination
            queryBuilder.append("OFFSET ");
            queryBuilder.append(pageable.getOffset());
            queryBuilder.append(" "); // added for pagination

            SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                    		courseScheduleListForm.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                    		courseScheduleListForm.getToDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("courseCategoryID", courseScheduleListForm.getCourseCategoryId()).addValue("courseNameId", courseScheduleListForm.getCourseNameId())
                    .addValue("instructorId", courseScheduleListForm.getInstructorId()).addValue("venueId", courseScheduleListForm.getVenueId())
                    .addValue("departmentId", courseScheduleListForm.getDepartmentId()).addValue("deadline", courseScheduleListForm.getDeadline())
                    .addValue("mandatory", courseScheduleListForm.getMandatory()).addValue("mandatoryType", courseScheduleListForm.getMandatoryType())
                    .addValue("participantId", user.getId());
            List<CourseParticipant> listCourseEnrolled = template.query(queryBuilder.toString(), courseEnrolledParameters,
                    new CourseParticipantRowMapper());
            return new LinkedHashSet<>(listCourseEnrolled);        
        } else {
            queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND CPART.PARTICIPANT_ID = :participantId ");
            queryBuilder.append("AND CSCHED.STATUS = 'A' ");
            queryBuilder.append("ORDER BY ");
            queryBuilder.append(orderProperty); // + ", CSCHED.ID " // added for sorting
            queryBuilder.append("LIMIT ");
            queryBuilder.append(pageable.getPageSize());
            queryBuilder.append(" "); // added for pagination
            queryBuilder.append("OFFSET ");
            queryBuilder.append(pageable.getOffset());
            queryBuilder.append(" "); // added for pagination

            SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                    		courseScheduleListForm.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                    		courseScheduleListForm.getToDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("participantId", courseScheduleListForm.getParticipantId());
            List<CourseParticipant> listCourseEnrolled = template.query(queryBuilder.toString(), courseEnrolledParameters,
                    new CourseParticipantRowMapper());
            return new LinkedHashSet<>(listCourseEnrolled);
        }
    }

    /**
     * <pre>
     * Map the correct and proper field name
     * 
     * <pre>
     * 
     * @param order
     * @return String
     * @author d.dinglasan
     */
    private String getOrderProperty(Order order) {
        switch (order.getProperty()) {
            case "course_name":
                return "C.NAME " + order.getDirection();
            case "instructor":
                return "INSTRUCTOR_LAST_NAME " + order.getDirection() + ", INSTRUCTOR_FIRST_NAME "
                        + order.getDirection();
            case "mandatory":
                return "MANDATORY " + order.getDirection();
            case "mandatory_type":
                return "MANDATORY_TYPE " + order.getDirection();
            case "venue":
                return "VENUE_NAME " + order.getDirection();
            case "scheduled_start_datetime":
                return "SCHEDULED_START_DATETIME " + order.getDirection();
            case "scheduled_end_datetime":
                return "SCHEDULED_END_DATETIME " + order.getDirection();
            case "duration":
                return "DURATION " + order.getDirection();
            case "courseCategory":
                return "COURSE_CATEGORY " + order.getDirection();
            default:
                return "";
        }
    }

    @Override
    public int countCourse(CourseScheduleListForm courseScheduleListForm) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        List<String> conditionList = new LinkedList<>();
        StringBuilder queryBuilder = new StringBuilder();
        boolean withTags = courseScheduleListForm.getMemberRole() != null && !courseScheduleListForm.getMemberRole().isEmpty();
        
        queryBuilder.append("SELECT COUNT( DISTINCT CPART.ID) ");
        queryBuilder.append("FROM COURSE_SCHEDULE AS CSCHED ");
        queryBuilder.append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSCHEDDET ");
        queryBuilder.append("ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID ");
        queryBuilder.append("INNER JOIN tsup.COURSE_PARTICIPANT AS CPART ");
        queryBuilder.append("ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID ");
        queryBuilder.append("INNER JOIN tsup.COURSE AS C ");
        queryBuilder.append("ON C.ID = CSCHED.COURSE_ID ");
        queryBuilder.append("INNER JOIN EMPLOYEE AS E ");
        queryBuilder.append("ON E.ID = CSCHED.INSTRUCTOR_ID ");
        queryBuilder.append("INNER JOIN tsup.VENUE AS V ");
        queryBuilder.append("ON V.ID = CSCHED.VENUE_ID \r\n");
        queryBuilder.append("INNER JOIN DEPARTMENT AS D  ");
        queryBuilder.append("ON E.DEPARTMENT_ID = D.ID ");
        if (withTags) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM "); //ADD
            queryBuilder.append("ON CTM.course_id = C.id "); //ADD
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR "); //ADD
            queryBuilder.append("ON MR.id = CTM.tag_id "); //ADD
            enrollmentDaoImpl.addTagsToConditionList(conditionList, courseScheduleListForm.getMemberRole());
        }
        try {
            if (!user.getRoles().contains("Instructor") || user.getRoles().contains("PMO")) {
            queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
            queryBuilder.append("AND TO_CHAR(CSCHED.COURSE_ID, 'FM9999') LIKE :courseNameId ");
            queryBuilder.append("AND TO_CHAR(CSCHED.INSTRUCTOR_ID, 'FM9999') LIKE :instructorId ");
            queryBuilder.append("AND TO_CHAR(CSCHED.VENUE_ID, 'FM9999') LIKE :venueId ");
            queryBuilder.append("AND TO_CHAR(C.DEPARTMENT_ID, 'FM9999') LIKE :departmentId ");
            queryBuilder.append("AND C.MANDATORY LIKE :mandatory "); 
            queryBuilder.append("AND C.MANDATORY_TYPE LIKE :mandatoryType ");
            queryBuilder.append("AND C.DEADLINE LIKE :deadline "); 
            queryBuilder.append("AND CPART.PARTICIPANT_ID = :participantId ");
            queryBuilder.append("AND CSCHED.STATUS = 'A' ");
            
            if (withTags) {
                queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining()));
            }
            
            SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
            courseScheduleListForm.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
            .addValue("toDateTime",
            courseScheduleListForm.getToDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
            .addValue("courseCategoryID", courseScheduleListForm.getCourseCategoryId()).addValue("courseNameId", courseScheduleListForm.getCourseNameId())
            .addValue("instructorId", courseScheduleListForm.getInstructorId()).addValue("venueId", courseScheduleListForm.getVenueId())
            .addValue("departmentId", courseScheduleListForm.getDepartmentId()).addValue("deadline", courseScheduleListForm.getDeadline())
            .addValue("mandatory", courseScheduleListForm.getMandatory()).addValue("mandatoryType", courseScheduleListForm.getMandatoryType())
            .addValue("participantId", user.getId());
            
                return template.queryForObject(queryBuilder.toString(), courseEnrolledParameters, Integer.class);
            
            } else {
            	queryBuilder.append("WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, ");
                queryBuilder.append("CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
                queryBuilder.append("AND CPART.PARTICIPANT_ID = :participantId " + "AND CSCHED.STATUS = 'A' ");
                
                SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                        .addValue("fromDateTime",
                courseScheduleListForm.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                .addValue("toDateTime",
                courseScheduleListForm.getToDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                .addValue("participantId", courseScheduleListForm.getParticipantId());
                    return template.queryForObject(queryBuilder.toString(), courseEnrolledParameters, Integer.class);
            }
        } catch (NullPointerException e) {
            return 0;
        }

    }
}

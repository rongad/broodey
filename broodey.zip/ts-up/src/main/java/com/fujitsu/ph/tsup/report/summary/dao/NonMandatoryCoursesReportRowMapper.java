//==================================================================================================
// Project Name : Training Sign-Up
// System Name : NonMandatoryCoursesReportRowMapper
// Class Name : NonMandatoryCoursesReportRowMapper.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/06 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fujitsu.ph.tsup.report.summary.model.Attendee;

/**
 * <pre>
 * Row Mapper class of
 * NonMandatoryCoursesReport
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public class NonMandatoryCoursesReportRowMapper implements RowMapper<Attendee> {

    /*
     * (non-Javadoc)
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public Attendee mapRow(ResultSet rs, int rowNum) throws SQLException {
        Attendee attendee = new Attendee();

        String courseName = rs.getString("COURSE_NAME");
        String employeeName = rs.getString("EMPLOYEE_NAME");
        String dateAttended = rs.getString("DATE_ATTENDED");
        Long courseId = rs.getLong("COURSE_ID");
        Long employeeId = rs.getLong("EMPLOYEE_ID");

        attendee.setId(courseId);
        attendee.setCourseName(courseName);
        attendee.setEmployeeName(employeeName);
        attendee.setEmployeeId(employeeId);
        attendee.setDateAttended(dateAttended);

        return attendee;
    }

}

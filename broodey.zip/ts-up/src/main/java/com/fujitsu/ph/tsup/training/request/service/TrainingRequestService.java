package com.fujitsu.ph.tsup.training.request.service;

import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestForm;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

//=======================================================
//Project Name: Training Sign Up
//Class Name: TrainingRequestService.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 07/12/2021 | WS) L.Celoso    | New Creation
//0.02    | 08/06/2021 | WS) L.Celoso    | Update
//=======================================================

/**
* <pre>
* The interface for training request service
* <pre>
* @version 0.01
* @author L.Celoso	
*
*/
public interface TrainingRequestService {
    
    /**
     * Create a training request
     * @param trainingRequestForm
     */
    void createTrainingRequest(TrainingRequestForm trainingRequestForm);
    
    /**
     * Get all training request
     */
    Set<TrainingRequest> getAllTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm, Pageable pageable);
    
    /**
     * Cancel training request
     */
    void cancelTrainingRequest(Long id);
    
    /**
     * Cancel training request
     */
    void closeTrainingRequest(Long id);
    
    /**
     * Update a training request
     * @param trainingRequestForm
     */
    void updateTrainingRequest(TrainingRequestForm trainingRequestForm);
    

    /**
     * Decline a training request
     */
    void changeTrainingRequestStatus(Long id, String status, String remarks);

    /**
     * Count the number of training request
     * @param trainingRequestForm
     */
    int countTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm);
}
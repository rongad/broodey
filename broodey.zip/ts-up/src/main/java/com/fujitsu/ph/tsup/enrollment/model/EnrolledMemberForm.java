package com.fujitsu.ph.tsup.enrollment.model;

public class EnrolledMemberForm {

	private Long courseId;
	
	private String batchId;
	
	public Long getCourseId() {
		return courseId;
	}

	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}
	
	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	
}

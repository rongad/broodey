/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.batch;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.fujitsu.ph.tsup.authz.autoregister.model.AutoRegistration;

//=======================================================
//$Id:
//Project Name: Training Sign Up
//Class Name: BatchConfiguration.java
//
//<<Modification History>>
//Version | Date | Updated by | Content
//--------+------------+------------------+---------------
//0.01 | ----/--/-- | Je.Bacal | Created
//=======================================================


/**
 * BatchConfiguration class
 * 
 * @author Je.Bacal (New Creation by: Je.Bacal)
 * @author Je.Bacal
 * @version 0.01
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;

    @Value("${employee.requiredMonths}")
    private int requiredMonths;

    public int retrieveProperty() {
    	return requiredMonths;
    }
    private String queryFindEmployees;

    /**
     * Connectivity to database and Query for the item reader
     */
    @PostConstruct
    public void postConstruct() {
        template = new NamedParameterJdbcTemplate(dataSource);
        queryFindEmployees = "SELECT id,joining_date  FROM tsup.employee "
                + "WHERE DATE_PART('month', AGE(now(), joining_date)) >= " + requiredMonths;
    }

    private static final Logger log = LoggerFactory.getLogger(BatchConfiguration.class);

    /**
     * Runs the Item reader and Reads the data from the database
     */
    @Bean
    public ItemReader<AutoRegistration> reader() {
        return new JdbcCursorItemReaderBuilder<AutoRegistration>().name("cursorItemReader")
                .dataSource(dataSource).sql(queryFindEmployees)
                .rowMapper(new BeanPropertyRowMapper<>(AutoRegistration.class)).build();

        
    }

    /**
     * Runs the custom item processor - business logic and Checks if joining date is >= 3 months
     */
    @Bean
    public CustomItemProcessor processor() {
        return new CustomItemProcessor();
    }

    /**
     * Runs the item writer and Updates the database
     */
    @Bean
    public JdbcBatchItemWriter<AutoRegistration> writer() {
        JdbcBatchItemWriter<AutoRegistration> writer = new JdbcBatchItemWriter<AutoRegistration>();
        try {
            writer.setDataSource(dataSource);
            writer.setSql("UPDATE tsup.EMPLOYEE SET status = ? WHERE id = ? "); // sql query to update status
                                                                                // when joining_date is > 3
                                                                                // mos
            writer.setItemPreparedStatementSetter(new UserItemPreparedStm());
        } catch (Exception e) {
            log.error("Error Message", e);
        }

        return writer;
    }

    /**
     * Set values to the update query
     */
    private class UserItemPreparedStm implements ItemPreparedStatementSetter<AutoRegistration> {
        @Override
        public void setValues(AutoRegistration autoRegistration, PreparedStatement ps) throws SQLException {

            ps.setString(1, autoRegistration.getStatus());
            ps.setLong(2, autoRegistration.getId());
        }
    }

    /**
     * Step writes up to ten records at a time using chunk (10)
     */
    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1").<AutoRegistration, AutoRegistration>chunk(10).reader(reader())
                .processor(processor()).writer(writer()).build();

    }

    /**
     * Process the step
     */
    @Bean
    public Job importUserJob() {

        return jobBuilderFactory.get("importUserJob").incrementer(new RunIdIncrementer()).flow(step1()).end()
                .build();

    }

}

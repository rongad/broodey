package com.fujitsu.ph.tsup.training.request.web;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestForm;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;
import com.fujitsu.ph.tsup.training.request.service.TrainingRequestService;

// =======================================================
// Project Name: Training Sign Up
// Class Name: TrainingRequestController.java
//
// <<Modification History>>
// Version | Date | Updated by | Content
// --------+------------+------------------+---------------
// 0.01 | 07/09/2021 | WS) L.Celoso | New Creation
// 0.02 | 08/06/2021 | WS) L.Celoso | Update
// 0.03 | 08/16/2021 | WS) D.Dinglasan | Update
// 0.04 | 08/20/2021 | WS) L.Celoso | Fix bug on validating course details
// 0.05 | 09/08/2021 | WS) R.dela Cruz | Update
// =======================================================
/**
 * <pre>
 * The implementation of Training Request Controller
 * 
 * <pre>
 * 
 * @version 0.01
 * @author L.celoso
 */
@Controller
@RequestMapping("/training")
public class TrainingRequestController {
    private static Logger logger = LoggerFactory.getLogger(TrainingRequestController.class);

    @Autowired
    private TrainingRequestService trainingRequestService;

    private static final int MAX_COURSE_NAME_LEN = 150;

    private static final int MAX_COURSE_DETAILS_LEN = 500;

    private static final int MAX_PARTICIPANTS_ALLOWED = 99999;

    private static final int PAGE_SIZE = 10;

    /**
     * <pre>
     * Open the create form of request training
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @GetMapping("/request")
    public String createRequestTraining(Model model) {

        return "training-request/createTrainingRequest";
    }

    /**
     * <pre>
     * View all request training available
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @GetMapping("/manage")
    public String manageRequestTraining(
            @Valid @ModelAttribute("trainingRequestSearchForm") TrainingRequestSearchForm form,
            BindingResult result, Model model, @RequestParam("currentPage") Optional<Integer> page,
            @RequestParam("size") Optional<Integer> size,
            @RequestParam("sortField") Optional<String> sortField,
            @RequestParam("sortDir") Optional<String> sortDir) {

        int currentPage = page.orElse(1);
        int pageSize = size.orElse(PAGE_SIZE);

        String sortFieldVal = sortField.filter(str -> !str.isEmpty()).orElse("scheduled_start_datetime");
        String sortVal = sortDir.filter(str -> !str.isEmpty()).orElse("asc");

        String currentPageStr = form.getCurrentPage();
        if (isNumeric(currentPageStr)) {
            currentPage = Integer.parseInt(currentPageStr);
        }

        Sort sort = Sort.by(Direction.valueOf(sortVal.toUpperCase()), sortFieldVal);
        Pageable pageable = PageRequest.of(currentPage - 1, pageSize, sort);

        LocalDateTime startDateTime = form.getSearchStartDateTime();
        LocalDateTime endDateTime = form.getSearchEndDateTime();

        if (form.getSearchStartDateTime() == null) {
            form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
        } else {
            form.setSearchStartDateTimeZone(
                    startDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }

        if (form.getSearchEndDateTime() == null) {
            // set end date variable to specific end quarter
            // e.g. Mar-31 | Jun-30 | Sept-30 | Dec-31, 11:59 PM
            // for initial load of data

            int searchStartDateTimeTZMonthValue = form.getSearchStartDateTimeZone().getMonthValue();
            int addMonths = 0;
            int quarterEndMonth = 3; // initial value of 3 to depict first quarter

            // get the difference of searchStartDateTimeTZMonthValue from its proper quarter range
            // then store it to addMonths
            while (quarterEndMonth <= 12) {
                if (searchStartDateTimeTZMonthValue <= quarterEndMonth) {
                    addMonths = quarterEndMonth - searchStartDateTimeTZMonthValue;
                    break;
                }
                quarterEndMonth += 3;
            }

            try {
                int daysOfTheMonth = (quarterEndMonth == 3 || quarterEndMonth == 12) ? 31 : 30;
                ZonedDateTime toDatePlaceHolder = form.getSearchStartDateTimeZone().plusMonths(addMonths) // add
                                                                                                          // months
                                                                                                          // to
                                                                                                          // set
                                                                                                          // specific
                                                                                                          // end
                                                                                                          // quarter
                        .withDayOfMonth(daysOfTheMonth) // set the end day of the month
                        .withHour(23).withMinute(59); // this will set the time to 11:59 PM
                form.setSearchEndDateTimeZone(toDatePlaceHolder);
            } catch (Exception e) {
                model.addAttribute("paginatedAttendCourseList", Page.empty());
                model.addAttribute("attendCourseList", form);
                model.addAttribute("nullMessage", e.getMessage());
            }
        } else {
            form.setSearchEndDateTimeZone(
                    endDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }

        form.setStatus(checkFilterId(form.getStatus()));
        form.setRequester(checkFilterId(form.getRequester()));

        Set<TrainingRequest> trainingRequest = trainingRequestService.getAllTrainingRequest(form, pageable);

        // For pagination
        List<TrainingRequest> listOfTrainingRequest = trainingRequest.stream().collect(Collectors.toList());
        int trainingRequestCount = trainingRequestService.countTrainingRequest(form);
        Page<TrainingRequest> paginatedCourseEnroll = new PageImpl<>(listOfTrainingRequest, pageable,
                trainingRequestCount);
        Paged<TrainingRequest> pagedCourseEnroll = new Paged<>(paginatedCourseEnroll, Paging.of(
                paginatedCourseEnroll.getTotalPages(), pageable.getPageNumber() + 1, pageable.getPageSize()));
        model.addAttribute("trainingRequestSet", pagedCourseEnroll);
        model.addAttribute("trainingRequestSearchForm", form);

        model.addAttribute("currentPage", currentPage);
        model.addAttribute("size", pageSize);
        model.addAttribute("sortField", sortFieldVal);
        model.addAttribute("sortDir", sortVal);

        if (trainingRequest.isEmpty()) {
            model.addAttribute("nullMessage", "No Training Request Found");
        }

        return "training-request/manageTrainingRequest";
    }

    /**
     * <pre>
     * Call the information model to confirm the details before the operation
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @GetMapping("/{deleteRequestId}/cancel")
    public String showDeleteCourseForm(@RequestParam(value = "deleteRequestIdInput") Long id,
            @RequestParam(value = "funcType") String funcType,
            @RequestParam(value = "inputRemarks") String remarks,
            @ModelAttribute("trainingRequestSearchForm") TrainingRequestSearchForm form,
            BindingResult bindingResult, Model model, RedirectAttributes redir) {

        LocalDateTime startDateTime = form.getSearchStartDateTime();
        LocalDateTime endDateTime = form.getSearchEndDateTime();

        if (form.getSearchStartDateTime() == null) {
            form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
        } else {
            form.setSearchStartDateTimeZone(
                    startDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }
        if (form.getSearchEndDateTime() == null) {
            form.setSearchEndDateTimeZone(ZonedDateTime.now().plusDays(5));
        } else {
            form.setSearchEndDateTimeZone(
                    endDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }

        redir.addFlashAttribute("funcType", funcType);
        redir.addFlashAttribute("inputRemarks", remarks);
        redir.addFlashAttribute("trainingRequestSearchForm", form);
        redir.addFlashAttribute("confirmationMessage",
                "Are you sure you want to " + funcType + " this training request?");

        return "redirect:/training/manage?deleteRequestId=" + id + "#confirmModal";
    }

    /**
     * <pre>
     * Cancel/Delete the training request or change its status
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @PostMapping("/{deleteRequestId}/cancel")
    public String cancelRequestTraining(@PathVariable("deleteRequestId") Long id,
            @RequestParam(value = "funcType") String funcType,
            @RequestParam(value = "inputRemarks") String remarks, TrainingRequestSearchForm form,
            RedirectAttributes redirectAttributes, Model model) {

        LocalDateTime startDateTime = form.getSearchStartDateTime();
        LocalDateTime endDateTime = form.getSearchEndDateTime();

        if (form.getSearchStartDateTime() == null) {
            form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
        } else {
            form.setSearchStartDateTimeZone(
                    startDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }
        if (form.getSearchEndDateTime() == null) {
            form.setSearchEndDateTimeZone(ZonedDateTime.now().plusDays(5));
        } else {
            form.setSearchEndDateTimeZone(
                    endDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }

        redirectAttributes.addFlashAttribute("trainingRequestSearchForm", form);

        try {
            if (funcType.equals("Decline")) {
                trainingRequestService.changeTrainingRequestStatus(id, funcType, remarks);
                redirectAttributes.addFlashAttribute("successMessage",
                        "Succesfully declined the training request");
            } else if (funcType.equals("Approve")) {
                trainingRequestService.changeTrainingRequestStatus(id, funcType, remarks);
                redirectAttributes.addFlashAttribute("successMessage",
                        "Succesfully approved the training request");
            } else if (funcType.equals("Cancel")) {
                trainingRequestService.cancelTrainingRequest(id);
                redirectAttributes.addFlashAttribute("successMessage",
                        "Succesfully cancelled the training request");
            } else {
                trainingRequestService.closeTrainingRequest(id);
                redirectAttributes.addFlashAttribute("successMessage",
                        "Succesfully closed the training request");
            }

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/training/manage#errorModal";
        }

        return "redirect:/training/manage#successModal";
    }

    /**
     * <pre>
     * Validate the updates of training request made by user
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @GetMapping("/{updateRequestId}/update")
    public String showUpdateCourseForm(@RequestParam(value = "updateRequestIdInput") Long id,
            @ModelAttribute("trainingRequestSearchForm") TrainingRequestSearchForm form,
            @ModelAttribute("trainingRequestForm") TrainingRequestForm updateForm,
            BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes) {

        LocalDateTime startDateTime = form.getSearchStartDateTime();
        LocalDateTime endDateTime = form.getSearchEndDateTime();

        if (form.getSearchStartDateTime() == null) {
            form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
        } else {
            form.setSearchStartDateTimeZone(
                    startDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }
        if (form.getSearchEndDateTime() == null) {
            form.setSearchEndDateTimeZone(ZonedDateTime.now().plusDays(5));
        } else {
            form.setSearchEndDateTimeZone(
                    endDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }

        redirectAttributes.addFlashAttribute("trainingRequestSearchForm", form);

        /* Validations */
        boolean hasErrors = false;
        String courseName = updateForm.getCourseName().trim();
        int minParticipants = updateForm.getMinRequired();
        int maxParticipants = updateForm.getMaxRequired();
        ZonedDateTime updateStartDateTime = updateForm.getStartDateTime();
        ZonedDateTime updateEndDateTime = updateForm.getEndDateTime();
        String courseDetails = updateForm.getCourseDetails().trim();

        // Course Name
        if (courseName.isEmpty()) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseNameError", "Course Name is required");
        } else if (courseName.length() > MAX_COURSE_NAME_LEN) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseNameError", "Please input upto 150 characters only");
        }

        // Course Details
        if (courseDetails.isEmpty()) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseDetailError", "Course Details is required");
        } else if (courseDetails.length() > MAX_COURSE_DETAILS_LEN) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseDetailError",
                    "Please input upto 500 characters only");
        }

        // Schedule
        if (updateStartDateTime == null) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("startDateTimeError", "Start Date and Time is required");
        } else if (updateStartDateTime.isBefore(ZonedDateTime.now())) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("startDateTimeError", "Please pick a future date and time");
        }

        if (updateEndDateTime == null) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("endDateTimeError", "End Date and Time is required");
        }

        if (updateStartDateTime != null && updateEndDateTime != null) {
            if (updateStartDateTime.isAfter(updateEndDateTime)
                    || updateStartDateTime.isEqual(updateEndDateTime)) {
                hasErrors = true;
                redirectAttributes.addFlashAttribute("endDateTimeError",
                        "End Date and Time should be later than Start Date and Time");
            }
        }

        // Participants
        if (minParticipants == 0) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("minParticipantsError", "Minimum Participants is required");
        } else if (minParticipants > maxParticipants && maxParticipants != 0) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("minParticipantsError",
                    "Maximum Participants should be greater than Minimum Participants");
        }

        if (maxParticipants == 0) {
            updateForm.setMaxRequired(MAX_PARTICIPANTS_ALLOWED);
        }

        if (!hasErrors) {
            try {
                redirectAttributes.addFlashAttribute("confirmationMessage",
                        "Are you sure you want to update this training request?");
                return "redirect:/training/manage?updateRequestId=" + id + "#confirmUpdateModal";
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("mainError", e.getMessage());
                redirectAttributes.addFlashAttribute("hasErrors", true);
                return "redirect:/training/manage#updateModal";
            }
        } else {
            redirectAttributes.addFlashAttribute("hasErrors", true);
            return "redirect:/training/manage#updateModal";
        }

    }

    /**
     * <pre>
     * Update the request training based on the changes made by user
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @PostMapping("/update")
    public String updateRequestTraining(
            @ModelAttribute("trainingRequestSearchForm") TrainingRequestSearchForm form,
            @ModelAttribute("trainingRequestForm") TrainingRequestForm updateForm,
            RedirectAttributes redirectAttributes, Model model) {

        LocalDateTime startDateTime = form.getSearchStartDateTime();
        LocalDateTime endDateTime = form.getSearchEndDateTime();

        if (form.getSearchStartDateTime() == null) {
            form.setSearchStartDateTimeZone(ZonedDateTime.now().withHour(0).withMinute(0));
        } else {
            form.setSearchStartDateTimeZone(
                    startDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }
        if (form.getSearchEndDateTime() == null) {
            form.setSearchEndDateTimeZone(ZonedDateTime.now().plusDays(5));
        } else {
            form.setSearchEndDateTimeZone(
                    endDateTime.atZone(ZoneId.systemDefault()).withHour(0).withMinute(0));
        }

        redirectAttributes.addFlashAttribute("trainingRequestSearchForm", form);

        try {
            ZonedDateTime updateStartDateTime = updateForm.getStartDateTime();
            ZonedDateTime updateEndDateTime = updateForm.getEndDateTime();
            updateForm.setDuration(computeDuration(updateStartDateTime, updateEndDateTime));

            trainingRequestService.updateTrainingRequest(updateForm);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/training/manage#errorModal";
        }

        redirectAttributes.addFlashAttribute("successMessage", "Succesfully updated the training request");
        return "redirect:/training/manage#successModal";
    }

    /**
     * <pre>
     * Submit the Request Training form and save it to the database
     * 
     * <pre>
     * 
     * @param form
     * @param bindingResult
     * @param model
     * @return String
     * @author L.Celoso
     */
    @PostMapping("/create")
    public String submitRequestTraining(TrainingRequestForm form, BindingResult bindingResult, Model model,
            RedirectAttributes redirectAttributes) {

        logger.debug("TrainingRequestForm: {}", form);

        boolean hasErrors = false;
        String courseName = form.getCourseName().trim();
        int minParticipants = form.getMinRequired();
        int maxParticipants = form.getMaxRequired();
        ZonedDateTime startDateTime = form.getStartDateTime();
        ZonedDateTime endDateTime = form.getEndDateTime();
        String courseDetails = form.getCourseDetails().trim();

        /* Validations */
        // Course Name
        if (courseName.isEmpty()) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseNameError", "Course Name is required");
        } else if (courseName.length() > MAX_COURSE_NAME_LEN) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseNameError", "Please input upto 150 characters only");
        }

        // Course Details
        if (courseDetails.isEmpty()) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseDetailError", "Course Details is required");
        } else if (courseDetails.length() > MAX_COURSE_DETAILS_LEN) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("courseDetailError",
                    "Please input upto 500 characters only");
        }

        // Schedule
        if (startDateTime == null) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("startDateTimeError", "Start Date and Time is required");
        } else if (startDateTime.isBefore(ZonedDateTime.now())) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("startDateTimeError", "Please pick a future date and time");
        }

        if (endDateTime == null) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("endDateTimeError", "End Date and Time is required");
        }

        if (startDateTime != null && endDateTime != null) {
            if (startDateTime.isAfter(endDateTime) || startDateTime.isEqual(endDateTime)) {
                hasErrors = true;
                redirectAttributes.addFlashAttribute("endDateTimeError",
                        "End Date and Time should be later than Start Date and Time");
            } else {
                form.setDuration(computeDuration(startDateTime, endDateTime));
            }
        }

        // Participants
        if (minParticipants == 0) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("minParticipantsError", "Minimum Participants is required");
        } else if (minParticipants > maxParticipants && maxParticipants != 0) {
            hasErrors = true;
            redirectAttributes.addFlashAttribute("minParticipantsError",
                    "Maximum Participants should be greater than Minimum Participants");
        }

        if (maxParticipants == 0) {
            form.setMaxRequired(MAX_PARTICIPANTS_ALLOWED);
        }

        if (!hasErrors) {
            try {
                trainingRequestService.createTrainingRequest(form);
                redirectAttributes.addFlashAttribute("showSuccessModal", true);
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("mainError", e.getMessage());
                redirectAttributes.addFlashAttribute("hasErrors", true);
            }
        } else {
            redirectAttributes.addFlashAttribute("hasErrors", true);
        }

        return "redirect:/training/request";
    }

    private float computeDuration(ZonedDateTime scheduledStartDateTime, ZonedDateTime scheduledEndDateTime) {
        float duration;
        Long durationToHours = Duration.between(scheduledStartDateTime, scheduledEndDateTime).toHours();
        Long durationToMinutes = Duration.between(scheduledStartDateTime, scheduledEndDateTime).toMinutes();

        float minutePercentage = durationToMinutes.floatValue() % 60 / 60;
        duration = durationToHours + minutePercentage;
        return duration;
    }

    /**
     * Check if filter Id is null, empty or undefined
     * 
     * @return
     */
    private String checkFilterId(String filterId) {

        if (filterId == null || filterId.isEmpty() || filterId.equals("undefined")
                || filterId.equals("All")) {
            return "%";
        }

        return filterId;
    }

    /**
     * Check if String is Numeric
     * 
     * @return
     */
    public static boolean isNumeric(String strNum) {
        if (strNum == null || strNum.length() == 0) {
            return false;
        }

        try {
            Double.parseDouble(strNum);
            return true;

        } catch (NumberFormatException e) {
            return false;
        }
    }
}

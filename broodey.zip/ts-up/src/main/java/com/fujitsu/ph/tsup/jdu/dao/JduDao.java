/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.jdu.dao;

import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.jdu.domain.Jdu;

// =======================================================
// Project Name: Training Sign Up
// Class Name: JduDao.java
//
// <<Modification History>>
// Version | Date | Updated by | Content
// --------+------------+------------------+---------------
// 0.01 | 28/06/2021 | WS) dw.cardenas | Created
// 0.02 | 07/07/2021 | WS) dw.cardenas | findAllJdus(pageable) & countJdu
// 0.02 | 03/08/2021 | WS) dw.cardenas | Update
// 0.03 | 10/09/2021 | WS) r.delacruz | Update
// =======================================================

/**
 * @author dw.cardenas
 */
public interface JduDao {

    /**
     * <pre>
     * Finds all JDUs in the database
     * 
     * <pre>
     *
     * @return
     */
    Set<Jdu> findAllJdus();

    /**
     * <pre>
     * Finds all JDUs in the database based on pageable.
     * 
     * <pre>
     *
     * @param pageable
     * @return Set of JDU based on parameters in pageable
     */
    Set<Jdu> findAllJdus(Pageable pageable);

    /**
     * <pre>
     * Finds specific JDU/s that contains string in jduName in the database
     * 
     * <pre>
     *
     * @param jduName
     * @return
     */
    Set<Jdu> findJduByName(String jduName);

    /**
     * <pre>
     * Inserts a new JDU in the database
     * 
     * <pre>
     *
     * @param newJdu
     */
    void createJdu(Jdu newJdu);

    /**
     * <pre>
     * Updates an existing JDU in the database
     * 
     * <pre>
     *
     * @param updatedJdu
     */
    void updateJdu(Jdu updatedJdu);

    /**
     * <pre>
     * Deletes an existing JDU using JDU id in the database
     * 
     * <pre>
     *
     * @param id
     */
    void deleteJdu(Long id);

    /**
     * <pre>
     * Counts number of JDUs saved in the database
     * 
     * <pre>
     *
     * @return Number of JDU
     */
    int countJdu();

    /**
     * <pre>
     * Find JDU with specific string in database
     * 
     * <pre>
     *
     * @param searchKey
     * @param pageable
     * @return
     */
    Set<Jdu> findJduByName(String searchKey, Pageable pageable);

    /**
     * <pre>
     * Counts number of JDUs saved in the database based on Search Key
     * 
     * <pre>
     *
     * @return Number of JDU based on Search Key
     */
    int countFoundJdu(String searchKey);
}

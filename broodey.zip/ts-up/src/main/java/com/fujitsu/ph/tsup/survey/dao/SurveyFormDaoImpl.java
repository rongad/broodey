package com.fujitsu.ph.tsup.survey.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.survey.domain.Survey;

//==================================================================================================
//$Id:PR16$
//Project Name : Training Sign up
//System Name  : Survey Form Process 
//Class Name   : SurveyFormDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By                                              | Content
//--------+------------+---------------------------------------------------------+-----------------
//0.01    | 08/12/2021 | WS) M.Berja                                             | New Creation
//0.02    | 10/27/2021 | WS) L.Celoso                                            | Added the course schedule ID to link the course schedule and survey tables in the DB
//==================================================================================================
/**
 * <pre>
* The data access class for survey form related database access
 * </pre>
 * 
 * @version 0.1
 * @author m.berja
 * 
 */

@Repository
public class SurveyFormDaoImpl implements SurveyFormDao {

	/*
	 * <pre> Useful methods for logging and also decouple the logging implementation
	 * from application
	 * 
	 * <pre>
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(SurveyFormDaoImpl.class);

	/*
	 * <pre> JDBC Template
	 */
	@Autowired
	private NamedParameterJdbcTemplate template;

	/**
	 * <pre>
	 * Creates the survey form
	 * 
	 * <pre>
	 * 
	 * @param surveyForm
	 */
	@Override
	public void createSurvey(Survey surveyForm) {

		try {
			StringBuilder insertQuery = new StringBuilder();
			
			insertQuery.append("INSERT INTO survey_form");
			insertQuery.append(" (courseTitle, ");
	        insertQuery.append(" trainingVenue, ");
			insertQuery.append(" instructorName, ");
	        insertQuery.append(" courseDateTime, ");
            insertQuery.append(" course_schedule_id, ");
	        insertQuery.append(" mdQuestion1, mdQuestion2, mdQuestion3, mdQuestion4, ");
	        insertQuery.append(" matQuestion1, matQuestion2, matQuestion3, matQuestion4, ");
	        insertQuery.append(" insQuestion1, insQuestion2, insQuestion3, insQuestion4, insQuestion5, insQuestion6, ");
	        insertQuery.append(" eqFaQuestion1, eqFaQuestion2, eqFaQuestion3, ");
	        insertQuery.append(" commentsE, commentsF, commentsG)");
	        insertQuery.append(" VALUES(:courseTitle, ");
            insertQuery.append(" :trainingVenue, ");
            insertQuery.append(" :instructorName, ");
            insertQuery.append(" :courseDateTime, ");
            insertQuery.append(" :courseScheduleId, ");
            insertQuery.append(" :mdQuestion1, :mdQuestion2, :mdQuestion3, :mdQuestion4, ");
            insertQuery.append(" :matQuestion1, :matQuestion2, :matQuestion3, :matQuestion4, ");
            insertQuery.append(" :insQuestion1, :insQuestion2, :insQuestion3, :insQuestion4, :insQuestion5, :insQuestion6, ");
            insertQuery.append(" :eqFaQuestion1, :eqFaQuestion2, :eqFaQuestion3, ");
            insertQuery.append(" :commentsE, :commentsF, :commentsG)");

			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue("courseTitle", surveyForm.getCourseTitle())
					.addValue("trainingVenue", surveyForm.getTrainingVenue())
					.addValue("instructorName", surveyForm.getInstructorName())
					.addValue("courseDateTime", surveyForm.getCourseDateTime().toOffsetDateTime())
                    .addValue("courseScheduleId", surveyForm.getCourseScheduleDetailId())
					.addValue("mdQuestion1", surveyForm.getMdQuestion1()).addValue("mdQuestion2", surveyForm.getMdQuestion2())
					.addValue("mdQuestion3", surveyForm.getMdQuestion3()).addValue("mdQuestion4", surveyForm.getMdQuestion4())
					.addValue("matQuestion1", surveyForm.getMatQuestion1()).addValue("matQuestion2", surveyForm.getMatQuestion2())
					.addValue("matQuestion3", surveyForm.getMatQuestion3()).addValue("matQuestion4", surveyForm.getMatQuestion4())
					.addValue("insQuestion1", surveyForm.getInsQuestion1()).addValue("insQuestion2", surveyForm.getInsQuestion2())
					.addValue("insQuestion3", surveyForm.getInsQuestion3()).addValue("insQuestion4", surveyForm.getInsQuestion4())
					.addValue("insQuestion5", surveyForm.getInsQuestion5()).addValue("insQuestion6", surveyForm.getInsQuestion6())
					.addValue("eqFaQuestion1", surveyForm.getEqFaQuestion1()).addValue("eqFaQuestion2", surveyForm.getEqFaQuestion2())
					.addValue("eqFaQuestion3", surveyForm.getEqFaQuestion3()).addValue("commentsE", surveyForm.getCommentsE())
					.addValue("commentsF", surveyForm.getCommentsF()).addValue("commentsG", surveyForm.getCommentsG());

			template.update(insertQuery.toString(), sqlParameterSource);
		} catch (DataAccessException e) {
			LOGGER.info("SurveyFormImpl {}", e.getMessage());
		}

	}

}

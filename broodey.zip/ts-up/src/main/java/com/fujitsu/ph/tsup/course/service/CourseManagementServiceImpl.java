/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.service;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.course.dao.CourseManagementDao;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.exception.TsupException;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.search.CourseSearchFilter;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Course Management
//Class Name   : CourseManagementServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2020/08/28 | WS) c.lepiten       | Initial Version
//0.02    | 2021/04/20 | WS) i.fajardo       | Updated
//0.03	  | 2021/05/27 | WS) mi.aguinaldo    | Implemented update function
//0.04	  | 2021/07/2  | WS) mi.aguinaldo    | Implemented courseNameExists function
//0.05	  | 2021/07/16  | WS) mi.aguinaldo   | Updated
//0.06	  | 2021/08/05  | WS) mi.aguinaldo   | Updated
//0.07	  | 2021/09/05  | WS) d.dinglasan    | Updated
//==================================================================================================

@Service
public class CourseManagementServiceImpl implements CourseManagementService {

	@Autowired
	CourseManagementDao courseManagementDao;

	@Override
	public void deleteCourseById(Long id) {

		courseManagementDao.deleteCourseById(id);

	}

	@Override
	public Course findCourseById(Long id) {
		return courseManagementDao.findCourseById(id);
	}

	@Override
	public Set<Course> findAllCourses() {

		return courseManagementDao.findAllCourses();
	}

	@Override
	public Page<Course> findAllCourses(Pageable pagable) {

		List<Course> courses = courseManagementDao.findAllCourses(pagable).stream().collect(Collectors.toList());

		int countCourse = courseManagementDao.countCourse();

		return new PageImpl<>(courses, pagable, countCourse);
	}
	
    /*
     * (non-Javadoc)
     * @see
     * com.fujitsu.ph.tsup.course.service.CourseManagementService#findAllCoursesAsPaged(org.springframework.
     * data.domain.Pageable)
     */
	@Override
	public Paged<Course> findAllCoursesAsPaged(Pageable pagable) {
		Page<Course> paginatedCourse = findAllCourses(pagable);
		return new Paged<>(paginatedCourse, Paging.of(paginatedCourse.getTotalPages(),
				pagable.getPageNumber() + 1, pagable.getPageSize()));
	}

	@Override
	public Set<Course> findCoursesByCourseSearchFilter(CourseSearchFilter searchCriteria) {
		Set<Course> courses = courseManagementDao.findCoursesByCourseSearchFilter(searchCriteria, null);
		return courses.isEmpty() ? Collections.emptySet() : courses;
	}

	@Override
	public Page<Course> findCoursesByCourseSearchFilter(CourseSearchFilter courseSearchFilter, Pageable pageable) {
		int countCourse = courseManagementDao.countFoundCourse(courseSearchFilter);

		List<Course> courses = courseManagementDao.findCoursesByCourseSearchFilter(courseSearchFilter, pageable)
				.stream().collect(Collectors.toList());

		return new PageImpl<>(courses, pageable, countCourse);
	}
	
    /*
     * (non-Javadoc)
     * @see
     * com.fujitsu.ph.tsup.course.service.CourseManagementService#findCoursesByCourseSearchFilterAsPaged(com.
     * fujitsu.ph.tsup.search.CourseSearchFilter, org.springframework.data.domain.Pageable)
     */
	@Override
	public Paged<Course> findCoursesByCourseSearchFilterAsPaged(CourseSearchFilter courseSearchFilter,
			Pageable pageable) {
		Page<Course> paginatedCourse = findCoursesByCourseSearchFilter(courseSearchFilter, pageable);
		return new Paged<>(paginatedCourse, Paging.of(paginatedCourse.getTotalPages(),
				pageable.getPageNumber() + 1, pageable.getPageSize()));
	}

	@Override
	public Course findCoursesByName(String name) {
		Optional<Course> course = courseManagementDao.findCoursesByName(name);

		return course.orElse(null);
	}

	@Override
	public boolean courseNameExists(String name) {
		return courseManagementDao.findCoursesByName(name).isPresent();
	}

	/**
	 * Author: WS)I.Fajardo Find if Course name already exists
	 * 
	 * @param name Course name
	 * @param id   Course id
	 * @return isCourseExists
	 */
	@Override
	public boolean courseNameExists(String name, Long id) {
		Predicate<Course> sameId = course -> Objects.equals(course.getId(), id);
		Predicate<Course> sameCourseName = course -> Objects.equals(course.getName(), name);

		return courseManagementDao.findCoursesByName(name).filter(sameId.and(sameCourseName)).isPresent();
	}

	/**
	 * Author: WS)I.Fajardo Creates course.
	 */
	public void createCourse(Course course) {

		try {
			courseManagementDao.createCourse(course);
		} catch (DataAccessException ex) {
			throw new TsupException("Can't create new course", ex.getCause());
		}
	}

	@Override
	public Set<String> loadAllCourseName() {
		return courseManagementDao.loadAllCourseName();
	}

	/**
	 * Update a course
	 * 
	 * @param course; Course object to be update
	 */
	@Override
	public void updateCourse(Course course) {
		String courseName = StringUtils.trim(course.getName());
		if (!courseNameExists(courseName, course.getId()) && courseNameExists(courseName)) {
			throw new TsupException(courseName + ", Course Name Already Exists");
		}

		try {
			courseManagementDao.updateCourse(course);
		} catch (DataAccessException ex) {
			throw new TsupException("Can't update the course", ex.getCause());
		}

	}
}

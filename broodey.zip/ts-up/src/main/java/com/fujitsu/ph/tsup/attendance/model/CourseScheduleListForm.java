package com.fujitsu.ph.tsup.attendance.model;

import java.time.ZonedDateTime;
import java.util.List;
// import java.util.Set;

import org.springframework.format.annotation.DateTimeFormat;

// ==================================================================================================
// $Id:PR03$
// Project Name :Training Sign Up
// System Name :Attendance process
// Class Name :CourseScheduleListForm.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+----------------------------------------+---------------------------------------------------
// 0.01 | 06/23/2020 | WS) J. Iwarat | New Creation
// 0.02 | 06/25/2020 | WS) J. Iwarat | Update
// 0.03 | 08/26/2020 | WS) K.Abad WS) J.Iwarat WS) R.Ramos | Update
// 0.04 | 09/02/2021 | WS) CJ.Zamora    | Update
// 0.05 | 10/08/2021 | WS) MI.Aguinaldo | Update
// ==================================================================================================
/**
 * <pre>
 * JavaBean for CourseScheduleListForm In this Class,Instances or fields of the List of the data for the
 * initial setting of the data base
 * 
 * <pre>
 * 
 * @version 0.03
 * @author k.abad
 * @author j.iwarat
 * @author r.ramos
 */
public class CourseScheduleListForm {
    /**
     * From Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime fromDateTime;

    /**
     * To Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime toDateTime;

    /**
     * List of Course Schedule Form
     */
    private List<CourseScheduleForm> courseSchedules;

    /* Filter course category ID */
    private String courseCategoryId;
    
    /* Filter course category ID */
    private String participantId;

    /* Filter course name ID */
    private String courseNameId;

    /* Filter instructor ID */
    private String instructorId;

    /* Filter venue ID */
    private String venueId;

    /* Filter department ID */
    private String departmentId;

    /* Filter mandatory */
    private String mandatory;

    /* Filter mandatory type */
    private String mandatoryType;

    private String deadline; // added
    
    /* Filter memberRole */
    private String memberRole;

    // pagination code ============
    /** Current Page in pagination */
    private String currentPage;
    // pagination code end=========

    /**
     * @return
     */
    public List<CourseScheduleForm> getCourseSchedules() {
        return courseSchedules;
    }

    /**
     * @param courseSchedules
     */
    public void setCourseSchedules(List<CourseScheduleForm> courseSchedules) {
        this.courseSchedules = courseSchedules;
    }

    /**
     * @return
     */
    public ZonedDateTime getFromDateTime() {
        return fromDateTime;
    }

    /**
     * @param fromDateTime
     */
    public void setFromDateTime(ZonedDateTime fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    /**
     * @return
     */
    public ZonedDateTime getToDateTime() {
        return toDateTime;
    }

    /**
     * @param toDateTime
     */
    public void setToDateTime(ZonedDateTime toDateTime) {
        this.toDateTime = toDateTime;
    }

    @Override
    public String toString() {
        return "CourseScheduleListForm [fromDateTime=" + fromDateTime + ", toDateTime" + toDateTime
                + ", courseSchedules=" + courseSchedules + "]";
    }

    /** Filter course category ID Getter */
    public String getCourseCategoryId() {
        return courseCategoryId;
    }

    /** Filter course category ID Setter */
    public void setCourseCategoryId(String courseCategoryId) {
        this.courseCategoryId = courseCategoryId;
    }

    /** Filter course name ID Getter */
    public String getCourseNameId() {
        return courseNameId;
    }

    /** Filter course name ID Setter */
    public void setCourseNameId(String courseNameId) {
        this.courseNameId = courseNameId;
    }

    /** Filter instructor ID Getter */
    public String getInstructorId() {
        return instructorId;
    }

    /** Filter instructor ID Setter */
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }

    /** Filter venue ID Getter */
    public String getVenueId() {
        return venueId;
    }

    /** Filter venue ID Setter */
    public void setVenueId(String venueId) {
        this.venueId = venueId;
    }

    /** Filter department ID Getter */
    public String getDepartmentId() {
        return departmentId;
    }

    /** Filter department ID Setter */
    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    /** Filter Mandatory Getter */
    public String getMandatory() {
        return mandatory;
    }

    /** Filter Mandatory Setter */
    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    /** Filter Mandatory Type Getter */
    public String getMandatoryType() {
        return mandatoryType;
    }

    /** Filter Mandatory Type Setter */
    public void setMandatoryType(String mandatoryType) {
        this.mandatoryType = mandatoryType;
    }

    // pagination code ===========================
    /** Current Page Getter */
    public String getCurrentPage() {
        return currentPage;
    }

    /** Current Page Setter */
    public void setCurrentPage(String currentPage) {
        this.currentPage = currentPage;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;

    }

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public String getMemberRole() {
		return memberRole;
	}

	public void setMemberRole(String memberRole) {
		this.memberRole = memberRole;
	}

    // pagination code end ========================

}

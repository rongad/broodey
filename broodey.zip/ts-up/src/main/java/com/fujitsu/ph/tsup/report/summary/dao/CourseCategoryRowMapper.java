//==================================================================================================
// Project Name : Training Sign-Up
// System Name : CourseCategoryRowMapper
// Class Name : CourseCategoryRowMapper.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05| WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fujitsu.ph.tsup.report.summary.model.CourseCategory;

/**
 * <pre>
 * Row Mapper for
 * Course Category
 * </pre>
 *
 * @version 1.00
 * @author WS) d.dinglasan
 */
public class CourseCategoryRowMapper implements RowMapper<CourseCategory> {

    /*
     * (non-Javadoc)
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public CourseCategory mapRow(ResultSet rs, int rowNum) throws SQLException {
        final String COL_ID = "ID";
        final String COL_CATEGORY = "CATEGORY";
        return new CourseCategory(rs.getLong(COL_ID), rs.getString(COL_CATEGORY));
    }

}

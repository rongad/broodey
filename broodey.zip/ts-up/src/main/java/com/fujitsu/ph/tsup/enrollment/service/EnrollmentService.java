package com.fujitsu.ph.tsup.enrollment.service;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import com.fujitsu.ph.tsup.common.domain.MemberRole;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.model.Course;

// ==================================================================================================
// $Id:PR01$
// Project Name :Training Sign Up
// System Name :Enrollment Course
// Class Name :EnrollmentService.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 06/24/2020 | WS) T.Oviedo       | New Creation
// 0.02 | 08/24/2020 | WS) J.Yu           | Updated
// 0.03 | 02/23/2021 | WS) E.Ceniza       | Updated
// 0.04 | 05/04/2021 | WS) A.Senamin      | Updated
// 0.05 | 06/14/2021 | WS) L.Celoso       | Updated
// 0.06 | 06/30/2021 | WS) L.Celoso       | Updated
// 0.07 | 07/08/2021 | WS) L.Celoso       | Updated
// 0.07 | 07/16/2021 | WS) MI.Aguinaldo   | Updated
// 0.08 | 08/06/2021 | WS) K.Sevilla      | Updated
// 0.08 | 08/23/2021 | WS) K.Sevilla      | Updated
// 0.09 | 09/13/2021 | WS) K.Sevilla      | Updated
// 0.10 | 10/13/2021 | WS) R.delaCruz     | Updated
// 0.11 | 12/29/2021 | WS) ep.delosreyes  | Removed top learner
// ==================================================================================================

import com.fujitsu.ph.tsup.enrollment.domain.CourseParticipant;
import com.fujitsu.ph.tsup.enrollment.domain.CourseSchedule;
import com.fujitsu.ph.tsup.enrollment.domain.CourseScheduleDetail;
import com.fujitsu.ph.tsup.enrollment.domain.ParticipantTrainingPeriod;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;
import com.fujitsu.ph.tsup.enrollment.model.CourseEnrollmentForm;
import com.fujitsu.ph.tsup.enrollment.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.enrollment.model.EnrolledMemberForm;
import com.fujitsu.ph.tsup.enrollment.model.FileStorageProperties;
import com.fujitsu.ph.tsup.enrollment.model.SearchForm;
import com.fujitsu.ph.tsup.scheduling.model.DepartmentForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;
import com.fujitsu.ph.tsup.search.MyCourseScheduleFilter;

/**
 * <pre>
 * JavaBean for EnrollmentService
 * 
 * <pre>
 * 
 * @version 0.01
 * @author t.oviedo
 */
public interface EnrollmentService {

    /** Sends calendar invite to the successfully enrolled participant */
    void sendCalendarInvite(CourseParticipant courseParticipant);

    /** Finds all scheduled courses based on the given date range */
    Set<CourseSchedule> findAllScheduledCourses(CourseScheduleListForm form, Pageable pageable);

    /** Finds specific details on courses based on the given date range */
    Set<CourseSchedule> findAllMemberScheduledCourses(CourseScheduleListForm form, Pageable pageable);

    /** Finds the course schedule by Id */
    CourseSchedule findCourseScheduleById(Long id);

    /** Enrolls to a scheduled course */
    void enroll(CourseParticipant courseParticipant);

    /** Finds all my enrolled courses starting from this day onwards */
    Set<CourseParticipant> findAllEnrolledCoursesByParticipantId(Long participantId,
            ZonedDateTime fromDateTime, ZonedDateTime toDateTime);

    /** Finds all my enrolled courses base on participant training period */
    Page<CourseEnrollmentForm> findAllEnrolledCoursesBy(ParticipantTrainingPeriod trainingPeriod,
            Pageable pageable);

    /** Finds course participant by id */
    CourseParticipant findCourseParticipantById(Long id);

    /** Decline the course which the participant was previously enrolled */
    void declineCourse(CourseParticipant courseParticipant);

    /** Cancels a scheduled course */
    void cancel(Long id);

    /**
     * Cancel all course schedule below minimum participants
     * 
     * @param courseScheduleSet
     */
    void cancelCourseSchedules(Set<CourseSchedule> courseScheduleSet);

    /**
     * Find all Active Course schedule
     * 
     * @return
     */
    Set<CourseSchedule> findAllActiveCourseSchedule();

    /**
     * Find all course schedule by month/quarter
     * 
     * @param queryBy
     * @return
     */
    Set<CourseSchedule> findAllCouresScheduleByMonthOrQuarter(String queryBy);

    /**
     * Reschedule Course schedule
     * 
     * @param courseScheduleDetail
     */
    void rescheduleCourseScheduleById(CourseScheduleDetail courseScheduleDetail);

    /**
     * Find all course schedule below minimum
     * 
     * @return
     */
    Set<CourseSchedule> findAllCourseScheduleBelowMinimumParticipants();

    /**
     * Find all participant in course schedule
     * 
     * @param courseScheduleId
     * @return
     */
    Set<CourseParticipant> findAllParticipantByCourseScheduleId(Long courseScheduleId);

    /**
     * find all members not enrolled in course schedule
     * 
     * @param courseParticipant
     * @return
     */
    Set<CourseParticipant> findAllMemberNotEnrolledByCourseScheduleId(CourseParticipant courseParticipant);

    /**
     * Search feature - find all participant not enrolled in course schedule and in search criteria
     * 
     * @param searchForm
     * @return
     */
    Set<CourseParticipant> findMemberNotEnrolledByCourseScheduleId(SearchForm searchForm);

    /**
     * Find available course schedule by course id
     * 
     * @param courseId
     * @return
     */
    Set<CourseSchedule> findCourseScheduleByCourseId(CourseSchedule courseSchedule);

    void updateSchedule(CourseParticipant courseParticipant);

    /* Upload Certificate */
    void uploadCertificate(Certificate certificate);

    public String storeFile(MultipartFile file, Long id, FileStorageProperties fileStorageProperties,
            Long userId);

    public Resource loadFileAsResource(String fileName, FileStorageProperties fileStorageProperties);

    /**
     * find all mandatory courses
     * 
     * @param mandatoryCourse
     * @return
     */
    List<String> findCourseScheduleIfMandatory();

    public String findCertificateName(long userId, long courseId);

    /**
     * <pre>
     * Method for loading all course category in View Enroll Course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<CourseCategory> findAllCourseCategory();

    /**
     * <pre>
     * Method for loading all course name in View Enroll Course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<Course> findAllCourseName();

    /**
     * <pre>
     * Method for loading all instructor in View Enroll Course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<InstructorForm> findAllInstructor();

    /**
     * <pre>
     * Method for loading all venue in View Enroll Course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<VenueForm> findAllVenue();

    /**
     * <pre>
     * Method for loading all department in View Enroll Course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<DepartmentForm> findAllDepartment();

    /**
     * <pre>
     * Method for loading all member role in View Enroll Course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<MemberRole> findAllMemberRole();

    /**
     * <pre>
     * Method for removing selected enrolled members from a course schedule
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    void removeBatchMember(EnrolledMemberForm enrolledMember);

    /**
     * <pre>
     * Method for enrolling selected enrolled members to a course schedule
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    void enrollBatchMember(EnrolledMemberForm enrolledMember);

    /**
     * <pre>
     * Method for counting the number of available course
     * 
     * @author l.celoso
     *
     *         <pre>
     * @param string 
     */
    int countCourse(CourseScheduleListForm form);

    /**
     * <pre>
     * Sends multiple calendar invite for selected enrolled members in a course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    void sendBatchCalendarInvite(Long courseScheduleId, Set<CourseParticipant> courseParticipant);

    /**
     * <pre>
     * Get all emails of members to be enrolled
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<CourseParticipant> getAllEmails(String batchId);

    // Advanced Search
    Page<CourseEnrollmentForm> findCoursesByMyCourseScheduleFilter(
            MyCourseScheduleFilter myCourseScheduleFilter, Pageable pageable);

}

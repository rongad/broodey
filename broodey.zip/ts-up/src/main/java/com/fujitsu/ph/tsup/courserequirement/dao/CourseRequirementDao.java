package com.fujitsu.ph.tsup.courserequirement.dao;

import java.util.List;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.EmployeeChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseScheduleDetail;

//===============================================================
//$Id: PR30$
//Project Name: Training Sign Up
//System Name : Course Checklist 
//Class Name: CourseRequirementDao.java
//
//<<Modification History>>
//Version | Date       | Updated by          | Content
//--------+------------+---------------------+-----------------
//0.01    | 10/18/2021 | WS) A.Abellanosa    | Initial Creation
//0.02    | 10/29/2021 | WS) e.delosreyes    | Added updateCourseRequirement
//0.03    | 11/05/2021 | WS) e.delosreyes    | Added getCourseScheduleDetails
//0.04    | 11/05/2021 | WS) a.abellanosa    | remove getAttendeeChecklist
//===============================================================
/**
* <pre>
* The data access interface for course requirement related database access
* 
* </pre>
*
* @version 0.04
* @author a.abellanosa
*
*/
public interface CourseRequirementDao {

	//This method will get the list of courses
	List<Course> getCourses();
	
	/**
	 * <pre>
	 * This method will get the list of Course Requirements
	 * </pre>
	 * 
	 * @param courseId
	 * @return
	 */
	List<CourseChecklist> getCourseRequirements(Integer courseId);
	
	/**
	 * <pre>
	 * This method will create a course requirement
	 * </pre>
	 * 
	 * @param courseRequirement
	 */
	void createCourseRequirement(CourseChecklist courseRequirement);
	
	/**
	 * <pre>
	 * This method will delete a course requirement
	 * </pre>
	 * 
	 * @param courseRequirementId
	 */
	void deleteCourseRequirement(Integer courseRequirementId);
	
	/**
	 * <pre>
	 * This method will update the checklist of attendee
	 * </pre>
	 * 
	 * @param employeeChecklists
	 */
	void updateAttendeeChecklist(EmployeeChecklist employeeChecklists);
	
	/**
	 * <pre>
	 * This method will update the course checklist
	 * </pre>
	 * 
	 * @param courseChecklist
	 */
	void updateCourseRequirement(CourseChecklist courseChecklist);


	/**
	 * <pre>
	 * This method will create the participant checklist
	 * </pre>
	 * 
	 * @param participanChecklist
	 */
	void createParticipantCourseChecklist(EmployeeChecklist participanChecklist);

	/**
	 * <pre>
	 * This method will creturn the list of CourseScheduleDetail
	 * </pre>
	 * 
	 * @param courseId
	 */
	List<CourseScheduleDetail> getCourseScheduleDetails(Integer courseId);

	/**
	 * <pre>
	 * This method will return the list of attendees of the course schedule
	 * </pre>
	 * 
	 * @param courseScheduleId
	 */
	List<CourseParticipant> getCourseParticipants(Integer courseScheduleId);

	/**
	 * <pre>
	 * This method will return the list of checklist of the participant
	 * </pre>
	 * 
	 * @param participantId
	 */
	List<EmployeeChecklist> getParticipantChecklists(Integer participantId);
}

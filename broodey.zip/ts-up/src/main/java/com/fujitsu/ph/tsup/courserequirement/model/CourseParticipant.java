package com.fujitsu.ph.tsup.courserequirement.model;

import java.time.ZonedDateTime;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : CourseChecklist
 * Class Name   : CourseParticipant.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * 0.02    | 2021/11/10 | WS) je.subelario      | Revised Comments
 * ===================================================================================================
 */

 /**
 * <pre>
 * The model for Course Participant
 * 
 * <pre>
 * 
 * @version 0.02
 * @author je.subelario 
 */

public class CourseParticipant {
    private int id;
    private ZonedDateTime registrationDate;
    private Employee participant;
    private CourseSchedule courseSchedule;

    public CourseParticipant() {

    }

    public CourseParticipant(int id, ZonedDateTime registrationDate, Employee participant,
            CourseSchedule courseSchedule) {
        this.id = id;
        this.registrationDate = registrationDate;
        this.participant = participant;
        this.courseSchedule = courseSchedule;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ZonedDateTime getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(ZonedDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }

    public Employee getParticipant() {
        return participant;
    }

    public void setParticipant(Employee participant) {
        this.participant = participant;
    }

    public CourseSchedule getCourseSchedule() {
        return courseSchedule;
    }

    public void setCourseSchedule(CourseSchedule courseSchedule) {
        this.courseSchedule = courseSchedule;
    }

    
}

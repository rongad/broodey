/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.ZonedDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for Dev
//Class Name   : SummaryGSTDevDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | ---        | WS) r.rivero          | Initial Version
//0.01    | ---        | WS) g.cabiling        | Initial Version
//0.02    | 2021/06/14 | WS) m.padaca          | Updated
//0.03    | 2021/10/15 | WS) r.buot            | Updated
//==================================================================================================
/**
 * <pre>
 * The implementation of G3CC standardization training for dev dao
 * </pre>
 * 
 * @version 0.02
 * @author r.rivero
 * @author g.cabiling
 * @author m.padaca
 * @author r.buot
 *
 */

@Repository
public class SummaryGSTDevDaoImpl implements SummaryGSTDevDao {

    // Call NamedParameterJdbcTemplate
    @Autowired
    private NamedParameterJdbcTemplate template;

    /**
     * <pre>
     * Find All Courses By Category ID
     * </pre>
     * @return courses
     */
    @Override
    public Set<Long> findAllCoursesByCategoryId() {
    	
        String query = "SELECT C.id FROM tsup.COURSE C "
                + "LEFT JOIN tsup.COURSE_CATEGORY CC ON CC.ID = C.COURSE_CATEGORY_ID "
                + "WHERE CC.CATEGORY = :category";
        
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("category",
                "JDU Standardization Training");
        List<Long> coursesList = template.queryForList(query, sqlParameterSource, Long.class);
        Set<Long> courses = new LinkedHashSet<>(coursesList);
        return courses;
    }

    /**
     * <pre>
     * Find All JDU Dev
     * </pre>
     * @return employee
     */
    @Override
    public Set<Long> findAllJDUDev() {
    	
        String query = "SELECT E.id FROM tsup.EMPLOYEE E LEFT JOIN tsup.DEPARTMENT D"
                + " ON E.DEPARTMENT_ID = D.ID WHERE D.DEPARTMENT_NAME = :dept_name";
        
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("dept_name", "FDC-G3CC");
        List<Long> employeeList = template.queryForList(query, sqlParameterSource, Long.class);
        Set<Long> employee = new LinkedHashSet<>(employeeList);
        return employee;
    }

    @Override
    public int findAllJDUDevLastWeek() {
        // TODO Auto-generated method stub
        return 0;
    }

     @Override
    public int findAllJDUExisitingMembers() {
        // TODO Auto-generated method stub
         return 0;
    }

    @Override
    public int findAllJDUNewMembers() {
        // TODO Auto-generated method stub
        return 0;
    }
    
    /**
     * <pre>
     * Find Total Course of JDU Dev Finished
     * </pre>
     * @param course_id
     * @param participant_id
     * @param reportDate
     * @return no_of_course
     */
    @Override
    public int findTotalCoursePerEmployee(Set<Long> course_id, Long participant_id, ZonedDateTime reportDate) {
        try {
	    	String query = "SELECT COUNT(DISTINCT course_id)" 
	                +" FROM tsup.course_attendance CA" 
	                +" LEFT Join tsup.course_schedule_detail CSD ON" 
	                +" CSD.id = CA.course_schedule_detail_id" 
	                +" LEFT Join tsup.course_schedule CS" 
	                +" ON CS.id=CSD.course_schedule_id"
	                +" WHERE CS.status = 'D'"
	                +" AND CA.status = 'P'"
	                +" AND CS.course_id IN (:courses)"
	                +" AND CA.participant_id = :participant_id"
	        		+" AND ca.log_out_dateTime <= :reportDate;";
	    	
	        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("courses", course_id)
	                .addValue("participant_id", participant_id)
	        		.addValue("reportDate", reportDate.toOffsetDateTime());
	        int no_of_course = template.queryForObject(query, sqlParameterSource, Integer.class);
	
	        return no_of_course;
        } catch(NullPointerException e) {
    		return 0;
    	}
    }

    /**
     * <pre>
     * Find Total Course of JDU Dev Finished Last Week
     * </pre>
     * @param reportDate
     * @param course_id
     * @param participant_id
     * @return no_of_course
     */
    @Override
    public int findTotalCoursePerEmployeeLastWeek(ZonedDateTime reportDate,
            Set<Long> course_id, Long participant_id) {
    	try {
	        String query = "SELECT COUNT(DISTINCT course_id)"  
	                +" FROM  tsup.course_attendance CA"  
	                +" LEFT Join tsup.course_schedule_detail CSD"  
	                +" ON CSD.id = CA.course_schedule_detail_id" 
	                +" LEFT Join tsup.course_schedule CS" 
	                +" ON CS.id=CSD.course_schedule_id"
	                +" WHERE CS.status = 'D'" 
	                +" AND CA.status = 'P'" 
	                +" AND CS.course_id IN (:courses)" 
	                +" AND CA.participant_id = :participant_id"
	                +" and (ca.log_out_dateTime <= date_trunc('week', :reportDate - interval '1 week'));";
	        
	        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("courses", course_id)
	                .addValue("participant_id", participant_id)
					.addValue("reportDate", reportDate.toOffsetDateTime());
			        int no_of_course = template.queryForObject(query, sqlParameterSource, Integer.class);
	        return no_of_course;
    	} catch(NullPointerException e) {
            return 0;
        }
    }

}

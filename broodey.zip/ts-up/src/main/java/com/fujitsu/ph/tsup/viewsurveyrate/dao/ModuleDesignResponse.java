/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.dao;

import com.fujitsu.ph.tsup.viewsurveyrate.domain.Ratings;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : ModuleDesignResponse.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

public class ModuleDesignResponse {
    
    private Ratings question1Ratings;
    private Ratings question2Ratings;
    private Ratings question3Ratings;
    private Ratings question4Ratings;

    public ModuleDesignResponse() {
    }

    private ModuleDesignResponse(Builder builder) {
        this.question1Ratings = builder.question1Ratings;
        this.question2Ratings = builder.question2Ratings;
        this.question3Ratings = builder.question3Ratings;
        this.question4Ratings = builder.question4Ratings;
    }

    /**
     * @return the question1Ratings
     */
    public Ratings getQuestion1Ratings() {
        return question1Ratings;
    }

    /**
     * @return the question2Ratings
     */
    public Ratings getQuestion2Ratings() {
        return question2Ratings;
    }

    /**
     * @return the question3Ratings
     */
    public Ratings getQuestion3Ratings() {
        return question3Ratings;
    }

    /**
     * @return the question4Ratings
     */
    public Ratings getQuestion4Ratings() {
        return question4Ratings;
    }



    /**
     * Creates builder to build {@link ModuleDesignResponse}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link ModuleDesignResponse}.
     */
    public static final class Builder {
        private Ratings question1Ratings;
        private Ratings question2Ratings;
        private Ratings question3Ratings;
        private Ratings question4Ratings;

        private Builder() {
        }

        public Builder withQuestion1Ratings(Ratings question1Ratings) {
            this.question1Ratings = question1Ratings;
            return this;
        }
        
        public Builder withQuestion1Ratings(Integer question1Ratings) {
            this.question1Ratings = Ratings.fromValue(question1Ratings);
            return this;
        }

        public Builder withQuestion2Ratings(Ratings question2Ratings) {
            this.question2Ratings = question2Ratings;
            return this;
        }
        
        public Builder withQuestion2Ratings(Integer question2Ratings) {
            this.question2Ratings = Ratings.fromValue(question2Ratings);
            return this;
        }

        public Builder withQuestion3Ratings(Ratings question3Ratings) {
            this.question3Ratings = question3Ratings;
            return this;
        }
        
        public Builder withQuestion3Ratings(Integer question3Ratings) {
            this.question3Ratings = Ratings.fromValue(question3Ratings);
            return this;
        }

        public Builder withQuestion4Ratings(Ratings question4Ratings) {
            this.question4Ratings = question4Ratings;
            return this;
        }
        
        public Builder withQuestion4Ratings(Integer question4Ratings) {
            this.question4Ratings = Ratings.fromValue(question4Ratings);
            return this;
        }

        public ModuleDesignResponse build() {
            return new ModuleDesignResponse(this);
        }
    }

}

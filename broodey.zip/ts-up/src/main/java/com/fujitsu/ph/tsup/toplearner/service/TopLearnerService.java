package com.fujitsu.ph.tsup.toplearner.service;

import java.time.ZonedDateTime;
import java.util.List;

import com.fujitsu.ph.tsup.enrollment.model.TopLearnerForm;

/** ==================================================================================================
  * Id:PR32
  * Project Name :Training Sign Up
  * System Name : Top Learners
  * Class Name : TopLearnerService.java
  *
  * <<Modification History>>
  * Version | Date       | Updated By         | Content
  * --------+------------+-----------------------+---------------------------------------------------
  * 0.01    | 12/29/2021 | WS) ep.delosreyes  | Initial Create
  * ==================================================================================================
  */

public interface TopLearnerService {
    /**
     * Find top learners
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param numberOfResult
     * @return List<TopLearnerForm>
     */
    List<TopLearnerForm> findTopLearner(ZonedDateTime fromDateTime, ZonedDateTime toDateTime, int numberOfResult);
}

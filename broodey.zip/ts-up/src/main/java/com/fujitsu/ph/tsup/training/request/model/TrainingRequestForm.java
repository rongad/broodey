package com.fujitsu.ph.tsup.training.request.model;

import java.time.ZonedDateTime;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

//==================================================================================================
//Project Name :Training Sign Up
//System Name  :Training Request
//Class Name   :TrainingRequestForm.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 07/13/2021 | WS) L.Celoso          | New Creation
//==================================================================================================
/**
 * <pre>
 * Form for the training request
 * 
 * <pre>
 * 
 * @version 0.01
 * @author L.Celoso
 */
public class TrainingRequestForm {
	
	private long id;
	
	private String courseName;
	
	@Min(value = 1, message = "This field is required.")
    private int minRequired;
	
	private int maxRequired;

	/**
     *	Start Date and Time
     */
	@NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private ZonedDateTime startDateTime;
	
	/**
     *	End Date and Time
     */
	@NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private ZonedDateTime endDateTime;
	
	private double duration;
	
    private String courseDetails;
	
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
    
	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public void setMinRequired(int minRequired) {
        this.minRequired = minRequired;
    }
    
    public int getMinRequired() {
        return minRequired;
    }
    
    public void setMaxRequired(Integer maxRequired) {
        this.maxRequired = maxRequired;
    }
    
    public int getMaxRequired() {
        return maxRequired;
    }
    
    public ZonedDateTime getStartDateTime() {
		return startDateTime;
	}
    
	public void setStartDateTime(ZonedDateTime startDateTime) {
		this.startDateTime = startDateTime;
	}
	
    public ZonedDateTime getEndDateTime() {
		return endDateTime;
	}
    
    public void setEndDateTime(ZonedDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}
	
    public void setDuration(double duration) {
		this.duration = duration;
	}
	
    public double getDuration() {
		return duration;
	}
    
    public String getCourseDetails() {
		return courseDetails;
	}

	public void setCourseDetails(String courseDetails) {
		this.courseDetails = courseDetails;
	}
    
}

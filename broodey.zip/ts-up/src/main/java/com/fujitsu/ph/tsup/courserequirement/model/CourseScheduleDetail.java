package com.fujitsu.ph.tsup.courserequirement.model;

import java.time.ZonedDateTime;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : CourseChecklist
 * Class Name   : CourseScheduleDetail.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * 0.02    | 2021/11/10 | WS) je.subelario      | Revised Comments
 * ===================================================================================================
 */

 /**
 * <pre>
 * The model for Course Schedule Detail
 * 
 * <pre>
 * 
 * @version 0.02
 * @author je.subelario 
 */

public class CourseScheduleDetail {
    private Long id;
    private CourseSchedule courseSchedule;
    private ZonedDateTime scheduledStart;
    private ZonedDateTime scheduledEnd;
    private Integer duration;
    private ZonedDateTime rescheduleScheduledStart;
    private ZonedDateTime rescheduleScheduledEnd;

    public CourseScheduleDetail() {
        
    }

    public CourseScheduleDetail(Long id, CourseSchedule courseSchedule, ZonedDateTime scheduledStart,
            ZonedDateTime scheduledEnd, Integer duration, ZonedDateTime rescheduleScheduledStart,
            ZonedDateTime rescheduleScheduledEnd) {
        this.id = id;
        this.courseSchedule = courseSchedule;
        this.scheduledStart = scheduledStart;
        this.scheduledEnd = scheduledEnd;
        this.duration = duration;
        this.rescheduleScheduledStart = rescheduleScheduledStart;
        this.rescheduleScheduledEnd = rescheduleScheduledEnd;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CourseSchedule getCourseSchedule() {
        return courseSchedule;
    }

    public void setCourseSchedule(CourseSchedule courseSchedule) {
        this.courseSchedule = courseSchedule;
    }

    public ZonedDateTime getScheduledStart() {
        return scheduledStart;
    }

    public void setScheduledStart(ZonedDateTime scheduledStart) {
        this.scheduledStart = scheduledStart;
    }

    public ZonedDateTime getScheduledEnd() {
        return scheduledEnd;
    }

    public void setScheduledEnd(ZonedDateTime scheduledEnd) {
        this.scheduledEnd = scheduledEnd;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public ZonedDateTime getRescheduleScheduledStart() {
        return rescheduleScheduledStart;
    }

    public void setRescheduleScheduledStart(ZonedDateTime rescheduleScheduledStart) {
        this.rescheduleScheduledStart = rescheduleScheduledStart;
    }

    public ZonedDateTime getRescheduleScheduledEnd() {
        return rescheduleScheduledEnd;
    }

    public void setRescheduleScheduledEnd(ZonedDateTime rescheduleScheduledEnd) {
        this.rescheduleScheduledEnd = rescheduleScheduledEnd;
    }

    
}

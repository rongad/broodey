package com.fujitsu.ph.tsup.enrollment.certificate.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fujitsu.ph.tsup.enrollment.certificate.dao.ManageCertificateDao;
import com.fujitsu.ph.tsup.enrollment.certificate.model.ManageCertificate;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;
import com.fujitsu.ph.tsup.enrollment.model.FileStorageProperties;


//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Manage Certificate
//Class Name   : ManageCertificateServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/08/11 | WS) hl.berja       | Initial Version
//==================================================================================================

/**
 * <pre>
 * It is the implementation of the manage certificate service
 * In this class, it implements the ManageCertificateService class for the initial setting of the database
 * </pre>
 * 
* @author WS) hl.berja
* 
* */
@Service
public class ManageCertificateServiceImpl implements ManageCertificateService {
    private static Logger logger = LoggerFactory.getLogger(ManageCertificateServiceImpl.class);
    
    @Autowired
    private ManageCertificateDao manageCertificateDao; 
    
    
    /**
     * <pre>
     * Load all certificates by employee given with a Pageable object call
     * manageCertificateDao.loadAllCertificates using the given pageable object and return the result
     * </pre>
     * 
     * @param pageable Pageable
     * @return ManageCertificate Page
     */
    
    @Override 
    public Page<ManageCertificate> loadAllCertificates(Pageable pageable) {
        
        List<ManageCertificate> certificates = manageCertificateDao.loadAllCertificates(pageable).stream()
                .collect(Collectors.toList());
        int countCertificates = manageCertificateDao.countCertificates();

        return new PageImpl<>(certificates, pageable, countCertificates);
    }
    
    /**
     * <pre>
     * Delete a certificate given with a certificate id call
     * manageCertificateDao.deleteCertificateByid using the given certificate id and return the result
     * </pre>
     * 
     * @param id Long
     * @return Boolean if certificate was deleted or not.
     */

    @Override
    public Boolean deleteCertificateById(Long id) {
        return manageCertificateDao.deleteCertificateById(id);
    }
    
    /**
     * <pre>
     * Update a certificate given with a given Certificate object call
     * manageCertificateDao.updateCertificate using the given certificate object and return the result
     * </pre>
     * 
     * @param certificate Certificate
     * @return Boolean if certificate was updated or not.
     */

    @Override
    public Boolean updateCertificate(Certificate certificate) {
        return manageCertificateDao.updateCertificate(certificate);
    }
    
    /**
     * <pre>
     * Store file in the specified directory
     * </pre>
     * 
     * @param file MultipartFile
     * @param id Long
     * @param fileStorageProperties FileStorageProperties
     * @param userId Employee id
     * @return the file name as a String
     */

    @Override
    public String storeFile(MultipartFile file, Long id, FileStorageProperties fileStorageProperties,
            Long userId) {
        // Normalize file name
        Path fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir()).toAbsolutePath()
                .normalize();
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        fileName = userId + "_" + id + "_" + fileName;

        try {
            // Check if the file's name contains invalid characters
            Files.createDirectories(fileStorageLocation);
            if (fileName.contains("..")) {
                throw new IllegalArgumentException(
                        "Sorry! Filename contains invalid path sequence " + fileName);
            }

            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = fileStorageLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return fileName;
        } catch (IOException ex) {
            throw new IllegalArgumentException("Could not store file " + fileName + ". Please try again!",
                    ex);
        } catch (Exception ex) {
            throw new IllegalArgumentException(
                    "Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    /**
     * <pre>
     * Get the certificate in the directory for viewing and downloading
     * </pre>
     * 
     * @param fileName String
     * @param fileStorageProperties FileStorageProperties
     * @return a Resource which contains the certificate file
     */
    
    @Override
    public Resource loadFileAsResource(String fileName, FileStorageProperties fileStorageProperties) {
        fileName = fileName.substring(35).replaceAll("%20", " ");

        try {
            Path filePath = Paths.get(fileStorageProperties.getUploadDir()).toAbsolutePath().normalize()
                    .resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if (resource.exists()) {
                return resource;
            } else {
                throw new IllegalArgumentException("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
            throw new IllegalArgumentException("File not found " + fileName, ex);
        }
    }
    
    /**
     * <pre>
     * Get the certificate download URI with the given employee id and course id
     * manageCertificateDao.getCertificateDownloadUri eith the give employeeId and courseId
     * and return the result
     * </pre>
     * 
     * @param userId Employee id
     * @param courseId Course id
     * @return a 
     */
    

    @Override
    public String getCertificateDownloadUri(Long userId, Long courseId) {
        return manageCertificateDao.getCertificateDownloadUri(userId, courseId);
    }

}

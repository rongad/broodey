//==================================================================================================
// Project Name : Training Sign-Up
// System Name : NonMandatoryCoursesReportController
// Class Name : NonMandatoryCoursesReportController.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.web;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fujitsu.ph.tsup.report.summary.model.CourseCategory;
import com.fujitsu.ph.tsup.report.summary.model.MemberNonMandatoryCoursesCompletionForm;
import com.fujitsu.ph.tsup.report.summary.service.NonMandatoryCoursesReportService;

/**
 * <pre>
 * Controller for
 * Members' completion report of Non Mandatory Courses
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
@Controller
@RequestMapping("/report/summary")
public class NonMandatoryCoursesReportController {

    @Autowired
    private NonMandatoryCoursesReportService nonMandatoryCoursesReportService;

    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(NonMandatoryCoursesReportController.class);

    /**
     * Return report page
     */
    private static final String NON_MANDATORY_COURSES_REPORT_PAGE = "reports/summaryNonMandatoryCourses";

    /**
     * <pre>
     * Get list of non-mandatory course categories
     * </pre>
     * 
     * @return Course Category List
     */
    private List<CourseCategory> getAllNonMandatoryCourseCategory() {
        Set<CourseCategory> courseCategorySet = nonMandatoryCoursesReportService
                .getAllNonMandatoryCourseCategory();
        return courseCategorySet.stream().sorted(Comparator.comparing(CourseCategory::getCourseCategoryName))
                .collect(Collectors.toList());
    }

    @GetMapping("/nonMandatory")
    public String viewReportPageByCourseCategory(
            @RequestParam(value = "courseCategoryID", required = false) Long courseCategoryID,
            Model model) {

        // For Course Category field (drop-down values)
        List<CourseCategory> courseCategoryList = getAllNonMandatoryCourseCategory();
        model.addAttribute("courseCategoryList", courseCategoryList);

        if (courseCategoryID != null) {

            MemberNonMandatoryCoursesCompletionForm completionForm = nonMandatoryCoursesReportService
                    .getSummary(courseCategoryID);

            List<CourseCategory> filterList = courseCategoryList.stream()
                    .filter(cc -> cc.getId().equals(courseCategoryID)).collect(Collectors.toList());

            if (!filterList.isEmpty()) {
                String courseCategoryName = filterList.get(0).getCourseCategoryName();
                logger.debug("Category: {}", courseCategoryName);
                completionForm.getCourseCategory().setCourseCategoryName(courseCategoryName);
            }

            model.addAttribute("courseCategory", completionForm.getCourseCategory());
            model.addAttribute("membersAttendance", completionForm.getMemberList());
        }
        return NON_MANDATORY_COURSES_REPORT_PAGE;
    }
}

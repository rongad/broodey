package com.fujitsu.ph.tsup.instructorconduct.domain;

import java.time.ZonedDateTime;

//=======================================================
//$Id: PR17$//Project Name: Training Sign Up
//Class Name: CourseSchedule.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja    | New Creation
//0.02    | 10/25/2021 | WS) L.Celoso    | Added a method to identify Status using Status Code 
//=======================================================

/**
* <pre>
* The Course Schedule Model.
* This uses a Builder Pattern 
* <pre>
* @version 0.01
* @author j.lanaja
*
*/


public class CourseSchedule {
    
    /**
     * Id
     */
    private Long id;
    
    /**
     * Course Id
     */
    private Long courseId;
    
    /**
     * Course Name
     */
    private String courseName;
    
    /**
     * Instructor Id
     */
    private Long instructorId;
    
    /**
     * Instructor Last Name
     */
    private String instructorLastName;
    
    /**
     * Instructor First Name
     */
    private String instructorFirstName;
    
    /**
     * Venue Id
     */
    private Long venueId;
    
    /**
     * Venue Name
     */
    private String venueName;
    
    private ZonedDateTime scheduledStartDateTime;
    
    /**
     * End Date and Time
     */
    private ZonedDateTime scheduledEndDateTime;
    
    /**
     * Status
     */
    private char status;
    
    /**
     * Total Participants
     */
    private int totalParticipants;
    
    /**
     * Course Details
     */
    private String courseDetails;

    /**
     * <pre>
     * Creates an instance of the CourseSchedule using the given builder class.
     * <pre>
     * 
     * @param builder
     */
    private CourseSchedule(Builder builder) {
        this.id = builder.id;
        this.courseId = builder.courseId;
        this.courseName = builder.courseName;
        this.instructorId = builder.instructorId;
        this.instructorLastName = builder.instructorLastName;
        this.instructorFirstName = builder.instructorFirstName;
        this.venueId = builder.venueId;
        this.venueName = builder.venueName;
        this.status = builder.status;
        this.totalParticipants = builder.totalParticipants;
        this.courseDetails = builder.courseDetails;
        this.scheduledStartDateTime = builder.scheduledStartDateTime;
        this.scheduledEndDateTime = builder.scheduledEndDateTime;
    }
    
    
    public Long getId() {
        return id;
    }

    public Long getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public Long getInstructorId() {
        return instructorId;
    }


    public String getInstructorLastName() {
        return instructorLastName;
    }


    public String getInstructorFirstName() {
        return instructorFirstName;
    }


    public Long getVenueId() {
        return venueId;
    }


    public String getVenueName() {
        return venueName;
    }

    public ZonedDateTime getScheduledStartDateTime() {
        return scheduledStartDateTime;
    }
    
    public ZonedDateTime getScheduledEndDateTime() {
        return scheduledEndDateTime;
    }

    public char getStatus() {
        return status;
    }

    public String getStatusValue() {
        return getStatusValue(status);
    }
    
    public String getStatusValue(char status) {
        switch (status) {
            case 'A':
                return "Active";
            case 'O':
                return "Ongoing";
            case 'D':
                return "Done";
            case 'C':
                return "Closed";

            default:
               throw new IllegalStateException("Course Schedule status of "+ status + " not found!");
        }
    }
    
    public int getTotalParticipants() {
		return totalParticipants;
	}


	public String getCourseDetails() {
		return courseDetails;
	}

	public String getInstructorName() {
	    return instructorLastName + ", " + instructorFirstName;
	}
	
	/**
     * <pre>
     * The builder class of the course schedule. 
     * The builder is a public static member class of CourseSchedule
     * <pre>
     */
    public static class Builder {

		/**
         * Id
         */
        private Long id;
        
        
        /**
         * Course Id
         */
        private Long courseId;
        
        /**
         * Course Name
         */
        private String courseName;
        
        
        /**
         * Instructor Id
         */
        private Long instructorId;
        
        /**
         * Instructor Last Name
         */
        private String instructorLastName;
        
        /**
         * Instructor First Name
         */
        private String instructorFirstName;
        
        /**
         * Venue Id
         */
        private Long venueId;
        
        /**
         * Venue Name
         */
        private String venueName;
        
        /**
         * Start Date and Time
         */
        private ZonedDateTime scheduledStartDateTime;
        
        /**
         * End Date and Time
         */
        private ZonedDateTime scheduledEndDateTime;
        
        /**
         * Status
         */
        private char status;
        
        /**
         * Total Participants
         */
        private int totalParticipants;
        
        /**
         * Course Details
         */
        private String courseDetails;
        
        
        /**
         * <pre>
         * Creates a new instance of Builder for creating a course schedule.
         * It validates and sets the argument into the Builder instance variables. 
         * This method is used for setting the data from the database.
         * <pre>
         * @param Id
         * @param courseId
         * @param courseName
         * @param instuctorId
         * @param instuctorLastName
         * @param instuctorFirstName
         * @param venueId
         * @param venueName
         * @param status
         */
    
        public Builder(Long id, Long courseId,  String courseName,Long instructorId, String instructorLastName, 
            String instructorFirstName, Long venueId, String venueName, char status, int totalParticipants, ZonedDateTime scheduledStartDateTime, 
            ZonedDateTime scheduledEndDateTime) {
        
        validateId(id);
        validateCourseId(courseId);
        validateInstructorId(instructorId);
        validateVenueId(venueId);
        validateCourseName(courseName);
        validateInstructorLastName(instructorLastName);
        validateInstructorFirstName(instructorFirstName);
        validateVenueName(venueName);
        validateStatus(status);
        validateTotalParticipants(totalParticipants);
        validateScheduledStartDateTime(scheduledStartDateTime);
        
        
        this.id = id;
        this.courseId = courseId;
        this.courseName = courseName;
        this.instructorId = instructorId;
        this.instructorLastName = instructorLastName;
        this.instructorFirstName = instructorFirstName;
        this.venueId = venueId;
        this.venueName = venueName;
        this.status = status;
        this.totalParticipants = totalParticipants;
        this.scheduledStartDateTime = scheduledStartDateTime;
        this.scheduledEndDateTime = scheduledEndDateTime; 
        }
        
        /**
         * <pre>
         * Creates a new instance of Builder for creating a course schedule.
         * It validates and sets the argument into the Builder instance variables. 
         * This method is used for changing status of course schedule
         * <pre>
         * 
         * @param Id
         * @param courseId
         */
        public Builder(Long id, Long courseId) {
        
            validateId(id);
            validateCourseId(courseId);
            
            this.id = id;
            this.courseId = courseId;
        }

        
        /**
         * <pre>
         * Validates and add the argument into the Builder instance variables. T
         * This method is used in displaying Course Details in Course Schedule Delete Form.
         * <pre>
         * 
         * @param courseDetails
         * @return builder
         */
        public Builder addCourseDetail(String courseDetails) {
            
            validateCourseDetails(courseDetails);
            this.courseDetails = courseDetails;
        
            return this;    
        }

         /**
         * Creates a new instance of the course schedule.
         * 
         * @return new CourseSchedule(this)
         */
        public CourseSchedule build() {
        
            return new CourseSchedule(this);
        }
        
        /**
         * <pre>
         * Validate the id based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param id
         */
        private void validateId(Long id) {
            if(id == null || id == 0L) {
             throw new IllegalArgumentException("ID should not be empty.");
            }
        }
        
        /**
         * <pre>
         * Validate the course id based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param courseId
         */
        private void validateCourseId(Long courseId) {  
            if(courseId == null || courseId == 0L) {
             throw new IllegalArgumentException("Course should not be empty.");
            }
        }
        
        /**
         * <pre>
         * Validate the instructor id based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param instructorId
         */
        private void validateInstructorId(Long instructorId) {
            if(instructorId == null || instructorId == 0L) {
                throw new IllegalArgumentException("Instructor name should not be empty.");
            }
        }
    
        /**
         * <pre>
         * Validate the venue id based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param venueId
         */
        private void validateVenueId(Long venueId) {
            if(venueId == null || venueId == 0L) {
                throw new IllegalArgumentException("Venue should not be empty.");
            }
        }
        
        /**
         * <pre>
         * Validate the course name based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param courseName
         */
        private void validateCourseName(String courseName) {
            if(courseName == null || courseName.isEmpty()) {
                throw new IllegalArgumentException("Course name should not be empty.");
            }
        }
            
        /**
         * <pre>
         * Validate the instructor last name based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param instructorLastName
         */
        private void validateInstructorLastName(String instructorLastName) {
            if(instructorLastName == null || instructorLastName.isEmpty()) {
                throw new IllegalArgumentException("Instructor name should not be empty.");
            }
        }
        
        /**
         * <pre>
         * Validate the instructor first name based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param instructorFirstName
         */
        private void validateInstructorFirstName(String instructorFirstName) {
            if(instructorFirstName == null || instructorFirstName.isEmpty()) {
                throw new IllegalArgumentException("Instructor name should not be empty.");
            }
        }
        
        /**
         * <pre>
         * Validate the venue name based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param venueName
         */
        private void validateVenueName(String venueName) {
            if(venueName == null || venueName.isEmpty()) {
                throw new IllegalArgumentException("Venue should not be empty.");
            }
        }
        
        /**
         * <pre>
         * Validate the status based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param status
         */
        private void validateStatus(char status) {
            if(status != 'O' && status != 'D' && status != 'A' && status != 'C') {
                throw new IllegalArgumentException("Status should be 'A','C','O' or 'D' only");
        }
    }
    
        private void validateTotalParticipants(int totalParticipants) {
        	 if(totalParticipants < 0 ) {
                 throw new IllegalArgumentException("Total Participants value should be numeric");
        	 }
        }
        
        private void validateCourseDetails(String courseDetails) {
       	 if(venueName == null || venueName.isEmpty()) {
                throw new IllegalArgumentException("Course details should not be empty.");
       	     }
        }
        
        /**
         * <pre>
         * Validate the Scheduled Start Date and Time based on the condition below. 
         * If it is invalid then throw an IllegalArgumentException with the corresponding message.
         * <pre>
         * 
         * @param scheduledStartDateTime
         */
        private void validateScheduledStartDateTime(ZonedDateTime scheduledStartDateTime) {
            if (scheduledStartDateTime == null || String.valueOf(scheduledStartDateTime).isEmpty()) {
                throw new IllegalArgumentException("Scheduled Start Date and Time should not be empty");
            }
        }
        
        @Override
        public String toString() {
            return "Builder [id=" + id + ", courseId=" + courseId + ", courseName=" + courseName + ", instructorId="
                    + instructorId + ", instructorLastName=" + instructorLastName + ", instructorFirstName="
                    + instructorFirstName + ", venueId=" + venueId + ", venueName=" + venueName
                    + ", status=" + status + ", scheduledStartDateTime=" + scheduledStartDateTime + ", scheduledEndDateTime=" + scheduledEndDateTime + "]";
        }
    }
}


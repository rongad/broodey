package com.fujitsu.ph.tsup.tms.model;

public class CourseStatusDetails {
	private String courseName;
	private String manager;
	private long cntCompleted;
	private long cntIncomplete;
	private long cntNotRegistered;
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	
	public long getCntCompleted() {
		return cntCompleted;
	}
	public void setCntCompleted(long cntCompleted) {
		this.cntCompleted = cntCompleted;
	}
	public long getCntIncomplete() {
		return cntIncomplete;
	}
	
	public void setCntIncomplete(long cntIncomplete) {
		this.cntIncomplete = cntIncomplete;
	}
	public long getCntNotRegistered() {
		return cntNotRegistered;
	}
	public void setCntNotRegistered(long cntNotRegistered) {
		this.cntNotRegistered = cntNotRegistered;
	}
	
	
}

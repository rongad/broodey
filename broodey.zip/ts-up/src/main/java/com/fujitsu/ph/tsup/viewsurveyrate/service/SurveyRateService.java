/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */    
package com.fujitsu.ph.tsup.viewsurveyrate.service;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Set;

import javax.servlet.ServletContext;

import com.fujitsu.ph.tsup.viewsurveyrate.dao.SurveyResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.domain.SurveyRateForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.EquipmentAndFacilitiesResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.InstructionResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.MaterialsResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.ModuleDesignResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.ResponseResult;
//==================================================================================================                                                                                                                                                                            
//Project Name : Training Sign Up
//System Name  : SurveyRateDao                                                                                                                                                               
//Class Name   : SurveyRateDao.java                                                                                                                                                                          
//                                                                                                                                                                     
//<<Modification History>>                                                                                                                                                                             
//Version  | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.01    | 2021/08/16 | WS)E.Juan             | New Creation    
// 0.02    | 2021/10/12 | WS)MI.Aguinaldo       | Added new services    
// 0.03    | 2021/10/27 | WS)L.Celoso           | Added export funtionality for Survey   
//================================================================================================== 
public interface SurveyRateService {
    
    /**
     * Finds the survey result assigned to specific course
     * @param courseTitle, instructorName, courseDateTime
     * @return Set<SurveyRateForm>
     */
    Set<SurveyRateForm> findSurvey (String courseTitle,String instructorName,ZonedDateTime courseDateTime);
    
    /**
     * Find survey responses.
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return the sets the <SurveyResponse>
     */
    Set<SurveyResponse> findSurveyResponses (String courseTitle,String instructorName,ZonedDateTime courseDateTime);
    
    /**
     * Find survey responses by course_schedule_id
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return the sets the <SurveyResponse>
     */
    Set<SurveyResponse> findSurveyResponses (Long courseScheduleId);
    
    /**
     * Tally module design response.
     *
     * @param surveyResponses the survey responses
     * @return the module design response form
     */
    ModuleDesignResponseForm tallyModuleDesignResponse(Set<SurveyResponse> surveyResponses);
    
    /**
     * Tally materials response.
     *
     * @param surveyResponses the survey responses
     * @return the materials response form
     */
    MaterialsResponseForm tallyMaterialsResponse(Set<SurveyResponse> surveyResponses);
    
    /**
     * Tally instruction response.
     *
     * @param surveyResponses the survey responses
     * @return the instruction response form
     */
    InstructionResponseForm tallyInstructionResponse(Set<SurveyResponse> surveyResponses);
    
    /**
     * Tally equipment and facilities response.
     *
     * @param surveyResponses the survey responses
     * @return the equipment and facilities response form
     */
    EquipmentAndFacilitiesResponseForm tallyEquipmentAndFacilitiesResponse(Set<SurveyResponse> surveyResponses);
    
    /**
     * Compute average ratings.
     *
     * @param responseResult the response result
     * @return the big decimal
     */
    BigDecimal computeAverageRatings (ResponseResult responseResult);
    
    /**
     * <pre>
     * 
     * Creates pdf 
     * 
     * </pre>
     * 
     * @param survey
     * @param context
     */
    boolean createPdf(Set<SurveyResponse> surveyResponses, ServletContext context);
    
}

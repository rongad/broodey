/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */    
package com.fujitsu.ph.tsup.viewsurveyrate.service;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.viewsurveyrate.dao.EquipmentAndFacilitiesResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.dao.InstructionResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.dao.MaterialsResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.dao.ModuleDesignResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.dao.SurveyRateDao;
import com.fujitsu.ph.tsup.viewsurveyrate.dao.SurveyResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.domain.Ratings;
import com.fujitsu.ph.tsup.viewsurveyrate.domain.SurveyRateForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.EquipmentAndFacilitiesResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.InstructionResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.MaterialsResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.ModuleDesignResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.ResponseResult;
import com.fujitsu.ph.tsup.viewsurveyrate.model.SurveyRateList;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

//==================================================================================================                                                                                                                                                                            
//Project Name : Training Sign Up
//System Name  : SurveyRateDao                                                                                                                                                               
//Class Name   : SurveyRateDao.java                                                                                                                                                                          
//                                                                                                                                                                     
//<<Modification History>>                                                                                                                                                                             
//Version  | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.01    | 2021/08/16 | WS)E.Juan             | New Creation    
// 0.02    | 2021/10/12 | WS)MI.Aguinaldo       | Added new services    
// 0.03    | 2021/10/27 | WS)L.Celoso           | Added export functionality for Survey
//==================================================================================================    
@Service
public class SurveyRateServiceImpl implements SurveyRateService {
    
    @Autowired
    private SurveyRateDao dao;


    
    /**
     * Finds the survey result that the specific course have
     * @param courseTitle, instructorName, courseDateTime
     * @return Set<SurveyRateForm>
     */
    @Override
    public Set<SurveyRateForm> findSurvey(String courseTitle,String instructorName,ZonedDateTime courseDateTime) {
        return dao.findSurvey(courseTitle,instructorName,courseDateTime);
    }
    
    /**
     * Find survey responses.
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return the sets the <SurveyResponse>
     */
    @Override
    public Set<SurveyResponse> findSurveyResponses(String courseTitle, String instructorName,
            ZonedDateTime courseDateTime) {
       
        return dao.findSurveyResponses(courseTitle, instructorName, courseDateTime);
    }

    /**
     * Find survey responses.
     *
     * @param courseTitle the course title
     * @param instructorName the instructor name
     * @param courseDateTime the course date time
     * @return the sets the <SurveyResponse>
     */
    @Override
    public Set<SurveyResponse> findSurveyResponses(Long courseScheduleId) {
       
        return dao.findSurveyResponses(courseScheduleId);
    }
    
    /**
     * Tally module design response.
     *
     * @param surveyResponses the survey responses
     * @return the module design response form
     */
    @Override
    public ModuleDesignResponseForm tallyModuleDesignResponse(Set<SurveyResponse> surveyResponses) {
        
        List<ModuleDesignResponse> moduleDesignResponses = surveyResponses.stream()
                                                                          .map(SurveyResponse::getModuleDesignResponseRatings)
                                                                          .collect(Collectors.toList());

        ResponseResult response1 = extractResponseResult(moduleDesignResponses,ModuleDesignResponse::getQuestion1Ratings);
        ResponseResult response2 = extractResponseResult(moduleDesignResponses,ModuleDesignResponse::getQuestion2Ratings);
        ResponseResult response3 = extractResponseResult(moduleDesignResponses,ModuleDesignResponse::getQuestion3Ratings);
        ResponseResult response4 = extractResponseResult(moduleDesignResponses,ModuleDesignResponse::getQuestion4Ratings);
        
        ModuleDesignResponseForm moduleDesignResponseForm = ModuleDesignResponseForm.ofResponseResults(response1,response2,
                                                                                                       response3,response4);
                                                                                    
        
        BigDecimal question1Ratings = computeAverageRatings(response1);
        BigDecimal question2Ratings = computeAverageRatings(response2);
        BigDecimal question3Ratings = computeAverageRatings(response3);
        BigDecimal question4Ratings = computeAverageRatings(response4);
        
        moduleDesignResponseForm.setQuestion1Ratings(question1Ratings.doubleValue());
        moduleDesignResponseForm.setQuestion2Ratings(question2Ratings.doubleValue());
        moduleDesignResponseForm.setQuestion3Ratings(question3Ratings.doubleValue());
        moduleDesignResponseForm.setQuestion4Ratings(question4Ratings.doubleValue());
        
        BigDecimal averageModuleDesignRatings = question1Ratings.add(question2Ratings)
                                               .add(question3Ratings)
                                               .add(question4Ratings)
                                               .divide(BigDecimal.valueOf(4), 2, RoundingMode.HALF_UP);
        
        moduleDesignResponseForm.setAverage(averageModuleDesignRatings.doubleValue());
        
        return moduleDesignResponseForm;
    }
    

    /**
     * Tally materials response.
     *
     * @param surveyResponses the survey responses
     * @return the materials response form
     */
    @Override
    public MaterialsResponseForm tallyMaterialsResponse(Set<SurveyResponse> surveyResponses) {
        List<MaterialsResponse> materialsResponses = surveyResponses.stream()
                                                                    .map(SurveyResponse::getMaterialsResponse)
                                                                    .collect(Collectors.toList());
        
        ResponseResult response1 = extractResponseResult(materialsResponses,MaterialsResponse::getQuestion1Ratings);
        ResponseResult response2 = extractResponseResult(materialsResponses,MaterialsResponse::getQuestion2Ratings);
        ResponseResult response3 = extractResponseResult(materialsResponses,MaterialsResponse::getQuestion3Ratings);
        ResponseResult response4 = extractResponseResult(materialsResponses,MaterialsResponse::getQuestion4Ratings);
        
        MaterialsResponseForm materialsResponseForm = MaterialsResponseForm.ofResponseResults(response1,response2,
                                                                                              response3,response4);
        
        BigDecimal question1Ratings = computeAverageRatings(response1);
        BigDecimal question2Ratings = computeAverageRatings(response2);
        BigDecimal question3Ratings = computeAverageRatings(response3);
        BigDecimal question4Ratings = computeAverageRatings(response4);
        
        materialsResponseForm.setQuestion1Ratings(question1Ratings.doubleValue());
        materialsResponseForm.setQuestion2Ratings(question2Ratings.doubleValue());
        materialsResponseForm.setQuestion3Ratings(question3Ratings.doubleValue());
        materialsResponseForm.setQuestion4Ratings(question4Ratings.doubleValue());
        
        BigDecimal averageRatings = question1Ratings.add(question2Ratings)
                                               .add(question3Ratings)
                                               .add(question4Ratings)
                                               .divide(BigDecimal.valueOf(4), 2, RoundingMode.HALF_UP);
        
        materialsResponseForm.setAverage(averageRatings.doubleValue());
        
        return materialsResponseForm;
    }



    /**
     * Tally instruction response.
     *
     * @param surveyResponses the survey responses
     * @return the instruction response form
     */
    @Override
    public InstructionResponseForm tallyInstructionResponse(Set<SurveyResponse> surveyResponses) {
        List<InstructionResponse> instructionResponses = surveyResponses.stream()
                                                                    .map(SurveyResponse::getInstructionResponse)
                                                                    .collect(Collectors.toList());

        ResponseResult response1 = extractResponseResult(instructionResponses,InstructionResponse::getQuestion1Ratings);
        ResponseResult response2 = extractResponseResult(instructionResponses,InstructionResponse::getQuestion2Ratings);
        ResponseResult response3 = extractResponseResult(instructionResponses,InstructionResponse::getQuestion3Ratings);
        ResponseResult response4 = extractResponseResult(instructionResponses,InstructionResponse::getQuestion4Ratings);
        ResponseResult response5 = extractResponseResult(instructionResponses,InstructionResponse::getQuestion5Ratings);
        ResponseResult response6 = extractResponseResult(instructionResponses,InstructionResponse::getQuestion6Ratings);
        
        InstructionResponseForm instructionResponseForm = InstructionResponseForm.ofResponseResults(response1, response2, 
                                                                                                    response3, response4, 
                                                                                                    response5, response6);
        BigDecimal question1Ratings = computeAverageRatings(response1);
        BigDecimal question2Ratings = computeAverageRatings(response2);
        BigDecimal question3Ratings = computeAverageRatings(response3);
        BigDecimal question4Ratings = computeAverageRatings(response4);
        BigDecimal question5Ratings = computeAverageRatings(response5);
        BigDecimal question6Ratings = computeAverageRatings(response6);
        
        instructionResponseForm.setQuestion1Ratings(question1Ratings.doubleValue());
        instructionResponseForm.setQuestion2Ratings(question2Ratings.doubleValue());
        instructionResponseForm.setQuestion3Ratings(question3Ratings.doubleValue());
        instructionResponseForm.setQuestion4Ratings(question4Ratings.doubleValue());
        instructionResponseForm.setQuestion5Ratings(question5Ratings.doubleValue());
        instructionResponseForm.setQuestion6Ratings(question6Ratings.doubleValue());
        
        BigDecimal averageRatings = question1Ratings.add(question2Ratings)
                                                    .add(question3Ratings)
                                                    .add(question4Ratings)
                                                    .add(question5Ratings)
                                                    .add(question6Ratings)
                                                    .divide(BigDecimal.valueOf(6), 2, RoundingMode.HALF_UP);
        
        instructionResponseForm.setAverage(averageRatings.doubleValue());
        

        return instructionResponseForm;
    }


    /**
     * Tally equipment and facilities response.
     *
     * @param surveyResponses the survey responses
     * @return the equipment and facilities response form
     */
    @Override
    public EquipmentAndFacilitiesResponseForm tallyEquipmentAndFacilitiesResponse(
            Set<SurveyResponse> surveyResponses) {
        
        List<EquipmentAndFacilitiesResponse> equipmentAndFacilitiesResponses = surveyResponses.stream()
                                                                                              .map(SurveyResponse::getEquipmentAndFacilitiesResponse)
                                                                                              .collect(Collectors.toList());

        ResponseResult response1 = extractResponseResult(equipmentAndFacilitiesResponses,EquipmentAndFacilitiesResponse::getQuestion1Ratings);
        ResponseResult response2 = extractResponseResult(equipmentAndFacilitiesResponses,EquipmentAndFacilitiesResponse::getQuestion2Ratings);
        ResponseResult response3 = extractResponseResult(equipmentAndFacilitiesResponses,EquipmentAndFacilitiesResponse::getQuestion3Ratings);
        
        EquipmentAndFacilitiesResponseForm equipmentAndFacilitiesResponseForm = EquipmentAndFacilitiesResponseForm.ofResponseResults(response1, 
                                                                                                                                     response2, 
                                                                                                                                     response3);
        BigDecimal question1Ratings = computeAverageRatings(response1);
        BigDecimal question2Ratings = computeAverageRatings(response2);
        BigDecimal question3Ratings = computeAverageRatings(response3);
        
        
        equipmentAndFacilitiesResponseForm.setQuestion1Ratings(question1Ratings.doubleValue());
        equipmentAndFacilitiesResponseForm.setQuestion2Ratings(question2Ratings.doubleValue());
        equipmentAndFacilitiesResponseForm.setQuestion3Ratings(question3Ratings.doubleValue());
        
        BigDecimal averageRatings = question1Ratings.add(question2Ratings)
                                                    .add(question3Ratings)
                                                    .divide(BigDecimal.valueOf(3), 2, RoundingMode.HALF_UP);
     
        equipmentAndFacilitiesResponseForm.setAverage(averageRatings.doubleValue());
        
        return equipmentAndFacilitiesResponseForm;
    }

    
    /**
     * Compute average ratings.
     *
     * @param responseResult the response result
     * @return the big decimal
     */
    @Override
    public BigDecimal computeAverageRatings (ResponseResult responseResult) {
        Objects.requireNonNull(responseResult);
        
        int totallyDisagree = responseResult.getCountOfTotallyDisagree().intValue();
        int disAgree = responseResult.getCountOfDisagree().intValue();
        int agree = responseResult.getCountOfAgree().intValue();
        int totallyAgree = responseResult.getCountOfTotallyAgree().intValue();
        int nonApplicable = responseResult.getCountOfnonApplicable().intValue();
        
        
        BigDecimal divident = BigDecimal.valueOf(totallyDisagree + (disAgree * 2) + (agree * 3) + (long) (totallyAgree * 4));

        BigDecimal divisor = BigDecimal.valueOf(totallyDisagree + disAgree + agree + totallyAgree + (long) nonApplicable);
        
        return divident.divide(divisor, 2, RoundingMode.HALF_UP);
    }




    /**
     * Extract response result.
     *
     * @param <T> the generic type
     * @param designQuestions the design questions
     * @param mapper the mapper
     * @return the response result
     */
    private <T> ResponseResult extractResponseResult(List<T> designQuestions,
            Function<? super T, ? extends Ratings> mapper) {
        long totallyDisagreeCount = designQuestions.stream()
                                           .map(mapper)
                                           .filter(rating -> rating.equals(Ratings.TOTALY_DISAGREE))
                                           .count();
        
        long disagreeCount = designQuestions.stream()
                                           .map(mapper)
                                           .filter(rating -> rating.equals(Ratings.DISAGREE))
                                           .count();
        
        long agreeCount = designQuestions.stream()
                                           .map(mapper)
                                           .filter(rating -> rating.equals(Ratings.AGREE))
                                           .count();
        
        long totallyAgreeCount = designQuestions.stream()
                                           .map(mapper)
                                           .filter(rating -> rating.equals(Ratings.TOTALY_AGREE))
                                           .count();
        
        long nonApplicableCount = designQuestions.stream()
                                           .map(mapper)
                                           .filter(rating -> rating.equals(Ratings.NON_APPLICABLE))
                                           .count();
       
        
        return ResponseResult.of(totallyDisagreeCount, disagreeCount, agreeCount, totallyAgreeCount, nonApplicableCount);
    }
    
    /**
     * <pre>
     * Create a PDF Template Base on the Attendance absent or Present, Using the parameter of export,
     * context,request and checkBox.
     * 
     * <pre>
     * 
     * @param export
     * @param context
     * @param request
     * @param checkBox
     * @return
     */
    @Override
    public boolean createPdf(Set<SurveyResponse> surveyResponses, ServletContext context) {
        
        Document document = new Document(PageSize.A4, 15, 15, 45, 30);
        
        try {
            
            String filePath = context.getRealPath("/resource/reports");
            File file = new File(filePath);
            boolean exists = new File(filePath).exists();
            if (!exists) {
                new File(filePath).mkdirs();
            }
            
            // RATE TALLYING ============
            SurveyRateList survey = new SurveyRateList();
            ModuleDesignResponseForm moduleDesignResponseForm = tallyModuleDesignResponse(surveyResponses);
            MaterialsResponseForm materialsResponseForm = tallyMaterialsResponse(surveyResponses);
            InstructionResponseForm instructionResponseForm = tallyInstructionResponse(surveyResponses);
            EquipmentAndFacilitiesResponseForm equipmentAndFacilitiesResponseForm = tallyEquipmentAndFacilitiesResponse(surveyResponses);
            
            survey.setModuleDesignResponseForm(moduleDesignResponseForm);
            survey.setMaterialsResponseForm(materialsResponseForm);
            survey.setInstructionResponseForm(instructionResponseForm);
            survey.setEquipmentAndFacilitiesResponseForm(equipmentAndFacilitiesResponseForm);

            double oaAv = (moduleDesignResponseForm.getAverage() + materialsResponseForm.getAverage() + instructionResponseForm.getAverage() + equipmentAndFacilitiesResponseForm.getAverage()) / 4;
            survey.setOaAverage(oaAv);
            // ============================
            
            PdfWriter.getInstance(document, new FileOutputStream(file + "/" + "export" + ".pdf"));
            document.open();

            PdfPTable courseInfoTable = new PdfPTable(1);
            courseInfoTable.setHorizontalAlignment(Element.ALIGN_LEFT);
            courseInfoTable.setWidthPercentage(100);
            courseInfoTable.setSpacingBefore(5f);
            courseInfoTable.setSpacingAfter(5);
            
            PdfPTable ratingsTable = new PdfPTable(9);
            ratingsTable.setWidthPercentage(100);
            ratingsTable.setSpacingBefore(5f);
            ratingsTable.setSpacingAfter(5);

            PdfPTable commentsTable = new PdfPTable(4);
            commentsTable.setWidthPercentage(100);
            commentsTable.setSpacingBefore(5f);
            commentsTable.setSpacingAfter(5);

            Font surveyType = FontFactory.getFont("Arial", 14, Font.BOLD);
            Font courseInfoHeader = FontFactory.getFont("Arial", 12, Font.BOLD);
            Font courseInfoBody = FontFactory.getFont("Arial", 11);
            Font tableHeader = FontFactory.getFont("Arial", 10, Font.BOLD);
            Font tableBody = FontFactory.getFont("Arial", 9);

            float[] columnWidthCourseInfo = { 3f };
            courseInfoTable.setWidths(columnWidthCourseInfo);

            float[] columnWidthsRatings = { 3f, 4f, 3f, 3f, 3f, 3f, 3f, 3f, 3f};
            ratingsTable.setWidths(columnWidthsRatings);

            float[] columnWidthComments = { 2f, 4f, 4f, 4f};
            commentsTable.setWidths(columnWidthComments);
            
            DecimalFormat format = new DecimalFormat("#.0");
            
            // COURSE INFORMATION
            SurveyResponse courseInfo = surveyResponses.iterator().next();
            
            createCell(courseInfoTable, "Course Information", surveyType, 1 ,1, false);
            
            createCell(courseInfoTable, " Course Name : ", courseInfoHeader, 1 ,1, false);
            createCell(courseInfoTable, " " + courseInfo.getCourseTitle(), courseInfoBody, 1 ,1, false);
            createCell(courseInfoTable, " Course Schedule : ", courseInfoHeader, 1 ,1, false);
            createCell(courseInfoTable, " " + DateTimeFormatter.ofPattern("E, dd MMM yyyy HH:mm z").format(courseInfo.getCourseDateTime()), courseInfoBody, 1 ,1, false);
            createCell(courseInfoTable, " Instructor Name : ", courseInfoHeader, 1 ,1, false);
            createCell(courseInfoTable, " " + courseInfo.getInstructorName(), courseInfoBody, 1 ,1, false);
            
            // RATINGS
            createCell(ratingsTable, "Ratings", surveyType, 1, 9, false);            
            
            // HEADERS
            createCell(ratingsTable, "Category", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Survey List", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Totally Disagree", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Disagree", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Agree", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Totally Agree", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Not Applicable", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Ratings", tableHeader, 1, 1, true);
            createCell(ratingsTable, "Average", tableHeader, 1, 1, true);

            // MODULE DESIGN
            createCell(ratingsTable, "Module Design", tableHeader, 4, 1, true);
            createCell(ratingsTable, "The goals or objectives of each training session were clear.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion1TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion1Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion1Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion1TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion1NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getModuleDesignResponseForm().getQuestion1Ratings()), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getModuleDesignResponseForm().getAverage()), tableHeader, 4, 1, true);
            
            createCell(ratingsTable, "The topics discussed during the sessions were relevant to the goals and objectives.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion2TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion2Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion2Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion2TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion2NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getModuleDesignResponseForm().getQuestion2Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The exercises and activities gave the opportunity to apply the topics and concepts being studied.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion3TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion3Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion3Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion3TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion3NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getModuleDesignResponseForm().getQuestion3Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "There were enough exercises and activities during the seminar to apply all major topics that were covered.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion4TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion4Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion4Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion4TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getModuleDesignResponseForm().getQuestion4NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getModuleDesignResponseForm().getQuestion4Ratings()), tableBody, 1, 1, true);
            
            
            // MATERIALS
            createCell(ratingsTable, "Materials", tableHeader, 4, 1, true);
            createCell(ratingsTable, "The content of the manual was helpful and appropriate.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion1TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion1Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion1Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion1TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion1NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getMaterialsResponseForm().getQuestion1Ratings()), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getMaterialsResponseForm().getAverage()), tableHeader, 4, 1, true);
            
            createCell(ratingsTable, "The layout and physical appearance of the manual was clear and readable.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion2TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion2Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion2Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion2TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion2NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getMaterialsResponseForm().getQuestion2Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The instructions of the exercises and activities were clear.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion3TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion3Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion3Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion3TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion3NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getMaterialsResponseForm().getQuestion3Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The materials provided for the activities were of good quality.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion4TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion4Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion4Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion4TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getMaterialsResponseForm().getQuestion4NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getMaterialsResponseForm().getQuestion4Ratings()), tableBody, 1, 1, true);
            
            
            // INSTRUCTION
            createCell(ratingsTable, "Instruction", tableHeader, 6, 1, true);
            createCell(ratingsTable, "The instructor demonstrated a very good grasp of the subject matter.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion1TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion1Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion1Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion1TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion1NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getQuestion1Ratings()), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getAverage()), tableHeader, 6, 1, true);
            
            createCell(ratingsTable, "The instructor was articulate and eloquent in explaining the topics in class.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion2TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion2Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion2Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion2TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion2NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getQuestion2Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The instructor encouraged the open exchange of ideas.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion3TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion3Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion3Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion3TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion3NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getQuestion3Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The instructor was approachable for consultation.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion4TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion4Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion4Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion4TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion4NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getQuestion4Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The instructor gave clear instructions to accomplish the exercises and activities.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion5TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion5Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion5Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion5TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion5NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getQuestion5Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The instructor gave feedback on the mistakes committed during the exercises and activities.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion6TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion6Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion6Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion6TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getInstructionResponseForm().getQuestion6NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getInstructionResponseForm().getQuestion6Ratings()), tableBody, 1, 1, true);
            
            
            // EQUIPMENT AND FACILITIES
            createCell(ratingsTable, "Equipment and Facilities", tableHeader, 3, 1, true);
            createCell(ratingsTable, "The equipment used during the seminar were in good condition. ", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion1TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion1Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion1Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion1TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion1NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getEquipmentAndFacilitiesResponseForm().getQuestion1Ratings()), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getEquipmentAndFacilitiesResponseForm().getAverage()), tableHeader, 3, 1, true);
            
            createCell(ratingsTable, "The facilities used during the seminar were in good condition.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion2TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion2Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion2Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion2TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion2NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getEquipmentAndFacilitiesResponseForm().getQuestion2Ratings()), tableBody, 1, 1, true);
            
            createCell(ratingsTable, "The atmosphere in the training room was conducive for work.", tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion3TotallyDisagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion3Disagree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion3Agree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion3TotallyAgree(), tableBody, 1, 1, true);
            createCell(ratingsTable, survey.getEquipmentAndFacilitiesResponseForm().getQuestion3NotApplicable(), tableBody, 1, 1, true);
            createCell(ratingsTable, format.format(survey.getEquipmentAndFacilitiesResponseForm().getQuestion3Ratings()), tableBody, 1, 1, true);
            
            // AVERAGE
            createCell(ratingsTable, "Overall Average Rating", tableHeader, 1, 8, true);
            createCell(ratingsTable, format.format(survey.getOaAverage()), tableHeader, 1, 1, true);
            
            // COMMENTS

            createCell(commentsTable, "Comments", surveyType, 1, 4, false);
            
            // HEADERS
            createCell(commentsTable, "Participant", tableHeader, 1, 1, true);
            createCell(commentsTable, "What aspect/s of this seminar did you find commendable?", tableHeader, 1, 1, true);
            createCell(commentsTable, "What aspect/s of this seminar did you not like?", tableHeader, 1, 1, true);
            createCell(commentsTable, "Do you have any recommendations on any aspect of this seminar? Please feel free to write them down.", tableHeader, 1, 1, true);
            
            // VALUES
            for (SurveyResponse response : surveyResponses) {
                createCell(commentsTable, "Anonymous Student " + response.getId(), tableBody, 1, 1, true);
                createCell(commentsTable, response.getCommentsE(), tableBody, 1, 1, true);
                createCell(commentsTable, response.getCommentsF(), tableBody, 1, 1, true);
                createCell(commentsTable, response.getCommentsG(), tableBody, 1, 1, true);
            }
            
            document.add(courseInfoTable);
            document.add(ratingsTable);
            document.add(commentsTable);
            document.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }
    
    private void createCell(PdfPTable table, Object value, Font cellFont, int rowSpan, int colSpan, boolean border) {
        
        PdfPCell addedCell = new PdfPCell(new Paragraph(value.toString(), cellFont));
        if (border) {
            addedCell.setBorderColor(BaseColor.BLACK);
            addedCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        } else {
            addedCell.setBorder(Rectangle.NO_BORDER);
            addedCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        }
        addedCell.setPaddingLeft(5);
        addedCell.setRowspan(rowSpan);
        addedCell.setColspan(colSpan);
        addedCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        addedCell.setBackgroundColor(BaseColor.WHITE);
        addedCell.setExtraParagraphSpace(5f);
        table.addCell(addedCell);
        
    }
 }

 
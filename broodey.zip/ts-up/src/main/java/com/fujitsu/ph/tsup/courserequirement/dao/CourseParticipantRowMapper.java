package com.fujitsu.ph.tsup.courserequirement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.Employee;

import org.springframework.jdbc.core.RowMapper;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : Course Checklist
 * Class Name   : CourseParticipantRowMapper.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * ===================================================================================================
 */

 /**
 * <pre>
 * The Row Mapper for  Course Participant
 * 
 * <pre>
 * 
 * @version 0.01
 * @author e.delosreyes
 */


public class CourseParticipantRowMapper implements RowMapper<CourseParticipant> {

    @Override
    public CourseParticipant mapRow(ResultSet rs, int rowNum) throws SQLException {
        Employee employee = new Employee();
        employee.setId(rs.getInt("Employee_Id"));
        employee.setFirstName(rs.getString("first_name"));
        employee.setLastName(rs.getString("last_name"));
        CourseParticipant courseParticipant = new CourseParticipant();
        courseParticipant.setId(rs.getInt("id"));
        courseParticipant.setParticipant(employee);
        return courseParticipant;
    }
    
}

package com.fujitsu.ph.tsup.enrollment.dao;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.common.domain.MemberRole;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.model.Course;

import com.fujitsu.ph.tsup.enrollment.domain.CourseParticipant;
import com.fujitsu.ph.tsup.enrollment.domain.CourseSchedule;
import com.fujitsu.ph.tsup.enrollment.domain.CourseScheduleDetail;
import com.fujitsu.ph.tsup.enrollment.domain.ParticipantTrainingPeriod;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;
import com.fujitsu.ph.tsup.enrollment.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.enrollment.model.EnrolledMemberForm;
import com.fujitsu.ph.tsup.enrollment.model.SearchForm;
import com.fujitsu.ph.tsup.scheduling.model.DepartmentForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;
import com.fujitsu.ph.tsup.search.MyCourseScheduleFilter;

// ====================================================
// $Id:PR01$
// Project Name :Training Sign Up
// System Name :Enrollment Process
// Class Name :EnrollmentDao.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+------
// 0.01 | 06/24/2020 | WS) J.Yu          | New Creation
// 0.02 | 09/14/2020 | WS) J.Yu          | Update
// 0.03 | 04/19/2021 | WS) M.Atayde      | Update
// 0.04 | 06/14/2021 | WS) L.Celoso      | Update
// 0.05 | 06/30/2021 | WS) L.Celoso      | Update
// 0.06 | 07/08/2021 | WS) L.Celoso      | Update
// 0.06 | 07/16/2021 | WS) MI.Aguinaldo  | Update
// 0.07 | 08/06/2021 | WS) K.Sevilla     | Updated
// 0.08 | 08/23/2021 | WS) K.Sevilla     | Updated
// 0.09 | 09/13/2021 | WS) K.Sevilla     | Updated
// 0.10 | 10/13/2021 | WS) R.delaCruz    | Updated
// 0.11 | 12/29/2021 | WS) ep.delosreyes | Removed top Learners
// ====================================================

/**
 * <pre>
 * The data access interface for enrollment related database access
 * 
 * <pre>
 * 
 * @version 0.01
 * @author j.yu
 */
public interface EnrollmentDao {

    /**
     * Finds the scheduled courses starting from today onwards
     * 
     * @param fromDateTime
     * @param toDateTime
     */
    Set<CourseSchedule> findAllScheduledCourses(CourseScheduleListForm form, Pageable pageable);

    /**
     * Finds the course schedule by id
     * 
     * @param id
     */
    CourseSchedule findCourseScheduleById(Long id);

    /**
     * Finds the course schedule enrollment by course schedule id and participant id
     * 
     * @param courseScheduleId
     * @param participantId
     */
    CourseParticipant findCourseParticipantByCourseScheduleIdAndParticipantId(Long courseScheduleId,
            Long participantId);

    /**
     * Saves the CourseParticipant object
     * 
     * @param courseParticipant
     */
    void saveCourseParticipant(CourseParticipant courseParticipant);

    /**
     * Finds the scheduled courses starting from today onwards
     * 
     * @param participantId
     * @param fromDateTime
     * @param toDateTime
     */
    Set<CourseParticipant> findAllEnrolledCoursesByParticipantId(Long participantId,
            ZonedDateTime fromDateTime, ZonedDateTime toDateTime);

    /**
     * Find all course enrolled base on the participant training period
     * 
     * @param participantTrainingPeriod
     * @param pageable
     * @return
     */
    Set<CourseParticipant> findAllEnrolledCoursesBy(ParticipantTrainingPeriod participantTrainingPeriod,
            Pageable pageable);

    /**
     * Count the enroll courses base on the participant training period
     * 
     * @param participantTrainingPeriod
     * @return
     */
    int countAllEnrolledCoursesByParticipantTrainingPeriod(
            ParticipantTrainingPeriod participantTrainingPeriod);

    /**
     * Finds the participant enrolled by id
     * 
     * @param id
     */
    CourseParticipant findCourseParticipantById(Long id);

    /**
     * Deletes the course participant by id
     * 
     * @param id
     */
    void deleteCourseParticipantById(Long id);

    /**
     * Save the course non participant
     * 
     * @param id
     */
    void saveCourseNonParticipant(CourseParticipant courseParticipant);

    /**
     * Save the course schedule
     * 
     * @param courseSchedule
     */
    void changeCourseScheduleStatus(CourseSchedule courseSchedule);

    /**
     * Find All Active Course Schedule
     * 
     * @return
     */
    Set<CourseSchedule> findAllActiveCourseSchedule();

    /**
     * Cancel Course Schedule By Id
     * 
     * @param courseScheduleSet
     */
    void cancelCourseSchedulesById(Set<CourseSchedule> courseScheduleSet);

    /**
     * Find Course Schedule that are below Minimum Participants
     * 
     * @return
     */
    Set<CourseSchedule> findAllCourseScheduleBelowMinimumParticipants();

    /**
     * Find CourseSchedule By Month
     * 
     * @return
     */
    Set<CourseSchedule> findAllCourseScheduleByMonth();

    /**
     * Find CourseSchedule By Quarter
     * 
     * @return
     */
    Set<CourseSchedule> findAllCourseScheduleByQuarter();

    /**
     * Reschedule Course Schedule Detail
     * 
     * @param courseScheduleDetail
     */
    void reschedule(CourseScheduleDetail courseScheduleDetail);

    /**
     * Find All Enrolled Participant in Course Schedule
     * 
     * @param courseParticipant
     * @return
     */
    Set<CourseParticipant> findAllParticipantByCourseScheduleId(Long courseParticipant);

    /**
     * Find all Member that are not yet enrolled in Course Schedule
     * 
     * @param courseSchedule
     * @return
     */
    Set<CourseParticipant> findAllMemberNotEnrolledByCourseScheduleId(CourseParticipant courseSchedule);

    /**
     * Search Feature / Find All Member that are not yet enrolled and in criteria of SearchForm
     * 
     * @param searchForm
     * @return
     */
    Set<CourseParticipant> findMemberNotEnrolledByCourseScheduleId(SearchForm searchForm);

    /**
     * Find available course schedule by course id
     * 
     * @param courseId
     * @return
     */
    Set<CourseSchedule> findCourseScheduleByCourseId(CourseSchedule courseSchedule);

    void updateCourseParticipant(CourseParticipant courseParticipant);
    /**
     * <pre>
     * viewEnrolledMembers
     *
     * @author c.delapena
     * 
     *         <pre>
     */
    // List<Participant> viewEnrolledMembers(Long id);

    /**
     * <pre>
     * addEnrolledMembers
     *
     * @author c.delapena
     * 
     *         <pre>
     */
    // Integer addEnrolledMembersById(Participant participant);

    /**
     * <pre>
     * uploads the certificate to the database
     * 
     * @param certificate
     * @author m.atayde
     *
     *         <pre>
     */
    void uploadCertificate(Certificate certificate);

    /**
     * <pre>
     * finds and only enables the upload certificate button for mandatory courses from the database
     * 
     * @param userId
     * @param courseId
     * @author m.atayde
     *
     *         <pre>
     */
    public List<String> findCourseScheduleIfMandatory();

    String findCertificateName(long userId, long courseId);

    /**
     * <pre>
     * Method for loading all course category
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<CourseCategory> findAllCourseCategory();

    /**
     * <pre>
     * Method for loading all course name
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<Course> findAllCourseName();

    /**
     * <pre>
     * Method for loading all instructor
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<InstructorForm> findAllInstructor();

    /**
     * <pre>
     * Method for loading all venue
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<VenueForm> findAllVenue();

    /**
     * <pre>
     * Method for loading all department
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<DepartmentForm> findAllDepartment();

    /**
     * <pre>
     * Method for loading all member role
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<MemberRole> findAllMemberRole();

    /**
     * <pre>
     * Method for removing selected enrolled members from a course schedule
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    void removeBatchMember(EnrolledMemberForm enrolledMember);

    /**
     * <pre>
     * Method for enrolling selected members to a course schedule
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    void enrollBatchMember(EnrolledMemberForm enrolledMember);

    /**
     * <pre>
     * Method for counting the number of available course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    int countCourse(CourseScheduleListForm form);

    /**
     * <pre>
     * Method for getting all email of employees to be enrolled
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    Set<CourseParticipant> getAllEmails(String batchId);

    Set<CourseParticipant> findCoursesByMyCourseScheduleFilter(MyCourseScheduleFilter searchCriteria,
            Pageable pageable);

    // Method for Filter Search
    int countFoundCourseSchedule(MyCourseScheduleFilter searchCriteria);

}

//==================================================================================================
// Project Name : Training Sign-Up
// System Name : NonMandatoryCoursesReportDao
// Class Name : NonMadatoryCoursesReportDao.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.util.Map;
import java.util.Set;

import com.fujitsu.ph.tsup.report.summary.model.Attendee;
import com.fujitsu.ph.tsup.report.summary.model.CourseCategory;

/**
 * <pre>
 * DAO interface for
 * Members' completion report of Non Mandatory Courses
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public interface NonMandatoryCoursesReportDao {

    /**
     * <pre>
     * Find all non-mandatory course category
     * </pre>
     * 
     * @return Course Category set
     */
    public Set<CourseCategory> findAllNonMandatoryCourseCategory();

    /**
     * <pre>
     * Find all non-mandatory courses under course category
     * </pre>
     * 
     * @param courseCategoryID
     * @return Map of course name and id
     */
    public Map<Long, String> findAllCoursesUnderCourseCategory(Long courseCategoryID);

    /**
     * <pre>
     * Find all members based from JDU type
     * </pre>
     * 
     * @param jduId
     * @return Attendee set
     */
    public Set<Attendee> findAllMembers(Long jduId);

    /**
     * <pre>
     * Get member's JDU type
     * </pre>
     * 
     * @return Long
     */
    public Long getJDUType();

    /**
     * <pre>
     * Get all attendees of non-mandatory courses under course category id
     * </pre>
     * 
     * @param courseCategoryID
     * @param jduId
     * @return Attendee set
     */
    public Set<Attendee> findAllAttendeesOfNonMandatoryCourses(Long courseCategoryID, Long jduId);
}

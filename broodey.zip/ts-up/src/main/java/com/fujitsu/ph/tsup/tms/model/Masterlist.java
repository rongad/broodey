package com.fujitsu.ph.tsup.tms.model;

import java.io.Serializable;

public class Masterlist{
	
	private String employeeName;
	private String employeeStatus;
	private String manager;
	private String courseTitle;
	private int targetCompletion;
	private int actualCompletion;
	private String Status;

	
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeStatus() {
		return employeeStatus;
	}
	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getCourseTitle() {
		return courseTitle;
	}
	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}
	public int getTargetCompletion() {
		return targetCompletion;
	}
	public void setTargetCompletion(double d) {
		this.targetCompletion = (int) d;
	}
	public int getActualCompletion() {
		return actualCompletion;
	}
	public void setActualCompletion(double d) {
		this.actualCompletion = (int) d;
	}
	public void setStatus(String status) 
	{
		this.Status = status;
		
	}
	public String getStatus() 
	{
		return Status;
	}
	
	
	@Override
	public String toString() {
		return "Masterlist [employeeName=" + employeeName + ", employeeStatus=" + employeeStatus + ", manager="
				+ manager + ", courseTitle=" + courseTitle + ", targetCompletion=" + targetCompletion
				+ ", actualCompletion=" + actualCompletion + ", status=" +Status + "]";
	}
	
	
}

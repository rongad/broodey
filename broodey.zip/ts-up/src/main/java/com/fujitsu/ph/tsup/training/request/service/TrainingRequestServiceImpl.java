package com.fujitsu.ph.tsup.training.request.service;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.fujitsu.ph.tsup.training.request.dao.TrainingRequestDao;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestForm;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

//=======================================================
//Project Name: Training Sign Up
//Class Name: TrainingRequestServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 07/12/2021 | WS) L.Celoso   | New Creation
//0.02    | 08/06/2021 | WS) L.Celoso    | Update
//=======================================================
/**
 * <pre>
 * The implementation of schedule service
 * 
 * <pre>
 * 
 * @version 0.01
 * @author L.Celoso
 */
@Service
public class TrainingRequestServiceImpl implements TrainingRequestService {
	
	@Autowired
	private TrainingRequestDao trainingRequestDao;
	
	/**
	 * <pre>
	 * Create a training request Call
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void createTrainingRequest(TrainingRequestForm trainingRequestForm) {

		try {
			trainingRequestDao.saveTrainingRequest(trainingRequestForm);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't save training request");
		}
	}
	
	/**
	 * <pre>
	 * Create a training request Call
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public Set<TrainingRequest> getAllTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm, Pageable pageable) {

		try {
			return trainingRequestDao.getAllTrainingRequest(trainingRequestSearchForm, pageable);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't get all training request");
		}
	}
	
	/**
	 * <pre>
	 * Cancel a training request Call
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void cancelTrainingRequest(Long id) {

		try {
			
			if (trainingRequestDao.checkToCancelTrainingRequest(id) == 0) {
				throw new IllegalArgumentException("Training request was already approved or declined");
			}
			
			trainingRequestDao.cancelTrainingRequest(id);
			trainingRequestDao.moveToArchive(id);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Training request does not exists");
		}
	}
	
	/**
	 * <pre>
	 * Close a training request Call
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void closeTrainingRequest(Long id) {

		try {
			trainingRequestDao.moveToArchive(id);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Training request does not exists");
		}
	}
	
	/**
	 * <pre>
	 * Update a training request Call
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void updateTrainingRequest(TrainingRequestForm trainingRequestForm) {

		try {
			
			if (trainingRequestDao.checkToCancelTrainingRequest(trainingRequestForm.getId()) == 0) {
				throw new IllegalArgumentException("Training request was already approved or declined");
			}
			
			trainingRequestDao.updateTrainingRequest(trainingRequestForm);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't update training request");
		}
	}
	
	/**
	 * <pre>
	 * Decline a training request Call
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void changeTrainingRequestStatus(Long id, String status, String remarks) {

		try {

			if (trainingRequestDao.checkToCancelTrainingRequest(id) == 0) {
				throw new IllegalArgumentException("Training request was already cancelled by the user");
			}				
			
			if(status.toLowerCase().equals("decline")) {
				trainingRequestDao.changeTrainingRequestStatus(id, "Declined", remarks);
			} else {
				trainingRequestDao.changeTrainingRequestStatus(id, "Approved", remarks);
			}
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Training request does not exists");
		}
	}
	
	/**
	 * <pre>
	 * Count the number of training request
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public int countTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm) {
	
		return trainingRequestDao.countTrainingRequest(trainingRequestSearchForm);
	
	}
}

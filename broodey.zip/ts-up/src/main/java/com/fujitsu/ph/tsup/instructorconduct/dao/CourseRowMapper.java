package com.fujitsu.ph.tsup.instructorconduct.dao;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: CourseRowMapper.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja | New Creation
//=======================================================

/**
* <pre>
* Custom Course RowMapper for course schedules assigned to instructor. 
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.fujitsu.ph.tsup.instructorconduct.model.CourseForm;

public class CourseRowMapper implements RowMapper<CourseForm>{
    
    /**
     * <pre>
     * Maps the Rows returned by ResultSet
     * <pre>
     * @param ResultSet
     * @param int rowNum
     * @throws SQLException
     */
    @Override
    public CourseForm mapRow(ResultSet rs, int rowNum) throws SQLException {
        CourseForm courseForm = new CourseForm();
        
        Long id = rs.getLong("ID");
        String name = rs.getString("NAME");
        courseForm.setId(id);
        courseForm.setName(name);
        
        return courseForm;
    }
}
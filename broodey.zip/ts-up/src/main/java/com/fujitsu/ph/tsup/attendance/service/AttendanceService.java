package com.fujitsu.ph.tsup.attendance.service;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.attendance.domain.CourseParticipant;
import com.fujitsu.ph.tsup.attendance.domain.CourseSchedule;
import com.fujitsu.ph.tsup.attendance.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.attendance.model.ScheduleDetail;

// ==================================================================================================
// $Id:PR03$
// Project Name : Training Sign up
// System Name : Attendance process
// Class Name : AttendanceService.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+--------------------------------------------------+-------------------------
// 0.01 | 06/23/2020 | WS) K.Abad                            | New Creation
// 0.02 | 07/30/2020 | WS) R.Ramos                           | Update
// 0.03 | 08/26/2020 | WS) K.abad, WS) J.Iwarat, WS) R.Ramos | Update
// 0.03 | 09/02/2021 | WS) CJ.Zamora                         | Update
// 0.03 | 08/17/2021 | WS) Jo.Dominguez                      | Update
// ==================================================================================================

/**
 * <pre>
 * It is the interface of attendance service
 * In this interface, it consists of the method required for the initial setting of the database
 * </pre>
 * 
 * @version 0.03
 * @author k.abad
 * @author j.iwarat
 * @author r.ramos
 */

public interface AttendanceService {

    /**
     * <pre>
     * Finds all scheduled courses based on the given date range
     * </pre>
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param instructorId
     * @return Course Schedule Set
     */
    Set<CourseSchedule> findAllScheduledCoursesByInstructor(ZonedDateTime fromDateTime,
            ZonedDateTime toDateTime, Long instructorId);

    /**
     * <pre>
     * Finds the course schedule and the participants using the course schedule Id
     * </pre>
     * 
     * @param id
     * @return Course Participant Set
     */
    Set<CourseParticipant> findCourseScheduleById(Long id);

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule Id
     * </pre>
     * 
     * @param id
     * @return Course Attendance Set
     */
    Set<CourseAttendance> findCourseAttendanceByCourseScheduleDetailId(Long id);

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule Id
     * </pre>
     * 
     * @param courseAttendanceSet
     */
    void changeStatus(Set<CourseAttendance> courseAttendanceSet);

    /**
     * <pre>
     * Finds the course schedule and those participants who didn't attend using the course schedule Id
     * </pre>
     * 
     * @param id
     * @return Course Attendance Set
     */
    Set<CourseAttendance> findCourseAbsentParticipantByCourseScheduleDetailId(Long id);

    /**
     * <pre>
     * Finds the course schedule and the participants and those who are attending using the course schedule detail Id
     * </pre>
     * 
     * @param id
     * @return Course Attendance
     */
    Set<CourseAttendance> findCourseScheduleDetailById(Long id);

    /**
     * <pre>
     * log in for attend
     * </pre>
     * 
     * @param courseAttendance
     */
    void attendLogin(CourseAttendance courseAttendance);

    /**
     * <pre>
     * log out for attend
     * </pre>
     * 
     * @param courseAttendance
     */
    void attendLogout(CourseAttendance courseAttendance);

    /**
     * <pre>
     * Finds all scheduled courses based on the given date range
     * </pre>
     * 
     * @param fromDateTime
     * @param toDateTime
     * @param participantId
     * @return Course Participant Set
     */
    Set<CourseParticipant> findAllScheduledCoursesByParticipant(CourseScheduleListForm courseScheduleListForm, Pageable pageable);

    // for pagination ====================================
    /**
     * <pre>
     * Method for counting the number of available course
     * 
     * @author l.celoso
     *
     *         <pre>
     */
    int countCourse(CourseScheduleListForm courseScheduleListForm);
    // for pagination end ================================

    /**
     * <pre>
     * Finds scheduled courses
     * 
     * <pre>
     * 
     * @param fromDate
     * @param toDate
     * @param id
     * @return
     */
    Map<String, List<ScheduleDetail>> findAllScheduledCourses(ZonedDateTime fromDate,
            ZonedDateTime toDate, Long id);

    /**
     * <pre>
     * Create a Template PDF of the Attendance Absent and Present.
     * </pre>
     * 
     * @param export
     * @param context
     * @param request
     * @param checkBox
     * @return 
     */
    boolean createPdf(Set<CourseAttendance> export,ServletContext context,int[] typeOfTraining);
    
    /**
     * <pre>
     * Download the Created Template PDF of the Attendance Absent and Present.
     * </pre>
     * 
     * @param fullPath
     * @param response
     * @param fileName
     * @return 
     */
    boolean fileDownload(String fullPath,HttpServletResponse response,ServletContext context, String fileName);
    
}


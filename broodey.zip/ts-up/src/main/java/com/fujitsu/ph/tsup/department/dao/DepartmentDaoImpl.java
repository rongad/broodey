/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.department.dao;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import com.fujitsu.ph.tsup.department.domain.Department;


//=======================================================
//Project Name: Training Sign Up
//Class Name: DepartmentDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 23/06/2021 | WS) dw.cardenas  | Created
//0.02    | 12/07/2021 | WS) dw.cardenas  | findAllDepartments(pageable) && count
//0.02    | 03/08/2021 | WS) dw.cardenas  | Update
//0.03    | 10/09/2021 | WS) r.delacruz   | Update
//=======================================================

/**
 *
 * @author dw.cardenas
 *
 */
@Repository
public class DepartmentDaoImpl implements DepartmentDao {

	@Autowired
	private NamedParameterJdbcTemplate paramTemplate;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public Set<Department> findAllDepartments() {
		String query = "SELECT * FROM department d INNER JOIN jdu_type j ON d.jdu_id = j.id ORDER BY d.id";
		List<Department> departmentList = paramTemplate.query(query, new DepartmentRowMapper());

		return new LinkedHashSet<>(departmentList);
	}

	@Override
	public Set<Department> findDepartmentByName(String departmentName) {
		String query = "SELECT * FROM department d INNER JOIN jdu_type j ON d.jdu_id = j.id"
				+ " WHERE LOWER(d.department_name)  LIKE LOWER('%" + departmentName + "%') ORDER BY d.id";

		List<Department> departmentList = paramTemplate.query(query, new DepartmentRowMapper());
		
		return new LinkedHashSet<>(departmentList);
	}

	@Override
	public void createDepartment(Department department) {
		String query = "INSERT INTO DEPARTMENT(department_name, jdu_id) VALUES(:department_name, :jdu_id)";
		SqlParameterSource sqlParamSource = new MapSqlParameterSource()
				.addValue("department_name", department.getName())
				.addValue("jdu_id", department.getJduId());
		
		paramTemplate.update(query, sqlParamSource);
	}

	@Override
	public void updateDepartment(Department updatedDept) {
		String query = "UPDATE DEPARTMENT SET department_name = :department_name, jdu_id = :jdu_id WHERE id = :id";
		SqlParameterSource sqlParamSource = new MapSqlParameterSource()
				.addValue("id", updatedDept.getId())
				.addValue("department_name", updatedDept.getName())
				.addValue("jdu_id", updatedDept.getJduId());
		
		paramTemplate.update(query, sqlParamSource);
	}

	@Override
	public void deleteDepartmentById(Long id) {
		String query = "DELETE FROM DEPARTMENT WHERE id = :id";
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
				.addValue("id", id);

		paramTemplate.update(query, sqlParameterSource);
	}

	@Override
	public Set<Department> findAllDepartments(Pageable pageable) {
		Order order = pageable.getSort().toList().get(0);
		String columnName;
		switch (order.getProperty()) {
			case "deptName":
				columnName = "d.department_name";
				break;

			case "jduName":
				columnName = "j.jdu_name";
				break;

			default:
				columnName = "d.department_name";
		}

		String query = "SELECT * FROM department d INNER JOIN jdu_type j ON d.jdu_id = j.id"
				+ " ORDER BY " + columnName + " " + order.getDirection()
				+ " LIMIT :pageSize OFFSET :pageOffset";
		SqlParameterSource sqlParameterSource= new MapSqlParameterSource()
				.addValue("pageSize", pageable.getPageSize())
				.addValue("pageOffset", pageable.getOffset());

		List<Department> deptList = paramTemplate.query(query, sqlParameterSource, new DepartmentRowMapper());

		return new LinkedHashSet<>(deptList);
	}

	@Override
	public int countDepartment() {
		try {
			return jdbcTemplate.queryForObject("SELECT count(*) FROM department", Integer.class);
		} catch(NullPointerException e) {
    		return 0;
    	}
	}
	
	@Override
	public int countDepartmentFound(String searchKey) {
		try {
			String query = "SELECT count(*) FROM department d INNER JOIN jdu_type j ON d.jdu_id = j.id "
					+ "WHERE LOWER(d.department_name)  LIKE LOWER('%" + searchKey + "%') ";
			
			return jdbcTemplate.queryForObject(query, Integer.class);
		} catch(NullPointerException e) {
    		return 0;
    	}
	}

	@Override
	public Set<Department> findDepartmentByName(String searchKey, Pageable pageable) {
		Order order = pageable.getSort().toList().get(0);
		String columnName;
		switch (order.getProperty()) {
			case "deptName":
				columnName = "d.department_name";
				break;

			case "jduName":
				columnName = "j.jdu_name";
				break;

			default:
				columnName = "d.department_name";
		}

		String query = "SELECT * FROM department d INNER JOIN jdu_type j ON d.jdu_id = j.id "
				+ "WHERE LOWER(d.department_name)  LIKE LOWER('%" + searchKey + "%') "
				+ "ORDER BY " + columnName + " " + order.getDirection() + " "
				+ "LIMIT :pageSize OFFSET :pageOffset";
		SqlParameterSource sqlParameterSource= new MapSqlParameterSource()
				.addValue("pageSize", pageable.getPageSize())
				.addValue("pageOffset", pageable.getOffset());

		List<Department> deptList = paramTemplate.query(query, sqlParameterSource, new DepartmentRowMapper());

		return new LinkedHashSet<>(deptList);
	}

}

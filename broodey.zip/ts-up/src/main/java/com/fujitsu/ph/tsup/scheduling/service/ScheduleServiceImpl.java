package com.fujitsu.ph.tsup.scheduling.service;

import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.enrollment.domain.CourseParticipant;
import com.fujitsu.ph.tsup.enrollment.service.EnrollmentService;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;
import com.fujitsu.ph.tsup.scheduling.dao.ScheduleDao;
import com.fujitsu.ph.tsup.scheduling.domain.CourseSchedule;
import com.fujitsu.ph.tsup.scheduling.domain.CourseScheduleDetail;
import com.fujitsu.ph.tsup.scheduling.model.ChangeStatusScheduleForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleDetailForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleNewForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleUpdateForm;
import com.fujitsu.ph.tsup.scheduling.model.CourseScheduleViewForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.TopLearnersForm;
import com.fujitsu.ph.tsup.scheduling.model.TrainingPeriod;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;

/**
 * <pre>
 * The implementation of schedule service
 * 
 * <pre>
 * 
 * @version 0.03
 * @author j.macabugao
 * @author jc.jimenez
 * @author j.balanon
 * @author j.atendido
 */

// =======================================================
// $Id: PR02$
// Project Name: Training Sign Up
// Class Name: ScheduleServiceImpl.java
//
// <<Modification History>>
// Version | Date | Updated by | Content
// --------+------------+-------------------+---------------
// 0.01    | 06/24/2020 | WS) JC. Jimenez   | New Creation
// 0.01    | 06/24/2020 | WS) J. Macabugao  | New Creattion
// 0.02    | 06/25/2020 | WS) J. Balanon    | New Creattion
// 0.03    | 07/08/2021 | WS) J.Atendido    | Added new columns for View/Edit data table
// 0.04    | 08/05/2021 | WS) MI.Aguinaldo  | Implemented findAllInstructorCourseScheduleds
// 0.05    | 08/05/2021 | WS) DW.Cardenas   | Pagination for View and Change Sched, Change Sched Status
// 0.06    | 09/07/2021 | WS) D.Dinglasan   | Limit the Pagination pages to 10
// 0.06    | 09/03/2021 | WS) RU.delaCruz   | Filter Functions for Instructor Course Schedule List
// 0.07    | 10/14/2021 | WS) Ju.Cuevas     | Add Tags Filter Functions for View and Change Sched, Instructor Course Schedule List
// 0.08    | 12/29/2021 | WS) ep.delosreyes | Removed process regarding top learners
//=======================================================
@Service
public class ScheduleServiceImpl implements ScheduleService {

	/**
	 * Schedule dao
	 */
	@Autowired
	private ScheduleDao scheduleDao;

	/**
	 * Enrollment Service
	 */
	@Autowired
	EnrollmentService enrollmentService;

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${sender.email}")
	private String senderEmail;

	public void sendEmailtoParticipants(Long id, ZonedDateTime formStart, ZonedDateTime formEnd) {

		CourseSchedule courseSched = scheduleDao.findCourseScheduleById(id);
		MimeMessage message = javaMailSender.createMimeMessage();
		String newStart = formStart.withZoneSameInstant(ZoneId.systemDefault())
				.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy hh:mm a"));
		String newEnd = formEnd.withZoneSameInstant(ZoneId.systemDefault())
				.format(DateTimeFormatter.ofPattern("MMM-dd-yyyy hh:mm a"));

		try {
			Set<CourseParticipant> participants = enrollmentService.findAllParticipantByCourseScheduleId(id);
			for (CourseParticipant participant : participants) {
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(participant.getEmail()));
			}

			message.setSubject("[UPDATE] " + courseSched.getCourseName() + " - Change in Schedule");
			message.setFrom(new InternetAddress(senderEmail));
			message.setContent(
					"<body style='text-align:center;'><table style='font-family: segoe ui; text-align:center; border:1px solid #e6e6e6; width: 480px'>"
							+ "<tr><td style='background: #2c3e50; color: white; padding: 15px'>"
							+ courseSched.getCourseName() + "</td></tr>"
							+ "<tr><td style='font-size: 12px'><br>NEW SCHEDULE</td></tr>"
							+ "<tr><td><table style='width:100%; padding: 5px; text-align:center; border-collapse:collapse; font-family: segoe ui; font-size: 14px'>"
							+ "<tr style='background: #fcfcfc'><th style='border: 1px solid #e6e6e6'>Start</th>"
							+ "<th style='border: 1px solid #e6e6e6'>End</th></tr>"
							+ "<tr><td style='padding-left: 10px; padding-right: 10px; border: 1px solid #e6e6e6'>"
							+ newStart + "</td>"
							+ "<td style='padding-left: 10px; padding-right: 10px; border: 1px solid #e6e6e6'>" + newEnd
							+ "</td></tr>" + "</table></td></tr>"
							+ "<tr><td style='text-align:left; font-size: 12px; color:gray; padding-top:20px; height: 20px;'>You are receiving this e-mail because you are enrolled to "
							+ courseSched.getCourseName() + ".</td></tr>"
							+ "<tr><td style='text-align:left; font-size: 12px; color:gray; padding-top:5px; padding-bottom:10px; height: 20px'>Training Sign-Up Team</td></tr>"
							+ "</table></body>",
					"text/html");
			System.out.println("Sending...");
			javaMailSender.send(message);
			System.out.println("Sent");
		} catch (MessagingException e) {
			throw new IllegalArgumentException("This should never happen unless mail properties are invalid.", e);
		}
		System.out.println(this.toString());
	}

	/**
	 * <pre>
	 * Finds all scheduled courses based on the given date range Call
	 * scheduleDao.findAllScheduledCourses using the given fromDateTime, toDateTime
	 * and return the result
	 * 
	 * <pre>
	 * 
	 * @param fromDate
	 * @param toDate
	 */
	@Override
	public Set<CourseSchedule> findAllScheduledCourses(ZonedDateTime fromDate, ZonedDateTime toDate) {
		try {
			return scheduleDao.findAllScheduledCourses(fromDate, toDate);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't access fromDate and toDate.");
		}
	}

	/**
	 * <pre>
	 * Finds all scheduled courses of the instructor based on the given date range
	 * and instructor id
	 * 
	 * <pre>
	 * 
	 * @param instructorId
	 * @param trainingPeriod
	 * @param pageable
	 * @return
	 */
	@Override
	public Set<CourseSchedule> findAllInstructorScheduledCourses(Long instructorId, TrainingPeriod trainingPeriod, CourseScheduleListForm courseScheduleListForm, Pageable pageable) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (!user.getId().equals(instructorId) && !user.getRoles().contains("Instructor")) {
            return new LinkedHashSet<>();
        }

        try {

            Set<CourseSchedule> courseScheduleSet = scheduleDao.findAllInstructorCourseSchedules(instructorId,
                    trainingPeriod, courseScheduleListForm, pageable);

            if (courseScheduleSet == null || courseScheduleSet.isEmpty()) {
                throw new IllegalArgumentException("No Course Schedule Found");
            }

            return courseScheduleSet;
        } catch (DataAccessException ex) {
            throw new IllegalArgumentException("Can't Access From Datetime and To Datetime");
        }
	}
	
    @Override
    public int countInstructorScheduledCourses(TrainingPeriod trainingPeriod, Long id, String courseCategoryId,String courseNameId, String venueId, String mandatory, String mandatoryType) {
    	
    	return scheduleDao.countAllInstructorCourseSchedules(id, trainingPeriod, courseCategoryId, courseNameId, venueId, mandatory,mandatoryType);
    	
    }

	/**
	 * <pre>
	 * Finds all courses. Call scheduleDao.findAllCourses and return the result.
	 * 
	 * <pre>
	 */
	@Override
	public Set<CourseForm> findAllCourses() {

		try {
			Set<CourseForm> courseFormList = scheduleDao.findAllCourses();
			if (courseFormList == null || courseFormList.isEmpty()) {
				throw new IllegalArgumentException("Can't find Courses");
			}

			return courseFormList;
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't access Courses");
		}
	}

	/**
	 * <pre>
	 * Finds all instructors Call scheduleDao.findAllInstructors and return the
	 * result
	 * 
	 * <pre>
	 */
	@Override
	public Set<InstructorForm> findAllInstructors() {

		try {
			Set<InstructorForm> instructorFormList = scheduleDao.findAllInstructors();
			if (instructorFormList == null || instructorFormList.isEmpty()) {
				throw new IllegalArgumentException("Can't find Instructors");
			}

			return instructorFormList;
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't access Instructors");
		}

	}

	/**
	 * <pre>
	 * Finds all venues Call scheduleDao.findAllVenues and return the result
	 * 
	 * <pre>
	 */
	@Override
	public Set<VenueForm> findAllVenues() {

		try {
			Set<VenueForm> venueFormList = scheduleDao.findAllVenues();
			if (venueFormList == null || venueFormList.isEmpty()) {
				throw new IllegalArgumentException("Can't find Venues");
			}

			return venueFormList;
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't access Venues");
		}

	}

	/**
	 * <pre>
	 * Create a course schedule Call the scheduleDao.saveCourseSchedule using the
	 * given courseSchedule
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void createCourseSchedule(CourseSchedule courseSchedule) {

		try {
			scheduleDao.saveCourseSchedule(courseSchedule);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't save course schedule");
		}
	}

	/**
	 * <pre>
	 * Update a course schedule Call ScheduleDao.updateCourseSchedule by using
	 * Course Schedule Object.
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void updateCourseSchedule(CourseSchedule courseSchedule) {

		try {
			scheduleDao.updateCourseSchedule(courseSchedule);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't update course schedule");
		}
	}

	/**
	 * <pre>
	 * Delete a course schedule Call ScheduleDao.deleteCourseScheduleById by using
	 * Course ID
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void deleteCourseScheduleById(Long id) {

		try {
			scheduleDao.deleteCourseScheduleById(id);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't delete course schedule");
		}
	}

	/**
	 * <pre>
	 * Counts the Enrolled Courses by Instructor Id Call
	 * ScheduleDao.countAllEnrolledCoursesByInstructorId by using Instructor Id
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 * @return
	 */
	@Override
	public int countAllEnrolledCoursesByInstructorId(Long id) {
		try {
			return scheduleDao.countAllEnrolledCoursesByInstructorId(id);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't Find Enrolled Courses");
		}

	}

	/**
	 * <pre>
	 * Find Course Schedule by Id Call ScheduleDao.findCourseScheduleById by using
	 * Id
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public CourseSchedule findCourseScheduleById(Long id) {
		try {
			return scheduleDao.findCourseScheduleById(id);
		} catch (DataAccessException ex) {
			String err = String.format("Can't find Course Schedule for id %d:%n [%s]", id, ex.getMessage());
			throw new IllegalArgumentException(err);
		}

	}

	
	/**
	 * <pre>
	 * Find Course Schedule by Id Call ScheduleDao.findCourseScheduleByCourseId by
	 * using Course Schedule Id
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public Set<CourseSchedule> findCourseScheduleByCourseId(Long id) {
		try {
			return scheduleDao.findCourseScheduleByCourseId(id);
		} catch (DataAccessException ex) {
			String err = String.format("Can't find Course Schedule for course id %d:%n [%s]", id, ex.getMessage());
			throw new IllegalArgumentException(err);
		}
	}

	/**
	 * <pre>
	 * Change Schedule Status by ScheduleDao.updateCourseScheduleStatus by using
	 * Course Schedule Id
	 * 
	 * <pre>
	 * 
	 * @param courseSchedule
	 */
	@Override
	public void changeScheduleStatus(Set<CourseSchedule> courseSchedules) {
		try {
			scheduleDao.updateCourseScheduleStatus(courseSchedules);
		} catch (DataAccessException ex) {
			throw new IllegalArgumentException("Can't update Course Schedule Status.");
		}
	}

	/**
	 * <pre>
	 * Check if venue can be overlapped from other course schedule
	 * </pre>
	 * @param venueId
	 * @return boolean
	 */
	private boolean isVenueOverlap(Long venueId) {
	    for (VenueForm venue : findAllVenues()) {
            if (venueId.equals(venue.getId())) {
                return true;
            }
        }
	    return false;
	}
	
	/**
	 * <pre>
	 * Check if course schedule conflicts from others with regards to time, venue and instructor
	 * </pre>
	 * @param courseSchedule
	 * @param cSchedDet
	 * @param courseScheduleDetailList
	 * @param courseId
	 * @param instructorId
	 * @param venueId
	 * @return boolean
	 */
	private boolean isScheduleConflict(CourseSchedule courseSchedule, CourseScheduleDetail cSchedDet, 
	        List<CourseScheduleDetailForm> courseScheduleDetailList, Long courseId, Long instructorId, Long venueId) {
	    
	    // Checks for time conflict
        if (courseScheduleDetailList.stream()
                .anyMatch(i -> (((i.getScheduledStartDateTime().isBefore(cSchedDet.getScheduledEndDateTime()))
                        && (cSchedDet.getScheduledStartDateTime().isBefore(i.getScheduledEndDateTime())))
                        || ((i.getScheduledEndDateTime().withZoneSameInstant(ZoneId.systemDefault())
                                .equals(cSchedDet.getScheduledEndDateTime()))
                                && (courseScheduleDetailList.stream()
                                        .anyMatch(o -> o.getScheduledStartDateTime()
                                                .withZoneSameInstant(ZoneId.systemDefault())
                                                .equals(cSchedDet.getScheduledStartDateTime()))))))) {
            // If there is a time conflict, check if venue is can have overlapping schedules
            if (isVenueOverlap(venueId) || courseSchedule.isVenueOverlap()) {
                // If venue can have overlap make sure course or trainer is not the same
                return (courseSchedule.getCourseId().equals(courseId)
                        || courseSchedule.getInstructorId().equals(instructorId));
            } else {
                // If Venue overlap is not allowed, check if venue chosen is the same as the
                // venue of an existing schedule
                if (venueId.equals(courseSchedule.getVenueId())) {
                    return true;
                } else {
                    // If Venue is not the same, check if the course or instructor is the same
                    return (courseSchedule.getCourseId().equals(courseId)
                            || courseSchedule.getInstructorId().equals(instructorId));
                }
            }
        }
        return false;
	}
	
	@Override
	public boolean checkForScheduleConflict(CourseScheduleNewForm form, CourseSchedule courseSchedule,
			CourseScheduleDetail cSchedDet) {

		return isScheduleConflict(courseSchedule, cSchedDet, form.getCourseScheduleDetailsAsList(),
		        form.getCourseId(), form.getInstructorId(), form.getVenueId());
	}

	public boolean checkForScheduleConflictUpdate(CourseScheduleUpdateForm form, CourseSchedule courseSchedule,
			CourseScheduleDetail cSchedDet) {

	    return isScheduleConflict(courseSchedule, cSchedDet, form.getCourseScheduleDetailList(), 
	            form.getCourseId(), form.getInstructorId(), form.getVenueId());
	}

	@Override
	public List<ChangeStatusScheduleForm> findCourseScheduleByCourseId(Long id, Pageable pageable) {
		try {
			return scheduleDao.findCourseScheduleByCourseId(id, pageable).stream().map(ChangeStatusScheduleForm::new)
					.collect(Collectors.toList());
		} catch (DataAccessException ex) {
			String err = String.format("Failed to get course schedules for id %d:%n [%s]", id, ex.getMessage());
			throw new IllegalArgumentException(err);
		}
	}

	@Override
	public int getCourseCountById(Long id) {
		return scheduleDao.countCoursesById(id);
	}

    /*
     * (non-Javadoc)
     * @see
     * com.fujitsu.ph.tsup.scheduling.service.ScheduleService#findAllScheduledCoursesWithinPeriod(com.fujitsu.
     * ph.tsup.scheduling.model.TrainingPeriod, org.springframework.data.domain.Pageable)
     */
    @Override
    public Paged<CourseScheduleViewForm> findAllScheduledCoursesWithinPeriod(TrainingPeriod trainingPeriod,
            Pageable pageable) {
        
        try {
            List<CourseScheduleViewForm> courseSchedList = scheduleDao
                    .findAllScheduledCoursesWithinPeriod(trainingPeriod, pageable).stream()
                    .map(CourseScheduleViewForm::new).collect(Collectors.toList());

            // 0.06 2021/09/07 WS) D.Dinglasan Mod_Start
            Page<CourseScheduleViewForm> pageImplCourseSched = new PageImpl<>(courseSchedList, pageable,
                    scheduleDao.countAllScheduledCoursesWithinPeriod(trainingPeriod));
            return new Paged<>(pageImplCourseSched, Paging.of(pageImplCourseSched.getTotalPages(),
                    pageable.getPageNumber() + 1, pageable.getPageSize()));
            // 0.06 2021/09/07 WS) D.Dinglasan Mod_End
        } catch (DataAccessException ex) {
            String err = String.format("Failed to get all course schedules between %s and %s:%n [%s]",
                    trainingPeriod.getFromDateTimeTimezoneOnUTC().toString(),
                    trainingPeriod.getToDateTimeTimezoneOnUTC().toString(), ex.getMessage());
            throw new IllegalArgumentException(err);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.fujitsu.ph.tsup.scheduling.service.ScheduleService#findAllScheduledCoursesForChangeStatus(com.
     * fujitsu.ph.tsup.scheduling.model.TrainingPeriod, org.springframework.data.domain.Pageable)
     */
    @Override
    public Paged<ChangeStatusScheduleForm> findAllScheduledCoursesForChangeStatus(
            TrainingPeriod trainingPeriod, Pageable pageable) {
        
        try {
            List<ChangeStatusScheduleForm> courseSchedList = scheduleDao
                    .findAllScheduledCoursesWithinPeriod(trainingPeriod, pageable).stream()
                    .map(ChangeStatusScheduleForm::new).collect(Collectors.toList());

            Page<ChangeStatusScheduleForm> pageCourseSchedule = new PageImpl<>(courseSchedList, pageable,
                    scheduleDao.countAllScheduledCoursesWithinPeriod(trainingPeriod));

            return new Paged<>(pageCourseSchedule, Paging.of(pageCourseSchedule.getTotalPages(),
                    pageable.getPageNumber() + 1, pageable.getPageSize()));
        } catch (DataAccessException ex) {
            String err = String.format("Failed to get all course schedules between %s and %s:%n [%s]",
                    trainingPeriod.getFromDateTimeTimezoneOnUTC().toString(),
                    trainingPeriod.getToDateTimeTimezoneOnUTC().toString(), ex.getMessage());
            throw new IllegalArgumentException(err);
        }
    }

    @Override
    public Set<CourseCategory> findAllCourseCategory() {

        return scheduleDao.findAllCourseCategory();
    }
}

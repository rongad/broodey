/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.domain;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : ResponseRating.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

public class ResponseRating {
    
    private Ratings question1Ratings;
    private Ratings question2Ratings;
    private Ratings question3Ratings;
    private Ratings question4Ratings;
    
    
    public ResponseRating() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    /**
     * @param question1Ratings
     * @param question2Ratings
     * @param question3Ratings
     * @param question4Ratings
     */
    public ResponseRating(Ratings question1Ratings, Ratings question2Ratings, Ratings question3Ratings,
            Ratings question4Ratings) {
        super();
        this.question1Ratings = question1Ratings;
        this.question2Ratings = question2Ratings;
        this.question3Ratings = question3Ratings;
        this.question4Ratings = question4Ratings;
    }



    public ResponseRating(Integer question1Ratings, Integer question2Ratings, Integer question3Ratings,
            Integer question4Ratings) {
        
        this.question1Ratings = Ratings.fromValue(question1Ratings);
        this.question2Ratings = Ratings.fromValue(question2Ratings);
        this.question3Ratings = Ratings.fromValue(question3Ratings);
        this.question4Ratings = Ratings.fromValue(question4Ratings);
    }

    /**
     * @return the question1Ratings
     */
    public Ratings getQuestion1Ratings() {
        return question1Ratings;
    }

    /**
     * @param question1Ratings the question1Ratings to set
     */
    public void setQuestion1Ratings(Ratings question1Ratings) {
        this.question1Ratings = question1Ratings;
    }

    /**
     * @return the question2Ratings
     */
    public Ratings getQuestion2Ratings() {
        return question2Ratings;
    }

    /**
     * @param question2Ratings the question2Ratings to set
     */
    public void setQuestion2Ratings(Ratings question2Ratings) {
        this.question2Ratings = question2Ratings;
    }

    /**
     * @return the question3Ratings
     */
    public Ratings getQuestion3Ratings() {
        return question3Ratings;
    }

    /**
     * @param question3Ratings the question3Ratings to set
     */
    public void setQuestion3Ratings(Ratings question3Ratings) {
        this.question3Ratings = question3Ratings;
    }

    /**
     * @return the question4Ratings
     */
    public Ratings getQuestion4Ratings() {
        return question4Ratings;
    }

    /**
     * @param question4Ratings the question4Ratings to set
     */
    public void setQuestion4Ratings(Ratings question4Ratings) {
        this.question4Ratings = question4Ratings;
    }

}

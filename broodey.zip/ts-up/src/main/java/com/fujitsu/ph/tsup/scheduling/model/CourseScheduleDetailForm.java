package com.fujitsu.ph.tsup.scheduling.model;

//=======================================================
//$Id: PR02$
//Project Name: Training Sign Up
//Class Name: CourseScheduleDetailForm.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 06/22/2020 | WS) J.Macabugao  | New Creation
//0.02    | 08/05/2021 | WS) MI.Aguinaldo | Update
//
//=======================================================

/**
* <pre>
* It is a JavaBean for CourseScheduleDetailForm
* <pre>
* @version 0.01
* @author j.macabugao
*
*/
import java.time.ZonedDateTime;
import java.util.Objects;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fujitsu.ph.tsup.scheduling.domain.CourseScheduleDetail;

public class CourseScheduleDetailForm {

    /**
     * Id
     */
    private Long id;

    /**
     * Start Date and Time
     */
    @NotNull
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime scheduledStartDateTime;

    /**
     * End Date and Time
     */
    @NotNull
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime scheduledEndDateTime;

    /**
     * Duration
     */
    private float duration;
    
    
    public CourseScheduleDetailForm() {

    }
    
    

    public CourseScheduleDetailForm(CourseScheduleDetail courseScheduleDetail) {
	Objects.requireNonNull(courseScheduleDetail);
	
	this.id = courseScheduleDetail.getId();
	this.scheduledStartDateTime = courseScheduleDetail.getScheduledStartDateTime();
	this.scheduledEndDateTime = courseScheduleDetail.getScheduledEndDateTime();
	this.duration = courseScheduleDetail.getDuration();
    }



    public Long getId() {
	return id;
    }

    public void setId(Long id) {
	this.id = id;
    }

    public ZonedDateTime getScheduledStartDateTime() {
	return scheduledStartDateTime;
    }

    public void setScheduledStartDateTime(ZonedDateTime scheduledStartDateTime) {
	this.scheduledStartDateTime = scheduledStartDateTime;
    }

    public ZonedDateTime getScheduledEndDateTime() {
	return scheduledEndDateTime;
    }

    public void setScheduledEndDateTime(ZonedDateTime scheduledEndDateTime) {
	this.scheduledEndDateTime = scheduledEndDateTime;
    }

    public float getDuration() {
	return duration;
    }

    public void setDuration(float duration) {
	this.duration = duration;
    }

    @Override
    public String toString() {
	return "CourseScheduleDetailForm [id=" + id + ", scheduledStartDateTime=" + scheduledStartDateTime
		+ ", scheduledEndDateTime=" + scheduledEndDateTime + ", duration = " + duration + "]";
    }
}

package com.fujitsu.ph.tsup.survey.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.attendance.service.AttendanceService;
import com.fujitsu.ph.tsup.survey.domain.Survey;
import com.fujitsu.ph.tsup.survey.model.MostRequestedTraining;
import com.fujitsu.ph.tsup.survey.model.SurveyForm;
import com.fujitsu.ph.tsup.survey.service.SurveyFormService;

// ===================================================================================================================
// $Id:PR16$
// Project Name : Training Sign up
// System Name : Survey Form Process
// Class Name : SurveyFormController.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-------------------------------------------------------------------------+-------------------
// 0.01 | 08/12/2021 | WS) J.Gabalones | New Creation
// 0.02 | 10/27/2021 | WS) L.Celoso | Made the comments optional / fix the indentions of the code
// 0.01 | 11/23/2021 | WS) Mj.liwag | added controller for API
// ===================================================================================================================
/**
 * <pre>
* It is the implementation of survey form service
* In this class, it implements the SurveyFormService class for the initial setting of the database
 * </pre>
 * 
 * @version 0.01
 * @author j.gabalones
 */

@Controller
@RequestMapping("/survey")
public class SurveyFormController {

    /*
     * <pre> Useful methods for logging and also decouple the logging implementation from application <pre>
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyFormController.class);

    /*
     * <pre> It is the interface of survey form service <pre>
     */
    @Autowired
    private SurveyFormService surveyFormService;

    /*
     * <pre> It is the interface of attendance service <pre>
     */
    @Autowired
    private AttendanceService attendanceService;

    /**
     * <pre>
     * As a member. I can view and take the survey form after signing out. URL Value = survey/surveyForm,
     * method = GET attendanceService.findCourseScheduleDetailById. Using the given id, set the values from
     * the previous step into the surveyForm, Return the surveyForm and view
     * 
     * <pre>
     * 
     * @param id
     * @param model
     * @return attendance/viewInstructorCourseParticipants
     */
    @GetMapping("/{courseScheduleDetailId}")
    public String showSurveyForm(Model model, @PathVariable("courseScheduleDetailId") Long id) {

        SurveyForm surveyForm = new SurveyForm();

        Set<CourseAttendance> courseAttendanceList = attendanceService.findCourseScheduleDetailById(id);

        for (CourseAttendance courseAttendance : courseAttendanceList) {
            LOGGER.info("Course AttendanceList : {}", courseAttendanceList);
            surveyForm.setCourseTitle(courseAttendance.getCourseName());
            surveyForm.setInstructorName(courseAttendance.getInstructorName());
            surveyForm.setCourseDateTime(courseAttendance.getScheduleStartDateTime());
            surveyForm.setCourseEndDate(courseAttendance.getScheduleEndDateTime());
            surveyForm.setCourseScheduleDetailId(courseAttendance.getCourseScheduleDetailId());
            surveyForm.setTrainingVenue(courseAttendance.getVenueName());
        }
        model.addAttribute("surveyForm", surveyForm);
        return "survey/surveyForm";
    }

    /**
     * <pre>
     * As a member. I can view and take the survey form after signing out. URL Value = survey/surveyForm,
     * method = POST
     * 
     * <pre>
     * 
     * @param form
     * @param model
     * @param @ModelVariable("courseScheduleDetailId")
     * @return redirect:/attendance/signin#surveyModal
     */
    @PostMapping("/create")
    public String createSurveyForm(@ModelAttribute("surveyForm") SurveyForm form, Model model) {

        try {

            Set<CourseAttendance> courseAttendanceList = attendanceService
                    .findCourseScheduleDetailById(form.getCourseScheduleDetailId());
            for (CourseAttendance courseAttendance : courseAttendanceList) {
                form.setCourseDateTime(courseAttendance.getScheduleStartDateTime());
            }
            LOGGER.info("SurveyForm{}", form);

            Survey surveyForm = new Survey.Builder(form.getCourseEndDate(), form.getCourseScheduleDetailId(),
                    form.getCourseTitle(), form.getTrainingVenue(), form.getInstructorName(),
                    form.getCourseDateTime(), form.getMdQuestion1(), form.getMdQuestion2(),
                    form.getMdQuestion3(), form.getMdQuestion4(), form.getMatQuestion1(),
                    form.getMatQuestion2(), form.getMatQuestion3(), form.getMatQuestion4(),
                    form.getInsQuestion1(), form.getInsQuestion2(), form.getInsQuestion3(),
                    form.getInsQuestion4(), form.getInsQuestion5(), form.getInsQuestion6(),
                    form.getEqFaQuestion1(), form.getEqFaQuestion2(), form.getEqFaQuestion3(),
                    form.getCommentsE(), form.getCommentsF(), form.getCommentsG()).build();

            surveyFormService.createSurvey(surveyForm);

        } catch (DataAccessException e) {
            model.addAttribute("surveyError", e.getMessage());
        }

        if (form.getGoToMostRequestedSurvey() == false) {
            return "redirect:/attendance/signin";
        } else {
            return "redirect:/survey/viewMostRequestedTraining";
        }
    }

    @GetMapping("/viewMostRequestedTraining")
    public String viewMostRequestedTraining(Model model) {

        List<MostRequestedTraining> result = new ArrayList<MostRequestedTraining>();

        String theUrl = "http://10.164.34.87:9010/survey/api/getAllSurvey?projectName=TestProject2-TypeCPO/Direct";
        RestTemplate restTemplate = new RestTemplate();
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth("QENqMDYxNjk0");
            HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
            ResponseEntity<MostRequestedTraining[]> response = restTemplate.exchange(theUrl, HttpMethod.GET,
                    entity, MostRequestedTraining[].class);

            System.out.println(
                    "Result - status (" + response.getStatusCode() + ") has body: " + response.hasBody());

            for (MostRequestedTraining res : response.getBody()) {
                System.out.print("res" + res.getExpiryDate());
                result.add(res);

            }

            model.addAttribute("mostRequestedTraining", result);
        } catch (Exception eek) {
            System.out.println("** Exception: " + eek.getMessage());
        }
        return "survey/mostRequestedTraining";
    }
}

/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.dao;

import java.time.ZonedDateTime;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : SurveyResponse.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

public class SurveyResponse {
    private Long id;
    
    private String courseTitle;
    
    private String instructorName;
    
    private ZonedDateTime courseDateTime;
    
    private ModuleDesignResponse moduleDesignResponseRatings;
    
    private MaterialsResponse materialsResponse;
    
    private InstructionResponse instructionResponse;
    
    private EquipmentAndFacilitiesResponse equipmentAndFacilitiesResponse;
    
    private String commentsE;
    
    private String commentsF;
    
    private String commentsG;
    
    
    public SurveyResponse() {
    }

    private SurveyResponse(Builder builder) {
        this.id = builder.id;
        this.courseTitle = builder.courseTitle;
        this.instructorName = builder.instructorName;
        this.courseDateTime = builder.courseDateTime;
        this.moduleDesignResponseRatings = builder.moduleDesignResponseRatings;
        this.materialsResponse = builder.materialsResponse;
        this.instructionResponse = builder.instructionResponse;
        this.equipmentAndFacilitiesResponse = builder.equipmentAndFacilitiesResponse;
        this.commentsE = builder.commentsE;
        this.commentsF = builder.commentsF;
        this.commentsG = builder.commentsG;
    }

    /**
     * @return the moduleDesignResponseRatings
     */
    public ModuleDesignResponse getModuleDesignResponseRatings() {
        return moduleDesignResponseRatings;
    }

    /**
     * @param moduleDesignResponseRatings the moduleDesignResponseRatings to set
     */
    public void setModuleDesignResponseRatings(ModuleDesignResponse moduleDesignResponseRatings) {
        this.moduleDesignResponseRatings = moduleDesignResponseRatings;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the courseTitle
     */
    public String getCourseTitle() {
        return courseTitle;
    }

    /**
     * @param courseTitle the courseTitle to set
     */
    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    /**
     * @return the instructorName
     */
    public String getInstructorName() {
        return instructorName;
    }

    /**
     * @param instructorName the instructorName to set
     */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    /**
     * @return the courseDateTime
     */
    public ZonedDateTime getCourseDateTime() {
        return courseDateTime;
    }

    /**
     * @param courseDateTime the courseDateTime to set
     */
    public void setCourseDateTime(ZonedDateTime courseDateTime) {
        this.courseDateTime = courseDateTime;
    }

    /**
     * @return the materialsResponse
     */
    public MaterialsResponse getMaterialsResponse() {
        return materialsResponse;
    }

    /**
     * @param materialsResponse the materialsResponse to set
     */
    public void setMaterialsResponse(MaterialsResponse materialsResponse) {
        this.materialsResponse = materialsResponse;
    }

    /**
     * @return the instructionResponse
     */
    public InstructionResponse getInstructionResponse() {
        return instructionResponse;
    }

    /**
     * @param instructionResponse the instructionResponse to set
     */
    public void setInstructionResponse(InstructionResponse instructionResponse) {
        this.instructionResponse = instructionResponse;
    }

    /**
     * @return the equipmentAndFacilitiesResponse
     */
    public EquipmentAndFacilitiesResponse getEquipmentAndFacilitiesResponse() {
        return equipmentAndFacilitiesResponse;
    }

    /**
     * @param equipmentAndFacilitiesResponse the equipmentAndFacilitiesResponse to set
     */
    public void setEquipmentAndFacilitiesResponse(EquipmentAndFacilitiesResponse equipmentAndFacilitiesResponse) {
        this.equipmentAndFacilitiesResponse = equipmentAndFacilitiesResponse;
    }

    /**
     * @return the commentsE
     */
    public String getCommentsE() {
        return commentsE;
    }

    /**
     * @param commentsE the commentsE to set
     */
    public void setCommentsE(String commentsE) {
        this.commentsE = commentsE;
    }

    /**
     * @return the commentsF
     */
    public String getCommentsF() {
        return commentsF;
    }

    /**
     * @param commentsF the commentsF to set
     */
    public void setCommentsF(String commentsF) {
        this.commentsF = commentsF;
    }

    /**
     * @return the commentsG
     */
    public String getCommentsG() {
        return commentsG;
    }

    /**
     * @param commentsG the commentsG to set
     */
    public void setCommentsG(String commentsG) {
        this.commentsG = commentsG;
    }

    /**
     * Creates builder to build {@link SurveyResponse}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link SurveyResponse}.
     */
    public static final class Builder {
        private Long id;
        private String courseTitle;
        private String instructorName;
        private ZonedDateTime courseDateTime;
        private ModuleDesignResponse moduleDesignResponseRatings;
        private MaterialsResponse materialsResponse;
        private InstructionResponse instructionResponse;
        private EquipmentAndFacilitiesResponse equipmentAndFacilitiesResponse;
        private String commentsE;
        private String commentsF;
        private String commentsG;

        private Builder() {
        }

        public Builder withId(Long id) {
            this.id = id;
            return this;
        }

        public Builder withCourseTitle(String courseTitle) {
            this.courseTitle = courseTitle;
            return this;
        }

        public Builder withInstructorName(String instructorName) {
            this.instructorName = instructorName;
            return this;
        }

        public Builder withCourseDateTime(ZonedDateTime courseDateTime) {
            this.courseDateTime = courseDateTime;
            return this;
        }

        public Builder withModuleDesignResponseRatings(ModuleDesignResponse moduleDesignResponseRatings) {
            this.moduleDesignResponseRatings = moduleDesignResponseRatings;
            return this;
        }

        public Builder withMaterialsResponse(MaterialsResponse materialsResponse) {
            this.materialsResponse = materialsResponse;
            return this;
        }

        public Builder withInstructionResponse(InstructionResponse instructionResponse) {
            this.instructionResponse = instructionResponse;
            return this;
        }

        public Builder withEquipmentAndFacilitiesResponse(
                EquipmentAndFacilitiesResponse equipmentAndFacilitiesResponse) {
            this.equipmentAndFacilitiesResponse = equipmentAndFacilitiesResponse;
            return this;
        }

        public Builder withCommentsE(String commentsE) {
            this.commentsE = commentsE;
            return this;
        }

        public Builder withCommentsF(String commentsF) {
            this.commentsF = commentsF;
            return this;
        }

        public Builder withCommentsG(String commentsG) {
            this.commentsG = commentsG;
            return this;
        }

        public SurveyResponse build() {
            return new SurveyResponse(this);
        }
    }
    
    
    
}

/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.model;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import org.springframework.format.annotation.DateTimeFormat;
import com.sun.istack.NotNull;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for Dev
//Class Name   : SummaryGSTDevDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | ----/--/-- | WS) -                 | Initial Version
//0.02    | ----/--/-- | WS) g.cabiling        | Updated
//0.03    | 2021/06/14 | WS) m.padaca          | Updated
//0.04    | 2021/10/15 | WS) r.buot            | Updated
//0.05    | 2021/10/20 | WS) dw.cardenas       | Updated
//==================================================================================================

/**
 * <pre>
 * The model for G3CC standardization training for dev
 * </pre>
 * 
 * @version 0.03
 * @author g.cabiling
 * @author m.padaca
 * @author r.buot
 */

public class SummaryGSTDevForm {
    /* Total Number of JDU Dev */
    private Long totalNoJDUDevValue;

    /* Total Number of JDU Dev Last Week */
    private int totalNoJDUDevLastWeekValue;

    /* Total Number of Original Members */
    private int totalNoExistingMemValue;

    /* Total Number of New Members */
    private int totalNoNewMemValue;

    /* Total Number of JDU Dev who finished the Training */
    private Long totalNoJDUDevFinValue;

    /* Total Number of JDU Devs Last Week Who Finished the training */
    private Long totalNoJDUDevLastWkFinValue;

    /* Percentage Finished As of Today (Total Devs and also Total Courses */
    private BigDecimal percentageFinTodayValue;

    /* Percentage Finished As of Last Week (Total Devs and also Total Courses) */
    private BigDecimal percentageFinLastWkValue;

    /** Selected Report Date and Time */
    @NotNull
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime reportDateTime;

    public ZonedDateTime getReportDateTime() {
        return reportDateTime;
    }

    /**
     * <pre>
     * Setter for reportDateTime
     * </pre>
     * 
     * @param reportDateTime
     */
    public void setReportDateTime(ZonedDateTime reportDateTime) {
        this.reportDateTime = reportDateTime;
    }

    /**
     * <pre>
     * Getter method for TotalNoJDUDevValue
     * </pre>
     * 
     * @return
     */
    public Long getTotalNoJDUDevValue() {
        return totalNoJDUDevValue;
    }

    /**
     * <pre>
     * Setter method for TotalNoJDUDevValue
     * </pre>
     * 
     * @param totalNoJDUDevValue
     */
    public void setTotalNoJDUDevValue(Long totalNoJDUDevValue) {
        this.totalNoJDUDevValue = totalNoJDUDevValue;
    }

    /**
     * <pre>
     * Getter method for TotalNoJDUDevLastWeekValue
     * </pre>
     * 
     * @return TotalNoJDUDevLastWeekValue
     */
    public int getTotalNoJDUDevLastWeekValue() {
        return totalNoJDUDevLastWeekValue;
    }

    /**
     * <pre>
     * Setter method for TotalNoJDUDevLastWeekValue
     * </pre>
     * 
     * @param totalNoJDUDevLastWeekValue
     */
    public void setTotalNoJDUDevLastWeekValue(int totalNoJDUDevLastWeekValue) {
        this.totalNoJDUDevLastWeekValue = totalNoJDUDevLastWeekValue;
    }

    /**
     * <pre>
     * Getter method for TotalNoExistingMemValue
     * </pre>
     * 
     * @return TotalNoExistingMemValue
     */
    public int getTotalNoExistingMemValue() {
        return totalNoExistingMemValue;
    }

    /**
     * <pre>
     * Setter method for TotalNoExistingMemValue
     * </pre>
     * 
     * @param TotalNoExistingMemValue
     */
    public void setTotalNoExistingMemValue(int TotalNoExistingMemValue) {
        this.totalNoExistingMemValue = TotalNoExistingMemValue;
    }

    /**
     * <pre>
     * Getter method for TotalNoNewMemValue
     * </pre>
     * 
     * @return TotalNoNewMemValue
     */
    public int getTotalNoNewMemValue() {
        return totalNoNewMemValue;
    }

    /**
     * <pre>
     * Setter method for TotalNoNewMemValue
     * </pre>
     * 
     * @param totalNoNewMemValue
     */
    public void setTotalNoNewMemValue(int totalNoNewMemValue) {
        this.totalNoNewMemValue = totalNoNewMemValue;
    }

    /**
     * <pre>
     * Getter method for TotalNoJDUDevFinValue
     * </pre>
     * 
     * @return TotalNoJDUDevFinValue
     */
    public Long getTotalNoJDUDevFinValue() {
        return totalNoJDUDevFinValue;
    }

    /**
     * <pre>
     * Setter method for TotalNoJDUDevFinValue
     * </pre>
     * 
     * @param totalNoJDUDevFinValue
     */
    public void setTotalNoJDUDevFinValue(Long totalNoJDUDevFinValue) {
        this.totalNoJDUDevFinValue = totalNoJDUDevFinValue;
    }

    /**
     * <pre>
     * Getter method for TotalNoJDUDevLastWkFinValue
     * </pre>
     * 
     * @return TotalNoJDUDevLastWkFinValue
     */
    public Long getTotalNoJDUDevLastWkFinValue() {
        return totalNoJDUDevLastWkFinValue;
    }

    /**
     * <pre>
     * Setter method for TotalNoJDUDevLastWkFinValue
     * </pre>
     * 
     * @param totalNoJDUDevLastWkFinValue
     */
    public void setTotalNoJDUDevLastWkFinValue(Long totalNoJDUDevLastWkFinValue) {
        this.totalNoJDUDevLastWkFinValue = totalNoJDUDevLastWkFinValue;
    }

    /**
     * <pre>
     * Getter method for PercentageFinTodayValue
     * </pre>
     * 
     * @return PercentageFinTodayValue
     */
    public BigDecimal getPercentageFinTodayValue() {
        return percentageFinTodayValue;
    }

    /**
     * <pre>
     * Put method description here
     * </pre>
     * 
     * @param percentageFinTodayValue
     */
    public void setPercentageFinTodayValue(BigDecimal percentageFinTodayValue) {
        this.percentageFinTodayValue = percentageFinTodayValue;
    }

    /**
     * <pre>
     * Getter method for PercentageFinLastWkValue
     * </pre>
     * 
     * @return PercentageFinLastWkValue
     */
    public BigDecimal getPercentageFinLastWkValue() {
        return percentageFinLastWkValue;
    }

    /**
     * <pre>
     * Setter method for PercentageFinLastWkValue
     * </pre>
     * 
     * @param percentageFinLastWkValue
     */
    public void setPercentageFinLastWkValue(BigDecimal percentageFinLastWkValue) {
        this.percentageFinLastWkValue = percentageFinLastWkValue;
    }

    @Override
    public String toString() {
        return "SummaryGSTDevForm = [TotalNoJDUDevValue = " + totalNoJDUDevValue
                + ", TotalNoJDUDevLastWeekValue =" + totalNoJDUDevLastWeekValue
                + ", TotalNoExistingMemValue =" + totalNoExistingMemValue + "," + ",TotalNoNewMemValue ="
                + totalNoNewMemValue + ", TotalNoJDUDevFinValue =" + totalNoJDUDevFinValue
                + ". TotalNoJDUDevLastWkFinValue =" + totalNoJDUDevLastWkFinValue + ","
                + ", PercentageFinTodayValue =" + percentageFinTodayValue + ", PercentageFinLastWkValue ="
                + percentageFinLastWkValue + " ]";
    }
}

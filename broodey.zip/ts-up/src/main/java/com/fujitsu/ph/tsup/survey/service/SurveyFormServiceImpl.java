package com.fujitsu.ph.tsup.survey.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.exception.TsupException;
import com.fujitsu.ph.tsup.survey.dao.SurveyFormDao;
import com.fujitsu.ph.tsup.survey.domain.Survey;

//==================================================================================================
//$Id:PR16$
//Project Name : Training Sign up
//System Name  : Survey Form Process 
//Class Name   : SurveyFormServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By                                              | Content
//--------+------------+---------------------------------------------------------+-----------------
//0.01    | 08/12/2021 | WS) J.Gabalones                                         | New Creation
//==================================================================================================
/**
* <pre>
* It is the implementation of survey form service
* In this class, it implements the ServiceFormService class for the initial setting of the database
* </pre>
* 
* @version 0.01
* @author j.gabalones
* 
*/ 

@Service
public class SurveyFormServiceImpl implements SurveyFormService {

    /*
     * SurveyFormDao
     */
    @Autowired
    private SurveyFormDao surveyFormDao;

    /**
     * <pre>
     * 
     * Call surveyFormDao.surveyForm using the given survey argument 
     * 
     * <pre>
     * 
     * @param surveyForm
     */
    @Override
    public void createSurvey(Survey surveyForm) {
        try {
          surveyFormDao.createSurvey(surveyForm);
        } catch (DataAccessException ex) {
            throw new TsupException("Can't create a survey", ex.getCause());
        }
    }

}

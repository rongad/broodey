package com.fujitsu.ph.tsup.course.category.model;

import org.springframework.util.StringUtils;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name   : CourseCategory.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2020/02/08 | WS) a.batongbaca      | Initial Version
//0.03	  | 2021/05/27 | WS) mi.aguinaldo      | Update
//0.04    | 2021/10/25 | WS) dw.acrdenas       | Update
//==================================================================================================

public class CourseCategory {
    private Long id;
    private String category;
    private String detail;

    protected CourseCategory() {}

    public CourseCategory(Builder builder) {
        this.id = builder.id;
        this.category = builder.category;
        this.detail = builder.detail;
    }

    @Override
    public String toString() {
        return "CourseCategory [category=" + category + ", detail=" + detail + "]";
    }

    /**
     * Getter method for Course Category Id
     * 
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Setter method for Course Id
     * 
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Getter method for Course Category
     * 
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * Setter method for Course
     * 
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Getter method for Course Category Detail
     * 
     * @return the detail
     */
    public String getDetail() {
        return detail;
    }

    /**
     * Setter method for Course Detail
     * 
     * @param detail the detail to set
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }

    /**
     * Created Builder for {@link CourseCategory}
     * @return Builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder Class
     * 
     * @author a.batongbaca
     */
    public static final class Builder {
        private Long id;
        private String category;
        private String detail;

        private Builder() {
        }

        public Builder addId(Long id) {
            validateId(id);
            this.id = id;
            return this;
        }

        public Builder addCategory(String category) {
            validateCategory(category);
            this.category = category;
            return this;
        }

        public Builder addDetail(String detail) {
            validateDetail(detail);
            this.detail = detail;
            return this;
        }

        public CourseCategory build() {
            return new CourseCategory(this);
        }

        /**
         * Validate course category name if null or empty
         * 
         * @param name Course Category Name
         */
        private void validateCategory(String category) {
            if (StringUtils.isEmpty(category)) {
                throw new IllegalArgumentException("Course category should not be empty");
            }
        }

        /**
         * Validate Course Category id if null or 0
         * 
         * @param id
         */
        private void validateId(Long id) {
            if (id == null || id == 0) {
                throw new IllegalArgumentException("Id should not be empty");
            }
        }

        /**
         * Validate Course Category Detail if null or empty
         * 
         * @param detail Course Category
         */
        private void validateDetail(String detail) {
            if (StringUtils.isEmpty(detail)) {
                throw new IllegalArgumentException("Detail should not be empty");
            }
        }
    }
}

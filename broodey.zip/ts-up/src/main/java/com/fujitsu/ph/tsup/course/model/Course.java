/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.model;

import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.department.domain.Department;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Course Management
// Class Name : Course.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2020/08/28 | WS) c.lepiten    | Initial Version
// 0.02 | 2021/04/19 | WS) st.diaz      | Updated
// 0.03 | 2021/05/10 | WS) D.Escala     | Updated
// 0.04 | 2021/05/25 | WS) mi.aguinaldo | Update builder and re-factor
// 0.05 | 2021/07/21 | WS) M.Taboada    | Updated
// 0.06 | 2021/08/05 | WS) mi.aguinaldo | Updated
// 0.07 | 2021/09/07 | WS) mi.aguinaldo | Updated
// 0.08 | 2021/10/13 | WS) mi.aguinaldo | Adding Tags in filter search
// 0.08 | 2021/10/07 | WS) r.delacruz   | Updated
// 0.09 | 2021/11/11 | WS) v.tallo      | Change default constructor to public
// ==================================================================================================

public class Course {

    private Long id;
    private String name;
    private String detail;
    private String isMandatory;
    private String deadline;
    private Long courseCategoryId;
    private String mandatoryType;
    private Long departmentId;
    private Department department;
    private CourseCategory courseCategory;
    private String courseCode;
    private String memberRole;

    private Course(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.detail = builder.detail;
        this.isMandatory = builder.isMandatory;
        this.deadline = builder.deadline;
        this.courseCategoryId = builder.courseCategoryId;
        this.mandatoryType = builder.mandatoryType;
        this.departmentId = builder.departmentId;
        this.department = builder.department;
        this.courseCategory = builder.courseCategory;
        this.courseCode = builder.courseCode;
        this.memberRole = builder.memberRole;
    }

    /**
     * Empty Constructor for Course class
     */
    public Course() {

    }

    /**
     * Getter method for Course Id
     * 
     * @return Course Id
     */
    public Long getId() {

        return id;

    }

    /**
     * Setter method for Course Id
     * 
     * @param id Course Id
     */
    public void setId(Long id) {

        this.id = id;

    }

    /**
     * Getter method for Course Name
     * 
     * @return Course name
     */
    public String getName() {

        return name;

    }

    /**
     * Setter method for Course Name
     * 
     * @param name Course Name
     */
    public void setName(String name) {

        this.name = name;

    }

    /**
     * Getter Method for Course Detail
     * 
     * @return Course Detail
     */
    public String getDetail() {

        return detail;

    }

    /**
     * Setter Method for Course Detail
     * 
     * @param detail Course Detail
     */
    public void setDetail(String detail) {

        this.detail = detail;

    }

    /**
     * Getter Method for Course is Mandatory
     * 
     * @return Course is Mandatory
     */
    public String getIsMandatory() {

        return isMandatory;

    }

    /**
     * Setter Method for Course is Mandatory
     * 
     * @param isMandatory Course is Mandatory
     */
    public void setIsMandatory(String isMandatory) {

        this.isMandatory = isMandatory;

    }

    /**
     * Getter Method for Course Deadline
     * 
     * @return Course Deadline
     */
    public String getDeadline() {

        return deadline;

    }

    /**
     * Setter Method for Course Deadline
     * 
     * @param deadline Course Deadline
     */
    public void setDeadline(String deadline) {
        this.deadline = deadline;

    }

    /**
     * Getter Method for Course Category ID
     * 
     * @return Course Category ID
     */

    public Long getCourseCategoryId() {
        return courseCategoryId;
    }

    /**
     * Setter Method for Course Category ID
     * 
     * @param Course Category ID
     */
    public void setCourseCategoryId(Long courseCategoryId) {
        this.courseCategoryId = courseCategoryId;
    }

    /**
     * @return the courseCategory
     */
    public CourseCategory getCourseCategory() {
        return courseCategory;
    }

    /**
     * @param courseCategory the courseCategory to set
     */
    public void setCourseCategory(CourseCategory courseCategory) {
        this.courseCategory = courseCategory;
    }

    public String getMandatoryType() {
        return mandatoryType;
    }

    public void setMandatoryType(String mandatoryType) {
        this.mandatoryType = mandatoryType;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * @return the department
     */
    public Department getDepartment() {
        return department;
    }

    /**
     * @param department the department to set
     */
    public void setDepartment(Department department) {
        this.department = department;
    }

    /**
     * @return the courseCode
     */
    public String getCourseCode() {
        return courseCode;
    }

    /**
     * @param courseCode the courseCode to set
     */
    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    /**
     * @return the memberRole
     */
    public String getMemberRole() {
        return memberRole;
    }

    /**
     * @param MemberRole the MemberRole to set
     */
    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }

    @Override
    public String toString() {
        return "Course [name=" + name + ", detail=" + detail + ", isMandatory=" + isMandatory + ", deadline="
                + deadline + ", courseCategory=" + courseCategory + "]";
    }

    /**
     * Creates builder to build {@link Course}.
     * 
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link Course}.
     */
    public static final class Builder {
        private Long id;
        private String name;
        private String detail;
        private String isMandatory;
        private String deadline;
        private Long courseCategoryId;
        private String mandatoryType;
        private Long departmentId;
        private Department department;
        private CourseCategory courseCategory;
        private String courseCode;
        private String memberRole;

        private Builder() {
        }

        public Builder withId(Long id) {
            this.id = id;
            return this;
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withDetail(String detail) {
            this.detail = detail;
            return this;
        }

        public Builder withIsMandatory(String isMandatory) {
            this.isMandatory = isMandatory;
            return this;
        }

        public Builder withDeadline(String deadline) {
            this.deadline = deadline;
            return this;
        }

        public Builder withCourseCategoryId(Long courseCategoryId) {
            this.courseCategoryId = courseCategoryId;
            return this;
        }

        public Builder withMandatoryType(String mandatoryType) {
            this.mandatoryType = mandatoryType;
            return this;
        }

        public Builder withDepartmentId(Long departmentId) {
            this.departmentId = departmentId;
            return this;
        }

        public Builder withDepartment(Department department) {
            this.department = department;
            return this;
        }

        public Builder withCourseCategory(CourseCategory courseCategory) {
            this.courseCategory = courseCategory;
            return this;
        }

        public Builder withCourseCode(String courseCode) {
            this.courseCode = courseCode;
            return this;
        }

        public Builder withMemberRole(String memberRole) {
            this.memberRole = memberRole;
            return this;
        }

        public Course build() {
            return new Course(this);
        }
    }

}

/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.model;

import java.math.BigDecimal;
import java.time.ZonedDateTime;

import org.springframework.format.annotation.DateTimeFormat;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Summary of JDU Standardization Training for PM
// Class Name : SummaryGSTForm.java
//
// <<Modification History>>
// Version | Date       | Updated By            | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/04/20 | WS) d.escala          | Initial Version
// 0.02    | 2021/04/21 | WS) d.escala          | Updated
// 0.03    | 2021/04/23 | WS) m.padaca          | Updated
// 0.04    | 2021/04/27 | WS) m.padaca          | Updated
// 0.05    | 2021/10/15 | WS) r.buot            | Updated
// 0.05    | 2021/10/20 | WS) dw.cardenas       | Updated
// ==================================================================================================

/**
 * <pre>
 * The controller for the SummaryGSTForm
 * 
 * <pre>
 * 
 * @version 0.04
 * @author m.padaca
 * @author d.escala
 * @author r.buot
 */

public class SummaryGSTForm {

    /** The total number of PMs in JDU. */
    private Long totalNoJDUPMValue;

    /** Total number of PMs last week. */
    private int totalNoJDUPMLastWeekValue;

    /** Total number of original members. */
    private int totalNoOrigMemValue;

    /** Total number of new members. */
    private int totalNoNewMemValue;

    /** Total number of PMs that took standardization training. */
    private Long totalNoJDUPMFinValue;

    /** Total number of PMs that took standardization training last week. */
    private Long totalNoJDUPMLastWkFinValue;

    /** Percentage of PMs already finished as of the selected report date. */
    private BigDecimal percentageFinTodayValue;

    /** Percentage of PMs that finished the training last week. */
    private BigDecimal percentageFinLastWkValue;

    /** Selected report date from the date picker. */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime reportDateTime;

    /**
     * <pre>
     * Default empty constructor
     * 
     * <pre>
     */
    public SummaryGSTForm() {
    }

    /**
     * @return reportDateTime the selected report date
     */
    public ZonedDateTime getReportDateTime() {
        return reportDateTime;
    }

    /**
     * @param reportDateTime
     */
    public void setReportDateTime(ZonedDateTime reportDateTime) {
        this.reportDateTime = reportDateTime;
    }

    /**
     * @return TotalNoJDUPMValue
     */
    public long getTotalNoJDUPMValue() {
        return totalNoJDUPMValue;
    }

    /**
     * @param totalNoJDUPMValue the total Number of JDU PM Value to set
     */
    public void setTotalNoJDUPMValue(Long totalNoJDUPMValue) {
        this.totalNoJDUPMValue = totalNoJDUPMValue;
    }

    /**
     * @return TotalNoJDUPMLastWeekValue
     */
    public int getTotalNoJDUPMLastWeekValue() {
        return totalNoJDUPMLastWeekValue;
    }

    /**
     * @param totalNoJDUPMLastWeekValue the total Number of JDU PM Last week Value to set
     */
    public void setTotalNoJDUPMLastWeekValue(int totalNoJDUPMLastWeekValue) {
        this.totalNoJDUPMLastWeekValue = totalNoJDUPMLastWeekValue;
    }

    /**
     * @return TotalNoOrigMemValue
     */
    public int getTotalNoOrigMemValue() {
        return totalNoOrigMemValue;
    }

    /**
     * @param totalNoOrigMemValue the total Number of Original Member Value to set
     */
    public void setTotalNoOrigMemValue(int totalNoOrigMemValue) {
        this.totalNoOrigMemValue = totalNoOrigMemValue;
    }

    /**
     * @return TotalNoNewMemValue
     */
    public int getTotalNoNewMemValue() {
        return totalNoNewMemValue;
    }

    /**
     * @param totalNoOrigMemValue the total Number of New Member Value to set
     */
    public void setTotalNoNewMemValue(int totalNoNewMemValue) {
        this.totalNoNewMemValue = totalNoNewMemValue;
    }

    /**
     * @return TotalNoJDUPMFinValue
     */
    public Long getTotalNoJDUPMFinValue() {
        return totalNoJDUPMFinValue;
    }

    /**
     * @param totalNoJDUPMFinValue the total Number of JDU PM finish Value to set
     */
    public void setTotalNoJDUPMFinValue(Long totalNoJDUPMFinValue) {
        this.totalNoJDUPMFinValue = totalNoJDUPMFinValue;
    }

    /**
     * @return TotalNoJDUPMLastWkFinValue
     */
    public Long getTotalNoJDUPMLastWkFinValue() {
        return totalNoJDUPMLastWkFinValue;
    }

    /**
     * @param totalNoJDUPMFinValue the total Number of JDU PM finish Last Week Value to set
     */
    public void setTotalNoJDUPMLastWkFinValue(Long totalNoJDUPMLastWkFinValue) {
        this.totalNoJDUPMLastWkFinValue = totalNoJDUPMLastWkFinValue;
    }

    /**
     * @return PercentageFinTodayValue
     */
    public BigDecimal getPercentageFinTodayValue() {
        return percentageFinTodayValue;
    }

    /**
     * @param percentageFinTodayValue the Percentage of JDU PM finish as of Today Value to set
     */
    public void setPercentageFinTodayValue(BigDecimal percentageFinTodayValue) {
        this.percentageFinTodayValue = percentageFinTodayValue;
    }

    /**
     * @return PercentageFinLastWkValue
     */
    public BigDecimal getPercentageFinLastWkValue() {
        return percentageFinLastWkValue;
    }

    /**
     * @param percentageFinLastWkValue the Percentage of JDU PM finish Last Week Value to set
     */
    public void setPercentageFinLastWkValue(BigDecimal percentageFinLastWkValue) {
        this.percentageFinLastWkValue = percentageFinLastWkValue;
    }

    @Override
    public String toString() {
        return String.format("SummaryGSTForm = [reportDateTime = %s, totalNoJDUPMValue = %d, "
                + "totalNoJDUPMFinValue = %d, totalNoJDUPMLastWkFinValue = %d, percentageFinTodayValue = %s, "
                + "percentageFinLastWkValue = %s]", reportDateTime, totalNoJDUPMValue, totalNoJDUPMFinValue,
                totalNoJDUPMLastWkFinValue, percentageFinTodayValue, percentageFinLastWkValue);
    }
}

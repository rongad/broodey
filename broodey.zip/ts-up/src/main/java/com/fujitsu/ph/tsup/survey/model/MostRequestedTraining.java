package com.fujitsu.ph.tsup.survey.model;

// ==================================================================================================
// $Id:PR16$
// Project Name :Training Sign Up
// System Name :Survey Form Process
// Class Name :SurveyForm.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+----------------------------------------+-----------------------------------
// 0.01 | 11/19/2021 | WS)CJ.Zamora | New Creation
// 0.02 | 11/23/2021 | WS)Mj.liwag  | Updated
// ==================================================================================================
public class MostRequestedTraining {
    /**
     * API Returned surveyId
     */
    private String surveyId;

    /**
     * API Returned surveyStatus
     */
    private String surveyStatus;

    /**
     * API Returned expiryDate
     */
    private String expiryDate;

    /**
     * API Returned surveyLink
     */
    private String surveyLink;

    public String getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(String surveyId) {
        this.surveyId = surveyId;
    }

    public String getSurveyStatus() {
        return surveyStatus;
    }

    public void setSurveyStatus(String surveyStatus) {
        this.surveyStatus = surveyStatus;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getSurveyLink() {
        return surveyLink;
    }

    public void setSurveyLink(String surveyLink) {
        this.surveyLink = surveyLink;
    }

}

package com.fujitsu.ph.tsup.toplearner.dao;

import java.util.List;

import com.fujitsu.ph.tsup.enrollment.dao.EnrollmentRowMapperTopLearner;
import com.fujitsu.ph.tsup.enrollment.model.TopLearnerForm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/** ==================================================================================================
  * Id:PR32
  * Project Name :Training Sign Up
  * System Name : Top Learners
  * Class Name : TopLearnerDaoImpl.java
  *
  * <<Modification History>>
  * Version | Date       | Updated By         | Content
  * --------+------------+-----------------------+---------------------------------------------------
  * 0.01    | 12/29/2021 | WS) ep.delosreyes  | Initial Create
  * ==================================================================================================
  */
  
@Repository
public class TopLearnerDaoImpl implements TopLearnerDao {

    @Autowired
    private NamedParameterJdbcTemplate template;

     /**
     * <pre>
     * Returns the list of top learners for the month
     * <pre>
     * @param numberOfResult
     * @return List<TopLearnerForm>
     */
    @Override
    public List<TopLearnerForm> findTopLearnerByMonth(int numberOfResult) {
        String query = " SELECT " + "CATTEN.PARTICIPANT_ID AS PARTICIPANT_ID, "
                + "E.LAST_NAME AS PARTICIPANT_LAST_NAME, " + "E.FIRST_NAME AS PARTICIPANT_FIRST_NAME "
                + "FROM COURSE_ATTENDANCE AS CATTEN " + "INNER JOIN EMPLOYEE AS E "
                + "ON CATTEN.PARTICIPANT_ID = E.ID " + "WHERE CATTEN.STATUS = 'P' "
                + "AND EXTRACT(MONTH FROM LOG_IN_DATETIME) = EXTRACT(MONTH FROM NOW()) "
                + "GROUP BY CATTEN.PARTICIPANT_ID, E.LAST_NAME, E.FIRST_NAME "
                + "ORDER BY COUNT(CATTEN.PARTICIPANT_ID) DESC, CATTEN.PARTICIPANT_ID DESC  LIMIT "+ numberOfResult +";";
        List<TopLearnerForm> topLearnerByMonth = template.query(query, new EnrollmentRowMapperTopLearner());
        return topLearnerByMonth;
    }

    /**
     * <pre>
     * Returns the list of top learners for the quarter
     * <pre>
     * @param numberOfResult
     * @return List<TopLearnerForm>
     */
    @Override
    public List<TopLearnerForm> findTopLearnerByQuarter(int numberOfResult) {
        String query = "SELECT CATTEN.PARTICIPANT_ID AS PARTICIPANT_ID, "
                + "E.LAST_NAME AS PARTICIPANT_LAST_NAME, " + "E.FIRST_NAME AS PARTICIPANT_FIRST_NAME "
                + "FROM COURSE_ATTENDANCE AS CATTEN " + "INNER JOIN EMPLOYEE AS E "
                + "ON CATTEN.PARTICIPANT_ID = E.ID " + "WHERE CATTEN.STATUS = 'P' "
                + "AND EXTRACT(QUARTER FROM LOG_IN_DATETIME) = EXTRACT(QUARTER FROM NOW()) "
                + "GROUP BY CATTEN.PARTICIPANT_ID, E.LAST_NAME, E.FIRST_NAME "
                + "ORDER BY COUNT(CATTEN.PARTICIPANT_ID) DESC, CATTEN.PARTICIPANT_ID DESC LIMIT "+ numberOfResult +";";
        List<TopLearnerForm> topLearnerByQuarter = template.query(query, new EnrollmentRowMapperTopLearner());
        return topLearnerByQuarter;
    }

}

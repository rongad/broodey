/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.authz.config;

/**
 * This is a test class for XXXXXXXX.java
 *
 * @version 0.1
 * @author mi.aguinaldo
 */
public class TsupRole {
    public static final String PMO = "PMO";
    public static final String MEMBER = "Member";
    public static final String INSTRUCTOR = "Instructor";

    private TsupRole() {

    }
}

//==================================================================================================
// Project Name : Training Sign-Up
// System Name : NonMandatoryCoursesReportService
// Class Name : NonMandatoryCoursesReportService.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.util.Set;

import com.fujitsu.ph.tsup.report.summary.model.CourseCategory;
import com.fujitsu.ph.tsup.report.summary.model.MemberNonMandatoryCoursesCompletionForm;

/**
 * <pre>
 * Service interface for
 * Members' completion report of Non Mandatory Courses
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public interface NonMandatoryCoursesReportService {

    /**
     * <pre>
     * Get set of non-mandatory course categories
     * </pre>
     * 
     * @return CourseCategory list
     */
    public Set<CourseCategory> getAllNonMandatoryCourseCategory();

    /**
     * <pre>
     * Get summary of all member completion report
     * for non-mandatory courses
     * </pre>
     * 
     * @param courseCategoryID
     * @return MemberNonMandatoryCoursesCompletionForm
     */
    public MemberNonMandatoryCoursesCompletionForm getSummary(Long courseCategoryID);

}

/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.dao;

import com.fujitsu.ph.tsup.viewsurveyrate.domain.Ratings;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : InstructionResponse.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

public class InstructionResponse {
    
    private Ratings question1Ratings;
    private Ratings question2Ratings;
    private Ratings question3Ratings;
    private Ratings question4Ratings;
    private Ratings question5Ratings;
    private Ratings question6Ratings;

    public InstructionResponse() {
    }


    private InstructionResponse(Builder builder) {
        this.question1Ratings = builder.question1Ratings;
        this.question2Ratings = builder.question2Ratings;
        this.question3Ratings = builder.question3Ratings;
        this.question4Ratings = builder.question4Ratings;
        this.question5Ratings = builder.question5Ratings;
        this.question6Ratings = builder.question6Ratings;
    }
    
    
    /**
     * @return the question1Ratings
     */
    public Ratings getQuestion1Ratings() {
        return question1Ratings;
    }
    /**
     * @return the question2Ratings
     */
    public Ratings getQuestion2Ratings() {
        return question2Ratings;
    }
    /**
     * @return the question3Ratings
     */
    public Ratings getQuestion3Ratings() {
        return question3Ratings;
    }
    /**
     * @return the question4Ratings
     */
    public Ratings getQuestion4Ratings() {
        return question4Ratings;
    }
    /**
     * @return the question5Ratings
     */
    public Ratings getQuestion5Ratings() {
        return question5Ratings;
    }
    /**
     * @return the question6Ratings
     */
    public Ratings getQuestion6Ratings() {
        return question6Ratings;
    }


    /**
     * Creates builder to build {@link InstructionResponse}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }
    /**
     * Builder to build {@link InstructionResponse}.
     */
    public static final class Builder {
        private Ratings question1Ratings;
        private Ratings question2Ratings;
        private Ratings question3Ratings;
        private Ratings question4Ratings;
        private Ratings question5Ratings;
        private Ratings question6Ratings;

        private Builder() {
        }

        public Builder withQuestion1Ratings(Ratings question1Ratings) {
            this.question1Ratings = question1Ratings;
            return this;
        }
        
        public Builder withQuestion1Ratings(Integer question1Ratings) {
            this.question1Ratings = Ratings.fromValue(question1Ratings);
            return this;
        }

        public Builder withQuestion2Ratings(Ratings question2Ratings) {
            this.question2Ratings = question2Ratings;
            return this;
        }
        
        public Builder withQuestion2Ratings(Integer question2Ratings) {
            this.question2Ratings = Ratings.fromValue(question2Ratings);
            return this;
        }

        public Builder withQuestion3Ratings(Ratings question3Ratings) {
            this.question3Ratings = question3Ratings;
            return this;
        }
        
        public Builder withQuestion3Ratings(Integer question3Ratings) {
            this.question3Ratings = Ratings.fromValue(question3Ratings);
            return this;
        }

        public Builder withQuestion4Ratings(Ratings question4Ratings) {
            this.question4Ratings = question4Ratings;
            return this;
        }
        
        public Builder withQuestion4Ratings(Integer question4Ratings) {
            this.question4Ratings = Ratings.fromValue(question4Ratings);
            return this;
        }

        public Builder withQuestion5Ratings(Ratings question5Ratings) {
            this.question5Ratings = question5Ratings;
            return this;
        }
        
        public Builder withQuestion5Ratings(Integer question5Ratings) {
            this.question5Ratings = Ratings.fromValue(question5Ratings);
            return this;
        }

        public Builder withQuestion6Ratings(Ratings question6Ratings) {
            this.question6Ratings = question6Ratings;
            return this;
        }
        
        public Builder withQuestion6Ratings(Integer question6Ratings) {
            this.question6Ratings = Ratings.fromValue(question6Ratings);
            return this;
        }

        public InstructionResponse build() {
            return new InstructionResponse(this);
        }
    }

}

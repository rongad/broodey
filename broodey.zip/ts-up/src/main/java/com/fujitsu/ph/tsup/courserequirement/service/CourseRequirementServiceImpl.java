package com.fujitsu.ph.tsup.courserequirement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.courserequirement.dao.CourseRequirementDao;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.CourseScheduleDetail;
import com.fujitsu.ph.tsup.courserequirement.model.EmployeeChecklist;
import com.fujitsu.ph.tsup.exception.TsupException;

//===============================================================
//$Id: PR30$
//Project Name: Training Sign Up
//System Name : Course Checklist
//Class Name: CourseRequirementService.java
//
//<<Modification History>>
//Version | Date       | Updated by          | Content
//--------+------------+---------------------+-----------------
//0.01    | 10/19/2021 | WS) a.abellanosa    | Initial Creation
//0.02    | 2021/10/20 | WS) e.delosreyes    | Added @Service
//0.03    | 2021/11/05 | WS) e.delosreyes    | updated service
//0.04    | 2021/11/05 | WS) a.abellanosa    | update unnecessary imports, add comments, remove getAttendeeChecklist
//===============================================================
/**
 * <pre>
 * Implementation for course requirement service
 * 
 * </pre>
 *
 * @version 0.04
 * @author a.abellanosa
 *
 */
@Service
public class CourseRequirementServiceImpl implements CourseRequirementService {

	@Autowired
	CourseRequirementDao courseRequirementDao;
	
	// Get all courses from List of courses from database
	@Override
	public List<Course> getCourses() {
		
		return courseRequirementDao.getCourses();
	}

	/**
	 * <pre>
	 * Get all course requirement of specific course
	 * </pre>
	 * 
	 * @param courseId
	 * @return
	 */
	@Override
	public List<CourseChecklist> getCourseRequirements(Integer courseId) {
		
		return courseRequirementDao.getCourseRequirements(courseId);
	}

	/**
	 * <pre>
	 * Create the course requirement
	 * </pre>
	 * 
	 * @param courseRequirement
	 */
	@Override
	public void createCourseRequirement(CourseChecklist courseRequirement) {
		try {
			courseRequirementDao.createCourseRequirement(courseRequirement);
		} catch (DataAccessException ex) {
			throw new TsupException("Failed to create requirement", ex.getCause());
		}

	}

	/**
	 * <pre>
	 * Delete course requirement
	 * </pre>
	 * 
	 * @param courseRequirementId
	 */
	@Override
	public void deleteCourseRequirement(Integer courseRequirementId) {
		courseRequirementDao.deleteCourseRequirement(courseRequirementId);
	}

	/**
	 * <pre>
	 * Update status of Attendee's checklist
	 * </pre>
	 * 
	 * @param employeeChecklists
	 */
	@Override
	public void updateAttendeeChecklist(List<EmployeeChecklist> employeeChecklists) {
		for (EmployeeChecklist employeeChecklist : employeeChecklists) {
			if (employeeChecklist.getId()>0) {
				courseRequirementDao.updateAttendeeChecklist(employeeChecklist);
			} else {
				courseRequirementDao.createParticipantCourseChecklist(employeeChecklist);
			}
		}
	}

	/**
	 * <pre>
	 * Update course checklist
	 * </pre>
	 * 
	 * @param employeeChecklists
	 */
	@Override
	public void updateCourseRequirement(CourseChecklist courseChecklist) {
		
		courseRequirementDao.updateCourseRequirement(courseChecklist);
	}

	/**
	 * <pre>
	 * This method will return the list of CourseScheduleDetail
	 * </pre>
	 * 
	 * @param courseId
	 */
	@Override
	public List<CourseScheduleDetail> getCourseScheduleDetails(Integer courseId) {
		
		return courseRequirementDao.getCourseScheduleDetails(courseId);
	}

	/**
	 * <pre>
	 * This method will return the list of participants of the course schedule
	 * <pre>
	 * @param courseScheduleId
	 * @return List<CourseParticipant>
	 */
	@Override
	public List<CourseParticipant> getCourseParticipants(Integer courseScheduleId) {
		
		return courseRequirementDao.getCourseParticipants(courseScheduleId);
	}

	/**
	 * <pre>
	 * This method will return the list of participants of the course schedule
	 * <pre>
	 * @param participantId
	 * @return List<EmployeeChecklist>
	 */
	@Override
	public List<EmployeeChecklist> getParticipantChecklist(Integer participantId, Integer courseId) {
		List<EmployeeChecklist> employeeChecklists = courseRequirementDao.getParticipantChecklists(participantId);
		List<CourseChecklist> courseChecklists = courseRequirementDao.getCourseRequirements(courseId);
		for (EmployeeChecklist courseChecklist : employeeChecklists) {
			courseChecklists.removeIf(z->z.getId().equals(courseChecklist.getCourseChecklist().getId()));
		}
		if (!courseChecklists.isEmpty()) {
			for (CourseChecklist courseChecklist : courseChecklists) {
				CourseParticipant courseParticipant = new CourseParticipant();
				courseParticipant.setId(participantId);
				EmployeeChecklist employeeChecklist = new EmployeeChecklist();
				employeeChecklist.setCourseChecklist(courseChecklist);
				employeeChecklist.setIs_Accomplished(false);
				employeeChecklist.setId(0);
				employeeChecklist.setCourseParticipant(courseParticipant);
				employeeChecklists.add(employeeChecklist);
			}
		}
		return employeeChecklists;
	}

}

/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

// =======================================================
// $Id:
// Project Name: Training Sign Up
// Class Name: BatchScheduler.java
//
// <<Modification History>>
// Version | Date | Updated by | Content
// --------+------------+------------------+---------------
// 0.01 | ----/--/-- | Re.Pureza | Created
// =======================================================

/**
 * BatchScheduler class
 * 
 * @author Re.Pureza (New Creation by: Re.Pureza)
 * @author Re.Pureza
 * @version 0.01
 */

@Component
@EnableScheduling
public class BatchScheduler {
    @Autowired
    private JobLauncher launcher;

    @Autowired
    private Job job;

    private static final Logger log = LoggerFactory.getLogger(BatchScheduler.class);

    /**
     * Set schedule time every 12mn: 0 0 0 * * *
     */
    @Scheduled(cron = "*0 0 0 * * *")
    public void myScheduler() {
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
                .toJobParameters();
        try {
            JobExecution execution = launcher.run(job, jobParameters);
            System.out.println("####### status:" + execution.getStatus());

        } catch (JobExecutionAlreadyRunningException e) {
            log.error("JobExecutionAlreadyRunning", e);
        } catch (JobRestartException e) {
            log.error("JobRestartException", e);
        } catch (JobInstanceAlreadyCompleteException e) {
            log.error("JobInstanceAlreadyComplete", e);
        } catch (JobParametersInvalidException e) {
            log.error("JobParametersInvalid", e);
        }
    }

}


package com.fujitsu.ph.tsup.courserequirement.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist.Builder;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : Course Checklist
 * Class Name   : CourseRequirementRowMapper.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * ===================================================================================================
 */

 /**
 * <pre>
 * The Row Mapper for  Course Requirement
 * 
 * <pre>
 * 
 * @version 0.01
 * @author e.delosreyes
 */

public class CourseRequirementRowMapper implements RowMapper<CourseChecklist> {

	@Override
	public CourseChecklist mapRow(ResultSet rs, int rowNum) throws SQLException {
		Integer id = rs.getInt("id");
		String courseRequirement = rs.getString("requirement");
		
		
		Builder courseRequirementBuilder = CourseChecklist.builder()
				.withId(id)
				.withRequirement(courseRequirement);
		
		if(hasColumn(rs,"requirement")) {
			courseRequirement = rs.getString("requirement");
		    courseRequirementBuilder.withRequirement(courseRequirement);
		}
		
		return courseRequirementBuilder.build();
	}
	
	
	private static boolean hasColumn(ResultSet rs, String columnName) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		int columns = rsmd.getColumnCount();
		for (int x = 1; x <= columns; x++) {
		    if (columnName.equals(rsmd.getColumnName(x))) {
			return true;
		    }
		}
		return false;
	    }
}

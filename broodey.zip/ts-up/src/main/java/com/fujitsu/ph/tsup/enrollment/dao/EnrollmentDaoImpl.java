package com.fujitsu.ph.tsup.enrollment.dao;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.auth.model.FpiUser;
import com.fujitsu.ph.tsup.common.dao.MemberRoleRowMapper;
import com.fujitsu.ph.tsup.common.domain.MemberRole;
import com.fujitsu.ph.tsup.course.category.dao.CourseCategoryRowMapper;
import com.fujitsu.ph.tsup.course.category.model.CourseCategory;
import com.fujitsu.ph.tsup.course.dao.CourseRowMapper;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.enrollment.domain.CourseParticipant;
import com.fujitsu.ph.tsup.enrollment.domain.CourseSchedule;
import com.fujitsu.ph.tsup.enrollment.domain.CourseScheduleDetail;
import com.fujitsu.ph.tsup.enrollment.domain.ParticipantTrainingPeriod;
import com.fujitsu.ph.tsup.enrollment.model.Certificate;
import com.fujitsu.ph.tsup.enrollment.model.CourseScheduleListForm;
import com.fujitsu.ph.tsup.enrollment.model.EnrolledMemberForm;
import com.fujitsu.ph.tsup.enrollment.model.SearchForm;
import com.fujitsu.ph.tsup.scheduling.dao.DepartmentRowMapper;
import com.fujitsu.ph.tsup.scheduling.dao.InstructorRowMapper;
import com.fujitsu.ph.tsup.scheduling.dao.VenueRowMapper;
import com.fujitsu.ph.tsup.scheduling.model.DepartmentForm;
import com.fujitsu.ph.tsup.scheduling.model.InstructorForm;
import com.fujitsu.ph.tsup.scheduling.model.VenueForm;
import com.fujitsu.ph.tsup.search.MyCourseScheduleFilter;

// =================================================================================================
// $Id:PR01$
// Project Name :Training Sign Up
// System Name :Enroll Course
// Class Name :EnrollmentDaoImpl.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+--------------------------------------------------
// 0.01 | 06/26/2020 | WS) M.Lumontad    | New Creation
// 0.02 | 06/29/2020 | WS) G.Cabiling    | Updated
// 0.03 | 06/30/2020 | WS) K.Freo        | Updated
// 0.04 | 07/07/2020 | WS) J.Yu          | Updated
// 0.05 | 07/14/2020 | WS) T.Oviedo      | Updated
// 0.06 | 09/14/2020 | WS) J.Yu          | Updated
// 0.07 | 09/14/2020 | WS) M.Lumontad    | Updated
// 0.08 | 04/19/2021 | WS) M.Atayde      | Updated
// 0.09 | 05/27/2021 | WS) L.Celoso      | Updated
// 0.10 | 06/14/2021 | WS) L.Celoso      | Updated
// 0.10 | 06/16/2021 | WS) M.Taboada     | Updated
// 0.11 | 07/08/2021 | WS) L.Celoso      | Updated
// 0.11 | 07/16/2021 | WS) MI.Aguinaldo  | Updated
// 0.11 | 07/22/2021 | WS) K.Sevilla     | Updated
// 0.12 | 08/06/2021 | WS) K.Sevilla     | Updated
// 0.12 | 08/23/2021 | WS) K.Sevilla     | Updated
// 0.13 | 09/07/2021 | WS) L.Celoso      | Added alias to [Status]
// 0.13 | 09/13/2021 | WS) K.Sevilla     | Updated
// 0.14 | 09/17/2021 | WS) D.Dinglasan   | Updated
// 0.15 | 10/13/2021 | WS) L.Celoso      | Added Tags on filter search
// 0.15 | 10/13/2021 | WS) R.delaCruz    | Updated
// 0.15 | 10/13/2021 | WS) Mj.liwag      | Updated
// 0.16 | 12/23/2021 | WS) ep.delosreyes | Updated findCourseScheduleIfMandatory query
//      |            |                   | set condition to only show when certificate not uploaded
// 0.16 | 12/28/2021 | WS) ep.delosreyes | removed top learners
// =================================================================================================
/**
 * <pre>
 * EnrollmentDaoImpl.java is data access class for enrollment related database access
 * 
 * <pre>
 * 
 * @version 0.01
 * @author m.lumontad
 */
@Repository
public class EnrollmentDaoImpl implements EnrollmentDao {
    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Finds the scheduled courses by the given fromDateTime and toDateTime
     * 
     * @param fromDateTime
     * @param toDateTime
     * @return Course Schedule Set
     * @author J.yu
     **/
    @Override
    public Set<CourseSchedule> findAllScheduledCourses(CourseScheduleListForm form, Pageable pageable) {
        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        StringBuilder queryBuilder = new StringBuilder();
        List<String> conditionList = new LinkedList<>();
        boolean withTags = (form.getMemberRole() != null && !form.getMemberRole().isEmpty());

        queryBuilder.append("SELECT DISTINCT C.NAME AS COURSE_NAME, " + "CS.ID AS ID, ");
        queryBuilder.append("CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, ");
        queryBuilder.append(
                "CS.COURSE_ID AS COURSE_ID, " + "C.DETAIL AS DETAILS, " + "C.MANDATORY AS MANDATORY, ");
        queryBuilder.append("C.MANDATORY_TYPE AS MANDATORY_TYPE, ");
        queryBuilder.append("D.DEPARTMENT_NAME AS DEPARTMENT, ");
        queryBuilder.append("C.DEADLINE AS DEADLINE, ");
        queryBuilder.append("CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, ");
        queryBuilder.append("E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "CS.VENUE_ID AS VENUE_ID, ");
        queryBuilder.append("V.NAME AS VENUE_NAME, " + "CS.MIN_REQUIRED AS MIN_REQUIRED, ");
        queryBuilder.append("CS.MAX_ALLOWED AS MAX_ALLOWED, ");
        queryBuilder.append("(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT ");
        queryBuilder.append("WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, ");
        queryBuilder.append(
                "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, ");
        queryBuilder.append(
                "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, ");
        queryBuilder.append("CSD.DURATION AS DURATION ");

        if (withTags) {
            queryBuilder.append(", STRING_AGG (MR.role_type, ', ') AS role_type ");
        }

        queryBuilder.append("FROM COURSE_SCHEDULE AS CS ");
        queryBuilder
                .append("INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID ");
        queryBuilder
                .append("INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E ");
        queryBuilder
                .append("ON CS.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID ");
        queryBuilder.append("INNER JOIN COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID ");
        queryBuilder.append("INNER JOIN DEPARTMENT AS D ");
        queryBuilder.append("ON C.DEPARTMENT_ID = D.ID ");

        if (withTags) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM "); // ADD
            queryBuilder.append("ON CTM.course_id = CS.COURSE_ID "); // ADD
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR "); // ADD
            queryBuilder.append("ON MR.id = CTM.tag_id "); // ADD

            addTagsToConditionList(conditionList, form.getMemberRole());
        }

        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("SCHEDULED_START_DATETIME");
        String orderProperty = getOrderProperty(order);
        if (!user.getRoles().contains("Instructor") || user.getRoles().contains("PMO")) {
            queryBuilder.append("WHERE COALESCE(CSD.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSD.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND CS.STATUS = 'A' ");
            queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
            queryBuilder.append("AND TO_CHAR(CS.COURSE_ID, 'FM9999') LIKE :courseNameId ");
            queryBuilder.append("AND TO_CHAR(CS.INSTRUCTOR_ID, 'FM9999') LIKE :instructorId ");
            queryBuilder.append("AND TO_CHAR(CS.VENUE_ID, 'FM9999') LIKE :venueId ");
            queryBuilder.append("AND TO_CHAR(C.DEPARTMENT_ID, 'FM9999') LIKE :departmentId ");
            queryBuilder
                    .append("AND C.MANDATORY LIKE :mandatory " + "AND C.MANDATORY_TYPE LIKE :mandatoryType ");
            queryBuilder.append(
                    "AND C.DEADLINE LIKE :deadline " + "AND D.jdu_id = (" + "             SELECT D.jdu_id ");
            queryBuilder.append("             FROM DEPARTMENT D ");
            queryBuilder.append(
                    "             INNER JOIN EMPLOYEE E ON E.department_id = D.id WHERE E.id = :employee_id) ");

            if (withTags) {
                queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining())); // ADD
            }

            queryBuilder.append("GROUP BY ");
            queryBuilder.append("C.NAME, ");
            queryBuilder.append("CS.ID, ");
            queryBuilder.append("CSD.ID, ");
            queryBuilder.append("CC.CATEGORY, ");
            queryBuilder.append("CS.COURSE_ID, ");
            queryBuilder.append("C.DETAIL, ");
            queryBuilder.append("C.MANDATORY, ");
            queryBuilder.append("C.MANDATORY_TYPE, ");
            queryBuilder.append("D.DEPARTMENT_NAME, ");
            queryBuilder.append("C.DEADLINE, ");
            queryBuilder.append("CS.INSTRUCTOR_ID, ");
            queryBuilder.append("E.LAST_NAME, ");
            queryBuilder.append("E.FIRST_NAME, ");
            queryBuilder.append("CS.VENUE_ID, ");
            queryBuilder.append("V.NAME, ");
            queryBuilder.append("CS.MIN_REQUIRED, ");
            queryBuilder.append("CS.MAX_ALLOWED, ");
            queryBuilder.append("CS.STATUS, ");
            queryBuilder.append("CSD.SCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSD.SCHEDULED_END_DATETIME, ");
            queryBuilder.append("CSD.DURATION ");

            queryBuilder.append("ORDER BY " + orderProperty + " ");
            queryBuilder.append("LIMIT " + pageable.getPageSize() + " ");
            queryBuilder.append("OFFSET " + pageable.getOffset() + " ");

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                            form.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                            form.getToDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("courseCategoryID", form.getCourseCategoryId())
                    .addValue("courseNameId", form.getCourseNameId())
                    .addValue("instructorId", form.getInstructorId()).addValue("venueId", form.getVenueId())
                    .addValue("departmentId", form.getDepartmentId())
                    .addValue("mandatory", form.getMandatory())
                    .addValue("mandatoryType", form.getMandatoryType())
                    .addValue("deadline", form.getDeadline()).addValue("employee_id", user.getId());// Added

            List<CourseSchedule> courseScheduleList = template.query(queryBuilder.toString(),
                    courseScheduleParameters, new EnrollmentRowMapperCourseSchedule());
            return new LinkedHashSet<>(courseScheduleList);
        } else {
            queryBuilder.append("WHERE COALESCE(CSD.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSD.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append(orderProperty + " ");
            queryBuilder.append("LIMIT " + pageable.getPageSize() + " ");
            queryBuilder.append("OFFSET " + pageable.getOffset() + " ");

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                            form.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                            form.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());

            List<CourseSchedule> courseScheduleList = template.query(queryBuilder.toString(),
                    courseScheduleParameters, new EnrollmentRowMapperCourseSchedule());
            return new LinkedHashSet<>(courseScheduleList);
        }
    }

    /**
     * <pre>
     * Map the correct and proper field name
     * 
     * <pre>
     * 
     * @param order
     * @return String
     * @author ru.delacruz
     * @author d.dinglasan
     */
    private String getOrderProperty(Order order) {
        switch (order.getProperty()) {
            case "course_category":
                return "COURSE_CATEGORY " + order.getDirection();
            case "course_name":
                return "COURSE_NAME " + order.getDirection();
            case "instructor":
                return "INSTRUCTOR_LAST_NAME " + order.getDirection() + ", INSTRUCTOR_FIRST_NAME "
                        + order.getDirection();
            case "mandatory":
                return "MANDATORY " + order.getDirection();
            case "mandatory_type":
                return "MANDATORY_TYPE " + order.getDirection();
            case "department":
                return "DEPARTMENT " + order.getDirection();
            case "scheduled_start_datetime":
                return "SCHEDULED_START_DATETIME " + order.getDirection();
            case "scheduled_end_datetime":
                return "SCHEDULED_END_DATETIME " + order.getDirection();
            case "duration":
                return "DURATION " + order.getDirection();
            case "total_participants":
                return "TOTAL_PARTICIPANTS " + order.getDirection();
            case "venue":
                return "VENUE_NAME " + order.getDirection();
            case "min_participants":
                return "MIN_REQUIRED " + order.getDirection();
            case "max_participants":
                return "MAX_ALLOWED " + order.getDirection();
            case "deadline":
                return "DEADLINE " + order.getDirection();
            case "course_status":
                return "COURSE_STATUS " + order.getDirection();
            case "venue_name":
                return "VENUE_NAME " + order.getDirection();
            case "jduType":
                return "JDU_TYPE " + order.getDirection();
            default:
                return "";
        }
    }

    /**
     * Method to sort the table tsup.course_schedule by tsup.course_schedule.id and
     * tsup.course_schedule.status
     *
     * @param id
     * @param status
     * @return findCourseScheduleById(Long id)
     * @author J.yu
     **/
    @Override
    public CourseSchedule findCourseScheduleById(Long id) {
        String query = "SELECT C.NAME AS COURSE_NAME, " + "CS.ID AS ID, " + "C.DETAIL AS DETAILS, "
                + "CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "CS.COURSE_ID AS COURSE_ID, " + "CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "C.MANDATORY AS MANDATORY," + "C.MANDATORY_TYPE AS MANDATORY_TYPE,"
                + "C.DEADLINE AS DEADLINE," + "D.DEPARTMENT_NAME AS DEPARTMENT," + "CS.VENUE_ID AS VENUE_ID, "
                + "V.NAME AS VENUE_NAME, " + "CS.MIN_REQUIRED AS MIN_REQUIRED, "
                + "CS.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, "
                + "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSD.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CS "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN DEPARTMENT AS D "
                + "ON C.DEPARTMENT_ID = D.ID " + "INNER JOIN EMPLOYEE AS E " + "ON CS.INSTRUCTOR_ID = E.ID "
                + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID " + "INNER JOIN COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "WHERE CS.ID = :id AND CS.STATUS = 'A' "
                + "ORDER BY C.NAME, CSD.SCHEDULED_START_DATETIME";
        SqlParameterSource findCourseScheduleByIdParameter = new MapSqlParameterSource().addValue("id", id);
        return template.queryForObject(query, findCourseScheduleByIdParameter,
                new EnrollmentRowMapperCourseSchedule());
    }

    /**
     * Method to Sort the table tsup.course_participant by tsup.course_participant.course_schedule_id and
     * tsup.course_participant_id Method to Sort the Table Course Participant by COURSE SCHEDULE ID and
     * 
     * @param courseScheduleId
     * @param participantId
     * @return findCourseParticipantByCourseScheduleIdAndParticipantId(Long courseScheduleId, Long
     *         participantId)
     * @author t.oviedo
     **/
    @Override
    public CourseParticipant findCourseParticipantByCourseScheduleIdAndParticipantId(Long courseScheduleId,
            Long participantId) {
        String query = "SELECT CP.ID AS ID, CP.COURSE_SCHEDULE_ID AS COURSE_SCHEDULE_ID, "
                + "CP.PARTICIPANT_ID AS PARTICIPANT_ID, " + "CP.REGISTRATION_DATE AS REGISTRATION_DATE_TIME "
                + "FROM COURSE_PARTICIPANT AS CP " + "WHERE CP.COURSE_SCHEDULE_ID = :courseScheduleId "
                + "AND CP.PARTICIPANT_ID = :participantId";
        try {
            SqlParameterSource namedParameters = new MapSqlParameterSource()
                    .addValue("courseScheduleId", courseScheduleId).addValue("participantId", participantId);
            return template.queryForObject(query, namedParameters,
                    new EnrollmentRowMapperCourseParticipantByCourseScheduleIdAndParticipantId());
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * Method to Save data to Table tsup.course_participant
     **/
    @Override
    public void saveCourseParticipant(CourseParticipant courseParticipant) {
        String saveCourseParticipantSql = "INSERT INTO COURSE_PARTICIPANT "
                + "(COURSE_SCHEDULE_ID, PARTICIPANT_ID, REGISTRATION_DATE) "
                + "VALUES (:courseScheduleId, :participantId, :registrationDate)";
        SqlParameterSource saveCourseParticipantParameters = new MapSqlParameterSource()
                .addValue("courseScheduleId", courseParticipant.getCourseScheduleId())
                .addValue("participantId", courseParticipant.getParticipantId())
                .addValue("registrationDate", courseParticipant.getRegistrationDate()
                        .withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());
        template.update(saveCourseParticipantSql, saveCourseParticipantParameters);
        String saveAttendance = "INSERT INTO COURSE_ATTENDANCE"
                + "(COURSE_SCHEDULE_DETAIL_ID, PARTICIPANT_ID, STATUS, LOG_IN_DATETIME, LOG_OUT_DATETIME, EMAIL) "
                + "VALUES (:courseScheduleDetailId, :participantId, 'A', null, null, :email)";
        SqlParameterSource saveAttendanceParameters = new MapSqlParameterSource()
                .addValue("courseScheduleDetailId", courseParticipant.getCourseScheduleDetail().getId())
                .addValue("participantId", courseParticipant.getParticipantId())
                .addValue("email", courseParticipant.getEmail());

        template.update(saveAttendance, saveAttendanceParameters);
    }

    /**
     * Finds the scheduled courses starting from today onwards
     * 
     * @param participantId
     * @param fromDateTime
     * @param toDateTime
     * @author m.lumontad
     */
    @Override
    public Set<CourseParticipant> findAllEnrolledCoursesByParticipantId(Long participantId,
            ZonedDateTime fromDateTime, ZonedDateTime toDateTime) {
        String query = "SELECT CPART.ID AS COURSE_PARTICIPANT_ID, " + "C.ID AS COURSE_ID, "
                + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CSCHED.ID AS COURSE_SCHEDULE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "C.MANDATORY AS MANDATORY,"
                + "C.DEADLINE AS DEADLINE," + "CSCHED.STATUS AS COURSE_STATUS,"
                + "CC.CATEGORY AS COURSE_CATEGORY," + "D.DEPARTMENT_NAME AS DEPARTMENT,"
                + "C.MANDATORY_TYPE AS MANDATORY_TYPE," + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, "
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "V.NAME AS VENUE_NAME, "
                + "CPART.PARTICIPANT_ID AS PARTICIPANT_ID, "
                + "(SELECT LAST_NAME FROM tsup.EMPLOYEE WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_LAST_NAME, "
                + "(SELECT FIRST_NAME FROM tsup.EMPLOYEE WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_FIRST_NAME, "
                + "CSCHEDDET.DURATION AS DURATION, " + "CPART.REGISTRATION_DATE AS REGISTRATION_DATE, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CATTEN.STATUS AS ATTENDANCE_STATUS " + "FROM tsup.COURSE_SCHEDULE AS CSCHED  "
                + "INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE_PARTICIPANT AS CPART " + "ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE AS C " + "ON C.ID = CSCHED.COURSE_ID "
                + "INNER JOIN tsup.COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "INNER JOIN tsup.DEPARTMENT AS D " + "ON C.DEPARTMENT_ID = D.ID "
                + "INNER JOIN tsup.JDU_TYPE AS JT " + "ON D.JDU_ID = JT.ID "
                + "INNER JOIN tsup.EMPLOYEE AS E " + "ON E.ID = CSCHED.INSTRUCTOR_ID "
                + "INNER JOIN tsup.VENUE AS V " + "ON V.ID = CSCHED.VENUE_ID "
                + "INNER JOIN tsup.COURSE_ATTENDANCE AS CATTEN "
                + "ON CPART.PARTICIPANT_ID = CATTEN.PARTICIPANT_ID AND CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID "
                + "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                + "AND CPART.PARTICIPANT_ID = :participantId " + "AND CSCHED.STATUS = 'A' "
                + "ORDER BY CSCHED.ID, CSCHEDDET.SCHEDULED_START_DATETIME ";

        SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                .addValue("participantId", participantId)
                .addValue("fromDateTime",
                        fromDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                .addValue("toDateTime", toDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());

        List<CourseParticipant> courseEnrolledList = template.query(query, courseEnrolledParameters,
                new EnrollmentRowMapperCourseParticipant());

        return new LinkedHashSet<>(courseEnrolledList);
    }

    /**
     * Find all course enrolled base on the participant training period
     * 
     * @param participantTrainingPeriod
     * @param pageable
     * @return
     */
    @Override
    public Set<CourseParticipant> findAllEnrolledCoursesBy(
            ParticipantTrainingPeriod participantTrainingPeriod, Pageable pageable) {
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("scheduled_start_datetime");
        String orderProperty = getOrderProperty(order);
        String query = "SELECT CPART.ID AS COURSE_PARTICIPANT_ID, " + "C.ID AS COURSE_ID, "
                + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CSCHED.ID AS COURSE_SCHEDULE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "C.MANDATORY AS MANDATORY,"
                + "C.DEADLINE AS DEADLINE," + "CSCHED.STATUS AS COURSE_STATUS,"
                + "CC.CATEGORY AS COURSE_CATEGORY," + "D.DEPARTMENT_NAME AS DEPARTMENT,"
                + "C.MANDATORY_TYPE AS MANDATORY_TYPE," + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, "
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "V.NAME AS VENUE_NAME, "
                + "CPART.PARTICIPANT_ID AS PARTICIPANT_ID, "
                + "(SELECT LAST_NAME FROM tsup.EMPLOYEE WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_LAST_NAME, "
                + "(SELECT FIRST_NAME FROM tsup.EMPLOYEE WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_FIRST_NAME, "
                + "CSCHEDDET.DURATION AS DURATION, " + "CPART.REGISTRATION_DATE AS REGISTRATION_DATE, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CATTEN.STATUS AS ATTENDANCE_STATUS " + "FROM tsup.COURSE_SCHEDULE AS CSCHED  "
                + "INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE_PARTICIPANT AS CPART " + "ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE AS C " + "ON C.ID = CSCHED.COURSE_ID "
                + "INNER JOIN tsup.COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "INNER JOIN tsup.DEPARTMENT AS D " + "ON C.DEPARTMENT_ID = D.ID "
                + "INNER JOIN tsup.JDU_TYPE AS JT " + "ON D.JDU_ID = JT.ID "
                + "INNER JOIN tsup.EMPLOYEE AS E " + "ON E.ID = CSCHED.INSTRUCTOR_ID "
                + "INNER JOIN tsup.VENUE AS V " + "ON V.ID = CSCHED.VENUE_ID "
                + "INNER JOIN tsup.COURSE_ATTENDANCE AS CATTEN "
                + "ON CPART.PARTICIPANT_ID = CATTEN.PARTICIPANT_ID AND CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID "
                + "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                + "AND CPART.PARTICIPANT_ID = :participantId " + "ORDER BY " + orderProperty + ", CSCHED.ID ";

        if (Objects.nonNull(pageable)) {
            query += "LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset();
        }

        SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                .addValue("participantId", participantTrainingPeriod.getParticipantId())
                .addValue("fromDateTime", participantTrainingPeriod.getFromDateTimeTimezoneOnUTC())
                .addValue("toDateTime", participantTrainingPeriod.getToDateTimeTimezoneOnUTC());

        List<CourseParticipant> courseEnrolledList = template.query(query, courseEnrolledParameters,
                new EnrollmentRowMapperCourseParticipant());

        return courseEnrolledList.isEmpty() ? Collections.emptySet()
                : new LinkedHashSet<>(courseEnrolledList);
    }

    /**
     * Count the enroll courses base on the participant training period
     * 
     * @param participantTrainingPeriod
     * @return
     */
    @Override
    public int countAllEnrolledCoursesByParticipantTrainingPeriod(
            ParticipantTrainingPeriod participantTrainingPeriod) {
        try {
            String query = "SELECT COUNT(CPART.ID) " + "FROM tsup.COURSE_SCHEDULE AS CSCHED  "
                    + "INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                    + "ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID "
                    + "INNER JOIN tsup.COURSE_PARTICIPANT AS CPART "
                    + "ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID " + "INNER JOIN tsup.COURSE AS C "
                    + "ON C.ID = CSCHED.COURSE_ID " + "INNER JOIN tsup.EMPLOYEE AS E "
                    + "ON E.ID = CSCHED.INSTRUCTOR_ID " + "INNER JOIN tsup.VENUE AS V "
                    + "ON V.ID = CSCHED.VENUE_ID " + "INNER JOIN tsup.COURSE_ATTENDANCE AS CATTEN "
                    + "ON CPART.PARTICIPANT_ID = CATTEN.PARTICIPANT_ID AND CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID "
                    + "WHERE COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                    + "CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime "
                    + "AND CPART.PARTICIPANT_ID = :participantId ";

            SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                    .addValue("participantId", participantTrainingPeriod.getParticipantId())
                    .addValue("fromDateTime", participantTrainingPeriod.getFromDateTimeTimezoneOnUTC())
                    .addValue("toDateTime", participantTrainingPeriod.getToDateTimeTimezoneOnUTC());

            return template.queryForObject(query, courseEnrolledParameters, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    /**
     * <pre>
     * FindCourseParticipantById
     *
     * @author k.freo
     * 
     *         <pre>
     */
    @Override
    public CourseParticipant findCourseParticipantById(Long id) {
        String sql = "SELECT CPART.ID AS COURSE_PARTICIPANT_ID, " + "CSCHED.ID AS ID, "
                + "CSCHEDDET.COURSE_SCHEDULE_ID AS COURSE_SCHEDULE_ID, " + "C.ID AS COURSE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "C.MANDATORY AS MANDATORY,"
                + "C.DEADLINE AS DEADLINE," + "CSCHED.STATUS AS COURSE_STATUS,"
                + "CC.CATEGORY AS COURSE_CATEGORY," + "D.DEPARTMENT_NAME AS DEPARTMENT,"
                + "C.MANDATORY_TYPE AS MANDATORY_TYPE," + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, "
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "V.NAME AS VENUE_NAME, "
                + "CPART.REGISTRATION_DATE AS REGISTRATION_DATE, " + "(SELECT LAST_NAME  "
                + "FROM tsup.EMPLOYEE " + "WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_LAST_NAME, "
                + "(SELECT FIRST_NAME FROM tsup.EMPLOYEE "
                + "WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_FIRST_NAME,"
                + "(SELECT REASON FROM tsup.COURSE_NON_PARTICIPANT "
                + " WHERE ID = CPART.PARTICIPANT_ID) AS REASON, "
                + "(SELECT DECLINE_DATE FROM tsup.COURSE_NON_PARTICIPANT "
                + " WHERE ID = CPART.PARTICIPANT_ID) AS DECLINE_DATE, "
                + "CPART.PARTICIPANT_ID AS PARTICIPANT_ID, " + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, "
                + "CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, "
                + "CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSCHEDDET.DURATION AS DURATION, " + "CATTEN.STATUS AS ATTENDANCE_STATUS "
                + "FROM tsup.COURSE_SCHEDULE AS CSCHED "
                + "INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHED.ID = CSCHEDDET.COURSE_SCHEDULE_ID " + "INNER JOIN tsup.COURSE AS C "
                + "ON CSCHED.COURSE_ID = C.ID " + "INNER JOIN tsup.COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "INNER JOIN tsup.DEPARTMENT AS D "
                + "ON C.DEPARTMENT_ID = D.ID " + "INNER JOIN tsup.JDU_TYPE AS JT " + "ON D.JDU_ID = JT.ID "
                + "INNER JOIN tsup.EMPLOYEE AS E " + "ON CSCHED.INSTRUCTOR_ID = E.ID  "
                + "INNER JOIN tsup.VENUE AS V  " + "ON CSCHED.VENUE_ID = V.ID "
                + "INNER JOIN tsup.COURSE_PARTICIPANT AS CPART  " + "ON CSCHED.ID = CPART.COURSE_SCHEDULE_ID "
                + "INNER JOIN tsup.COURSE_ATTENDANCE AS CATTEN "
                + "ON CPART.PARTICIPANT_ID = CATTEN.PARTICIPANT_ID AND CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID "
                + "WHERE CPART.ID = :part_id " + "AND CSCHED.STATUS = 'A'";
        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("part_id", id);
        CourseParticipant courseParticipant = template.queryForObject(sql, namedParameters,
                new EnrollmentRowMapperCourseParticipant());
        return courseParticipant;
    }

    /**
     * <pre>
     * saveCourseNonParticipant
     *
     * @author k.freo
     * 
     *         <pre>
     */
    @Override
    public void saveCourseNonParticipant(CourseParticipant courseParticipant) {
        try {
            String courseParticipantSql = "INSERT INTO COURSE_NON_PARTICIPANT "
                    + "(COURSE_SCHEDULE_ID, PARTICIPANT_ID, REGISTRATION_DATE, REASON, DECLINE_DATE) "
                    + "SELECT COURSE_SCHEDULE_ID, PARTICIPANT_ID, REGISTRATION_DATE, :reason, :declineDate "
                    + "FROM COURSE_PARTICIPANT " + "WHERE ID = :id";
            SqlParameterSource coursenonpartParameters = new MapSqlParameterSource()
                    .addValue("id", courseParticipant.getId())
                    .addValue("reason", courseParticipant.getReason())
                    .addValue("declineDate", courseParticipant.getDeclineDate()
                            .withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime());
            template.update(courseParticipantSql, coursenonpartParameters);
            System.out.println("\nCourse Participant ID who decline: " + courseParticipant.getId() + "\n");

            FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            KeyHolder generatedKeyHolder = new GeneratedKeyHolder();
            String sql = "DELETE FROM COURSE_ATTENDANCE " + "WHERE COURSE_SCHEDULE_DETAIL_ID = :cscheddet_id "
                    + "AND PARTICIPANT_ID = :part_id ";
            SqlParameterSource namedParameters = new MapSqlParameterSource()
                    .addValue("cscheddet_id", courseParticipant.getCourseScheduleDetail().getId())
                    .addValue("part_id", user.getId());
            template.update(sql, namedParameters, generatedKeyHolder);

            Long key = (Long) generatedKeyHolder.getKeys().get("id");
            System.out.println("\nCourse Participant ID to be deleted: " + key + "\n");
        } catch (NullPointerException e) {
            return;
        }
    }

    /**
     * <pre>
     * deleteCourseParticipantById
     *
     * @author k.freo
     * 
     *         <pre>
     */
    @Override
    public void deleteCourseParticipantById(Long id) {
        try {
            KeyHolder generatedKeyHolder = new GeneratedKeyHolder();
            String sql = "DELETE FROM COURSE_PARTICIPANT WHERE id = :id";
            SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("id", id);
            template.update(sql, namedParameters, generatedKeyHolder);

            Long key = (Long) generatedKeyHolder.getKeys().get("id");
            System.out.println("\nCourse Participant ID to be deleted: " + key + "\n");
        } catch (NullPointerException e) {
            return;
        }
    }

    @Override
    public void changeCourseScheduleStatus(CourseSchedule courseSchedule) {
        String sql = "UPDATE COURSE_SCHEDULE SET status = :status WHERE id = :id";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("status", courseSchedule.getStatus()).addValue("id", courseSchedule.getId());
        template.update(sql, namedParameters);
    }

    /**
     * Find All Active Course Schedule
     * 
     * @return
     */
    @Override
    public Set<CourseSchedule> findAllActiveCourseSchedule() {

        String query = "SELECT C.NAME AS COURSE_NAME, " + "CS.ID AS ID, "
                + "CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "CS.COURSE_ID AS COURSE_ID, " + "C.DETAIL AS DETAILS, "
                + "CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, "
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "C.MANDATORY AS MANDATORY,"
                + "C.DEADLINE AS DEADLINE," + "C.MANDATORY_TYPE AS MANDATORY_TYPE,"
                + "D.DEPARTMENT_NAME AS DEPARTMENT," + "CS.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, "
                + "CS.MIN_REQUIRED AS MIN_REQUIRED, " + "CS.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, "
                + "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSD.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CS "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CS.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "INNER JOIN DEPARTMENT AS D " + "ON C.DEPARTMENT_ID = D.ID " + "WHERE CS.STATUS = 'A' "
                + "ORDER BY SCHEDULED_START_DATETIME";
        List<CourseSchedule> courseScheduleList = template.query(query,
                new EnrollmentRowMapperCourseSchedule());
        Set<CourseSchedule> courseScheduleSet = new LinkedHashSet<>(courseScheduleList);
        return courseScheduleSet;
    }

    /**
     * Cancel Course Schedule By Id
     * 
     * @param courseScheduleSet
     */
    @Override
    public void cancelCourseSchedulesById(Set<CourseSchedule> courseScheduleSet) {

        String sql = "UPDATE COURSE_SCHEDULE SET status = :status WHERE id = :id";
        for (CourseSchedule courseSchedule : courseScheduleSet) {
            System.out.println("(DAO) COURSE_SCHEDULE_ID" + courseSchedule.getId());
            SqlParameterSource namedParameters = new MapSqlParameterSource()
                    .addValue("status", courseSchedule.getStatus()).addValue("id", courseSchedule.getId());
            template.update(sql, namedParameters);
        }
    }

    @Override
    public Set<CourseSchedule> findAllCourseScheduleBelowMinimumParticipants() {
        String sql = "SELECT C.NAME AS COURSE_NAME, " + "CS.ID AS ID, "
                + "CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "CS.COURSE_ID AS COURSE_ID, " + "C.DETAIL AS DETAILS, "
                + "CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, " + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, "
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "C.MANDATORY AS MANDATORY,"
                + "C.MANDATORY_TYPE AS MANDATORY_TYPE," + "D.DEPARTMENT_NAME AS DEPARTMENT,"
                + "C.DEADLINE AS DEADLINE," + "CS.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, "
                + "CS.MIN_REQUIRED AS MIN_REQUIRED, " + "CS.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, "
                + "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSD.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CS "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CS.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "INNER JOIN DEPARTMENT AS D " + "ON C.DEPARTMENT_ID = D.ID " + "WHERE CS.STATUS = 'A' "
                + "AND (SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT WHERE COURSE_SCHEDULE_ID = CS.ID) < MIN_REQUIRED "
                + "ORDER BY SCHEDULED_START_DATETIME";
        List<CourseSchedule> courseScheduleList = template.query(sql,
                new EnrollmentRowMapperCourseSchedule());
        Set<CourseSchedule> courseScheduleSet = new LinkedHashSet<>(courseScheduleList);
        return courseScheduleSet;
    }

    @Override
    public Set<CourseSchedule> findAllCourseScheduleByMonth() {

        String sql = "SELECT C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "CS.ID AS ID, "
                + "CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "CS.COURSE_ID AS COURSE_ID, " + "CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "C.MANDATORY AS MANDATORY," + "C.DEADLINE AS DEADLINE," + "CS.VENUE_ID AS VENUE_ID, "
                + "V.NAME AS VENUE_NAME, " + "CS.MIN_REQUIRED AS MIN_REQUIRED, "
                + "CS.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, "
                + "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSD.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CS "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CS.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "WHERE CS.STATUS = 'A' "
                + "AND EXTRACT(MONTH FROM CSD.SCHEDULED_START_DATETIME) = EXTRACT(MONTH FROM NOW()) "
                + "ORDER BY SCHEDULED_START_DATETIME";
        List<CourseSchedule> courseScheduleList = template.query(sql,
                new EnrollmentRowMapperCourseSchedule());
        Set<CourseSchedule> courseScheduleSet = new LinkedHashSet<>(courseScheduleList);
        return courseScheduleSet;
    }

    @Override
    public Set<CourseSchedule> findAllCourseScheduleByQuarter() {

        String sql = "SELECT C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "CS.ID AS ID, "
                + "CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CC.CATEGORY AS COURSE_CATEGORY, "
                + "CS.COURSE_ID AS COURSE_ID, " + "CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "C.MANDATORY AS MANDATORY, " + "C.DEADLINE AS DEADLINE, " + "CS.VENUE_ID AS VENUE_ID, "
                + "V.NAME AS VENUE_NAME, " + "CS.MIN_REQUIRED AS MIN_REQUIRED, "
                + "CS.MAX_ALLOWED AS MAX_ALLOWED, "
                + "(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, "
                + "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSD.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CS "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E "
                + "ON CS.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID "
                + "INNER JOIN COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "WHERE CS.STATUS = 'A' "
                + "AND EXTRACT(QUARTER FROM CSD.SCHEDULED_START_DATETIME) = EXTRACT(QUARTER FROM NOW()) "
                + " ORDER BY SCHEDULED_START_DATETIME";
        List<CourseSchedule> courseScheduleList = template.query(sql,
                new EnrollmentRowMapperCourseSchedule());
        Set<CourseSchedule> courseScheduleSet = new LinkedHashSet<>(courseScheduleList);
        return courseScheduleSet;
    }

    @Override
    public void reschedule(CourseScheduleDetail courseScheduleDetail) {

        String query = "UPDATE COURSE_SCHEDULE_DETAIL SET RESCHEDULED_START_DATETIME = :startDateTime, "
                + "		RESCHEDULED_END_DATETIME = :endDateTime," + "		DURATION = :duration "
                + "		WHERE ID = :id";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("startDateTime",
                        courseScheduleDetail.getScheduledStartDateTime().toOffsetDateTime())
                .addValue("endDateTime", courseScheduleDetail.getScheduledEndDateTime().toOffsetDateTime())
                .addValue("duration", courseScheduleDetail.getDuration())
                .addValue("id", courseScheduleDetail.getId());
        template.update(query, namedParameters);
    }

    @Override
    public Set<CourseParticipant> findAllParticipantByCourseScheduleId(Long courseParticipant) {

        String query = "SELECT E.NUMBER AS EMPLOYEE_ID, " + "						E.ID as EMP_ID, "
                + "			E.LAST_NAME AS EMPLOYEE_LAST_NAME, "
                + "			E.FIRST_NAME AS EMPLOYEE_FIRST_NAME, " + "			E.EMAIL_ADDRESS AS EMAIL "
                + "		FROM COURSE_PARTICIPANT AS CP INNER JOIN EMPLOYEE AS E ON CP.PARTICIPANT_ID = E.ID "
                + "		WHERE CP.COURSE_SCHEDULE_ID = :courseScheduleId";
        SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource().addValue("courseScheduleId",
                courseParticipant);
        List<CourseParticipant> courseEnrolledList = template.query(query, courseEnrolledParameters,
                new EnrollmentRowMapperCourseParticipantByCourseScheduleId());
        Set<CourseParticipant> courseEnrolled = new LinkedHashSet<>(courseEnrolledList);
        return courseEnrolled;
    }

    @Override
    public Set<CourseParticipant> findAllMemberNotEnrolledByCourseScheduleId(
            CourseParticipant courseParticipant) {

        String query = "SELECT E.NUMBER AS EMPLOYEE_ID, " + " E.ID as EMP_ID, "
                + " E.LAST_NAME AS EMPLOYEE_LAST_NAME, " + " E.FIRST_NAME AS EMPLOYEE_FIRST_NAME, "
                + " E.EMAIL_ADDRESS AS EMAIL, " + " E.DEPARTMENT_ID AS DEPARTMENT " + " FROM TSUP.EMPLOYEE E "
                + " WHERE DEPARTMENT_ID = (SELECT E.DEPARTMENT_ID FROM tsup.EMPLOYEE E WHERE E.NUMBER = :employeeNumber) "
                + " AND E.NUMBER " + " NOT IN (SELECT E.NUMBER " + " FROM TSUP.EMPLOYEE E "
                + " INNER JOIN TSUP.COURSE_PARTICIPANT CP " + " ON E.ID = CP.PARTICIPANT_ID "
                + " WHERE CP.COURSE_SCHEDULE_ID = :courseScheduleId)";
        SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                .addValue("courseScheduleId", courseParticipant.getCourseScheduleId())
                .addValue("employeeNumber", courseParticipant.getEmployeeNumber());
        List<CourseParticipant> courseEnrolledList = template.query(query, courseEnrolledParameters,
                new EnrollmentRowMapperCourseParticipantByCourseScheduleId());
        Set<CourseParticipant> courseEnrolled = new LinkedHashSet<>(courseEnrolledList);
        return courseEnrolled;
    }

    @Override
    public Set<CourseParticipant> findMemberNotEnrolledByCourseScheduleId(SearchForm searchForm) {

        String sql = "SELECT E.NUMBER AS EMPLOYEE_ID, " + "E.ID as EMP_ID, "
                + "E.LAST_NAME AS EMPLOYEE_LAST_NAME, " + "E.FIRST_NAME AS EMPLOYEE_FIRST_NAME, "
                + "E.EMAIL_ADDRESS AS EMAIL, " + "E.DEPARTMENT_ID AS DEPARTMENT " + "FROM TSUP.EMPLOYEE E "
                + "WHERE DEPARTMENT_ID = (SELECT E.DEPARTMENT_ID FROM tsup.EMPLOYEE E WHERE E.NUMBER = :employeeNumber) "
                + "AND LOWER(CONCAT(E.FIRST_NAME, E.LAST_NAME, E.USERNAME)) LIKE :search " + "AND E.NUMBER  "
                + "NOT IN (SELECT E.NUMBER " + "	FROM TSUP.EMPLOYEE E "
                + "	INNER JOIN TSUP.COURSE_PARTICIPANT CP " + "	ON E.ID = CP.PARTICIPANT_ID "
                + "	WHERE E.DEPARTMENT_ID = (SELECT E.DEPARTMENT_ID FROM tsup.EMPLOYEE E WHERE E.NUMBER = :employeeNumber) "
                + "	AND CP.COURSE_SCHEDULE_ID = :courseScheduleId) " + "";

        SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource()
                .addValue("employeeNumber", searchForm.getEmployeeNumber())
                .addValue("search", "%" + searchForm.getSearch() + "%")
                .addValue("courseScheduleId", searchForm.getCourseScheduleId());
        List<CourseParticipant> courseEnrolledList = template.query(sql, courseEnrolledParameters,
                new EnrollmentRowMapperCourseParticipantByCourseScheduleId());
        Set<CourseParticipant> courseEnrolled = new LinkedHashSet<>(courseEnrolledList);
        return courseEnrolled;
    }

    @Override
    public Set<CourseSchedule> findCourseScheduleByCourseId(CourseSchedule courseSchedule) {

        String query = "SELECT C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "CS.ID AS ID, "
                + "CSD.ID AS COURSE_SCHEDULE_DETAIL_ID, "// Added
                + "CC.CATEGORY AS COURSE_CATEGORY, " // Added 2021/06/07
                + "CS.COURSE_ID AS COURSE_ID, " + "CS.INSTRUCTOR_ID AS INSTRUCTOR_ID, "
                + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, " + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, "
                + "CS.VENUE_ID AS VENUE_ID, " + "V.NAME AS VENUE_NAME, " + "CS.MIN_REQUIRED AS MIN_REQUIRED, "
                + "CS.MAX_ALLOWED AS MAX_ALLOWED, " + "C.DETAIL AS COURSE_DETAIL, "
                + "C.MANDATORY AS MANDATORY, " + "D.DEPARTMENT_NAME AS DEPARTMENT, "
                + "C.DEADLINE AS DEADLINE, " + "C.MANDATORY_TYPE AS MANDATORY_TYPE, "
                + "(SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID), " + "CS.STATUS AS STATUS, "
                + "COALESCE(CSD.RESCHEDULED_START_DATETIME, CSD.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSD.RESCHEDULED_END_DATETIME, CSD.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CSD.DURATION AS DURATION " + "FROM COURSE_SCHEDULE AS CS "
                + "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID "
                + "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN DEPARTMENT AS D "
                + "ON C.DEPARTMENT_ID = D.ID " + "INNER JOIN EMPLOYEE AS E " + "ON CS.INSTRUCTOR_ID = E.ID "
                + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID " + "INNER JOIN COURSE_CATEGORY AS CC "
                + "ON C.COURSE_CATEGORY_ID = CC.ID " + "WHERE CS.STATUS = 'A' "
                + "AND (SELECT COUNT(PARTICIPANT_ID) AS TOTAL_PARTICIPANTS FROM TSUP.COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = CS.ID) < CS.MAX_ALLOWED " + "	AND CS.COURSE_ID = :courseId "
                + "AND NOT CS.ID = :courseScheduleId " + "ORDER BY SCHEDULED_START_DATETIME DESC"; // Added
                                                                                                   // 'DESC'
                                                                                                   // 2021/09/17
        SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                .addValue("courseId", courseSchedule.getCourseId())
                .addValue("courseScheduleId", courseSchedule.getId());
        List<CourseSchedule> courseScheduleList = template.query(query, courseScheduleParameters,
                new EnrollmentRowMapperCourseSchedule());
        Set<CourseSchedule> courseScheduleSet = new LinkedHashSet<>(courseScheduleList);
        return courseScheduleSet;
    }

    @Override
    public void updateCourseParticipant(CourseParticipant courseParticipant) {
        String query = "UPDATE COURSE_PARTICIPANT "
                + " SET COURSE_SCHEDULE_ID = :courseScheduleId, REGISTRATION_DATE = now() "
                + " WHERE COURSE_SCHEDULE_ID = :id AND PARTICIPANT_ID = :participantId;";
        SqlParameterSource updateCourseParticipantParameters = new MapSqlParameterSource()
                .addValue("courseScheduleId", courseParticipant.getCourseScheduleId())
                .addValue("id", courseParticipant.getId())
                .addValue("participantId", courseParticipant.getParticipantId());
        template.update(query, updateCourseParticipantParameters);

        String updateAttendance = "UPDATE tsup.COURSE_ATTENDANCE AS CATTEN\r\n"
                + "SET COURSE_SCHEDULE_DETAIL_ID = SCHED_REPLACE.COURSE_SCHEDULE_DETAIL_ID\r\n"
                + "FROM (SELECT SCHEDDET1.ID AS COURSE_SCHEDULE_DETAIL_ID\r\n"
                + "        FROM tsup.COURSE_SCHEDULE AS SCHED1\r\n"
                + "          INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS SCHEDDET1\r\n"
                + "          ON SCHED1.ID = SCHEDDET1.COURSE_SCHEDULE_ID\r\n"
                + "         WHERE SCHED1.ID = :courseScheduleId) AS SCHED_REPLACE\r\n"
                + "WHERE CATTEN.COURSE_SCHEDULE_DETAIL_ID = (SELECT SCHEDDET2.ID\r\n"
                + "        FROM tsup.COURSE_SCHEDULE AS SCHED2\r\n"
                + "          INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS SCHEDDET2\r\n"
                + "          ON SCHED2.ID = SCHEDDET2.COURSE_SCHEDULE_ID\r\n"
                + "         WHERE SCHED2.ID = :id)\r\n"
                + "        AND CATTEN.PARTICIPANT_ID = :participantId";
        SqlParameterSource updateCourseAttendanceParameters = new MapSqlParameterSource()
                .addValue("courseScheduleId", courseParticipant.getCourseScheduleId())
                .addValue("id", courseParticipant.getId())
                .addValue("participantId", courseParticipant.getParticipantId());
        template.update(updateAttendance, updateCourseAttendanceParameters);
    }

    /**
     * finds and only enables the upload certificate button for mandatory courses from the database
     * 
     * @return mandatoryCourses
     * @author M.Atayde
     **/
    @Override
    public List<String> findCourseScheduleIfMandatory() {

        String query = "SELECT name" + " from TSUP.COURSE"
                + " WHERE MANDATORY = :isMandatory AND MANDATORY_TYPE = 'GDC'";

        SqlParameterSource courseMandatoryParameters = new MapSqlParameterSource().addValue("isMandatory",
                "Yes");
        List<String> mandatoryCourses = template.queryForList(query, courseMandatoryParameters, String.class);
        return mandatoryCourses;
    }

    /**
     * uploads the certificate to the database
     * 
     * @param certificate
     * @author M.Atayde
     **/
    @Override
    public void uploadCertificate(Certificate certificate) {

        String query = "INSERT INTO CERTIFICATE_UPLOAD"
                + " (employee_id, course_id, certificate, upload_date, fileDownloadUri)"
                + " VALUES(:employee_id, :course_id, :certificate, :upload_date, :filedownloaduri)";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("certificate", certificate.getCertificate())
                .addValue("employee_id", certificate.getUser())
                .addValue("course_id", certificate.getCourseId())
                .addValue("upload_date",
                        certificate.getUploadDate().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                .addValue("filedownloaduri", certificate.getFileDownloadUri());
        template.update(query, sqlParameterSource);
    }

    @Override
    public String findCertificateName(long userId, long courseId) {
        String query = "SELECT filedownloaduri from tsup.certificate_upload"
                + " where upload_date =(select max(upload_date)" + " from tsup.certificate_upload"
                + " where course_id = :course_id and employee_id = :employee_id)";

        try {
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("course_id", courseId).addValue("employee_id", userId);

            String certificateName = template.queryForObject(query, sqlParameterSource, String.class);
            return certificateName;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public Set<CourseCategory> findAllCourseCategory() {

        String query = "SELECT * FROM COURSE_CATEGORY ORDER BY category";
        List<CourseCategory> courseCategoryList = template.query(query, new CourseCategoryRowMapper());
        Set<CourseCategory> courseCategory = new LinkedHashSet<>(courseCategoryList);
        return courseCategory;
    }

    @Override
    public Set<Course> findAllCourseName() {

        String query = "SELECT * FROM COURSE ORDER BY name";
        List<Course> courseNameList = template.query(query, new CourseRowMapper());
        Set<Course> courseName = new LinkedHashSet<>(courseNameList);
        return courseName;
    }

    @Override
    public Set<InstructorForm> findAllInstructor() {

        String query = "SELECT E.ID, E.FIRST_NAME, E.LAST_NAME " + "FROM EMPLOYEE AS E "
                + "INNER JOIN EMPLOYEE_AUTH AS EA " + "ON E.USERNAME = EA.USERNAME "
                + "WHERE EA.AUTH_NAME = 'Instructor'" + "ORDER BY E.LAST_NAME ASC";
        List<InstructorForm> instructorList = template.query(query, new InstructorRowMapper());
        Set<InstructorForm> instructor = new LinkedHashSet<>(instructorList);
        return instructor;
    }

    /**
     * <pre>
     * Finds all venues
     * 
     * <pre>
     */
    @Override
    public Set<VenueForm> findAllVenue() {
        String query = "SELECT * FROM VENUE ORDER BY name ASC";

        List<VenueForm> venueList = template.query(query, new VenueRowMapper());
        Set<VenueForm> venue = new LinkedHashSet<>(venueList);

        return venue;
    }

    /**
     * <pre>
     * Finds all departments
     * 
     * <pre>
     */
    @Override
    public Set<DepartmentForm> findAllDepartment() {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String query = "SELECT D.id AS ID," + "  D.department_name AS DEPARTMENT_NAME,"
                + "  D.jdu_id AS JDU_ID," + "  JT.jdu_name AS JDU_NAME"
                + " FROM DEPARTMENT D INNER JOIN JDU_TYPE JT ON D.jdu_id = JT.id" + " WHERE D.jdu_id = ("
                + "		SELECT D.jdu_id " + "		FROM DEPARTMENT D "
                + "		INNER JOIN EMPLOYEE E ON E.department_id = D.id WHERE E.id = :employee_id) "
                + " ORDER BY department_name ASC";

        SqlParameterSource params = new MapSqlParameterSource().addValue("employee_id", user.getId());
        List<DepartmentForm> departmentList = template.query(query, params, new DepartmentRowMapper());
        Set<DepartmentForm> department = new LinkedHashSet<>(departmentList);

        return department;
    }

    /**
     * <pre>
     * Finds all member roles
     * 
     * <pre>
     */
    @Override
    public Set<MemberRole> findAllMemberRole() {

        String query = "SELECT id as ID, role_type as NAME, role_desc as DESC FROM MEMBER_ROLE";

        List<MemberRole> memberRoleList = template.query(query, new MemberRoleRowMapper());
        return new LinkedHashSet<>(memberRoleList);
    }

    /**
     * <pre>
     * Method for removing selected enrolled members in a course schedule
     * 
     * <pre>
     */
    @Override
    public void removeBatchMember(EnrolledMemberForm enrolledMember) {

        List<Long> items = Arrays.asList(enrolledMember.getBatchId().split(",")).stream()
                .map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());

        // Delete record from the COURSE_PARTICIPANT table
        String deleteFromCoursePaticipant = "DELETE FROM COURSE_PARTICIPANT "
                + "WHERE COURSE_SCHEDULE_ID = :course_id " + "AND PARTICIPANT_ID IN (:participant_id) ";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("course_id", enrolledMember.getCourseId()).addValue("participant_id", items);
        template.update(deleteFromCoursePaticipant, sqlParameterSource);

        // Delete record from the COURSE_ATTENDANCE table
        String deleteFromCourseAttendance = "DELETE FROM COURSE_ATTENDANCE "
                + "WHERE COURSE_SCHEDULE_DETAIL_ID = :course_id "
                + "AND PARTICIPANT_ID IN (:participant_id) ";
        template.update(deleteFromCourseAttendance, sqlParameterSource);
    }

    /**
     * Method to Save data to Table tsup.course_participant
     **/
    @Override
    public void enrollBatchMember(EnrolledMemberForm enrolledMember) {
        List<Long> items = Arrays.asList(enrolledMember.getBatchId().split(",")).stream()
                .map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());

        // Insert record to the COURSE_PARTICIPANT table
        String enrollToCoursePaticipant = "INSERT INTO COURSE_PARTICIPANT "
                + "(COURSE_SCHEDULE_ID, PARTICIPANT_ID, REGISTRATION_DATE) "
                + "SELECT :course_id, E.id, NOW() FROM EMPLOYEE E WHERE E.id IN (:participant_id); ";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("course_id", enrolledMember.getCourseId()).addValue("participant_id", items);
        template.update(enrollToCoursePaticipant, sqlParameterSource);

        // Insert record to the COURSE_ATTENDANCE table
        String enrollToCourseAttendance = "INSERT INTO tsup.COURSE_ATTENDANCE "
                + "(COURSE_SCHEDULE_DETAIL_ID, PARTICIPANT_ID,STATUS,LOG_IN_DATETIME,LOG_OUT_DATETIME, EMAIL) "
                + "SELECT :course_id, E.id, 'A', null, null, E.email_address FROM tsup.EMPLOYEE E WHERE E.id IN (:participant_id); ";
        template.update(enrollToCourseAttendance, sqlParameterSource);
    }

    /**
     * Method to Count the available course
     **/
    @Override
    public int countCourse(CourseScheduleListForm form) {
        try {
            FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            StringBuilder queryBuilder = new StringBuilder();
            List<String> conditionList = new LinkedList<>();
            boolean withTags = (form.getMemberRole() != null && !form.getMemberRole().isEmpty());

            queryBuilder.append("SELECT COUNT(DISTINCT CS.id) " + "FROM COURSE_SCHEDULE AS CS ");
            queryBuilder.append(
                    "INNER JOIN COURSE_SCHEDULE_DETAIL AS CSD " + "ON CS.ID = CSD.COURSE_SCHEDULE_ID ");
            queryBuilder.append(
                    "INNER JOIN COURSE AS C " + "ON CS.COURSE_ID = C.ID " + "INNER JOIN EMPLOYEE AS E ");
            queryBuilder.append(
                    "ON CS.INSTRUCTOR_ID = E.ID " + "INNER JOIN VENUE AS V " + "ON CS.VENUE_ID = V.ID ");
            queryBuilder.append("INNER JOIN COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID ");
            queryBuilder.append("INNER JOIN DEPARTMENT AS D ");
            queryBuilder.append("ON C.DEPARTMENT_ID = D.ID ");

            if (withTags) {
                queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM "); // ADD
                queryBuilder.append("ON CTM.course_id = CS.COURSE_ID "); // ADD
                queryBuilder.append("INNER JOIN MEMBER_ROLE MR "); // ADD
                queryBuilder.append("ON MR.id = CTM.tag_id "); // ADD
                addTagsToConditionList(conditionList, form.getMemberRole());
            }

            queryBuilder.append("WHERE COALESCE(CSD.RESCHEDULED_START_DATETIME, ");
            queryBuilder.append("CSD.SCHEDULED_START_DATETIME) BETWEEN :fromDateTime AND :toDateTime ");
            queryBuilder.append("AND CS.STATUS = 'A' ");
            queryBuilder.append("AND TO_CHAR(C.course_category_id, 'FM9999') LIKE :courseCategoryID ");
            queryBuilder.append("AND TO_CHAR(CS.COURSE_ID, 'FM9999') LIKE :courseNameId ");
            queryBuilder.append("AND TO_CHAR(CS.INSTRUCTOR_ID, 'FM9999') LIKE :instructorId ");
            queryBuilder.append(
                    "AND TO_CHAR(CS.VENUE_ID, 'FM9999') LIKE :venueId " + "AND C.MANDATORY LIKE :mandatory ");
            queryBuilder.append(
                    "AND C.DEADLINE LIKE :deadline " + "AND D.jdu_id = (" + "       SELECT D.jdu_id ");
            queryBuilder.append("       FROM DEPARTMENT D ");
            queryBuilder.append(
                    "       INNER JOIN EMPLOYEE E ON E.department_id = D.id WHERE E.id = :employee_id) ");

            if (withTags) {
                queryBuilder.append("AND " + conditionList.stream().collect(Collectors.joining())); // ADD
            }

            SqlParameterSource courseScheduleParameters = new MapSqlParameterSource()
                    .addValue("fromDateTime",
                            form.getFromDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("toDateTime",
                            form.getToDateTime().withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
                    .addValue("courseCategoryID", form.getCourseCategoryId())
                    .addValue("courseNameId", form.getCourseNameId())
                    .addValue("instructorId", form.getInstructorId()).addValue("venueId", form.getVenueId())
                    .addValue("departmentId", form.getDepartmentId())
                    .addValue("mandatory", form.getMandatory())
                    .addValue("mandatoryType", form.getMandatoryType())
                    .addValue("deadline", form.getDeadline()).addValue("employee_id", user.getId());// Added
                                                                                                    // 2021/07/08
            return template.queryForObject(queryBuilder.toString(), courseScheduleParameters, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    /**
     * Method for counting course base on SearchFilter object provided
     */
    @Override
    public int countFoundCourseSchedule(MyCourseScheduleFilter searchCriteria) {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String query = "SELECT COUNT( DISTINCT(CPART.ID)) " + "FROM tsup.COURSE_SCHEDULE AS CSCHED  "
                + "INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE_PARTICIPANT AS CPART " + "ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE AS C " + "ON C.ID = CSCHED.COURSE_ID "
                + "INNER JOIN tsup.COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "INNER JOIN tsup.DEPARTMENT AS D " + "ON C.DEPARTMENT_ID = D.ID "
                + "INNER JOIN tsup.JDU_TYPE AS JT " + "ON D.JDU_ID = JT.ID "
                + "INNER JOIN tsup.EMPLOYEE AS E " + "ON E.ID = CSCHED.INSTRUCTOR_ID "
                + "INNER JOIN tsup.VENUE AS V " + "ON V.ID = CSCHED.VENUE_ID "
                + "INNER JOIN tsup.COURSE_ATTENDANCE AS CATTEN "
                + "ON CPART.PARTICIPANT_ID = CATTEN.PARTICIPANT_ID AND CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID ";

        StringBuilder queryBuilder = new StringBuilder(query);
        List<String> conditionList = new LinkedList<>();

        if (!searchCriteria.getMemberRole().isEmpty()) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM ");
            queryBuilder.append("ON CTM.course_id = C.id ");
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR ");
            queryBuilder.append("ON MR.id = CTM.tag_id ");

            addTagsToConditionList(conditionList, searchCriteria.getMemberRole());
        }

        queryBuilder.append("WHERE ");

        addToConditionList(conditionList, "CSCHED.STATUS = 'A' ");

        if (Objects.nonNull(searchCriteria.getToDateTimeTimezoneOnUTC())
                && Objects.nonNull(searchCriteria.getFromDateTimeTimezoneOnUTC())) {
            String betweenCondition = "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN '"
                    + searchCriteria.getFromDateTimeTimezoneOnUTC() + "' AND '"
                    + searchCriteria.getToDateTimeTimezoneOnUTC() + "' ";
            addToConditionList(conditionList, betweenCondition);
        }

        if (Objects.nonNull(user.getId())) {
            addToConditionList(conditionList, "CPART.PARTICIPANT_ID = " + user.getId() + " ");
        }

        if (StringUtils.isNoneBlank(searchCriteria.getCourseName())) {
            addToConditionList(conditionList, "C.name", searchCriteria.getCourseName());
        }

        if (StringUtils.isNoneBlank(searchCriteria.getCourseCategory())) {
            addToConditionList(conditionList, "CC.category", searchCriteria.getCourseCategory());
        }

        if (StringUtils.isNoneBlank(searchCriteria.getInstructorName())) {
            addToConditionList(conditionList, "E.id", searchCriteria.getInstructorName());
        }

        if (StringUtils.isNoneBlank(searchCriteria.getVenueName())) {
            addToConditionList(conditionList, "V.name", searchCriteria.getVenueName());
        }

        queryBuilder.append(conditionList.stream().collect(Collectors.joining()));

        return jdbcTemplate.queryForObject(queryBuilder.toString(), Integer.class);
    }

    /**
     * Method for getting all email of employees to be enrolled
     */
    @Override
    public Set<CourseParticipant> getAllEmails(String batchId) {

        List<Long> items = Arrays.asList(batchId.split(",")).stream().map(s -> Long.parseLong(s.trim()))
                .collect(Collectors.toList());
        String query = "SELECT E.NUMBER AS EMPLOYEE_ID, " + " E.ID as EMP_ID, "
                + " E.LAST_NAME AS EMPLOYEE_LAST_NAME, " + " E.FIRST_NAME AS EMPLOYEE_FIRST_NAME, "
                + " E.EMAIL_ADDRESS AS EMAIL " + " FROM EMPLOYEE AS E " + " WHERE E.ID IN (:participantIds)";

        SqlParameterSource courseEnrolledParameters = new MapSqlParameterSource().addValue("participantIds",
                items);
        List<CourseParticipant> employeeList = template.query(query, courseEnrolledParameters,
                new EnrollmentRowMapperCourseParticipantByCourseScheduleId());
        Set<CourseParticipant> employee = new LinkedHashSet<>(employeeList);

        return employee;
    }

    @Override
    public Set<CourseParticipant> findCoursesByMyCourseScheduleFilter(MyCourseScheduleFilter searchCriteria,
            Pageable pageable) {

        FpiUser user = (FpiUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("scheduled_start_datetime");
        String orderProperty = getOrderProperty(order);

        String query = "SELECT DISTINCT CPART.ID AS COURSE_PARTICIPANT_ID, " + "C.ID AS COURSE_ID, "
                + "CSCHEDDET.ID AS COURSE_SCHEDULE_DETAIL_ID, " + "CSCHED.ID AS COURSE_SCHEDULE_ID, "
                + "C.NAME AS COURSE_NAME, " + "C.DETAIL AS DETAILS, " + "C.MANDATORY AS MANDATORY,"
                + "C.DEADLINE AS DEADLINE," + "CSCHED.STATUS AS COURSE_STATUS,"
                + "CC.CATEGORY AS COURSE_CATEGORY," + "D.DEPARTMENT_NAME AS DEPARTMENT,"
                + "C.MANDATORY_TYPE AS MANDATORY_TYPE," + "E.LAST_NAME AS INSTRUCTOR_LAST_NAME, "
                + "E.FIRST_NAME AS INSTRUCTOR_FIRST_NAME, " + "V.NAME AS VENUE_NAME, "
                + "CPART.PARTICIPANT_ID AS PARTICIPANT_ID, "
                + "(SELECT LAST_NAME FROM tsup.EMPLOYEE WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_LAST_NAME, "
                + "(SELECT FIRST_NAME FROM tsup.EMPLOYEE WHERE ID = CPART.PARTICIPANT_ID) AS PARTICIPANT_FIRST_NAME, "
                + "CSCHEDDET.DURATION AS DURATION, " + "CPART.REGISTRATION_DATE AS REGISTRATION_DATE, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, CSCHEDDET.SCHEDULED_START_DATETIME) AS SCHEDULED_START_DATETIME, "
                + "COALESCE(CSCHEDDET.RESCHEDULED_END_DATETIME, CSCHEDDET.SCHEDULED_END_DATETIME) AS SCHEDULED_END_DATETIME, "
                + "CATTEN.STATUS AS ATTENDANCE_STATUS " + "FROM tsup.COURSE_SCHEDULE AS CSCHED  "
                + "INNER JOIN tsup.COURSE_SCHEDULE_DETAIL AS CSCHEDDET "
                + "ON CSCHEDDET.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE_PARTICIPANT AS CPART " + "ON CPART.COURSE_SCHEDULE_ID = CSCHED.ID "
                + "INNER JOIN tsup.COURSE AS C " + "ON C.ID = CSCHED.COURSE_ID "
                + "INNER JOIN tsup.COURSE_CATEGORY AS CC " + "ON C.COURSE_CATEGORY_ID = CC.ID "
                + "INNER JOIN tsup.DEPARTMENT AS D " + "ON C.DEPARTMENT_ID = D.ID "
                + "INNER JOIN tsup.JDU_TYPE AS JT " + "ON D.JDU_ID = JT.ID "
                + "INNER JOIN tsup.EMPLOYEE AS E " + "ON E.ID = CSCHED.INSTRUCTOR_ID "
                + "INNER JOIN tsup.VENUE AS V " + "ON V.ID = CSCHED.VENUE_ID "
                + "INNER JOIN tsup.COURSE_ATTENDANCE AS CATTEN "
                + "ON CPART.PARTICIPANT_ID = CATTEN.PARTICIPANT_ID AND CSCHEDDET.ID = CATTEN.COURSE_SCHEDULE_DETAIL_ID ";

        StringBuilder queryBuilder = new StringBuilder(query);
        List<String> conditionList = new LinkedList<>();

        if (!searchCriteria.getMemberRole().isEmpty()) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM ");
            queryBuilder.append("ON CTM.course_id = C.id ");
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR ");
            queryBuilder.append("ON MR.id = CTM.tag_id ");

            addTagsToConditionList(conditionList, searchCriteria.getMemberRole());
        }

        queryBuilder.append("WHERE ");

        addToConditionList(conditionList, "CSCHED.STATUS = 'A' ");

        if (Objects.nonNull(searchCriteria.getToDateTimeTimezoneOnUTC())
                && Objects.nonNull(searchCriteria.getFromDateTimeTimezoneOnUTC())) {
            String betweenCondition = "COALESCE(CSCHEDDET.RESCHEDULED_START_DATETIME, CSCHEDDET.SCHEDULED_START_DATETIME) BETWEEN '"
                    + searchCriteria.getFromDateTimeTimezoneOnUTC() + "' AND '"
                    + searchCriteria.getToDateTimeTimezoneOnUTC() + "' ";
            addToConditionList(conditionList, betweenCondition);
        }

        if (Objects.nonNull(user.getId())) {
            addToConditionList(conditionList, "CPART.PARTICIPANT_ID = " + user.getId() + " ");
        }

        if (StringUtils.isNoneBlank(searchCriteria.getCourseName())) {
            addToConditionList(conditionList, "C.name", searchCriteria.getCourseName());
        }

        if (StringUtils.isNoneBlank(searchCriteria.getCourseCategory())) {
            addToConditionList(conditionList, "CC.category", searchCriteria.getCourseCategory());
        }

        if (StringUtils.isNoneBlank(searchCriteria.getInstructorName())) {
            addToConditionList(conditionList, "E.last_name", searchCriteria.getInstructorName());
        }

        if (StringUtils.isNoneBlank(searchCriteria.getVenueName())) {
            addToConditionList(conditionList, "V.name", searchCriteria.getVenueName());
        }

        queryBuilder.append(conditionList.stream().collect(Collectors.joining()));
        queryBuilder.append(" ORDER BY " + orderProperty + " ");

        if (Objects.nonNull(pageable)) {
            queryBuilder.append("LIMIT " + pageable.getPageSize() + " ");
            queryBuilder.append("OFFSET " + pageable.getOffset() + " ");
        }

        List<CourseParticipant> courseEnrolledList = template.query(queryBuilder.toString(),
                new EnrollmentRowMapperCourseParticipant());

        return courseEnrolledList.isEmpty() ? Collections.emptySet()
                : new LinkedHashSet<>(courseEnrolledList);
    }

    /**
     * @param courseSearchFilter
     * @param conditionList
     */
    public void addToConditionList(List<String> conditionList, String sqlField, String fieldValue) {
        if (conditionList.isEmpty()) {
            conditionList.add("LOWER(" + sqlField + ") LIKE LOWER('%" + fieldValue + "%') ");
        } else {
            conditionList.add("AND LOWER(" + sqlField + ") LIKE LOWER('%" + fieldValue + "%') ");
        }
    }

    public void addToConditionList(List<String> conditionList, String condition) {
        if (conditionList.isEmpty()) {
            conditionList.add(condition);
        } else {
            conditionList.add("AND " + condition);
        }
    }

    /**
     * @param courseSearchFilter
     * @param conditionList
     */
    public void addTagsToConditionList(List<String> conditionList, String fieldValue) {

        String[] tags = fieldValue.split(",");

        for (String tag : tags) {
            if (conditionList.isEmpty()) {
                conditionList.add("( C.ID IN ");
                conditionList.add(" ( SELECT DISTINCT c.id ");
                conditionList.add("   FROM            course c ");
                conditionList.add("   INNER JOIN      course_tag_map ctm ");
                conditionList.add("   ON              ctm.course_id = c.id ");
                conditionList.add("   INNER JOIN      member_role mr ");
                conditionList.add("   ON              mr.id = ctm.tag_id WHERE ");
                conditionList.add("   LOWER(MR.role_type) LIKE lower('" + tag + "')  ");
            } else {
                conditionList.add("OR LOWER(MR.ROLE_TYPE) LIKE LOWER('" + tag + "') ");
            }
        }
        conditionList.add(" ) )");
    }
}

package com.fujitsu.ph.tsup.courserequirement.dao;

import java.math.BigInteger;
import java.sql.Types;
import java.util.List;

import com.fujitsu.ph.tsup.course.dao.CourseRowMapper;
import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.courserequirement.model.CourseChecklist;
import com.fujitsu.ph.tsup.courserequirement.model.CourseParticipant;
import com.fujitsu.ph.tsup.courserequirement.model.CourseScheduleDetail;
import com.fujitsu.ph.tsup.courserequirement.model.EmployeeChecklist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

/**
 * ===============================================================
 * $Id: PR30$
 *  Project Name: Training Sign Up
 * System Name : Course Checklist
 * Class Name: CourseRequirementDaoImpl.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated by          | Content
 * --------+------------+---------------------+-----------------
 * 0.01    | 2021/10/19 | WS) A.Labada        | Initial Creation
 * 0.02    | 2021/10/20 | WS) e.delosreyes    | Added @Service
 * 0.03    | 2021/10/28 | WS) e.delosreyes    | Updated
 * 0.04    | 2021/11/04 | WS) e.delosreyes    | Corrected queries 
 * 0.05    | 2021/11/04 | WS) a.labada        | Add update course queries 
 * 0.06    | 2021/11/04 | WS) e.delosreyes    | Fixed query for getAttendees
 * 0.07    | 2021/11/05 | WS) a.abellanosa    | remove getAttendeeChecklist, unnecessary imports
 * ===============================================================
 */

/**
 * <pre>
 * The data access implementation for course requirement related database
 * </pre>
 *
 * @version 0.07
 * @author a.abellanosa
 *
 */
@Service
@Qualifier("main")
public class CourseRequirementDAOImpl implements CourseRequirementDao {
	/*
	 * NamedParameterJdbcTemplate
	 */
	@Autowired
	private NamedParameterJdbcTemplate template;

	/**
	 * <pre>
	 * This method will create a course requirement
	 * </pre>
	 * 
	 * @param courseRequirement
	 */
	@Override
	public void createCourseRequirement(CourseChecklist courseRequirement) {
		String query = "INSERT INTO course_checklist(requirement, course_id)" + " VALUES(:requirement , :course_id)";
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
				.addValue("requirement", courseRequirement.getRequirement())
				.addValue("course_id", courseRequirement.getCourseId());

		template.update(query, sqlParameterSource);
	}

	/**
	 * List all the courses in the database.
	 * 
	 * @return List<Course>
	 */
	@Override
	public List<Course> getCourses() {
		String query = "SELECT * FROM course";
		return template.query(query, new CourseRowMapper());
	}

	/**
	 * List all course checklist in the database.
	 * 
	 * @return List<CourseChecklist>
	 */
	@Override
	public List<CourseChecklist> getCourseRequirements(Integer courseId) {
		String query = "SELECT * FROM tsup.course_checklist WHERE course_id=:courseId";
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("courseId", courseId,
				Types.BIGINT);
		return template.query(query, sqlParameterSource, new CourseRequirementRowMapper());
	}

	/**
	 * <pre>
	 * This method will update the checklist of attendee
	 * </pre>
	 * 
	 * @param employeeChecklists
	 */
	@Override
	public void updateAttendeeChecklist(EmployeeChecklist employeeChecklists) {
		String query = "UPDATE employee_checklist SET is)Accomplished= :is_Accomplished WHERE id=:id";

		SqlParameterSource updateAttendee = new MapSqlParameterSource()
				.addValue("is_Accomplished", employeeChecklists.getIs_Accomplished(), Types.BOOLEAN)
				.addValue("id", employeeChecklists.getId(), Types.BIGINT);
		template.update(query, updateAttendee);
	}

	/**
	 * <pre>
	 * This method will delete a course requirement
	 * </pre>
	 * 
	 * @param courseRequirementId
	 */
	@Override
	public void deleteCourseRequirement(Integer courseRequirementId) {
		StringBuilder query = new StringBuilder(); 
		query.append("DELETE FROM employee_checklist WHERE course_checklist_id=:courseRequirementId; ");
		query.append("DELETE FROM course_checklist WHERE id=:courseRequirementId");
		SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("courseRequirementId",
				courseRequirementId);
		template.update(query.toString(), namedParameters);
	}

	/**
	 * <pre>
	 * This method will update the course checklist
	 * </pre>
	 * 
	 * @param courseChecklist
	 */
	@Override
	public void updateCourseRequirement(CourseChecklist courseChecklist) {
		String query = "UPDATE tsup.course_checklist SET requirement=:requirement WHERE id=:id";
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
				.addValue("requirement", courseChecklist.getRequirement(), Types.VARCHAR)
				.addValue("id", courseChecklist.getId(), Types.INTEGER);
		template.update(query, sqlParameterSource);
	}

	/**
	 * <pre>
	 * This method will create the participant checklist
	 * </pre>
	 * 
	 * @param participanChecklist
	 */
	@Override
	public void createParticipantCourseChecklist(EmployeeChecklist participanChecklist) {
		StringBuilder query = new StringBuilder();
		query.append("INSERT INTO employee_checklist(is_Accomplished, course_participant_id,course_schedule_id, course_checklist_id)");
		query.append("values(:is_Accomplished , :course_participant_id, :course_schedule_id, :course_checklist_id )");
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
				.addValue("is_Accomplished", participanChecklist.getIs_Accomplished(), Types.BOOLEAN)
				.addValue("course_participant_id", participanChecklist.getCourseParticipant().getId(), Types.INTEGER)
				.addValue("course_schedule_id", participanChecklist.getCourseSchedule().getId(), Types.INTEGER)
				.addValue("course_checklist_id", participanChecklist.getCourseChecklist().getId(), Types.BIGINT);
		template.update(query.toString(), sqlParameterSource);
	}

	/**
	 * <pre>
	 * This method will creturn the list of CourseScheduleDetail
	 * </pre>
	 * 
	 * @param courseId
	 */
	@Override
	public List<CourseScheduleDetail> getCourseScheduleDetails(Integer courseId) {
		StringBuilder query = new StringBuilder();
		query.append("select tsup.course_schedule_detail.* from tsup.course_schedule_detail ");
		query.append(
				"inner join tsup.course_schedule on course_schedule.id = course_schedule_detail.course_schedule_id ");
		query.append("where course_schedule.course_id = :courseId");
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("courseId",
				BigInteger.valueOf(courseId.intValue()), Types.BIGINT);
		return template.query(query.toString(), sqlParameterSource, new CourseScheduleDetailRowMapper());
	}

	/**
	 * <pre>
	 * This method will return the list of attendees of the course schedule
	 * </pre>
	 * 
	 * @param courseScheduleId
	 */
	@Override
	public List<CourseParticipant> getCourseParticipants(Integer courseScheduleId) {
		StringBuilder query = new StringBuilder();
		query.append(
				"select tsup.Employee.first_name, tsup.Employee.id as Employee_Id, tsup.Employee.last_name, tsup.course_participant.id ");
		query.append("from tsup.Employee ");
		query.append("INNER JOIN tsup.course_participant on course_participant.participant_id = employee.id ");
		query.append("where course_participant.course_schedule_id = :courseScheduleId ");
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("courseScheduleId",
				BigInteger.valueOf(courseScheduleId.intValue()), Types.BIGINT);
		return template.query(query.toString(), sqlParameterSource, new CourseParticipantRowMapper());
	}

	/**
	 * <pre>
	 * This method will return the list of checklist of the participant
	 * </pre>
	 * 
	 * @param participantId
	 */
	@Override
	public List<EmployeeChecklist> getParticipantChecklists(Integer participantId) {
		StringBuilder query = new StringBuilder();
		query.append("select tsup.employee_checklist.id as checklist_id, ");
		query.append("tsup.employee_checklist.is_Accomplished, ");
		query.append("tsup.course_participant.id as course_participant_id, ");
		query.append("tsup.employee.id as employee_id, ");
		query.append("tsup.employee.first_name, ");
		query.append("tsup.employee.last_name, ");
		query.append("tsup.course_checklist.id as course_checklist_ID, ");
		query.append("tsup.course_checklist.requirement ");
		query.append("from tsup.employee_checklist ");
		query.append("inner join tsup.course_participant on course_participant.id = employee_checklist.course_participant_id ");
		query.append("inner join tsup.course_checklist on course_checklist.id = employee_checklist.course_checklist_id ");
		query.append("inner join tsup.employee on employee.id = course_participant.participant_id ");
		query.append("where course_participant.id = :participantId ");
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("participantId",
				BigInteger.valueOf(participantId.intValue()), Types.BIGINT);

		return template.query(query.toString(), sqlParameterSource, new EmployeeChecklistRowMapper());
	}
}

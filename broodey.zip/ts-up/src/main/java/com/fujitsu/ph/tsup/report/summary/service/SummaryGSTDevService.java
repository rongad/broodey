/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.service;

import java.time.ZonedDateTime;

import com.fujitsu.ph.tsup.report.summary.model.SummaryGSTDevForm;


//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for Dev
//Class Name   : SummaryGSTDevService.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | ----/--/-- | WS) n.dejesus         | Initial Version
//0.02    | 2021/06/14 | WS) m.padaca          | Updated
//0.03    | 2021/10/15 | WS) r.buot            | Updated
//0.03    | 2021/10/15 | WS) dw.cardenas       | Updated
//==================================================================================================


/**
 * <pre>
 * The interface of G3CC standardization training for dev service
 * </pre>
 * 
 * @version 0.02
 * @author n.dejesus
 * @author m.padaca
 * @author r.buot
 */
public interface SummaryGSTDevService {
    /**
     * <pre>
     * Get Summary of members who completed G3CC Standardization Training
     * </pre>
     * 
     * @param zonedDateTime2
     * @param zonedDateTime
     * @return SummaryGSTDevForm
     */

    // Method for accumulating summary data
    SummaryGSTDevForm getSummary(ZonedDateTime reportDate);
}

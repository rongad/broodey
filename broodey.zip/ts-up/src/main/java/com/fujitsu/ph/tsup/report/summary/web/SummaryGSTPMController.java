/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.web;


import java.time.ZonedDateTime;

import javax.validation.Valid;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.fujitsu.ph.tsup.report.summary.model.SummaryGSTForm;
import com.fujitsu.ph.tsup.report.summary.service.SummaryGSTPMService;

import ch.qos.logback.classic.Logger;

//==================================================================================================
// Project Name : Training Sign Up
// System Name  : Summary of JDU Standardization Training for PM
// Class Name   : SummaryGSTPMController.java
//
// <<Modification History>>
// Version | Date       | Updated By            | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/04/20 | WS) d.escala          | Initial Version
// 0.02    | 2021/04/23 | WS) m.padaca          | Updated
// 0.03    | 2021/04/27 | WS) m.padaca          | Updated
// 0.03    | 2021/05/10 | WS) D.Escala          | Updated
// 0.04    | 2021/10/15 | WS) r.buot            | Updated
// 0.04    | 2021/10/15 | WS) dw.cardenas       | Updated
//==================================================================================================
/**
* <pre>
* The controller for summaryGSTPM
* </pre>
* 
* @version 0.03
* @author m.padaca
* @author d.escala
* @author r.buot
*/

@Controller
@RequestMapping("/report/summary")
public class SummaryGSTPMController {

    @Autowired
    private SummaryGSTPMService summaryGSTPMService;

    // Logger Factory
    private static Logger logger = (Logger) LoggerFactory.getLogger(SummaryGSTPMController.class);

    /**
     * <pre>
     * Method for passing data to summaryGSTForm
     * </pre>
     * @param summaryGSTForm
     * @param reportTypeId
     * @param bindingResult
     * @param model
     * @return
     */
    @GetMapping("/standardization/pm")
    public String viewG3CCSummaryForPM(@Valid @ModelAttribute("summaryGSTForm") SummaryGSTForm summaryGSTForm,
            Long reportTypeId, BindingResult bindingResult, Model model) {

        logger.debug("SummaryGSTForm: {}", summaryGSTForm);
        logger.debug("Result: {}", bindingResult);

        if (bindingResult.hasErrors()) {
            return "reports/generateReport";
        }

        ZonedDateTime reportDate = summaryGSTForm.getReportDateTime();
        if (reportDate == null)
            reportDate = ZonedDateTime.now();
        SummaryGSTForm summaryForm = summaryGSTPMService.getSummary(reportDate);

        model.addAttribute("summaryGST", summaryForm);

        return "reports/summaryGSTForPM";
    }

}

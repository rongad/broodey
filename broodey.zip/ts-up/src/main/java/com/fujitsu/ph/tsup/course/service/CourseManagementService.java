/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.service;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.search.CourseSearchFilter;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Course Management
//Class Name   : CourseManagementService.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2020/08/28 | WS) c.lepiten       | Initial Version
//0.02    | 2021/04/16 | WS) i.fajardo       | Updated
//0.03    | 2021/05/27 | WS) mi.aguinaldo    | Added updateCourse
//0.04    | 2021/06/30 | WS) mi.aguinaldo    | Overload courseNameExists method
//0.05    | 2021/07/16 | WS) mi.aguinaldo    | Updated
//0.06    | 2021/08/05 | WS) mi.aguinaldo    | Updated
//0.07    | 2021/09/06 | WS) d.dinglasan     | Updated
//==================================================================================================

public interface CourseManagementService {

    void deleteCourseById(Long id);

    Course findCourseById(Long id);
    
    Set<Course> findAllCourses();
   
    // Method for finding all courses base on Pageable object provided
    Page<Course> findAllCourses(Pageable pagable);
    
    /**
     * <pre>
     * Retrive courses data in Paged object
     * </pre>
     * 
     * @param pagable
     * @return
     */
    Paged<Course> findAllCoursesAsPaged(Pageable pagable);
    
    Course findCoursesByName(String name);
    
    Set<Course> findCoursesByCourseSearchFilter(CourseSearchFilter courseSearchFilter);
    
    // Method for finding courses base on SearchFilter object provided
    Page<Course> findCoursesByCourseSearchFilter(CourseSearchFilter courseSearchFilter, Pageable pageable);
    
    /**
     * <pre>
     * Retrieve courses data by filter in Paged object
     * </pre>
     * 
     * @param courseSearchFilter
     * @param pageable
     * @return
     */
    Paged<Course> findCoursesByCourseSearchFilterAsPaged(CourseSearchFilter courseSearchFilter, Pageable pageable);
    
    void createCourse(Course course);
    
    // Method for updating a course
    void updateCourse(Course course);
    
    // Method for checking if course name and id already exists 
    boolean courseNameExists(String name, Long id);
    
    // Method for checking if course name already exists 
    boolean courseNameExists(String name);
    
    // Method for load all course names
    Set<String> loadAllCourseName();

}

package com.fujitsu.ph.tsup.instructorconduct.model;

import java.time.ZonedDateTime;
import java.util.Objects;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: CourseScheduleViewForm.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja     | New Creation
//0.02    | 08/10/2021 | WS) MI.Aguinaldo | Update
//=======================================================

/**
* <pre>
* JavaBean for CourseScheduleViewForm
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

import java.util.Set;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fujitsu.ph.tsup.instructorconduct.domain.CourseSchedule;

public class CourseScheduleViewForm {

    /**
     * Course Schedule Id
     */
    private Long id;

    /**
     * Course Id
     */
    private Long courseId;

    /**
     * Course Name
     */
    private String courseName;

    /**
     * Instructor Id
     */
    private Long instructorId;

    /**
     * Instructor Name(LASTNAME, FIRSTNAME)
     */
    private String instructorName;

    /**
     * Participants
     */
    private int participants;

    /**
     *	Start Date and Time
     */
    @NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private ZonedDateTime scheduledStartDateTime;
	
	/**
     *	End Date and Time
     */
	@NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private ZonedDateTime scheduledEndDateTime;
	
    private Set<CourseForm> courses;
	
    private String status;
    
    private int totalParticipants;
    
    private String venueName;
	
    public CourseScheduleViewForm() {

    }
    
    public CourseScheduleViewForm(CourseSchedule courseSchedule) {
        Objects.requireNonNull(courseSchedule);
        
        this.id = courseSchedule.getId();
        this.courseName = courseSchedule.getCourseName();
        this.instructorName = courseSchedule.getInstructorLastName() + ", " + courseSchedule.getInstructorFirstName();
        this.venueName = courseSchedule.getVenueName();
        this.totalParticipants = courseSchedule.getTotalParticipants();
        this.status = getStatusValue(courseSchedule.getStatus());
        this.scheduledStartDateTime = courseSchedule.getScheduledStartDateTime();
        this.scheduledEndDateTime = courseSchedule.getScheduledEndDateTime();
        
    }
    
    

    public ZonedDateTime getScheduledStartDateTime() {
		return scheduledStartDateTime;
	}
	
	public void setScheduledStartDateTime(ZonedDateTime scheduledStartDateTime) {
		this.scheduledStartDateTime = scheduledStartDateTime;
	}
	
	public ZonedDateTime getScheduledEndDateTime() {
		return scheduledEndDateTime;
	}
	
	public void setScheduledEndDateTime(ZonedDateTime scheduledEndDateTime) {
		this.scheduledEndDateTime = scheduledEndDateTime;
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public int getParticipants() {
        return participants;
    }

    public void setParticipants(int participants) {
        this.participants = participants;
    }
    
    public String getVenueName() {
    	return venueName;
    }
    public void setVenueName(String venueName) {
    	this.venueName = venueName;
    }
    
    public int getTotalParticipants() {
    	return totalParticipants;
    }
    public void setTotalParticipants(int totalParticipants) {
    	this.totalParticipants = totalParticipants;
    }
    
    public String getStatus() {
    	return status;
    }
    public void setStatus(String status) {
    	this.status = status;
    }
    

    public Set<CourseForm> getCourses() {
		return courses;
	}
    
	public void setCourses(Set<CourseForm> courses) {
		this.courses = courses;
	}
	
	public static int sortedByStartDate (CourseScheduleViewForm courseScheduleViewForm, CourseScheduleViewForm courseScheduleViewForm2) {
	    Objects.requireNonNull(courseScheduleViewForm);
	    Objects.requireNonNull(courseScheduleViewForm2);
	    
	    return courseScheduleViewForm.getScheduledStartDateTime().compareTo(courseScheduleViewForm2.getScheduledStartDateTime());
	}
	
	private String getStatusValue(char status) {
	    switch (status) {
            case 'A':
                return "Active";
            case 'O':
                return "Active";
            case 'D':
                return "Done";
            case 'C':
                return "Closed";

            default:
               throw new IllegalStateException("Course Schedule status of "+ status + " not found!");
        }
	}

    @Override
    public String toString() {
        return "CourseScheduleViewForm [id=" + id + ", courseId=" + courseId + ", courseName=" + courseName
                + ", instructorId=" + instructorId + ", instructorName=" + instructorName + ", participants="
                + participants + ", courses=" + courses
                + ", venueName=" + venueName + ", totalParticipants=" + totalParticipants + ", status=" + status 
                + ", scheduledStartDateTime=" + scheduledStartDateTime + ", scheduledEndDateTime=" + scheduledEndDateTime + "]";
    }
}

package com.fujitsu.ph.tsup.tms.model;

import java.util.Date;

public class Employee {
	
	private String employeeID;
	private String employeeName;
	String employeeEmail;
	private Date employeeHiredDate;
	private Date employeeJoinDate;
	private String employeeRole;
	private String employeeOnboardProjectName;
	private String employeeManager;
	private String employeeStatus;
	
	
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeEmail() {
		return employeeEmail;
	}
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	public Date getEmployeeHiredDate() {
		return employeeHiredDate;
	}
	public void setEmployeeHiredDate(Date employeeHiredDate) {
		this.employeeHiredDate = employeeHiredDate;
	}
	public Date getEmployeeJoinDate() {
		return employeeJoinDate;
	}
	public void setEmployeeJoinDate(Date employeeJoinDate) {
		this.employeeJoinDate = employeeJoinDate;
	}
	public String getEmployeeRole() {
		return employeeRole;
	}
	public void setEmployeeRole(String employeeRole) {
		this.employeeRole = employeeRole;
	}
	public String getEmployeeOnboardProjectName() {
		return employeeOnboardProjectName;
	}
	public void setEmployeeOnboardProjectName(String employeeOnboardProjectName) {
		this.employeeOnboardProjectName = employeeOnboardProjectName;
	}
	public String getEmployeeManager() {
		return employeeManager;
	}
	public void setEmployeeManager(String employeeManager) {
		this.employeeManager = employeeManager;
	}
	public String getEmployeeStatus() {
		return employeeStatus;
	}
	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
	public Employee(String employeeID, String employeeName, String employeeEmail, Date employeeHiredDate,
			Date employeeJoinDate, String employeeRole, String employeeOnboardProjectName, String employeeManager,
			String employeeStatus) {
		super();
		this.employeeID = employeeID;
		this.employeeName = employeeName;
		this.employeeEmail = employeeEmail;
		this.employeeHiredDate = employeeHiredDate;
		this.employeeJoinDate = employeeJoinDate;
		this.employeeRole = employeeRole;
		this.employeeOnboardProjectName = employeeOnboardProjectName;
		this.employeeManager = employeeManager;
		this.employeeStatus = employeeStatus;
	}
	public Employee() {
		super();
	}
	
	

}

/**
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.importing.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

// ==================================================================================================
// Project Name : Training Sign Up
// Class Name : SabaDTO.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/08/19 | WS) mi.aguinaldo | Initial Version
// 0.02 | 2021/09/07 | WS) mi.aguinaldo | Update
// ==================================================================================================

public class SabaDTO {
    private String courseTitle;
    private String courseId;
    private String courseCategoryName;
    private Long courseCategoryId;
    private List<TraineeInfo> traineeInfos;

    public SabaDTO() {
    }

    private SabaDTO(Builder builder) {
        this.courseTitle = builder.courseTitle;
        this.courseId = builder.courseId;
        this.courseCategoryName = builder.courseCategoryName;
        this.courseCategoryId = builder.courseCategoryId;
        this.traineeInfos = builder.traineeInfos;
    }

    /**
     * @return the courseTitle
     */
    public String getCourseTitle() {
        return courseTitle;
    }

    /**
     * @param courseTitle the courseTitle to set
     */
    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    /**
     * @return the courseId
     */
    public String getCourseId() {
        return courseId;
    }

    /**
     * @param courseId the courseId to set
     */
    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    /**
     * @return the courseCategoryName
     */
    public String getCourseCategoryName() {
        return courseCategoryName;
    }

    /**
     * @param courseCategoryName the courseCategoryName to set
     */
    public void setCourseCategoryName(String courseCategoryName) {
        this.courseCategoryName = courseCategoryName;
    }

    /**
     * @return the courseCategoryId
     */
    public Long getCourseCategoryId() {
        return courseCategoryId;
    }

    /**
     * @param courseCategoryId the courseCategoryId to set
     */
    public void setCourseCategoryId(Long courseCategoryId) {
        this.courseCategoryId = courseCategoryId;
    }

    /**
     * @return the traineeInfos
     */
    public List<TraineeInfo> getTraineeInfos() {
        return traineeInfos;
    }

    /**
     * @param traineeInfos the traineeInfos to set
     */
    public void setTraineeInfos(List<TraineeInfo> traineeInfos) {
        this.traineeInfos = traineeInfos;
    }

    public void addTraineeInfo(TraineeInfo traineeInfo) {
        if (Objects.isNull(traineeInfos)) {
            traineeInfos = new ArrayList<>();
        }

        if (traineeInfo.isValid()) {
            traineeInfos.add(traineeInfo);
        }

    }

    public void removeTraineeInfo(TraineeInfo traineeInfo) {
        if (Objects.isNull(traineeInfos)) {
            return;
        }

        if (traineeInfo.isValid()) {
            traineeInfos.remove(traineeInfo);
        }

    }

    @Override
    public String toString() {
        return "SabaDTO [courseTitle=" + courseTitle + ", courseId=" + courseId + ", courseCategoryName="
                + courseCategoryName + ", courseCategoryId=" + courseCategoryId + ", traineeInfos="
                + traineeInfos + "]";
    }

    /**
     * Creates builder to build {@link SabaDTO}.
     * 
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link SabaDTO}.
     */
    public static final class Builder {
        private String courseTitle;
        private String courseId;
        private String courseCategoryName;
        private Long courseCategoryId;
        private List<TraineeInfo> traineeInfos = Collections.emptyList();

        private Builder() {
        }

        public Builder withCourseTitle(String courseTitle) {
            this.courseTitle = courseTitle;
            return this;
        }

        public Builder withCourseId(String courseId) {
            this.courseId = courseId;
            return this;
        }

        public Builder withCourseCategoryName(String courseCategoryName) {
            this.courseCategoryName = courseCategoryName;
            return this;
        }

        public Builder withCourseCategoryId(Long courseCategoryId) {
            this.courseCategoryId = courseCategoryId;
            return this;
        }

        public Builder withTraineeInfos(List<TraineeInfo> traineeInfos) {
            this.traineeInfos = traineeInfos;
            return this;
        }

        public SabaDTO build() {
            return new SabaDTO(this);
        }
    }

}

/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.course.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.enrollment.dao.EnrollmentDaoImpl;
import com.fujitsu.ph.tsup.search.CourseSearchFilter;

// ==================================================================================================
// Project Name : Training Sign Up
// System Name : Course Management
// Class Name : CourseManagementDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2020/08/28 | WS) c.lepiten       | Initial Version
//0.02    | 2021/04/20 | WS) i.fajardo       | Updated
//0.03    | 2021/05/10 | WS) D.Escala        | Updated
//0.04    | 2021/05/26 | WS) mi.aguinaldo    | Implemented update course function and update findCoursesByName and findAllCourses
//0.05    | 2021/06/30 | WS) mi.aguinaldo    | Change the findCoursesByName to a optional
//0.06    | 2021/07/16 | WS) mi.aguinaldo    | Updated
//0.07    | 2021/07/21 | WS) M.Taboada       | Updated
//0.08    | 2021/08/05 | WS) mi.aguinaldo    | Updated
//0.09    | 2021/09/07 | WS) mi.aguinaldo    | Updated
//0.10    | 2021/10/07 | WS) r.delacruz      | Updated
//0.10    | 2021/10/13 | WS) l.celoso        | Adding Tags in filter search
//0.11    | 2021/10/27 | WS) l.celoso        | Adding Sorting of course
//==================================================================================================

@Repository
public class CourseManagementDaoImpl implements CourseManagementDao {

    // Call NamedParameterJdbcTemplate
    @Autowired
    private NamedParameterJdbcTemplate template;

    @Autowired
    private EnrollmentDaoImpl enrollmentDaoImpl;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Method for finding Course by Id
     */
    @Override
    public Course findCourseById(Long id) {

        String query = "SELECT * FROM COURSE WHERE ID =" + id;

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("id", id);

        return template.queryForObject(query, sqlParameterSource, new CourseRowMapper());
    }

    /**
     * Method for deleting Course by Id
     */
    @Override
    public void deleteCourseById(Long id) {

        String query = "DELETE FROM COURSE WHERE ID =" + id;

        SqlParameterSource namedParameters = new MapSqlParameterSource("id", id);
        template.update(query, namedParameters);

    }

    @Override
    public Set<Course> findAllCourses() {

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("SELECT C.id, ");
        queryBuilder.append(" C.name, ");
        queryBuilder.append(" C.detail, ");
        queryBuilder.append(" C.course_category_id, ");
        queryBuilder.append(" C.mandatory, ");
        queryBuilder.append(" C.deadline, ");
        queryBuilder.append(" C.department_id, ");
        queryBuilder.append(" C.mandatory_type, ");
        queryBuilder.append(" C.course_code, ");
        queryBuilder.append(" CC.id, ");
        queryBuilder.append(" CC.detail, ");
        queryBuilder.append(" COALESCE(string_agg(MR.role_type, ', '), '') AS role_type ");
        queryBuilder.append("FROM course C ");
        queryBuilder.append("LEFT JOIN course_category CC ");
        queryBuilder.append(" ON C.course_category_id = CC.id ");
        queryBuilder.append("LEFT JOIN COURSE_TAG_MAP CTM ");
        queryBuilder.append(" ON CTM.course_id = C.id ");
        queryBuilder.append("LEFT JOIN MEMBER_ROLE MR ");
        queryBuilder.append(" ON MR.id = CTM.tag_id ");
        queryBuilder.append("GROUP BY ");
        queryBuilder.append(" C.id, ");
        queryBuilder.append(" C.name, ");
        queryBuilder.append(" C.detail, ");
        queryBuilder.append(" C.course_category_id, ");
        queryBuilder.append(" C.mandatory, ");
        queryBuilder.append(" C.deadline, ");
        queryBuilder.append(" C.department_id, ");
        queryBuilder.append(" C.mandatory_type, ");
        queryBuilder.append(" C.course_code, ");
        queryBuilder.append(" CC.id, ");
        queryBuilder.append(" CC.detail ");
        queryBuilder.append("ORDER BY ");
        queryBuilder.append(" C.name ASC ");

        List<Course> courseList = template.query(queryBuilder.toString(), new CourseRowMapper());

        return new LinkedHashSet<>(courseList);
    }

    /**
     * Method for finding courses base on SearchFilter object provided
     */
    @Override
    public Set<Course> findCoursesByCourseSearchFilter(CourseSearchFilter courseSearchFilter,
            Pageable pageable) {

        StringBuilder queryBuilder = new StringBuilder();
        List<String> conditionList = new LinkedList<>();
        boolean withTags = (courseSearchFilter.getMemberRole() != null
                && !courseSearchFilter.getMemberRole().isEmpty());

        queryBuilder.append("SELECT ");
        queryBuilder.append(" C.id, ");
        queryBuilder.append(" C.name, ");
        queryBuilder.append(" C.detail, ");
        queryBuilder.append(" C.mandatory, ");
        queryBuilder.append(" C.deadline, ");
        queryBuilder.append(" C.course_category_id, ");
        queryBuilder.append(" CC.category, ");
        queryBuilder.append(" C.mandatory_type, ");
        queryBuilder.append(" C.department_id, ");
        queryBuilder.append(" D.department_name, ");
        queryBuilder.append(" C.course_code, ");
        queryBuilder.append(" COALESCE(string_agg(MR.role_type, ', '), '') AS role_type ");
        queryBuilder.append("FROM COURSE C ");
        queryBuilder.append("LEFT JOIN course_category CC ");
        queryBuilder.append("ON C.course_category_id = CC.id ");
        queryBuilder.append("INNER JOIN department D ");
        queryBuilder.append("ON C.department_id = D.id ");

        if (withTags) {
            queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM "); // ADD
            queryBuilder.append("ON CTM.course_id = C.id "); // ADD
            queryBuilder.append("INNER JOIN MEMBER_ROLE MR "); // ADD
            queryBuilder.append("ON MR.id = CTM.tag_id "); // ADD

            enrollmentDaoImpl.addTagsToConditionList(conditionList, courseSearchFilter.getMemberRole());
        } else {
            queryBuilder.append("LEFT JOIN COURSE_TAG_MAP CTM "); // ADD
            queryBuilder.append("ON CTM.course_id = C.id "); // ADD
            queryBuilder.append("LEFT JOIN MEMBER_ROLE MR "); // ADD
            queryBuilder.append("ON MR.id = CTM.tag_id "); // ADD
        }

        queryBuilder.append("WHERE ");

        HashMap<String, String> courseSearcHashMap = new HashMap<>();
        courseSearcHashMap.put("C.name", courseSearchFilter.getCourseName());
        courseSearcHashMap.put("CC.category", courseSearchFilter.getCourseCategory());
        courseSearcHashMap.put("C.mandatory", courseSearchFilter.getMandatory());
        courseSearcHashMap.put("C.deadline", courseSearchFilter.getDeadline());
        courseSearcHashMap.put("C.mandatory_type", courseSearchFilter.getMandatoryType());
        courseSearcHashMap.put("D.department_name", courseSearchFilter.getDepartment());

        courseSearcHashMap.entrySet().stream().filter(c -> StringUtils.isNoneBlank(c.getValue()))
                .forEach(entry -> enrollmentDaoImpl.addToConditionList(conditionList, entry.getKey(),
                        entry.getValue()));

        queryBuilder.append(conditionList.stream().collect(Collectors.joining()));
        queryBuilder.append("GROUP BY ");
        queryBuilder.append(" C.id, ");
        queryBuilder.append(" C.name, ");
        queryBuilder.append(" C.detail, ");
        queryBuilder.append(" C.mandatory, ");
        queryBuilder.append(" C.deadline, ");
        queryBuilder.append(" C.course_category_id, ");
        queryBuilder.append(" CC.category, ");
        queryBuilder.append(" C.mandatory_type, ");
        queryBuilder.append(" C.department_id, ");
        queryBuilder.append(" D.department_name, ");
        queryBuilder.append(" C.course_code ");

        if (Objects.nonNull(pageable)) {
            Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                    : Order.asc("CC.category");
            String orderProperty = getCourseOrder(order);

            queryBuilder.append("ORDER BY " + orderProperty + " " + order.getDirection() + " ");
            queryBuilder.append("LIMIT " + pageable.getPageSize() + " ");
            queryBuilder.append("OFFSET " + pageable.getOffset() + " ");
        }

        List<Course> courseList = template.query(queryBuilder.toString(), new CourseRowMapper());

        return new LinkedHashSet<>(courseList);
    }

    @Override
    public Set<Course> findAllCourses(Pageable pageable) {

        Order order = !pageable.getSort().isEmpty() ? pageable.getSort().toList().get(0)
                : Order.asc("CC.category");
        String orderProperty = getCourseOrder(order);

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("SELECT C.id, ");
        queryBuilder.append(" C.name, ");
        queryBuilder.append(" C.detail, ");
        queryBuilder.append(" C.course_category_id, ");
        queryBuilder.append(" C.mandatory, ");
        queryBuilder.append(" C.deadline, ");
        queryBuilder.append(" C.department_id, ");
        queryBuilder.append(" C.mandatory_type, ");
        queryBuilder.append(" C.course_code, ");
        queryBuilder.append(" CC.id, ");
        queryBuilder.append(" CC.category, ");
        queryBuilder.append(" CC.detail, ");
        queryBuilder.append(" D.id, ");
        queryBuilder.append(" D.department_name, ");
        queryBuilder.append(" COALESCE(string_agg(MR.role_type, ', '), '') AS role_type ");
        queryBuilder.append("FROM COURSE C ");
        queryBuilder.append("INNER JOIN course_category CC ");
        queryBuilder.append(" ON C.course_category_id = CC.id ");
        queryBuilder.append("INNER JOIN department D ");
        queryBuilder.append(" ON C.department_id = D.id ");
        queryBuilder.append("LEFT JOIN COURSE_TAG_MAP CTM ");
        queryBuilder.append(" ON CTM.course_id = C.id ");
        queryBuilder.append("LEFT JOIN MEMBER_ROLE MR ");
        queryBuilder.append(" ON MR.id = CTM.tag_id ");
        queryBuilder.append("GROUP BY ");
        queryBuilder.append(" C.id, ");
        queryBuilder.append(" C.name, ");
        queryBuilder.append(" C.detail, ");
        queryBuilder.append(" C.course_category_id, ");
        queryBuilder.append(" C.mandatory, ");
        queryBuilder.append(" C.deadline, ");
        queryBuilder.append(" C.department_id, ");
        queryBuilder.append(" C.mandatory_type, ");
        queryBuilder.append(" C.course_code, ");
        queryBuilder.append(" CC.id, ");
        queryBuilder.append(" CC.category, ");
        queryBuilder.append(" CC.detail, ");
        queryBuilder.append(" D.id, ");
        queryBuilder.append(" D.department_name ");
        queryBuilder.append("ORDER BY " + orderProperty + " " + order.getDirection() + " ");
        queryBuilder.append("LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset());

        List<Course> courseList = template.query(queryBuilder.toString(), new CourseRowMapper());
        return courseList.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(courseList);
    }

    @Override
    public int countCourse() {
        try {
            return jdbcTemplate.queryForObject("SELECT count(*) FROM course", Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    @Override
    public Set<String> loadAllCourseName() {
        List<String> courseNames = jdbcTemplate.query("SELECT name FROM course",
                new SingleColumnRowMapper<>(String.class));

        return courseNames.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(courseNames);
    }

    /**
     * Method for counting course base on SearchFilter object provided
     */
    @Override
    public int countFoundCourse(CourseSearchFilter courseSearchFilter) {

        try {
            StringBuilder queryBuilder = new StringBuilder();
            List<String> conditionList = new LinkedList<>();

            queryBuilder.append("SELECT COUNT(DISTINCT(C.id)) ");
            queryBuilder.append("FROM COURSE C ");
            queryBuilder.append("INNER JOIN course_category CC ");
            queryBuilder.append("ON C.course_category_id = CC.id ");
            queryBuilder.append("INNER JOIN department D ");
            queryBuilder.append("ON C.department_id = D.id ");

            if (courseSearchFilter.getMemberRole() != null && !courseSearchFilter.getMemberRole().isEmpty()) {
                queryBuilder.append("INNER JOIN COURSE_TAG_MAP CTM "); // ADD
                queryBuilder.append("ON CTM.course_id = C.id "); // ADD
                queryBuilder.append("INNER JOIN MEMBER_ROLE MR "); // ADD
                queryBuilder.append("ON MR.id = CTM.tag_id "); // ADD

                enrollmentDaoImpl.addTagsToConditionList(conditionList, courseSearchFilter.getMemberRole());
            } else {
                queryBuilder.append("LEFT JOIN COURSE_TAG_MAP CTM "); // ADD
                queryBuilder.append("ON CTM.course_id = C.id "); // ADD
                queryBuilder.append("LEFT JOIN MEMBER_ROLE MR "); // ADD
                queryBuilder.append("ON MR.id = CTM.tag_id "); // ADD
            }

            queryBuilder.append("WHERE ");

            HashMap<String, String> courseSearcHashMap = new HashMap<>();
            courseSearcHashMap.put("C.name", courseSearchFilter.getCourseName());
            courseSearcHashMap.put("CC.category", courseSearchFilter.getCourseCategory());
            courseSearcHashMap.put("C.mandatory", courseSearchFilter.getMandatory());
            courseSearcHashMap.put("C.deadline", courseSearchFilter.getDeadline());
            courseSearcHashMap.put("C.mandatory_type", courseSearchFilter.getMandatoryType());
            courseSearcHashMap.put("D.department_name", courseSearchFilter.getDepartment());

            courseSearcHashMap.entrySet().stream().filter(c -> StringUtils.isNoneBlank(c.getValue()))
                    .forEach(entry -> enrollmentDaoImpl.addToConditionList(conditionList, entry.getKey(),
                            entry.getValue()));

            queryBuilder.append(conditionList.stream().collect(Collectors.joining()));

            return jdbcTemplate.queryForObject(queryBuilder.toString(), Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    @Override
    public Optional<Course> findCoursesByName(String name) {

        String query = "SELECT * " + "FROM course " + "WHERE LOWER(name) = LOWER('" + name + "')";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("name", name);

        try {
            Course course = template.queryForObject(query, sqlParameterSource, new CourseRowMapper());
            return Optional.of(course);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }

    }

    @Override
    public void createCourse(Course course) {
        try {
            KeyHolder generatedKeyHolder = new GeneratedKeyHolder();
            String query = "INSERT INTO course"
                    + " (name, detail,mandatory,deadline,course_category_id,mandatory_type,department_id)"
                    + " VALUES(:name, :detail, :mandatory, :deadline,:course_category_id,:mandatory_type,:department_id)";

            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("name", course.getName()).addValue("detail", course.getDetail())
                    .addValue("mandatory", course.getIsMandatory()).addValue("deadline", course.getDeadline())
                    .addValue("course_category_id", course.getCourseCategoryId())
                    .addValue("mandatory_type", course.getMandatoryType())
                    .addValue("department_id", course.getDepartmentId());

            template.update(query, sqlParameterSource, generatedKeyHolder);
            Long key = (Long) generatedKeyHolder.getKeys().get("id");

            if (!course.getMemberRole().isEmpty()) {
                StringBuilder createTagsQuery = new StringBuilder();
                createTagsQuery.append("INSERT INTO COURSE_TAG_MAP (course_id, tag_id) ");
                createTagsQuery.append(addTagsValuesForUpdate(key, course.getMemberRole()));
                template.update(createTagsQuery.toString(), sqlParameterSource);
            }
        } catch (NullPointerException e) {
            throw new NullPointerException("Error in creating course");
        }
    }

    /**
     * Find if course name is already existing Author: WS)I.Fajardo
     * 
     * @param name Course name
     * @param id Course id
     * @return course
     */
    @Override
    public Set<Course> findIfCourseNameExists(String name, Long id) {
        String query = "SELECT * FROM COURSE WHERE LOWER(name) LIKE LOWER('" + name + "') AND id NOT IN ("
                + id + ")";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("name", name);
        List<Course> courseList = template.query(query, sqlParameterSource, new CourseRowMapper());

        return new LinkedHashSet<>(courseList);
    }

    /**
     * Load all course Author: WS)I.Fajardo
     * 
     * @return courses
     */
    @Override
    public Set<Course> loadAllCourse() {
        String query = "SELECT * FROM COURSE";

        List<Course> courseList = template.query(query, new CourseRowMapper());

        return new LinkedHashSet<>(courseList);
    }

    @Override
    public void updateCourse(Course course) {

        // Updating Course Information
        StringBuilder updateCourseQuery = new StringBuilder();
        updateCourseQuery.append("INSERT INTO course");
        updateCourseQuery.append(
                " (id,name, detail,mandatory,deadline,course_category_id,mandatory_type,department_id)");
        updateCourseQuery.append(
                " VALUES(:id, :name, :detail, :mandatory, :deadline,:course_category_id,:mandatory_type,:department_id)");
        updateCourseQuery.append(" ON CONFLICT (id)");
        updateCourseQuery.append(" DO UPDATE");
        updateCourseQuery.append(" SET name = EXCLUDED.name, detail = EXCLUDED.detail,");
        updateCourseQuery.append(" mandatory = EXCLUDED.mandatory, deadline = EXCLUDED.deadline,");
        updateCourseQuery.append(" course_category_id = EXCLUDED.course_category_id,");
        updateCourseQuery.append(" department_id = EXCLUDED.department_id,");
        updateCourseQuery.append(" mandatory_type = EXCLUDED.mandatory_type");

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("id", course.getId())
                .addValue("name", course.getName()).addValue("detail", course.getDetail())
                .addValue("mandatory", course.getIsMandatory()).addValue("deadline", course.getDeadline())
                .addValue("course_category_id", course.getCourseCategoryId())
                .addValue("mandatory_type", course.getMandatoryType())
                .addValue("department_id", course.getDepartmentId());

        template.update(updateCourseQuery.toString(), sqlParameterSource);

        // Updating Course Tags
        StringBuilder updateTagsQuery = new StringBuilder();
        updateTagsQuery.append("DELETE FROM COURSE_TAG_MAP WHERE COURSE_ID = :id");

        template.update(updateTagsQuery.toString(), sqlParameterSource);

        if (!course.getMemberRole().isEmpty()) {
            updateTagsQuery = new StringBuilder();
            updateTagsQuery.append("INSERT INTO COURSE_TAG_MAP (course_id, tag_id) ");
            updateTagsQuery.append(addTagsValuesForUpdate(course.getId(), course.getMemberRole()));
            template.update(updateTagsQuery.toString(), sqlParameterSource);
        }
    }

    /**
     * Method for finding courses base on list of course names
     */
    @Override
    public Set<Course> findCourseByCourseNames(List<String> courseNames) {
        SqlParameterSource parameters = new MapSqlParameterSource("courseNames", courseNames);

        List<Course> courseList = template.query("SELECT * FROM course WHERE name IN (:courseNames)",
                parameters, new CourseRowMapper());

        return courseList.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(courseList);
    }

    /**
     * Method for batch creating courses
     */
    @Override
    public int[] batchCourseCodeUpdate(List<Course> courses) {
        return jdbcTemplate.batchUpdate("UPDATE course SET course_code = ? WHERE id = ?",
                new BatchPreparedStatementSetter() {

                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        ps.setString(1, courses.get(i).getCourseCode());
                        ps.setLong(2, courses.get(i).getId());
                    }

                    public int getBatchSize() {
                        return courses.size();
                    }

                });
    }

    /**
     * Method for batch creating courses
     */
    @Transactional
    @Override
    public int[] batchCreateCourse(List<Course> courses) {
        String query = "INSERT INTO course"
                + " (name, detail,mandatory,deadline,course_category_id,mandatory_type,department_id,course_code)"
                + " VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        return jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {

            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setString(1, courses.get(i).getName());
                ps.setString(2, courses.get(i).getDetail());
                ps.setString(3, courses.get(i).getIsMandatory());
                ps.setString(4, courses.get(i).getDeadline());
                ps.setLong(5, courses.get(i).getCourseCategoryId());
                ps.setString(6, courses.get(i).getMandatoryType());
                ps.setLong(7, courses.get(i).getDepartmentId());
                ps.setString(8, courses.get(i).getCourseCode());
            }

            public int getBatchSize() {
                return courses.size();
            }

        });
    }

    /**
     * @param order
     * @return
     */
    private String getCourseOrder(Order order) {

        switch (order.getProperty()) {
            case "courseName":
                return "C.name";

            case "courseCategory":
                return "CC.category";

            case "mandatory":
                return "C.mandatory";

            case "deadline":
                return "C.deadline";

            case "mandatoryType":
                return "C.mandatory_type";

            case "department":
                return "D.department_name";

            default:
                return "CC.category";
        }
    }

    private String addTagsValuesForUpdate(Long courseId, String tags) {

        String[] tagsArray = tags.split(",");
        StringBuilder tagsValues = new StringBuilder();

        for (String tag : tagsArray) {
            if (tagsValues.length() != 0) {
                tagsValues.append(" , LOWER('" + tag + "')");
            } else {
                tagsValues.append("SELECT " + courseId + ", id");
                tagsValues.append(" FROM MEMBER_ROLE ");
                tagsValues.append(" WHERE LOWER(role_type) IN ( LOWER('" + tag + "')");
            }
        }

        tagsValues.append(" )");

        return tagsValues.toString();
    }
}

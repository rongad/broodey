/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.dao;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : SurveyResponse.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.springframework.jdbc.core.RowMapper;


public class SurveyResponseRowMapper implements RowMapper<SurveyResponse> {

    @Override
    public SurveyResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
        Long id = rs.getLong("id");
        String courseTitle = rs.getString("courseTitle");
        String instructorName = rs.getString("instructorName");
        ZonedDateTime courseDateTime = ZonedDateTime.ofInstant(rs.getTimestamp("courseDateTime").toInstant(),
                                                               ZoneId.systemDefault());

        Integer mdQuestion1 = rs.getInt("mdQuestion1");
        Integer mdQuestion2 = rs.getInt("mdQuestion2");
        Integer mdQuestion3 = rs.getInt("mdQuestion3");
        Integer mdQuestion4 = rs.getInt("mdQuestion4");

        int matQuestion1 = rs.getInt("matQuestion1");
        int matQuestion2 = rs.getInt("matQuestion2");
        int matQuestion3 = rs.getInt("matQuestion3");
        int matQuestion4 = rs.getInt("matQuestion4");

        int insQuestion1 = rs.getInt("insQuestion1");
        int insQuestion2 = rs.getInt("insQuestion2");
        int insQuestion3 = rs.getInt("insQuestion3");
        int insQuestion4 = rs.getInt("insQuestion4");
        int insQuestion5 = rs.getInt("insQuestion5");
        int insQuestion6 = rs.getInt("insQuestion6");

        int eqFaQuestion1 = rs.getInt("eqFaQuestion1");
        int eqFaQuestion2 = rs.getInt("eqFaQuestion2");
        int eqFaQuestion3 = rs.getInt("eqFaQuestion3");

        String commentsE = rs.getString("commentsE");
        String commentsF = rs.getString("commentsF");
        String commentsG = rs.getString("commentsG");


        ModuleDesignResponse moduleDesignResponseRatings = ModuleDesignResponse.builder()
                                                                               .withQuestion1Ratings(mdQuestion1)
                                                                               .withQuestion2Ratings(mdQuestion2)
                                                                               .withQuestion3Ratings(mdQuestion3)
                                                                               .withQuestion4Ratings(mdQuestion4)
                                                                               .build();
        
        MaterialsResponse materialsResponse = MaterialsResponse.builder()
                                                               .withQuestion1Ratings(matQuestion1)
                                                               .withQuestion2Ratings(matQuestion2)
                                                               .withQuestion3Ratings(matQuestion3)
                                                               .withQuestion4Ratings(matQuestion4)
                                                               .build();
        
        InstructionResponse instructionResponse = InstructionResponse.builder()
                                                                     .withQuestion1Ratings(insQuestion1)
                                                                     .withQuestion2Ratings(insQuestion2)
                                                                     .withQuestion3Ratings(insQuestion3)
                                                                     .withQuestion4Ratings(insQuestion4)
                                                                     .withQuestion5Ratings(insQuestion5)
                                                                     .withQuestion6Ratings(insQuestion6)
                                                                     .build();
        
        EquipmentAndFacilitiesResponse equipmentAndFacilitiesResponse = 
                EquipmentAndFacilitiesResponse.builder()
                                              .withQuestion1Ratings(eqFaQuestion1)
                                              .withQuestion2Ratings(eqFaQuestion2)
                                              .withQuestion3Ratings(eqFaQuestion3)
                                              .build();
        
        


        return SurveyResponse.builder()
                             .withModuleDesignResponseRatings(moduleDesignResponseRatings)
                             .withMaterialsResponse(materialsResponse)
                             .withInstructionResponse(instructionResponse)
                             .withEquipmentAndFacilitiesResponse(equipmentAndFacilitiesResponse)
                             .withId(id)
                             .withInstructorName(instructorName)
                             .withCourseTitle(courseTitle)
                             .withCourseDateTime(courseDateTime)
                             .withCommentsE(commentsE)
                             .withCommentsF(commentsF)
                             .withCommentsG(commentsG)
                             .build();
    }

}

/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.pagination;

/**
 * This is a test class for XXXXXXXX.java
 *
 * @version 0.1
 * @author mi.aguinaldo
 */
public class PageItem {
    
    private PageItemType pageItemType;

    private int index;

    private boolean active;

    private PageItem(Builder builder) {
        this.pageItemType = builder.pageItemType;
        this.index = builder.index;
        this.active = builder.active;
    }

    /**
     * @return the pageItemType
     */
    public PageItemType getPageItemType() {
        return pageItemType;
    }

    /**
     * @param pageItemType the pageItemType to set
     */
    public void setPageItemType(PageItemType pageItemType) {
        this.pageItemType = pageItemType;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * @return the active
     */
    public boolean isActive() {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * Creates builder to build {@link PageItem}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link PageItem}.
     */
    public static final class Builder {
        private PageItemType pageItemType;
        private int index;
        private boolean active;

        private Builder() {
        }

        public Builder withPageItemType(PageItemType pageItemType) {
            this.pageItemType = pageItemType;
            return this;
        }

        public Builder withIndex(int index) {
            this.index = index;
            return this;
        }

        public Builder withActive(boolean active) {
            this.active = active;
            return this;
        }

        public PageItem build() {
            return new PageItem(this);
        }
    }

    
    
}

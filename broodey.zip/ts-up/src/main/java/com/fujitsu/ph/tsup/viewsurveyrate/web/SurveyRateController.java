package com.fujitsu.ph.tsup.viewsurveyrate.web;
// =======================================================
// Project Name: Training Sign Up
// Class Name: SurveyRateController
//
// <<Modification History>>
// Version | Date       | Updated by       | Content
// --------+------------+------------------+---------------
// 0.01    | 2021/08/16 | WS) E.Juan       | Creation
// 0.02    | 2021/08/23 | WS) JD.Dominguez | Change the process of displaying the data, and calculation
// 0.03    | 2021/08/24 | WS) E.Juan       | Add the lacking data and calculation
// 0.04    | 2021/10/08 | WS) MI.Aguinaldo | Update the controller reduce complexity of viewSurveyRate
// 0.05    | 2021/10/08 | WS) M.Yanoyan    | Added attributes to retrieve course information
// 0.06    | 2021/10/08 | WS) L.Celoso     | Added export functionality
// ======================================================



import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fujitsu.ph.tsup.attendance.service.AttendanceService;
import com.fujitsu.ph.tsup.viewsurveyrate.dao.SurveyResponse;
import com.fujitsu.ph.tsup.viewsurveyrate.model.EquipmentAndFacilitiesResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.InstructionResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.MaterialsResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.ModuleDesignResponseForm;
import com.fujitsu.ph.tsup.viewsurveyrate.model.SurveyRateDetails;
import com.fujitsu.ph.tsup.viewsurveyrate.model.SurveyRateList;
import com.fujitsu.ph.tsup.viewsurveyrate.service.SurveyRateService;

@Controller
@RequestMapping("/survey")
public class SurveyRateController implements ServletContextAware {

    @Autowired
    private SurveyRateService surveyRateService;

    /*
     * <pre> It is the interface of attendance service
     * 
     * <pre>
     */
    @Autowired
    private AttendanceService attendanceService;
    
    /*
     * <pre> It is the interface of ServletContext <pre>
     */
    @Autowired
    private ServletContext contextServlet;

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.contextServlet = servletContext;

    }
    
    /**
     * Passes the data to viewSurveyRateForm when view button is pressed
     * 
     * @param courseName, instructorName, courseDateTime
     * @param model
     * @return List
     */

    @PostMapping("/viewSurveyRate")
    public String viewSurveyRate(@ModelAttribute("listSurveyRateDetails") SurveyRateDetails surveyRate,
            Model model, RedirectAttributes redirectAttributes) {

        String courseName = surveyRate.getCourseTitle();
        String instructorName = surveyRate.getInstructorName();
        ZonedDateTime courseDateTime = surveyRate.getCourseDateTime();
        String courseScheduleId = surveyRate.getCourseScheduleId();
 
        Set<SurveyResponse> surveyResponses = surveyRateService.findSurveyResponses(Long.parseLong(courseScheduleId));

        if (surveyResponses == null || surveyResponses.isEmpty() ) {
            redirectAttributes.addFlashAttribute("noRecords", 1);
            return "redirect:/surveysRates/load#noRecords";
        } else {
            SurveyRateList surveyList = new SurveyRateList();

            ModuleDesignResponseForm moduleDesignResponseForm = surveyRateService.tallyModuleDesignResponse(surveyResponses);
            MaterialsResponseForm materialsResponseForm = surveyRateService.tallyMaterialsResponse(surveyResponses);
            InstructionResponseForm instructionResponseForm = surveyRateService.tallyInstructionResponse(surveyResponses);
            EquipmentAndFacilitiesResponseForm equipmentAndFacilitiesResponseForm = surveyRateService.tallyEquipmentAndFacilitiesResponse(surveyResponses);
            
            surveyList.setModuleDesignResponseForm(moduleDesignResponseForm);
            surveyList.setMaterialsResponseForm(materialsResponseForm);
            surveyList.setInstructionResponseForm(instructionResponseForm);
            surveyList.setEquipmentAndFacilitiesResponseForm(equipmentAndFacilitiesResponseForm);
            
            double oaAv = (moduleDesignResponseForm.getAverage() + materialsResponseForm.getAverage() + instructionResponseForm.getAverage() + equipmentAndFacilitiesResponseForm.getAverage()) / 4;
            surveyList.setOaAverage(oaAv);
            
            model.addAttribute("surveyList", surveyList);
            model.addAttribute("listSurveyRate", surveyResponses);
            model.addAttribute("courseName", courseName);
            model.addAttribute("courseDate", DateTimeFormatter.ofPattern("E, dd MMM yyyy HH:mm z").format(courseDateTime));
            model.addAttribute("instructorName", instructorName);
            model.addAttribute("courseScheduleId", courseScheduleId);
            return "survey/viewSurveyRateForm";
        }
    }
    
    /**
     * <pre>
     * As an PMO, I can generate a pdf file of all the absent or the one who didn't attend the training. URL
     * Value =/generate/{courseScheduleDetailId}/absent/createPDF
     * 
     * <pre>
     * 
     * @param id
     * @param request
     * @param response
     * @param @PathVariable("courseScheduleDetailId")
     * @return
     * @author jo.dominguez
     */
    @GetMapping("/viewSurveyRate/export")
    public void createPdfSurvey(HttpServletRequest request, HttpServletResponse response, 
            @ModelAttribute("surveyForm") SurveyRateDetails surveyRate) {

        String courseScheduleId = surveyRate.getCourseScheduleId();
        
        try {
         
            Set<SurveyResponse> surveyResponses = surveyRateService.findSurveyResponses(Long.parseLong(courseScheduleId));
            
            if (surveyResponses != null ) {
                SurveyResponse courseInfo = surveyResponses.iterator().next();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                String courseName = courseInfo.getCourseTitle().replaceAll("[^a-zA-Z0-9]", " ");
                String instructorName = courseInfo.getInstructorName().replaceAll("[^a-zA-Z0-9]", " ");
                String courseSchedule = courseInfo.getCourseDateTime().format(formatter);
                
                boolean isFlag = surveyRateService.createPdf(surveyResponses, contextServlet);
                
                if (isFlag) {
                    String fullPath = request.getServletContext()
                            .getRealPath("/resource/reports/export.pdf");
                    attendanceService.fileDownload(fullPath, response, contextServlet,
                            "Survey_" + courseName + "_" + instructorName  + "_" + courseSchedule + ".pdf");
                }
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

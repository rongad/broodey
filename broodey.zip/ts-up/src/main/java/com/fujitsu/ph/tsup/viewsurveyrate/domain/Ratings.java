/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.domain;
//==================================================================================================
//Project Name : Training Sign Up
//Class Name : Ratings.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================


public enum Ratings {
    TOTALY_DISAGREE(1), 
    DISAGREE(2),
    AGREE(3),
    TOTALY_AGREE(4),
    NON_APPLICABLE(5);
    
    int value;

    Ratings(int value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public int value() {
        return value;
    }
    
    public static Ratings fromValue(int value) {
        for (Ratings type : values()) {
            if (type.value() == value) {
                return type;
            }
        }
        return null;
    }
    
    
    
}

package com.fujitsu.ph.tsup.attendance.model;

import java.time.format.DateTimeFormatter;

import com.fujitsu.ph.tsup.attendance.domain.CourseSchedule;
import com.fujitsu.ph.tsup.attendance.domain.CourseScheduleDetail;

// ==================================================================================================
// $Id:PR03$
// Project Name :Training Sign up
// System Name :Attendance process
// Class Name :ScheduleDetail.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+----------------------------------------+-----------------------------------
// 0.01 | 06/25/2020 | WS) K.Abad | New Creation
// 0.02 | 08/26/2020 | WS) K.Abad WS) J.Iwarat WS) R.Ramos | Update
// 0.02 | 08/17/2021 | WS) DW.Cardenas | Update
// 0.03 | 09/16/2021 | WS) DW.cardenas | Change class name from GenerateAttendanceCourse to ScheduleDetail for reusability
// ==================================================================================================
/**
 * <pre>
 * JavaBean for GenerateAttendanceCourse In this Class,Instances or fields of the List of the data for the
 * initial setting of the data base
 * 
 * <pre>
 * 
 * @version 0.02
 * @author k.abad
 * @author j.iwarat
 * @author r.ramos
 * @author dw.cardenas
 */
public class ScheduleDetail {
    /**
     * Course Schedule Detail Id
     */
    private Long id;

    /**
     * Training Period
     */
    private String trainingPeriod;
    
    /**
     * WORKAROUND FOR PRIO TASK (needed for change attendance status in instructor)
     * old Course Name format (Course Name | date --- date)
     */
    private String courseName;

    /**
     * Default constructor
     */
    public ScheduleDetail() {
    }

    /**
     * Constructor from given course schedule
     *
     * @param courseSched
     */
    public ScheduleDetail(CourseSchedule courseSched) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a");
        for (CourseScheduleDetail detail : courseSched.getCourseScheduleDetail()) {
            this.id = detail.getId();
            this.trainingPeriod = String.format("%s - %s",
                    detail.getScheduledStartDateTime().format(formatter),
                    detail.getScheduledEndDateTime().format(formatter));
        }
    }
    
    /**
     * (WORK AROUND FOR PRIO TASK)
     * Constructor for details with course name and course sched.
     * 
     * @param courseName
     * @param courseSched
     */
    public ScheduleDetail(String courseName, CourseSchedule courseSched) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a");
        DateTimeFormatter workaroundFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd - hh:mma");
        for (CourseScheduleDetail detail : courseSched.getCourseScheduleDetail()) {
            this.id = detail.getId();
            this.trainingPeriod = String.format("%s - %s",
                    detail.getScheduledStartDateTime().format(formatter),
                    detail.getScheduledEndDateTime().format(formatter));
            this.courseName = String.format("%s | %s --- %s", courseName,
                    detail.getScheduledStartDateTime().format(workaroundFormatter),
                    detail.getScheduledEndDateTime().format(workaroundFormatter));
        }
    }

    /**
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return
     */
    public String getTrainingPeriod() {
        return trainingPeriod;
    }

    /**
     * @param courseName
     */
    public void setTrainingPeriod(String trainingPeriod) {
        this.trainingPeriod = trainingPeriod;
    }

    @Override
    public String toString() {
        return "GenerateAttendanceCourse [id=" + id + ", trainingPeriod=" + trainingPeriod + "]";
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}

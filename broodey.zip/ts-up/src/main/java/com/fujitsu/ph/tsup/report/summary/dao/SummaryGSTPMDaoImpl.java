/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Summary of JDU Standardization Training for PM
//Class Name   : SummaryGSTPMDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/04/20 | WS) d.escala          | Initial Version
//0.02    | 2021/04/23 | WS) d.escala          | Updated
//0.03    | 2021/04/27 | WS) d.escala          | Updated
//0.04    | 2021/04/28 | WS) d.escala          | Updated
//0.05    | 2021/04/29 | WS) r.naval           | Updated
//0.06    | 2021/10/15 | WS) r.buot            | Updated
//0.06    | 2021/10/21 | WS) dw.cardenas       | Updated
//==================================================================================================

/**
 * <pre>
 * The controller for the SummaryGSTPMDaoImpl
 * 
 * <pre>
 * 
 * @version 0.04
 * @author d.escala
 */

@Repository
public class SummaryGSTPMDaoImpl implements SummaryGSTPMDao {

    @Autowired
    private NamedParameterJdbcTemplate template;

    @Override
    public int getDeptId() {
        try {
            String query = "SELECT id FROM tsup.DEPARTMENT WHERE department_name =:department_name";
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("department_name",
                    "FDC-G3CC");
            return template.queryForObject(query, sqlParameterSource, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    @Override
    public List<Integer> getEmployeeRoleId() {
        String query = "SELECT id FROM tsup.MEMBER_ROLE WHERE role_type =:rolePM or role_type = :roleTL";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                .addValue("rolePM", "PM")
                .addValue("roleTL", "TL");
        return template.queryForList(query, sqlParameterSource, Integer.class);
    }

    @Override
    public int getCatId() {
        try {
            String query = "SELECT id FROM tsup.COURSE_CATEGORY WHERE category = :category";
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("category", "JDU Standardization Training");
            return template.queryForObject(query, sqlParameterSource, Integer.class);
        } catch (NullPointerException e) {
            return 0;
        }
    }

    @Override
    public List<Integer> gstCourses(int catId) {
        String query = "SELECT id FROM tsup.COURSE WHERE course_category_id = :category_id";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("category_id", catId);

        return template.queryForList(query, sqlParameterSource, Integer.class);
    }

    @Override
    public Long countTotalNumberOfJDUPM(int deptId, List<Integer> roleID) {
        try {
            String query = "SELECT Count (*) FROM tsup.EMPLOYEE WHERE DEPARTMENT_ID = :deptId"
                    + " and member_role_id in (:roleId)";
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("deptId", deptId)
                    .addValue("roleId", roleID);
            return template.queryForObject(query, sqlParameterSource, Long.class);
        } catch (NullPointerException e) {
            return 0L;
        }
    }

    @Override
    public Long countTotalNumberJDUPMFinished(List<Integer> gstCourses, int deptId, List<Integer> roleID,
            ZonedDateTime reportDate) {
        try {
            String query = "SELECT Count (DISTINCT e.id)"
                    + " FROM tsup.employee as e"
                    + " INNER JOIN tsup.course_attendance as ca ON e.id = ca.participant_id"
                    + " INNER JOIN tsup.course_schedule_detail as csd ON ca.course_schedule_detail_id = csd.id"
                    + " INNER JOIN tsup.course_schedule as cs ON csd.course_schedule_id = cs.id"
                    + " INNER JOIN tsup.course as c ON cs.course_id = c.id"
                    + " WHERE c.id in (:courses)"
                    + " AND e.department_id = :deptId"
                    + " AND e.member_role_id in (:roleId)"
                    + " AND cs.status ='D'"
                    + " AND ca.log_out_dateTime <= :reportDate;";
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("deptId", deptId)
                    .addValue("courses", gstCourses).addValue("roleId", roleID)
                    .addValue("reportDate", reportDate.toOffsetDateTime());
            return template.queryForObject(query, sqlParameterSource, Long.class);
        } catch (NullPointerException e) {
            return 0L;
        }
    }

    @Override
    public Long countTotalNumberJDUPMFinishedLW(ZonedDateTime reportDate, List<Integer> gstCourses, int deptId,
            List<Integer> roleId) {
        try {
            String query = "SELECT Count (DISTINCT e.id)"
                    + " FROM tsup.employee as e"
                    + " INNER JOIN tsup.course_attendance as ca ON e.id = ca.participant_id"
                    + " INNER JOIN tsup.course_schedule_detail as csd ON ca.course_schedule_detail_id = csd.id"
                    + " INNER JOIN tsup.course_schedule as cs ON csd.course_schedule_id = cs.id"
                    + " INNER JOIN tsup.course as c ON cs.course_id = c.id"
                    + " WHERE c.id in (:courses)"
                    + " AND e.department_id = :deptId"
                    + " AND e.member_role_id in (:roleId)"
                    + " AND cs.status ='D'"
                    + " AND ca.status = 'P'"
                    + " AND (ca.log_out_dateTime <= date_trunc('week', :reportDate - interval '1 week'));";
            SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
                    .addValue("deptId", deptId)
                    .addValue("courses", gstCourses).addValue("roleId", roleId)
                    .addValue("reportDate", reportDate.toOffsetDateTime());
            return template.queryForObject(query, sqlParameterSource, Long.class);
        } catch (NullPointerException e) {
            return 0L;
        }
    }

}

package com.fujitsu.ph.tsup.survey.dao;

import com.fujitsu.ph.tsup.survey.domain.Survey;

//==================================================================================================
//$Id:PR16$
//Project Name :Training Sign Up
//System Name  :Survey Form Process
//Class Name   :SurveyFormDao.java
//
//<<Modification History>>
//Version | Date       | Updated By                                  | Content
//--------+------------+---------------------------------------------+-------------------------------
//0.01    | 08/12/2021 |  WS) M.Berja                                | New Creation
//==================================================================================================
/**
 * <pre>
* The data access interface for survey form related database access
 * 
 * </pre>
 * 
 * @version 0.01
 * @author m.berja
 */

public interface SurveyFormDao {

	/**
	 * Creates survey form
	 * 
	 * @param surveyForm
	 */
	void createSurvey(Survey surveyForm);

}
/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.model;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : EquipmentAndFacilitiesResponseForm.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

import java.util.Objects;

public class EquipmentAndFacilitiesResponseForm {
    private int question1TotallyDisagree;
    private int question1Disagree;
    private int question1Agree;
    private int question1TotallyAgree;
    private int question1NotApplicable;
    
    private int question2TotallyDisagree;
    private int question2Disagree;
    private int question2Agree;
    private int question2TotallyAgree;
    private int question2NotApplicable;
    
    
    private int question3TotallyDisagree;
    private int question3Disagree;
    private int question3Agree;
    private int question3TotallyAgree;
    private int question3NotApplicable;
    
    private double question1Ratings;
    private double question2Ratings;
    private double question3Ratings;
    
    private double average;


    public EquipmentAndFacilitiesResponseForm() {
    }
    
    public static EquipmentAndFacilitiesResponseForm ofResponseResults (ResponseResult question1, ResponseResult question2, ResponseResult question3) {
        Objects.requireNonNull(question1);
        Objects.requireNonNull(question2);
        Objects.requireNonNull(question3);
        
        return new EquipmentAndFacilitiesResponseForm(question1, question2, question3);
    }
    
    private EquipmentAndFacilitiesResponseForm(ResponseResult question1, ResponseResult question2, ResponseResult question3) {
        this.question1TotallyDisagree = question1.getCountOfTotallyDisagree().intValue();
        this.question1Disagree = question1.getCountOfDisagree().intValue();
        this.question1Agree = question1.getCountOfAgree().intValue();
        this.question1TotallyAgree = question1.getCountOfTotallyAgree().intValue();
        this.question1NotApplicable = question1.getCountOfnonApplicable().intValue();
        
        this.question2TotallyDisagree = question2.getCountOfTotallyDisagree().intValue();
        this.question2Disagree = question2.getCountOfDisagree().intValue();
        this.question2Agree = question2.getCountOfAgree().intValue();
        this.question2TotallyAgree = question2.getCountOfTotallyAgree().intValue();
        this.question2NotApplicable = question2.getCountOfnonApplicable().intValue();
        
        this.question3TotallyDisagree = question3.getCountOfTotallyDisagree().intValue();
        this.question3Disagree = question3.getCountOfDisagree().intValue();
        this.question3Agree = question3.getCountOfAgree().intValue();
        this.question3TotallyAgree = question3.getCountOfTotallyAgree().intValue();
        this.question3NotApplicable = question3.getCountOfnonApplicable().intValue();
     
    }
    
    private EquipmentAndFacilitiesResponseForm(Builder builder) {
        this.question1TotallyDisagree = builder.question1TotallyDisagree;
        this.question1Disagree = builder.question1Disagree;
        this.question1Agree = builder.question1Agree;
        this.question1TotallyAgree = builder.question1TotallyAgree;
        this.question1NotApplicable = builder.question1NotApplicable;
        this.question2TotallyDisagree = builder.question2TotallyDisagree;
        this.question2Disagree = builder.question2Disagree;
        this.question2Agree = builder.question2Agree;
        this.question2TotallyAgree = builder.question2TotallyAgree;
        this.question2NotApplicable = builder.question2NotApplicable;
        this.question3TotallyDisagree = builder.question3TotallyDisagree;
        this.question3Disagree = builder.question3Disagree;
        this.question3Agree = builder.question3Agree;
        this.question3TotallyAgree = builder.question3TotallyAgree;
        this.question3NotApplicable = builder.question3NotApplicable;
        this.question1Ratings = builder.question1Ratings;
        this.question2Ratings = builder.question2Ratings;
        this.question3Ratings = builder.question3Ratings;
        this.average = builder.average;
    }

    /**
     * @return the question1TotallyDisagree
     */
    public int getQuestion1TotallyDisagree() {
        return question1TotallyDisagree;
    }

    /**
     * @param question1TotallyDisagree the question1TotallyDisagree to set
     */
    public void setQuestion1TotallyDisagree(int question1TotallyDisagree) {
        this.question1TotallyDisagree = question1TotallyDisagree;
    }

    /**
     * @return the question1Disagree
     */
    public int getQuestion1Disagree() {
        return question1Disagree;
    }

    /**
     * @param question1Disagree the question1Disagree to set
     */
    public void setQuestion1Disagree(int question1Disagree) {
        this.question1Disagree = question1Disagree;
    }

    /**
     * @return the question1Agree
     */
    public int getQuestion1Agree() {
        return question1Agree;
    }

    /**
     * @param question1Agree the question1Agree to set
     */
    public void setQuestion1Agree(int question1Agree) {
        this.question1Agree = question1Agree;
    }

    /**
     * @return the question1TotallyAgree
     */
    public int getQuestion1TotallyAgree() {
        return question1TotallyAgree;
    }

    /**
     * @param question1TotallyAgree the question1TotallyAgree to set
     */
    public void setQuestion1TotallyAgree(int question1TotallyAgree) {
        this.question1TotallyAgree = question1TotallyAgree;
    }

    /**
     * @return the question1NotApplicable
     */
    public int getQuestion1NotApplicable() {
        return question1NotApplicable;
    }

    /**
     * @param question1NotApplicable the question1NotApplicable to set
     */
    public void setQuestion1NotApplicable(int question1NotApplicable) {
        this.question1NotApplicable = question1NotApplicable;
    }

    /**
     * @return the question2TotallyDisagree
     */
    public int getQuestion2TotallyDisagree() {
        return question2TotallyDisagree;
    }

    /**
     * @param question2TotallyDisagree the question2TotallyDisagree to set
     */
    public void setQuestion2TotallyDisagree(int question2TotallyDisagree) {
        this.question2TotallyDisagree = question2TotallyDisagree;
    }

    /**
     * @return the question2Disagree
     */
    public int getQuestion2Disagree() {
        return question2Disagree;
    }

    /**
     * @param question2Disagree the question2Disagree to set
     */
    public void setQuestion2Disagree(int question2Disagree) {
        this.question2Disagree = question2Disagree;
    }

    /**
     * @return the question2Agree
     */
    public int getQuestion2Agree() {
        return question2Agree;
    }

    /**
     * @param question2Agree the question2Agree to set
     */
    public void setQuestion2Agree(int question2Agree) {
        this.question2Agree = question2Agree;
    }

    /**
     * @return the question2TotallyAgree
     */
    public int getQuestion2TotallyAgree() {
        return question2TotallyAgree;
    }

    /**
     * @param question2TotallyAgree the question2TotallyAgree to set
     */
    public void setQuestion2TotallyAgree(int question2TotallyAgree) {
        this.question2TotallyAgree = question2TotallyAgree;
    }

    /**
     * @return the question2NotApplicable
     */
    public int getQuestion2NotApplicable() {
        return question2NotApplicable;
    }

    /**
     * @param question2NotApplicable the question2NotApplicable to set
     */
    public void setQuestion2NotApplicable(int question2NotApplicable) {
        this.question2NotApplicable = question2NotApplicable;
    }

    /**
     * @return the question3TotallyDisagree
     */
    public int getQuestion3TotallyDisagree() {
        return question3TotallyDisagree;
    }

    /**
     * @param question3TotallyDisagree the question3TotallyDisagree to set
     */
    public void setQuestion3TotallyDisagree(int question3TotallyDisagree) {
        this.question3TotallyDisagree = question3TotallyDisagree;
    }

    /**
     * @return the question3Disagree
     */
    public int getQuestion3Disagree() {
        return question3Disagree;
    }

    /**
     * @param question3Disagree the question3Disagree to set
     */
    public void setQuestion3Disagree(int question3Disagree) {
        this.question3Disagree = question3Disagree;
    }

    /**
     * @return the question3Agree
     */
    public int getQuestion3Agree() {
        return question3Agree;
    }

    /**
     * @param question3Agree the question3Agree to set
     */
    public void setQuestion3Agree(int question3Agree) {
        this.question3Agree = question3Agree;
    }

    /**
     * @return the question3TotallyAgree
     */
    public int getQuestion3TotallyAgree() {
        return question3TotallyAgree;
    }

    /**
     * @param question3TotallyAgree the question3TotallyAgree to set
     */
    public void setQuestion3TotallyAgree(int question3TotallyAgree) {
        this.question3TotallyAgree = question3TotallyAgree;
    }

    /**
     * @return the question3NotApplicable
     */
    public int getQuestion3NotApplicable() {
        return question3NotApplicable;
    }

    /**
     * @param question3NotApplicable the question3NotApplicable to set
     */
    public void setQuestion3NotApplicable(int question3NotApplicable) {
        this.question3NotApplicable = question3NotApplicable;
    }

    /**
     * @return the question1Ratings
     */
    public double getQuestion1Ratings() {
        return question1Ratings;
    }

    /**
     * @param question1Ratings the question1Ratings to set
     */
    public void setQuestion1Ratings(double question1Ratings) {
        this.question1Ratings = question1Ratings;
    }

    /**
     * @return the question2Ratings
     */
    public double getQuestion2Ratings() {
        return question2Ratings;
    }

    /**
     * @param question2Ratings the question2Ratings to set
     */
    public void setQuestion2Ratings(double question2Ratings) {
        this.question2Ratings = question2Ratings;
    }

    /**
     * @return the question3Ratings
     */
    public double getQuestion3Ratings() {
        return question3Ratings;
    }

    /**
     * @param question3Ratings the question3Ratings to set
     */
    public void setQuestion3Ratings(double question3Ratings) {
        this.question3Ratings = question3Ratings;
    }

    /**
     * @return the average
     */
    public double getAverage() {
        return average;
    }

    /**
     * @param average the average to set
     */
    public void setAverage(double average) {
        this.average = average;
    }

    /**
     * Creates builder to build {@link EquipmentAndFacilitiesResponseForm}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder to build {@link EquipmentAndFacilitiesResponseForm}.
     */
    public static final class Builder {
        private int question1TotallyDisagree;
        private int question1Disagree;
        private int question1Agree;
        private int question1TotallyAgree;
        private int question1NotApplicable;
        private int question2TotallyDisagree;
        private int question2Disagree;
        private int question2Agree;
        private int question2TotallyAgree;
        private int question2NotApplicable;
        private int question3TotallyDisagree;
        private int question3Disagree;
        private int question3Agree;
        private int question3TotallyAgree;
        private int question3NotApplicable;
        private double question1Ratings;
        private double question2Ratings;
        private double question3Ratings;
        private double average;

        private Builder() {
        }

        public Builder withQuestion1TotallyDisagree(int question1TotallyDisagree) {
            this.question1TotallyDisagree = question1TotallyDisagree;
            return this;
        }

        public Builder withQuestion1Disagree(int question1Disagree) {
            this.question1Disagree = question1Disagree;
            return this;
        }

        public Builder withQuestion1Agree(int question1Agree) {
            this.question1Agree = question1Agree;
            return this;
        }

        public Builder withQuestion1TotallyAgree(int question1TotallyAgree) {
            this.question1TotallyAgree = question1TotallyAgree;
            return this;
        }

        public Builder withQuestion1NotApplicable(int question1NotApplicable) {
            this.question1NotApplicable = question1NotApplicable;
            return this;
        }

        public Builder withQuestion2TotallyDisagree(int question2TotallyDisagree) {
            this.question2TotallyDisagree = question2TotallyDisagree;
            return this;
        }

        public Builder withQuestion2Disagree(int question2Disagree) {
            this.question2Disagree = question2Disagree;
            return this;
        }

        public Builder withQuestion2Agree(int question2Agree) {
            this.question2Agree = question2Agree;
            return this;
        }

        public Builder withQuestion2TotallyAgree(int question2TotallyAgree) {
            this.question2TotallyAgree = question2TotallyAgree;
            return this;
        }

        public Builder withQuestion2NotApplicable(int question2NotApplicable) {
            this.question2NotApplicable = question2NotApplicable;
            return this;
        }

        public Builder withQuestion3TotallyDisagree(int question3TotallyDisagree) {
            this.question3TotallyDisagree = question3TotallyDisagree;
            return this;
        }

        public Builder withQuestion3Disagree(int question3Disagree) {
            this.question3Disagree = question3Disagree;
            return this;
        }

        public Builder withQuestion3Agree(int question3Agree) {
            this.question3Agree = question3Agree;
            return this;
        }

        public Builder withQuestion3TotallyAgree(int question3TotallyAgree) {
            this.question3TotallyAgree = question3TotallyAgree;
            return this;
        }

        public Builder withQuestion3NotApplicable(int question3NotApplicable) {
            this.question3NotApplicable = question3NotApplicable;
            return this;
        }

        public Builder withQuestion1Ratings(double question1Ratings) {
            this.question1Ratings = question1Ratings;
            return this;
        }

        public Builder withQuestion2Ratings(double question2Ratings) {
            this.question2Ratings = question2Ratings;
            return this;
        }

        public Builder withQuestion3Ratings(double question3Ratings) {
            this.question3Ratings = question3Ratings;
            return this;
        }

        public Builder withAverage(double average) {
            this.average = average;
            return this;
        }

        public EquipmentAndFacilitiesResponseForm build() {
            return new EquipmentAndFacilitiesResponseForm(this);
        }
    }
    
    
}

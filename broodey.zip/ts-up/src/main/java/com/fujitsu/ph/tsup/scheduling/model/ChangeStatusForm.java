package com.fujitsu.ph.tsup.scheduling.model;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.format.annotation.DateTimeFormat;

import com.fujitsu.ph.tsup.pagination.Paged;

public class ChangeStatusForm {

    /**
     * Course Id
     */
    private Long id;

    /**
     * List of courses
     */
    private Set<CourseForm> courses;

    /**
     * List of course schedules
     */
    private List<ChangeStatusScheduleForm> courseSchedules;

    /**
     * Paged course schedules
     */
    private Paged<ChangeStatusScheduleForm> pagedCourseSchedules;

    /**
     * From Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    private ZonedDateTime fromDateTime;

    /**
     * To Date and Time
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    private ZonedDateTime toDateTime;

    /**
     * Course schedule status
     */
    private String status;

    /**
     * Course Id
     */
    private Long courseId;

    /**
     * Filter status
     */
    private String statusCode;
    
    /**
     * Filter course name ID
     */
    private String courseNameId;

    /**
     * Filter venue ID
     */
    private String venueId;

    /**
     * Filter instructor ID
     */
    private String instructorId;

    /**
     * Filter Tags
     */
    private String memberRole;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<CourseForm> getCourses() {
        return courses;
    }

    public void setCourses(Set<CourseForm> courses) {
        this.courses = courses;
    }

    public List<ChangeStatusScheduleForm> getCourseSchedules() {
        return courseSchedules;
    }

    public void setCourseSchedules(List<ChangeStatusScheduleForm> courseSchedules) {
        this.courseSchedules = courseSchedules;
    }

    /**
     * <pre>
     * Get [fromDateTime] value
     * </pre>
     * 
     * @return ZonedDateTime
     */
    public ZonedDateTime getFromDateTime() {
        return fromDateTime;
    }

    /**
     * <pre>
     * Get [fromDateTime] value
     * </pre>
     * 
     * @param fromDateTime
     */
    public void setFromDateTime(ZonedDateTime fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    /**
     * <pre>
     * Get [toDateTime] value
     * </pre>
     * 
     * @return ZonedDateTime
     */
    public ZonedDateTime getToDateTime() {
        return toDateTime;
    }

    /**
     * <pre>
     * Set [toDateTime] value
     * </pre>
     * 
     * @param toDateTime
     */
    public void setToDateTime(ZonedDateTime toDateTime) {
        this.toDateTime = toDateTime;
    }

    /**
     * <pre>
     * Get [pagedCourseSchedules] value
     * </pre>
     * 
     * @return
     */
    public Paged<ChangeStatusScheduleForm> getPagedCourseSchedules() {
        return pagedCourseSchedules;
    }

    /**
     * <pre>
     * Set [pagedCourseSchedules] value
     * </pre>
     * 
     * @param pagedCourseSchedules
     */
    public void setPagedCourseSchedules(Paged<ChangeStatusScheduleForm> pagedCourseSchedules) {
        this.pagedCourseSchedules = pagedCourseSchedules;
    }

    /**
     * <pre>
     * Get course schedule status.
     * </pre>
     * 
     * @return
     */
    public String getStatus() {
        return status;
    }

    /**
     * <pre>
     * Set course schedule status
     * </pre>
     * 
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * <pre>
     * Get course id
     * </pre>
     * 
     * @return Long
     */
    public Long getCourseId() {
        return courseId;
    }

    /**
     * <pre>
     * Set course id
     * </pre>
     * 
     * @param courseId
     */
    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    /**
     * @return the courseNameId
     */
    public String getCourseNameId() {
        return courseNameId;
    }

    /**
     * @param courseNameId the courseNameId to set
     */
    public void setCourseNameId(String courseNameId) {
        this.courseNameId = courseNameId;
    }

    /**
     * @return the venueId
     */
    public String getVenueId() {
        return venueId;
    }

    /**
     * @param venueId the venueId to set
     */
    public void setVenueId(String venueId) {
        this.venueId = venueId;
    }

    /**
     * @return the instructorId
     */
    public String getInstructorId() {
        return instructorId;
    }

    /**
     * @param instructorId the instructorId to set
     */
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }

    /**
     * @return the memberRole
     */
    public String getMemberRole() {
        return memberRole;
    }

    /**
     * @param memberRole the memberRole to set
     */
    public void setMemberRole(String memberRole) {
        this.memberRole = memberRole;
    }

    /**
     * @return the statusCode
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * @param statusCode the statusCode to set
     */
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeStatusForm [id=" + id + ", courses=" + courses + ", courseSchedules=" + courseSchedules
                + ", pagedCourseSchedules=" + pagedCourseSchedules + ", fromDateTime=" + fromDateTime
                + ", toDateTime=" + toDateTime + ", status=" + status + ", courseId=" + courseId
                + ", statusCode=" + statusCode + ", courseNameId=" + courseNameId + ", venueId=" + venueId
                + ", instructorId=" + instructorId + ", memberRole=" + memberRole + "]";
    }

}

//==================================================================================================
// Project Name : Training Sign-Up
// System Name : NonMandatoryCoursesReportServiceImpl
// Class Name : NonMandatoryCoursesReportServiceImpl.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.report.summary.dao.NonMandatoryCoursesReportDao;
import com.fujitsu.ph.tsup.report.summary.model.Attendee;
import com.fujitsu.ph.tsup.report.summary.model.AttendeeForm;
import com.fujitsu.ph.tsup.report.summary.model.CourseCategory;
import com.fujitsu.ph.tsup.report.summary.model.MemberNonMandatoryCoursesCompletionForm;

/**
 * <pre>
 * Service implementation for
 * Members' completion report of Non Mandatory Courses
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
@Service
public class NonMandatoryCoursesReportServiceImpl implements NonMandatoryCoursesReportService {

    @Autowired
    private NonMandatoryCoursesReportDao nonMandatoryCoursesReportDao;

    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(NonMandatoryCoursesReportServiceImpl.class);

    /*
     * (non-Javadoc)
     * @see
     * com.fujitsu.ph.tsup.report.summary.service.NonMandatoryCoursesReportService#getAllNonMandatoryCourses()
     */
    @Override
    public Set<CourseCategory> getAllNonMandatoryCourseCategory() {
        Set<CourseCategory> courseCategorySet = new LinkedHashSet<>();
        try {
            courseCategorySet = nonMandatoryCoursesReportDao.findAllNonMandatoryCourseCategory();
        } catch (DataAccessException dataAccessException) {
            logger.error("Error {}", dataAccessException.getMessage());
        }
        return courseCategorySet;
    }

    /*
     * (non-Javadoc)
     * @see
     * com.fujitsu.ph.tsup.report.summary.service.NonMandatoryCoursesReportService#getSummary(java.lang.Long)
     */
    @Override
    public MemberNonMandatoryCoursesCompletionForm getSummary(Long courseCategoryID) {

        MemberNonMandatoryCoursesCompletionForm completionForm = new MemberNonMandatoryCoursesCompletionForm();
        CourseCategory courseCategory = new CourseCategory(courseCategoryID, "");
        
        try {
            // Get all courses under course category
            courseCategory.setCourseMap(
                    nonMandatoryCoursesReportDao.findAllCoursesUnderCourseCategory(courseCategoryID));
            
            // Get all members
            Long jduId = nonMandatoryCoursesReportDao.getJDUType();
            Set<Attendee> membersSet = nonMandatoryCoursesReportDao.findAllMembers(jduId);
            
            // Get all attendees of all non-mandatory courses under course category id
            Set<Attendee> attendeesSet = nonMandatoryCoursesReportDao
                    .findAllAttendeesOfNonMandatoryCourses(courseCategoryID, jduId);

            // Check and get the attended date of each members
            List<AttendeeForm> attendeeFormList = new ArrayList<>();

            for (Attendee member : membersSet) {
                List<String> courseList = new ArrayList<>();
                List<String> attendanceList = new ArrayList<>();

                AttendeeForm attendeeFormTmp = new AttendeeForm();
                attendeeFormTmp.setId(member.getEmployeeId());
                attendeeFormTmp.setEmployeeName(member.getEmployeeName());

                for (Map.Entry<Long, String> course : courseCategory.getCourseMap().entrySet()) {
                    courseList.add(course.getValue());

                    List<Attendee> membersAttendanceList = attendeesSet.stream()
                            .filter(attendee -> attendee.getEmployeeId().equals(member.getEmployeeId()))
                            .filter(attendee -> attendee.getEmployeeName().equals(member.getEmployeeName()))
                            .filter(attendee -> attendee.getId().equals(course.getKey()))
                            .filter(attendee -> attendee.getCourseName().equals(course.getValue()))
                            .sorted(Comparator.comparing(Attendee::getDateAttended).reversed())
                            .collect(Collectors.toList());
                    if (membersAttendanceList.isEmpty()) {
                        attendanceList.add("-");
                    } else {
                        attendanceList.add(membersAttendanceList.get(0).getDateAttended());
                    }
                }

                attendeeFormTmp.setCourseName(courseList);
                attendeeFormTmp.setAttendanceStatus(attendanceList);
                attendeeFormList.add(attendeeFormTmp);
            }

            completionForm.setCourseCategory(courseCategory);
            completionForm.setMemberList(attendeeFormList);

        } catch (DataAccessException dataAccessException) {
            logger.error("Error {}", dataAccessException.getMessage());
        }

        return completionForm;
    }

}

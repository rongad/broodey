package com.fujitsu.ph.tsup.tms.model;

public class CourseStatus {
	private String courseName;
	private String status;
	private long count;
	private String manager;
	
	public CourseStatus(String courseName, String status, long count, String manager) {
		super();
		this.courseName = courseName;
		this.status = status;
		this.count = count;
		this.manager = manager;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	

}

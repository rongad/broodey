/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.viewsurveyrate.dao;

import com.fujitsu.ph.tsup.viewsurveyrate.domain.Ratings;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name : EquipmentAndFacilitiesResponse.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01 | 2021/10/12 | WS) mi.aguinaldo | Initial Version
//==================================================================================================

public class EquipmentAndFacilitiesResponse {
    
    private Ratings question1Ratings;
    private Ratings question2Ratings;
    private Ratings question3Ratings;

    public EquipmentAndFacilitiesResponse() {
        super();
    }


    private EquipmentAndFacilitiesResponse(Builder builder) {
        this.question1Ratings = builder.question1Ratings;
        this.question2Ratings = builder.question2Ratings;
        this.question3Ratings = builder.question3Ratings;
    }
    
    
    /**
     * @return the question1Ratings
     */
    public Ratings getQuestion1Ratings() {
        return question1Ratings;
    }
    /**
     * @return the question2Ratings
     */
    public Ratings getQuestion2Ratings() {
        return question2Ratings;
    }
    /**
     * @return the question3Ratings
     */
    public Ratings getQuestion3Ratings() {
        return question3Ratings;
    }


    /**
     * Creates builder to build {@link EquipmentAndFacilitiesResponse}.
     * @return created builder
     */
    public static Builder builder() {
        return new Builder();
    }
    /**
     * Builder to build {@link EquipmentAndFacilitiesResponse}.
     */
    public static final class Builder {
        private Ratings question1Ratings;
        private Ratings question2Ratings;
        private Ratings question3Ratings;

        private Builder() {
        }

        public Builder withQuestion1Ratings(Ratings question1Ratings) {
            this.question1Ratings = question1Ratings;
            return this;
        }
        
        public Builder withQuestion1Ratings(Integer question1Ratings) {
            this.question1Ratings = Ratings.fromValue(question1Ratings);
            return this;
        }

        public Builder withQuestion2Ratings(Ratings question2Ratings) {
            this.question2Ratings = question2Ratings;
            return this;
        }
        
        public Builder withQuestion2Ratings(Integer question2Ratings) {
            this.question2Ratings = Ratings.fromValue(question2Ratings);
            return this;
        }

        public Builder withQuestion3Ratings(Ratings question3Ratings) {
            this.question3Ratings = question3Ratings;
            return this;
        }
        
        public Builder withQuestion3Ratings(Integer question3Ratings) {
            this.question3Ratings = Ratings.fromValue(question3Ratings);
            return this;
        }

        public EquipmentAndFacilitiesResponse build() {
            return new EquipmentAndFacilitiesResponse(this);
        }
    }
    
}

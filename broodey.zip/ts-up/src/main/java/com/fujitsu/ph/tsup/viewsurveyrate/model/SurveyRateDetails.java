/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */    
package com.fujitsu.ph.tsup.viewsurveyrate.model;

import java.time.ZonedDateTime;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

//==================================================================================================                                                                                                                                                                            
//Project Name : Training Sign Up
//System Name  : SurveyRateDao                                                                                                                                                               
//Class Name   : SurveyRateDao.java                                                                                                                                                                          
//                                                                                                                                                                   
//<<Modification History>>                                                                                                                                                                             
//Version  | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.01    | 2021/08/23 | WS)JD.Dominguez       | New Creation    
// 0.02    | 2021/10/27 | WS)L.Celoso           | Added course schedule ID to link course schedule and survey tables in the DB   
//==================================================================================================  
public class SurveyRateDetails {
    
    @NotNull
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) 
    private ZonedDateTime courseDateTime;
    private String courseTitle;
    private String instructorName;
    private String courseId;
    private String courseScheduleId;
    
    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public ZonedDateTime getCourseDateTime() {
        return courseDateTime;
    }

    public void setCourseDateTime(ZonedDateTime courseDateTime) {
        this.courseDateTime = courseDateTime;
    }
    
    public String getCourseId() {
    	return courseId;
    }
    
    public void setCourseId(String courseId) {
    	this.courseId = courseId;
    }
    
    public String getCourseScheduleId() {
        return courseScheduleId;
    }
    
    public void setCourseScheduleId(String courseScheduleId) {
        this.courseScheduleId = courseScheduleId;
    }
}

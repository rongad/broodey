/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.enrollment.certificate.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import com.fujitsu.ph.tsup.enrollment.certificate.model.ManageCertificate;

import org.springframework.jdbc.core.RowMapper;

//=======================================================
//Project Name: Training Sign Up
//Class Name: ManageCertificateRowMapper.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 11/08/2021 | WS) k.mutia  | Created
//=======================================================

/**
*
* @author k.mutia
*
*/
public class ManageCertificateRowMapper implements RowMapper<ManageCertificate> {

    @Override
    public ManageCertificate mapRow(ResultSet rs, int rowNum) throws SQLException {
        Long id = rs.getLong("CU.ID");
        String certificate = rs.getString("CU.CERTIFICATE");
        Long employeeId = rs.getLong("CU.EMPLOYEE_ID");
        Long courseId = rs.getLong("CU.COURSE_ID");
        String courseName = rs.getString("C.NAME");
        ZonedDateTime uploadDate = ZonedDateTime.ofInstant(rs.getTimestamp("CU.UPLOAD_DATE").toInstant(),
                ZoneId.systemDefault());
        String fileDownloadUri = rs.getString("CU.FILEDOWNLOADURI");

        return new ManageCertificate.Builder(id, employeeId, courseId, courseName, certificate,
                fileDownloadUri, uploadDate).build();
    }
}

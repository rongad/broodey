/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.jdu.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fujitsu.ph.tsup.jdu.dao.JduDao;
import com.fujitsu.ph.tsup.jdu.domain.Jdu;
import com.fujitsu.ph.tsup.pagination.Paged;
import com.fujitsu.ph.tsup.pagination.Paging;

//=======================================================
//Project Name: Training Sign Up
//Class Name: JduServiceImpl.java
//
//<<Modification History>>
//Version | Date       | Updated by       | Content
//--------+------------+------------------+---------------
//0.01    | 28/06/2021 | WS) dw.cardenas  | Created
//0.02    | 03/08/2021 | WS) dw.cardenas  | Update
//0.03    | 10/09/2021 | WS) r.delacruz   | Update
//=======================================================

/**
 *
 * @author dw.cardenas
 *
 */
@Service
public class JduServiceImpl implements JduService {
	
	@Autowired
	JduDao jduDao;

	@Override
	public Set<Jdu> findAllJdus() {
		return jduDao.findAllJdus();
	}

	@Override
	public Page<Jdu> findAllJdus(Pageable pageable) {
		List<Jdu> jduList = jduDao.findAllJdus(pageable)
					.stream().collect(Collectors.toList());

		return new PageImpl<>(jduList, pageable, jduDao.countJdu());
	}

	@Override
	public Set<Jdu> findJduByName(String jduName) {
		return jduDao.findJduByName(jduName);
	}
	
	@Override
	public Paged<Jdu> findAllJdusAsPaged(Pageable pageable) {
		Page<Jdu> jduList = findAllJdus(pageable);

		return new Paged<>(jduList, Paging.of(jduList.getTotalPages(),
				jduList.getNumber() + 1, jduList.getSize()));
	}
	
	@Override
	public Paged<Jdu>  findJduByNameAsPaged (String searchKey, Pageable pageable) {
		Page<Jdu> jduListByName = findJduByName(searchKey, pageable);

		return new Paged<>(jduListByName, Paging.of(jduListByName.getTotalPages(),
				jduListByName.getNumber() + 1, jduListByName.getSize()));
	}
		
		
	

	@Override
	public void createJdu(Jdu newJdu) {
		try {
			jduDao.createJdu(newJdu);
		} catch (Exception ex) {
			String err = String.format("Failed to save new jdu: [%s]", ex.getMessage());
			throw new IllegalArgumentException(err);
		}
	}

	@Override
	public void updateJdu(Jdu updatedJdu) {
		try {
			jduDao.updateJdu(updatedJdu);
		} catch (Exception ex) {
			String err = String.format("Failed to update jdu: [%s]", ex.getMessage());
			throw new IllegalArgumentException(err);
		}
	}

	@Override
	public void deleteDepartment(Long id) {
		try {
			jduDao.deleteJdu(id);
		} catch (Exception ex) {
			String err = String.format("Failed to delete jdu: [%s]", ex.getMessage());
			throw new IllegalArgumentException(err);
		}
	}

	@Override
	public Page<Jdu> findJduByName(String searchKey, Pageable pageable) {
		List<Jdu> jduList = jduDao.findJduByName(searchKey, pageable)
				.stream().collect(Collectors.toList());

		return new PageImpl<>(jduList, pageable, jduDao.countFoundJdu(searchKey));
	}
}

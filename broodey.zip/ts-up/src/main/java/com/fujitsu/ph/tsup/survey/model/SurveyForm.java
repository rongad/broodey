package com.fujitsu.ph.tsup.survey.model;

import java.time.ZonedDateTime;

// ==================================================================================================
// $Id:PR16$
// Project Name :Training Sign Up
// System Name :Survey Form Process
// Class Name :SurveyForm.java
//
// <<Modification History>>
// Version | Date | Updated By | Content
// --------+------------+----------------------------------------+-----------------------------------
// 0.01 | 08/12/2021 | WS) KA.Espinoza | New Creation
// 0.02 | 11/23/2021 | WS) Mj.liwag    | Updated
// ==================================================================================================
/**
 * <pre>
* JavaBean for SurveyForm
* In this Class,Instances or fields of the List of the data for the initial setting of the data base
 * </pre>
 * 
 * @version 0.01
 * @author ka.espinoza
 */

public class SurveyForm {
    /**
     * Survey Form Id
     */
    private Long id;

    /**
     * Course Name
     */
    private String courseTitle;

    /**
     * Course Training Venue
     */
    private String trainingVenue;

    /**
     * Instructor Name
     */
    private String instructorName;

    /**
     * Course Start Date and Time
     */
    private ZonedDateTime courseDateTime;

    /**
     * Course End Date and Time
     */
    private ZonedDateTime courseEndDate;

    /**
     * Course Scheduled Id
     */
    private Long courseScheduleDetailId;

    /**
     * A. Module Design Question No 1
     */
    private Integer mdQuestion1;

    /**
     * A. Module Design Question No 2
     */
    private Integer mdQuestion2;

    /**
     * A. Module Design Question No 3
     */
    private Integer mdQuestion3;

    /**
     * A. Module Design Question No 4
     */
    private Integer mdQuestion4;

    /**
     * B. Materials Question 1
     */
    private Integer matQuestion1;

    /**
     * B. Materials Question 2
     */
    private Integer matQuestion2;

    /**
     * B. Materials Question 3
     */
    private Integer matQuestion3;

    /**
     * B. Materials Question 4
     */
    private Integer matQuestion4;

    /**
     * C. Instruction Question 1
     */
    private Integer insQuestion1;

    /**
     * C. Instruction Question 2
     */
    private Integer insQuestion2;

    /**
     * C. Instruction Question 3
     */
    private Integer insQuestion3;

    /**
     * C. Instruction Question 4
     */
    private Integer insQuestion4;

    /**
     * C. Instruction Question 5
     */
    private Integer insQuestion5;

    /**
     * C. Instruction Question 6
     */
    private Integer insQuestion6;

    /**
     * D. Equipment and Facilities Question 1
     */
    private Integer eqFaQuestion1;

    /**
     * D. Equipment and Facilities Question 2
     */
    private Integer eqFaQuestion2;

    /**
     * D. Equipment and Facilities Question 3
     */
    private Integer eqFaQuestion3;

    /**
     * Comments Question E
     */
    private String commentsE;

    /**
     * Comments Question F
     */
    private String commentsF;

    /**
     * Comments Question G
     */
    private String commentsG;

    /**
     * Comments Question G
     */
    private Boolean goToMostRequestedSurvey;

    /**
     * Empty Method
     */
    public SurveyForm() {

    }

    /**
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return
     */
    public String getCourseTitle() {
        return courseTitle;
    }

    /**
     * @param courseTitle
     */
    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    /**
     * @return
     */
    public String getTrainingVenue() {
        return trainingVenue;
    }

    /**
     * @param trainingVenue
     */
    public void setTrainingVenue(String trainingVenue) {
        this.trainingVenue = trainingVenue;
    }

    /**
     * @return
     */
    public String getInstructorName() {
        return instructorName;
    }

    /**
     * @param instructorName
     */
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    /**
     * @return
     */
    public ZonedDateTime getCourseDateTime() {
        return courseDateTime;
    }

    /**
     * @param courseDateTime
     */
    public void setCourseDateTime(ZonedDateTime courseDateTime) {
        this.courseDateTime = courseDateTime;
    }

    /**
     * @return
     */
    public ZonedDateTime getCourseEndDate() {
        return courseEndDate;
    }

    /**
     * @param courseEndDate
     */
    public void setCourseEndDate(ZonedDateTime courseEndDate) {
        this.courseEndDate = courseEndDate;
    }

    /**
     * @return
     */
    public Long getCourseScheduleDetailId() {
        return courseScheduleDetailId;
    }

    /**
     * @param courseScheduleDetailId
     */
    public void setCourseScheduleDetailId(Long courseScheduleDetailId) {
        this.courseScheduleDetailId = courseScheduleDetailId;
    }

    /**
     * @return
     */
    public Integer getMdQuestion1() {
        return mdQuestion1;
    }

    /**
     * @param mdQuestion1
     */
    public void setMdQuestion1(Integer mdQuestion1) {
        this.mdQuestion1 = mdQuestion1;
    }

    /**
     * @return
     */
    public Integer getMdQuestion2() {
        return mdQuestion2;
    }

    /**
     * @param mdQuestion2
     */
    public void setMdQuestion2(Integer mdQuestion2) {
        this.mdQuestion2 = mdQuestion2;
    }

    /**
     * @return
     */
    public Integer getMdQuestion3() {
        return mdQuestion3;
    }

    /**
     * @param mdQuestion3
     */
    public void setMdQuestion3(Integer mdQuestion3) {
        this.mdQuestion3 = mdQuestion3;
    }

    /**
     * @return
     */
    public Integer getMdQuestion4() {
        return mdQuestion4;
    }

    /**
     * @param mdQuestion4
     */
    public void setMdQuestion4(Integer mdQuestion4) {
        this.mdQuestion4 = mdQuestion4;
    }

    /**
     * @return
     */
    public Integer getMatQuestion1() {
        return matQuestion1;
    }

    /**
     * @param matQuestion1
     */
    public void setMatQuestion1(Integer matQuestion1) {
        this.matQuestion1 = matQuestion1;
    }

    /**
     * @return
     */
    public Integer getMatQuestion2() {
        return matQuestion2;
    }

    /**
     * @param matQuestion2
     */
    public void setMatQuestion2(Integer matQuestion2) {
        this.matQuestion2 = matQuestion2;
    }

    /**
     * @return
     */
    public Integer getMatQuestion3() {
        return matQuestion3;
    }

    /**
     * @param matQuestion3
     */
    public void setMatQuestion3(Integer matQuestion3) {
        this.matQuestion3 = matQuestion3;
    }

    /**
     * @return
     */
    public Integer getMatQuestion4() {
        return matQuestion4;
    }

    /**
     * @param matQuestion4
     */
    public void setMatQuestion4(Integer matQuestion4) {
        this.matQuestion4 = matQuestion4;
    }

    /**
     * @return
     */
    public Integer getInsQuestion1() {
        return insQuestion1;
    }

    /**
     * @param insQuestion1
     */
    public void setInsQuestion1(Integer insQuestion1) {
        this.insQuestion1 = insQuestion1;
    }

    /**
     * @return
     */
    public Integer getInsQuestion2() {
        return insQuestion2;
    }

    /**
     * @param insQuestion2
     */
    public void setInsQuestion2(Integer insQuestion2) {
        this.insQuestion2 = insQuestion2;
    }

    /**
     * @return
     */
    public Integer getInsQuestion3() {
        return insQuestion3;
    }

    /**
     * @param insQuestion3
     */
    public void setInsQuestion3(Integer insQuestion3) {
        this.insQuestion3 = insQuestion3;
    }

    /**
     * @return
     */
    public Integer getInsQuestion4() {
        return insQuestion4;
    }

    /**
     * @param insQuestion4
     */
    public void setInsQuestion4(Integer insQuestion4) {
        this.insQuestion4 = insQuestion4;
    }

    /**
     * @return
     */
    public Integer getInsQuestion5() {
        return insQuestion5;
    }

    /**
     * @param insQuestion5
     */
    public void setInsQuestion5(Integer insQuestion5) {
        this.insQuestion5 = insQuestion5;
    }

    /**
     * @return
     */
    public Integer getInsQuestion6() {
        return insQuestion6;
    }

    /**
     * @param insQuestion6
     */
    public void setInsQuestion6(Integer insQuestion6) {
        this.insQuestion6 = insQuestion6;
    }

    /**
     * @return
     */
    public Integer getEqFaQuestion1() {
        return eqFaQuestion1;
    }

    /**
     * @param EqFaQuestion1
     */
    public void setEqFaQuestion1(Integer eqFaQuestion1) {
        this.eqFaQuestion1 = eqFaQuestion1;
    }

    /**
     * @return
     */
    public Integer getEqFaQuestion2() {
        return eqFaQuestion2;
    }

    /**
     * @param EqFaQuestion2
     */
    public void setEqFaQuestion2(Integer eqFaQuestion2) {
        this.eqFaQuestion2 = eqFaQuestion2;
    }

    /**
     * @return
     */
    public Integer getEqFaQuestion3() {
        return eqFaQuestion3;
    }

    /**
     * @param EqFaQuestion3
     */
    public void setEqFaQuestion3(Integer eqFaQuestion3) {
        this.eqFaQuestion3 = eqFaQuestion3;
    }

    /**
     * @return
     */
    public String getCommentsE() {
        return commentsE;
    }

    /**
     * @param commentsE
     */
    public void setCommentsE(String commentsE) {
        this.commentsE = commentsE;
    }

    /**
     * @return
     */
    public String getCommentsF() {
        return commentsF;
    }

    /**
     * @param commentsF
     */
    public void setCommentsF(String commentsF) {
        this.commentsF = commentsF;
    }

    /**
     * @return
     */
    public String getCommentsG() {
        return commentsG;
    }

    /**
     * @param commentsG
     */
    public void setCommentsG(String commentsG) {
        this.commentsG = commentsG;
    }

    public Boolean getGoToMostRequestedSurvey() {
        return goToMostRequestedSurvey;
    }

    public void setGoToMostRequestedSurvey(Boolean goToMostRequestedSurvey) {
        this.goToMostRequestedSurvey = goToMostRequestedSurvey;
    }

    @Override
    public String toString() {
        return "SurveyForm [id=" + id + ", courseTitle=" + courseTitle + ", trainingVenue=" + trainingVenue
                + ", instructorName=" + instructorName + ", courseDateTime=" + courseDateTime
                + ", courseEndDate=" + courseEndDate + ", courseScheduleDetailId=" + courseScheduleDetailId
                + ", mdQuestion1=" + mdQuestion1 + ", mdQuestion2=" + mdQuestion2 + ", mdQuestion3="
                + mdQuestion3 + ", mdQuestion4=" + mdQuestion4 + ", matQuestion1=" + matQuestion1
                + ", matQuestion2=" + matQuestion2 + ", matQuestion3=" + matQuestion3 + ", matQuestion4="
                + matQuestion4 + ", insQuestion1=" + insQuestion1 + ", insQuestion2=" + insQuestion2
                + ", insQuestion3=" + insQuestion3 + ", insQuestion4=" + insQuestion4 + ", insQuestion5="
                + insQuestion5 + ", insQuestion6=" + insQuestion6 + ", eqFaQuestion1=" + eqFaQuestion1
                + ", eqFaQuestion2=" + eqFaQuestion2 + ", eqFaQuestion3=" + eqFaQuestion3 + ", commentsE="
                + commentsE + ", commentsF=" + commentsF + ", commentsG=" + commentsG
                + ",goToMostRequestedSurvey= " + goToMostRequestedSurvey + "]";
    }

}

package com.fujitsu.ph.tsup.attendance.model;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
/**
 * <pre>
 * 
 * In this class, List of Course Participants will be exported to pdf
 * </pre>
 * 
 * @version 0.01
 * @author an.wasawas
 *
 */
//==================================================================================================
//$Id:PR29$
//Project Name :Training Sign up
//System Name  :Instructor Conducted Course Participants Process
//Class Name   :PdfGenerator.java
//
//<<Modification History>>
//Version | Date       | Updated By                           | Content
//--------+------------+--------------------------------------+-------------------------------------
//0.01    | 11/03/2021 | WS) an.wasawas                      | New Creation
//==================================================================================================
public class PdfGenerator {
	
	
	/** Generates course participants into pdf */
	public static ByteArrayInputStream exportCourseParticipant(CourseParticipantsForm courseParticipant) {
		
		
		Document document = new Document();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		//yyyy/MM/dd - hh:mm a
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("MMM dd, yyyy (E) - hh:mm a");
		Date date=new Date();
		Instant instant=Instant.now();
		
		
		try {
			Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9.5f);
			Font headFont2 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9.0f);
			Font font = FontFactory.getFont(FontFactory.HELVETICA,8.5f);
			PdfPTable courseInfoTable1 = new PdfPTable(2);
			courseInfoTable1.setSpacingAfter(10.0f);
			courseInfoTable1.getDefaultCell().setBorder(0);
			courseInfoTable1.setWidthPercentage(94);
			courseInfoTable1.setWidths(new int[] {1,3});
			PdfPCell courseInfo = new PdfPCell(new Phrase("Course Name:", headFont2));
			courseInfo.setPadding(8.0f);
			courseInfo.setPaddingLeft(0);
			courseInfo.setBorder(Rectangle.NO_BORDER);
			courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
			courseInfo.setVerticalAlignment(Element.ALIGN_BOTTOM);
			courseInfoTable1.addCell(courseInfo);
			courseInfo = new PdfPCell(new Phrase(courseParticipant.getCourseName(),font));
			courseInfo.setPadding(8.0f);
			courseInfo.setBorder(Rectangle.NO_BORDER);
			courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
			courseInfo.setVerticalAlignment(Element.ALIGN_BOTTOM);
			courseInfoTable1.addCell(courseInfo);
			
		
			courseInfo = new PdfPCell(new Phrase("Instructor:", headFont2));
			courseInfo.setPadding(8.0f);
			courseInfo.setPaddingLeft(0);
			courseInfo.setBorder(Rectangle.NO_BORDER);
			courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
			courseInfo.setVerticalAlignment(Element.ALIGN_BOTTOM);
			courseInfoTable1.addCell(courseInfo);
			courseInfo = new PdfPCell(new Phrase(courseParticipant.getInstructorName(),font));
			courseInfo.setPadding(8.0f);
			courseInfo.setBorder(Rectangle.NO_BORDER);
			courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
			courseInfo.setVerticalAlignment(Element.ALIGN_BOTTOM);
			courseInfoTable1.addCell(courseInfo);
			
		
			
			PdfPTable courseInfoTable2 = new PdfPTable(3);
			courseInfoTable2.setSpacingAfter(10.0f);
			courseInfoTable2.getDefaultCell().setBorder(0);
			courseInfoTable2.setWidthPercentage(94);
			courseInfoTable2.setWidths(new int[] { 4, 4, 4 });
			int forEachIterator=0;
			for(CourseScheduleDetailForm course : courseParticipant.getCourseScheduleDetails()) {
				if(forEachIterator==0) {
					courseInfo = new PdfPCell(new Phrase("Start Date & Time", headFont2));
					courseInfo.setPadding(10.0f);
					courseInfo.setPaddingLeft(0);
					courseInfo.setPaddingTop(0);
					courseInfo.setBorder(Rectangle.NO_BORDER);
					courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
					courseInfoTable2.addCell(courseInfo);
					courseInfo = new PdfPCell(new Phrase("End Date & Time", headFont2));
					courseInfo.setPadding(10.0f);
					courseInfo.setPaddingLeft(0);
					courseInfo.setPaddingTop(0);
					courseInfo.setBorder(Rectangle.NO_BORDER);
					courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
					courseInfoTable2.addCell(courseInfo);
					courseInfo = new PdfPCell(new Phrase("Duration (in HRS):", headFont2));
					courseInfo.setPadding(10.0f);
					courseInfo.setPaddingLeft(0);
					courseInfo.setPaddingTop(0);
					courseInfo.setBorder(Rectangle.NO_BORDER);
					courseInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
					courseInfoTable2.addCell(courseInfo);
					
					
					instant=course.getScheduledStartDateTime().toInstant();
					date=Date.from(instant);
					
					
					courseInfo = new PdfPCell(new Phrase(simpleDateFormat.format(date),font));
					courseInfo.setPadding(15.0f);
					courseInfo.setPaddingTop(5.0f);
					courseInfo.setBorder(Rectangle.NO_BORDER);
					courseInfo.setHorizontalAlignment(Element.ALIGN_CENTER);
					courseInfoTable2.addCell(courseInfo);
					
					instant=course.getScheduledEndDateTime().toInstant();
					date=Date.from(instant);
					
					courseInfo = new PdfPCell(new Phrase(simpleDateFormat.format(date),font));
					courseInfo.setPadding(15.0f);
					courseInfo.setPaddingTop(5.0f);
					courseInfo.setBorder(Rectangle.NO_BORDER);
					courseInfo.setHorizontalAlignment(Element.ALIGN_CENTER);
					courseInfoTable2.addCell(courseInfo);
					courseInfo = new PdfPCell(new Phrase(Float.toString(course.getDuration()),font));
					courseInfo.setPadding(15.0f);
					courseInfo.setPaddingTop(5.0f);
					courseInfo.setBorder(Rectangle.NO_BORDER);
					courseInfo.setHorizontalAlignment(Element.ALIGN_CENTER);
					courseInfoTable2.addCell(courseInfo);
					forEachIterator++;
				}
			}
		
			
			PdfPTable courseParticipantsTable = new PdfPTable(3);
			courseParticipantsTable.setWidthPercentage(94);
			courseParticipantsTable.setWidths(new int[] { 4, 4, 4 });
			
			PdfPCell hcell;
			hcell = new PdfPCell(new Phrase("8-DIGIT EMPLOYEE ID NUMBER\n(If applicable)", headFont));
			hcell.setPadding(10.0f);
			hcell.setPaddingLeft(5.0f);
			hcell.setPaddingRight(5.0f);
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			courseParticipantsTable.addCell(hcell);
			Chunk fullName = new Chunk("PRINT FULLNAME",headFont);
		    fullName.setUnderline(0.5f, -1f); 
			
		    
		    Phrase phrase=new Phrase("PARTICIPANT'S NAME\n(Please ",headFont);
		    phrase.add(new Phrase(fullName));
		    phrase.add(new Phrase(new Chunk(")",headFont)));
			hcell = new PdfPCell(phrase);
			hcell.setPadding(10.0f);
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			courseParticipantsTable.addCell(hcell);
			hcell = new PdfPCell(new Phrase("E-MAIL ADDRESS", headFont));
			hcell.setPadding(10.0f);
			hcell.setPaddingTop(15.0f);
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			hcell.setVerticalAlignment(Element.ALIGN_CENTER);
			courseParticipantsTable.addCell(hcell);
			for (AttendanceParticipantDetail participant :courseParticipant.getParticipants()) {
				PdfPCell cell;
				cell = new PdfPCell(new Phrase(participant.getEmployeeNumber(),font));
				courseInfo.setPadding(5.0f);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				courseParticipantsTable.addCell(cell);
				cell = new PdfPCell(new Phrase(participant.getName(),font));
				courseInfo.setPadding(5.0f);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				courseParticipantsTable.addCell(cell);
				cell = new PdfPCell(new Phrase(String.valueOf(participant.getEmail()),font));
				courseInfo.setPadding(5.0f);
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				courseParticipantsTable.addCell(cell);
			}
			PdfWriter.getInstance(document, out);
			document.open();
			document.add(courseInfoTable1);
			document.add(courseInfoTable2);
			document.add(courseParticipantsTable);
			document.close();
		} catch (DocumentException ex) {
			//ignore
			//already has error fallback page
		}
		return new ByteArrayInputStream(out.toByteArray());
	}
}
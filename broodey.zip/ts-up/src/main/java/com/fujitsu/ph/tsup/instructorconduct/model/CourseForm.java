package com.fujitsu.ph.tsup.instructorconduct.model;

import java.util.Objects;

//=======================================================
//$Id: PR17$
//Project Name: Training Sign Up
//Class Name: CourseForm.java
//
//<<Modification History>>
//Version | Date       | Updated by      | Content
//--------+------------+-----------------+---------------
//0.01    | 08/01/2021 | WS) J.Lanaja    | New Creation
//0.02    | 10/25/2021 | WS) L.celoso    | Add sorting by date
//=======================================================

/**
* <pre>
* JavaBean for CourseForm
* <pre>
* @version 0.01
* @author j.lanaja
*
*/

public class CourseForm {
    
    /**
     * Course Id 
     */
    private Long id;
    
    /**
     * Course Name
     */
    private String name;
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Long getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public static int sortedByStartDate (CourseForm courseForm1, CourseForm courseForm2) {
        Objects.requireNonNull(courseForm1);
        Objects.requireNonNull(courseForm2);
        
        return courseForm1.getName().compareTo(courseForm2.getName());
    }
    
    @Override
    public String toString() {
        return "CourseForm [id = " + id + ", name = " + name + "]";
    }
}

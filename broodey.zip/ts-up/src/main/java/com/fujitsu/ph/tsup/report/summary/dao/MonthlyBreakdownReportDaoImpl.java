//==================================================================================================
// Project Name : Training Sign-Up
// System Name  : MonthlyBreakdownReportDaoImpl
// Class Name   : MonthlyBreakdownReportDaoImpl.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/10/26 | WS) d.dinglasan       | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.ZonedDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.course.dao.CoursesConductedRowMapper;
import com.fujitsu.ph.tsup.course.model.CoursesConducted;

/**
  *<pre>
  * Put Class Description here
  *</pre>
  *
  * @version 0.01
  * @author WS) d.dinglasan 
  */
@Repository
public class MonthlyBreakdownReportDaoImpl implements MonthlyBreakdownReportDao {

    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(MonthlyBreakdownReportDaoImpl.class);
    
    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;
    
    /**
     * JDBC Template
     */
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    /* (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.dao.MonthlyBreakdownReportDao#findAllConductedCoursesWithinPeriod(java.time.ZonedDateTime, java.time.ZonedDateTime)
     */
    @Override
    public Set<CoursesConducted> findAllConductedCoursesWithinPeriod(ZonedDateTime startDateTime,
            ZonedDateTime endDateTime) {
        
        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("SELECT ");
        queryBuilder.append("csd.id AS id, ");
        queryBuilder.append("c.name AS course_name, ");
        queryBuilder.append("csd.scheduled_start_datetime AS scheduled_start_datetime, ");
        queryBuilder.append("csd.scheduled_end_datetime AS scheduled_end_datetime, ");
        queryBuilder.append("COALESCE(csd.rescheduled_start_datetime, csd.scheduled_start_datetime) as rescheduled_start_datetime, ");
        queryBuilder.append("COALESCE(csd.rescheduled_end_datetime, csd.scheduled_end_datetime) as rescheduled_end_datetime, ");
        queryBuilder.append("(SELECT COUNT(*) FROM tsup.course_attendance ca ");
        queryBuilder.append("WHERE ca.course_schedule_detail_id = csd.id) AS no_of_participants ");
        queryBuilder.append("FROM tsup.course_schedule_detail AS csd ");
        queryBuilder.append("INNER JOIN tsup.course_schedule AS cs ON cs.id = csd.course_schedule_id ");
        queryBuilder.append("INNER JOIN tsup.course AS c ON c.id = cs.course_id ");
        queryBuilder.append("WHERE COALESCE(csd.rescheduled_start_datetime, csd.scheduled_start_datetime) ");
        queryBuilder.append("BETWEEN :startDateTime AND :endDateTime ");
        queryBuilder.append("AND cs.status = 'D' ");
        queryBuilder.append("ORDER BY scheduled_start_datetime asc, course_name asc;");
        
        SqlParameterSource mapSqlParameterSource = new MapSqlParameterSource()
                .addValue("startDateTime", startDateTime.toOffsetDateTime())
                .addValue("endDateTime", endDateTime.toOffsetDateTime());

        List<CoursesConducted> conductedCourseList = template.query(queryBuilder.toString(),
                mapSqlParameterSource, new CoursesConductedRowMapper());
        Set<CoursesConducted> conductedCourseSet = new LinkedHashSet<>(conductedCourseList);

        logger.debug("Result: {}", conductedCourseSet);

        return conductedCourseSet;
    }

    /* (non-Javadoc)
     * @see com.fujitsu.ph.tsup.report.summary.dao.MonthlyBreakdownReportDao#getStartYear()
     */
    @Override
    public int getStartYear() {
        
        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("SELECT EXTRACT(YEAR FROM csd.scheduled_start_datetime) AS start_year ");
        queryBuilder.append("FROM tsup.course_schedule_detail csd ");
        queryBuilder.append("ORDER BY csd.scheduled_start_datetime ASC ");
        queryBuilder.append("LIMIT 1;");
        
        Integer result = jdbcTemplate.queryForObject(queryBuilder.toString(), Integer.class);
        logger.debug("Result: {}", result);
        
        return (result == null) ? 0 : result;
    }

}

package com.fujitsu.ph.tsup.tms.web;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.ph.tsup.attendance.domain.CourseAttendance;
import com.fujitsu.ph.tsup.survey.model.SurveyForm;
import com.fujitsu.ph.tsup.survey.service.SurveyFormService;
import com.fujitsu.ph.tsup.survey.web.SurveyFormController;
import com.fujitsu.ph.tsup.tms.model.CheckFiles;
import com.fujitsu.ph.tsup.tms.model.Completed;
import com.fujitsu.ph.tsup.tms.model.CourseStatus;
import com.fujitsu.ph.tsup.tms.model.CourseStatusDetails;
import com.fujitsu.ph.tsup.tms.model.Course;
import com.fujitsu.ph.tsup.tms.model.Employee;
import com.fujitsu.ph.tsup.tms.model.IncompleteTraining;
import com.fujitsu.ph.tsup.tms.model.Masterlist;
import com.fujitsu.ph.tsup.tms.model.NotRegistered;
import com.fujitsu.ph.tsup.tms.model.OverallSummaryReport;
import com.fujitsu.ph.tsup.tms.model.PullDownOptions;
import com.fujitsu.ph.tsup.tms.model.SummaryReport;
import com.fujitsu.ph.tsup.tms.service.ExcelExportService;
import com.fujitsu.ph.tsup.tms.service.TmsService;

//===================================================================================================================
//
//Project Name : Training Management Service
//System Name : TMS Main
//Class Name : TmsController.java
//
//<<Modification History>>
//Version | Date | Updated By | Content
//--------+------------+-------------------------------------------------------------------------+-------------------
//0.01 | 05/27/2024 | WS) An.Wasawas | New Creation
//===================================================================================================================
/**
 * <pre>
* It is the implementation of Training Management Service
* In this class, it implements the TmsController class for the initial setting of the database
 * </pre>
 * 
 * @version 0.01
 * @author an.wasawas
 */

@Controller
@RequestMapping("/tms")
public class TmsController {

	/*
	 * <pre> Useful methods for logging and also decouple the logging implementation
	 * from application <pre>
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TmsController.class);

	TmsService tmsService = new TmsService();
	private List<Course> masterList;

	/*
	 * add details of module
	 */
	@GetMapping("/completedlist")
	public String showCompleted(Model model, @RequestParam(value = "p", defaultValue = "1") int currentPage)
			throws Exception {

		int rowsPerPage = 10; // rows shown on the table per page
		List<Completed> cList = tmsService.readCompletedlist();
		int totalRows = cList.size();
		int totalPages = (int) Math.ceil((double) totalRows / rowsPerPage); // adjust this to your total number of pages
		int start = (currentPage - 1) * rowsPerPage;
		int end = Math.min(start + rowsPerPage, totalRows);
		System.out.println(String.format("%d %d %d", totalPages, totalRows, rowsPerPage));

		List<Completed> completedlistPaged = cList.subList(start, end);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("completedlistPaged", completedlistPaged);
		return "tms/completed.html";

	}

	/*
	 * add details of module
	 */
	@GetMapping("/notregistered")
	public String showNotRegistered(@RequestParam(value = "p", defaultValue = "1") int currentPage, Model model)
			throws Exception {
		int rowsPerPage = 10; // rows shown on the table per page
		List<NotRegistered> nrEmployees = tmsService.readNotRegistered();
		int totalRows = nrEmployees.size();
		int totalPages = (int) Math.ceil((double) totalRows / rowsPerPage); // adjust this to your total number of pages
		int start = (currentPage - 1) * rowsPerPage;
		int end = Math.min(start + rowsPerPage, totalRows);
		System.out.println(String.format("%d %d %d", totalPages, totalRows, rowsPerPage));

		List<NotRegistered> pageEmployees = nrEmployees.subList(start, end);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("notregistered", pageEmployees);

		return "tms/notRegistered.html";
	}

	/*
	 * add details of module
	 */
	@Autowired
	private ExcelExportService excelExportService;

	/*
	 * add details of module
	 */
	@GetMapping("/summaryreport")
	public String showSummaryReport(Model model) throws Exception {
		List<IncompleteTraining> notcompletedEmployees = tmsService.readIncompleteTraining();
		return "tms/summaryReport.html";
	}

	/*
	 * add details of module
	 */
	@GetMapping("/summaryreport/data")
	public ResponseEntity<String> getData() throws Exception {
		OverallSummaryReport summaryReport = tmsService.readSummaryReport();
		return ResponseEntity.ok(tmsService.summaryReportDataFormatter(summaryReport).toString());
	}

	@GetMapping("/summaryreport/filtereddata")
	public ResponseEntity<String> getFilteredData(String manager, String course) throws Exception {

		List<CourseStatusDetails> summaryReport = tmsService.getFilteredData(manager, course);
		return ResponseEntity.ok(tmsService.filteredtDataFormatter(summaryReport).toString());
	}

	@GetMapping("/summaryreport/getpulldownoptions")
	public ResponseEntity<String> getPullDownOptions(String manager, String course) throws Exception {

		PullDownOptions pullDownOptions = tmsService.getPullDownOptions();
		return ResponseEntity.ok(tmsService.pullDownDataFormatter(pullDownOptions).toString());
	}

	/*
	 * add details of module
	 */
	@GetMapping("/incompleteTraining")

	public String showIncompleteTraining(@RequestParam(value = "p", defaultValue = "1") int currentPage
	// @RequestParam(required=false, value = "export", defaultValue = "a") String
	// export
			, Model model) throws Exception {
		int rowsPerPage = 10; // rows shown on the table per page
		List<IncompleteTraining> incEmployees = tmsService.readIncompleteTraining();
		int totalRows = incEmployees.size();
		int totalPages = (int) Math.ceil((double) totalRows / rowsPerPage); // adjust this to your total number of pages
		int start = (currentPage - 1) * rowsPerPage;
		int end = Math.min(start + rowsPerPage, totalRows);
		System.out.println(String.format("%d %d %d", totalPages, totalRows, rowsPerPage));

		List<IncompleteTraining> pageEmployees = incEmployees.subList(start, end);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("incompletetraining", pageEmployees);

		return "tms/incompleteTraining.html";

	}

	@GetMapping("/notregistered/export")
	public void exportToExcel(HttpServletResponse response,
			@RequestParam(required = false, defaultValue = "false") String export) throws Exception {
		List<NotRegistered> dataList = new ArrayList<>();
		if ("all".equalsIgnoreCase(export)) {
			dataList = tmsService.readNotRegistered();
		} else {
			/*
			 * Implement paginated table to export dataList =
			 * tmsService.readNotRegistered();
			 */
		}

		excelExportService.export(response, dataList, "List of Not Registered Employee.xlsx");
	}

	/*
	 * add details of module
	 */
	@GetMapping("/completedlist/export")
	public void exportToExcelCompleted(HttpServletResponse response,
			@RequestParam(required = false, defaultValue = "false") String exports) throws Exception {
		List<Completed> dataList = new ArrayList<>();
		if ("all".equalsIgnoreCase(exports)) {
			dataList = tmsService.readCompletedlist();
		} else {

		}

		excelExportService.exportCompleted(response, dataList, "List of Completed Trainings List.xlsx");
	}

	@GetMapping("/masterlist")
	public String showMasterList(Model model, @RequestParam(value = "p", defaultValue = "1") int currentPage)
			throws Exception {
		if (masterList == null) {
			masterList = tmsService.readMasterlist();
		}
		int rowsPerPage = 10; // rows shown on the table per page
		int totalRows = masterList.size();
		int totalPages = (int) Math.ceil((double) totalRows / rowsPerPage); // adjust this to your total number of pages
		int start = (currentPage - 1) * rowsPerPage;
		int end = Math.min(start + rowsPerPage, totalRows);
		System.out.println(String.format("%d %d %d", totalPages, totalRows, rowsPerPage));

		List<Course> masterlistPaged = masterList.subList(start, end);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("masterlistEmpCourse", masterlistPaged);
		return "tms/masterlist.html";
	}

	@GetMapping("/masterlist/export")
	public void exportMasterlist(HttpServletResponse response,
			@RequestParam(required = false, defaultValue = "false") String export) throws Exception {
		List<Course> dataList = new ArrayList<>();
		List<Employee> listOfEmployee = new ArrayList<>();
		if ("all".equalsIgnoreCase(export)) {
			listOfEmployee = tmsService.masterEmployeeDetails;
			dataList = masterList;
		} else {
			/*
			 * Implement paginated table to export dataList =
			 * tmsService.readNotRegistered();
			 */
		}
		String today = new SimpleDateFormat("MM_dd_yyyy").format(new Date());

		excelExportService.exportMasterlist(response, masterList, listOfEmployee,
				String.format("TMR [Masterlist] [%s].xlsx", today));
	}

	/*
	 * TMS Landing Page Controller
	 */
	@GetMapping("/tmsindex")
	public String checkRequiredFiles(Model model) throws IOException {
		CheckFiles chkfiles = tmsService.checkRequiredFiles();
		model.addAttribute("checkedFiles", chkfiles);
		if (chkfiles.isDisableMenu()) {
			return "tms/tmsIndex.html";
		} else {
			return "tms/summaryReport.html";
		}

	}

}
/**
 * Copyright (C) 2019 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.enrollment.domain;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

//==================================================================================================
//Project Name : Training Sign Up
//Class Name   : ParticipantTrainingPeriod.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/07/16 | WS) mi.aguinaldo      | Initial Version
//==================================================================================================


public class ParticipantTrainingPeriod {
    
    private Long participantId;
    
    private ZonedDateTime fromDateTime;
	
    private ZonedDateTime toDateTime;
    

    /**
     * 
     */
    public ParticipantTrainingPeriod() {
	super();
    }

    /**
     * @param participantId
     * @param fromDateTime
     * @param toDateTime
     */
    public ParticipantTrainingPeriod(Long participantId, ZonedDateTime fromDateTime, ZonedDateTime toDateTime) {
	super();
	this.participantId = participantId;
	this.fromDateTime = fromDateTime;
	this.toDateTime = toDateTime;
    }

    /**
     * @return the participantId
     */
    public Long getParticipantId() {
        return participantId;
    }

    /**
     * @param participantId the participantId to set
     */
    public void setParticipantId(Long participantId) {
        this.participantId = participantId;
    }

    /**
     * @return the fromDateTime
     */
    public ZonedDateTime getFromDateTime() {
        return fromDateTime;
    }

    /**
     * @param fromDateTime the fromDateTime to set
     */
    public void setFromDateTime(ZonedDateTime fromDateTime) {
        this.fromDateTime = fromDateTime;
    }

    /**
     * @return the toDateTime
     */
    public ZonedDateTime getToDateTime() {
        return toDateTime;
    }

    /**
     * @param toDateTime the toDateTime to set
     */
    public void setToDateTime(ZonedDateTime toDateTime) {
        this.toDateTime = toDateTime;
    }
    
    public OffsetDateTime getFromDateTimeTimezoneOnUTC() {
	return fromDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime();
    }
    
    public OffsetDateTime getToDateTimeTimezoneOnUTC() {
	return toDateTime.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime();
    }
    
}

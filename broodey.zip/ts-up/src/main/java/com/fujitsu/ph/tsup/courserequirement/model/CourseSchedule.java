package com.fujitsu.ph.tsup.courserequirement.model;

import java.time.ZonedDateTime;

import com.fujitsu.ph.tsup.course.model.Course;
import com.fujitsu.ph.tsup.venue.domain.Venue;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : CourseChecklist
 * Class Name   : CourseSchedule.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * 0.02    | 2021/11/10 | WS) je.subelario      | Revised Comments
* ===================================================================================================
 */

 /**
 * <pre>
 * The model for Course Schedule
 * 
 * <pre>
 * 
 * @version 0.02
 * @author je.subelario 
 */

public class CourseSchedule {
    private Integer id;
    private Course course;
    private Integer instructorId;
    private Venue venue;
    private Integer minRequired;
    private Integer maxRequired;
    private ZonedDateTime registrationDate;
    private Employee participant;
    private String status;

    public CourseSchedule() {
    }

    public CourseSchedule(Integer id, Course course, Integer instructorId, Venue venue, Integer minRequired,
            Integer maxRequired, ZonedDateTime registrationDate, Employee participant, String status) {
        this.id = id;
        this.course = course;
        this.instructorId = instructorId;
        this.venue = venue;
        this.minRequired = minRequired;
        this.maxRequired = maxRequired;
        this.registrationDate = registrationDate;
        this.participant = participant;
        this.status = status;
    }
    


    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Course getCourse() {
        return course;
    }
    public void setCourse(Course course) {
        this.course = course;
    }
    public Integer getInstructorId() {
        return instructorId;
    }
    public void setInstructorId(Integer instructorId) {
        this.instructorId = instructorId;
    }
    public Venue getVenue() {
        return venue;
    }
    public void setVenue(Venue venue) {
        this.venue = venue;
    }
    public Integer getMin_required() {
        return minRequired;
    }
    public void setMin_required(Integer min_required) {
        this.minRequired = min_required;
    }
    public Integer getMax_required() {
        return maxRequired;
    }
    public void setMax_required(Integer max_required) {
        this.maxRequired = max_required;
    }
    public ZonedDateTime getRegistration_date() {
        return registrationDate;
    }
    public void setRegistration_date(ZonedDateTime registration_date) {
        this.registrationDate = registration_date;
    }
    public Employee getParticipant() {
        return participant;
    }
    public void setParticipant(Employee participant) {
        this.participant = participant;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    
}

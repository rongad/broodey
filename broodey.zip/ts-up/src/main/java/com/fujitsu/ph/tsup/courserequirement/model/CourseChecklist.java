/*
 *Copyright (C) 2020 FUJITSU LIMITED All rights reserved. 
 */
package com.fujitsu.ph.tsup.courserequirement.model;

import com.fujitsu.ph.tsup.course.model.Course;

/**
 * ==================================================================================================
 * Project Name : Training Sign Up
 * System Name  : CourseChecklist
 * Class Name   : CourseChecklist.java
 * 
 * <<Modification History>>
 * Version | Date       | Updated By            | Content
 * --------+------------+-----------------------+-----------------------------------------------------
 * 0.01    | 2021/10/18 | WS) e.delosreyes      | Initial Version
 * 0.02    | 2021/11/10 | WS) je.subelario      | Revised Comments
 * ===================================================================================================
 */

 /**
 * <pre>
 * The model for Course Checklist
 * 
 * <pre>
 * 
 * @version 0.02
 * @author je.subelario 
 */

public class CourseChecklist {
	private Integer id;
	private Integer courseId;
	private String requirement;
	private Course course;
	

	/**
	 * Default Constructor
	 */
	public CourseChecklist() {
	}

	/**
	 * Parameterized constructor
	 * @param id
	 * @param courseId
	 * @param requirement
	 * @param course
	 */
	public CourseChecklist(Integer id, String requirement, Course course) {
		this.id = id;
		this.requirement = requirement;
		this.course = course;
	}



	/**
	 * @param id
	 * @param requirement
	 * @param course
	 */
	private CourseChecklist(Builder builder) {
		this.id = builder.id;
		this.courseId=builder.courseId;
		this.requirement = builder.requirement;
		this.course = builder.course;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	public Integer getCourseId() {
		return courseId;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the requirement
	 */
	public String getRequirement() {
		return requirement;
	}

	/**
	 * @param requirement the requirement to set
	 */
	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	/**
	 * @return the course
	 */
	public Course getCourse() {
		return course;
	}

	/**
	 * @param course the course to set
	 */
	public void setCourse(Course course) {
		this.course = course;
	}

	public static Builder builder() {
		return new Builder();
	}

	public static final class Builder {
		private Integer id;
		private Integer courseId;
		private String requirement;
		private Course course;

		private Builder() {
		}

		public CourseChecklist build() {
			return new CourseChecklist(this);
		}

		public Builder withId(Integer id) {
			this.id = id;
			return this;
		}

		public Builder withRequirement(String requirement) {
			this.requirement = requirement;
			return this;
		}

		public Builder withCourse(Course course) {
			this.course = course;
			return this;
		}
		
		public Builder withCoursId(Integer courseId) {
			this.courseId= courseId;
			return this;
		}

	}

}

//==================================================================================================
// Project Name : Training Sign-Up
// System Name : MemberNonMandatoryCoursesCompletionForm
// Class Name : MemberNonMandatoryCoursesCompletionForm.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01 | 2021/10/05 | WS) d.dinglasan | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.model;

import java.util.List;

/**
 * <pre>
 * Put Class Description here
 * </pre>
 *
 * @version 0.01
 * @author WS) d.dinglasan
 */
public class MemberNonMandatoryCoursesCompletionForm {

    /**
     * Contains course category id, name, and course names
     */
    private CourseCategory courseCategory;

    /**
     * List of all members
     */
    private List<AttendeeForm> memberList;

    /**
     * @return the courseCategory
     */
    public CourseCategory getCourseCategory() {
        return courseCategory;
    }

    /**
     * @param courseCategory the courseCategory to set
     */
    public void setCourseCategory(CourseCategory courseCategory) {
        this.courseCategory = courseCategory;
    }

    /**
     * @return the memberList
     */
    public List<AttendeeForm> getMemberList() {
        return memberList;
    }

    /**
     * @param memberList the memberList to set
     */
    public void setMemberList(List<AttendeeForm> memberList) {
        this.memberList = memberList;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "MemberNonMandatoryCoursesCompletionForm [courseCategory=" + courseCategory + ", memberList="
                + memberList + "]";
    }

}

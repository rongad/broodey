//==================================================================================================                                                                                                                                                                            
// Project Name : Training Sign Up
// System Name  : Reports                                                                                                                                                          
// Class Name   : ReportForTrainingRequestDaoImpl.java                                                                                                                                                                          
//                                                                                                                                                                          
// <<Modification History>>                                                                                                                                                                             
// Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
// 0.1     | 08/17/2021 | WS) L.Celoso          | New Creation  
// 0.2     | 09/07/2021 | WS) L.Celoso          | Added alias to [Status]
//==================================================================================================     
package com.fujitsu.ph.tsup.report.summary.dao;

import java.time.ZoneId;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.training.request.dao.TrainingRequestRowMapper;
import com.fujitsu.ph.tsup.training.request.domain.TrainingRequest;
import com.fujitsu.ph.tsup.training.request.model.TrainingRequestSearchForm;

@Repository
public class ReportForTrainingRequestDaoImpl implements ReportForTrainingRequestDao {
	
	/**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(ReportForTrainingRequestDaoImpl.class);
    
    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;

    /**
     *  Find all training requests
     * @return Set of Training Request
     */
    @Override
    public Set<TrainingRequest> findAllTrainingRequest(TrainingRequestSearchForm trainingRequestSearchForm) {
            
        String query = "SELECT TR.id As TR_ID, "
				+ "	TR.employee_id AS EMPLOYEE_ID,"
				+ " TR.course_name AS COURSE_NAME,"
				+ " TR.min_required AS MIN_PARTICIPANTS,"
				+ " TR.max_allowed AS MAX_PARTICIPANTS,"
				+ " TR.scheduled_start_datetime AS START_DATETIME,"
				+ " TR.scheduled_end_datetime AS END_DATETIME,"
				+ " TR.duration AS DURATION,"
				+ " TR.status AS REQUEST_STATUS,"
				+ " TR.remarks AS COURSE_DETAILS, "
				+ " CONCAT(E.LAST_NAME,', ',E.FIRST_NAME) AS REQUESTER_NAME, "
				+ " CASE WHEN (TR.APPROVER_ID is NULL) THEN '-' ELSE CONCAT(A.LAST_NAME,', ',A.FIRST_NAME) END AS APPROVER_NAME, "
				+ " TR.approver_remarks AS APPROVER_REMARKS "
				+ "FROM TRAINING_REQUEST TR "
				+ " INNER JOIN EMPLOYEE E ON E.id = TR.employee_id "
				+ " LEFT JOIN EMPLOYEE A ON A.id = TR.approver_id "
				+ "WHERE COALESCE(TR.scheduled_start_datetime, TR.scheduled_end_datetime) "
				+ " BETWEEN :fromDateTime AND :toDateTime"
				+ " AND TR.status LIKE (:status) "
				+ " UNION "
				+ " SELECT TRA.training_request_id As TR_ID, "
				+ "	TRA.employee_id AS EMPLOYEE_ID,"
				+ " TRA.course_name AS COURSE_NAME,"
				+ " TRA.min_required AS MIN_PARTICIPANTS,"
				+ " TRA.max_allowed AS MAX_PARTICIPANTS,"
				+ " TRA.scheduled_start_datetime AS START_DATETIME,"
				+ " TRA.scheduled_end_datetime AS END_DATETIME,"
				+ " TRA.duration AS DURATION,"
				+ " TRA.status AS REQUEST_STATUS,"
				+ " TRA.remarks AS COURSE_DETAILS, "
				+ " CONCAT(E.LAST_NAME,', ',E.FIRST_NAME) AS REQUESTER_NAME, "
				+ " CASE WHEN (TRA.APPROVER_ID is NULL) THEN '-' ELSE CONCAT(A.LAST_NAME,', ',A.FIRST_NAME) END AS APPROVER_NAME, "
				+ " TRA.approver_remarks AS APPROVER_REMARKS "
				+ "FROM TRAINING_REQUEST_ARCHIVE TRA "
				+ " INNER JOIN EMPLOYEE E ON E.id = TRA.employee_id "
				+ " LEFT JOIN EMPLOYEE A ON A.id = TRA.approver_id "
				+ "WHERE COALESCE(TRA.scheduled_start_datetime, TRA.scheduled_end_datetime) "
				+ " BETWEEN :fromDateTime AND :toDateTime"
				+ " AND TRA.status LIKE (:status) ";                                                                                    
        
        SqlParameterSource trainingRequestParameters = new MapSqlParameterSource()
				.addValue("fromDateTime", trainingRequestSearchForm.getSearchStartDateTimeZone()
							.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
				.addValue("toDateTime", trainingRequestSearchForm.getSearchEndDateTimeZone()
							.withZoneSameInstant(ZoneId.of("UTC")).toOffsetDateTime())
				.addValue("status", trainingRequestSearchForm.getStatus());
        
        List<TrainingRequest> trainingRequest = template.query(query, trainingRequestParameters, new TrainingRequestRowMapper());
        Set<TrainingRequest> trainingRequestSet = new LinkedHashSet<>(trainingRequest);

        logger.debug("Result: {}", trainingRequestSet);
        return trainingRequestSet;

    }
 
}

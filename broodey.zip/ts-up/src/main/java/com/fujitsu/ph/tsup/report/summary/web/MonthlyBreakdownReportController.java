//==================================================================================================
// Project Name : Training Sign-Up
// System Name  : MonthlyBreakdownReportController
// Class Name   : MonthlyBreakdownReportController.java

// <<Modification History>>
// Version | Date       | Updated By            | Content
//---------+------------+-----------------------+---------------------------------------------------
// 0.01    | 2021/10/26 | WS) d.dinglasan       | New Creation
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.web;

import java.time.ZonedDateTime;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fujitsu.ph.tsup.course.model.CoursesConducted;
import com.fujitsu.ph.tsup.report.summary.service.MonthlyBreakdownReportService;

/**
  *<pre>
  * Controller for
  * monthly breakdown report of conducted courses
  *</pre>
  *
  * @version 0.01
  * @author WS) d.dinglasan 
  */

@Controller
@RequestMapping("/report/summary")
public class MonthlyBreakdownReportController {

    /**
     * Logger Factory
     */
    private static Logger logger = LoggerFactory.getLogger(MonthlyBreakdownReportController.class);
    
    private static final String MONTHLY_BREAKDOWN_REPORT_PAGE = "reports/monthlyReport";
    
    @Autowired
    private MonthlyBreakdownReportService monthlyBreakdownReportService;
    
    @GetMapping("/monthlyBreakdown")
    public String viewMonthlyBreakdownReport(
            @RequestParam(value = "month", required = false, defaultValue = "0") Integer month,
            @RequestParam(value = "year", required = false, defaultValue = "0") Integer year, Model model) {
        
        int monthValue = (month.equals(0)) ? ZonedDateTime.now().getMonthValue() : month;
        int yearValue = year;
        
        if (year.equals(0)) {
            yearValue = ZonedDateTime.now().getYear();
            
            final int START_YEAR = monthlyBreakdownReportService.getStartYear();
            model.addAttribute("startYear", START_YEAR);
            logger.debug("Earliest year: {}", START_YEAR);
        }
        
        logger.debug("Month: {}", monthValue);
        logger.debug("Year: {}", yearValue);
        
        Set<CoursesConducted> conductedCourseSet = monthlyBreakdownReportService
                .findAllConductedCoursesWithinPeriod(monthValue, yearValue);
        
        model.addAttribute("month", monthValue);
        model.addAttribute("year", yearValue);
        model.addAttribute("conductedCourseSet", conductedCourseSet);
        
        return MONTHLY_BREAKDOWN_REPORT_PAGE;
    }
    
    
}

/*
 * Copyright (C) 2021 FUJITSU LIMITED All rights reserved.
 */    
package com.fujitsu.ph.tsup.viewsurveyrate.model;

//==================================================================================================                                                                                                                                                                            
//Project Name : Training Sign Up
//System Name  : SurveyRate                                                                                                                                                              
//Class Name   : SurveyRate.java                                                                                                                                                                          
//                                                                                                                                                                     
//<<Modification History>>                                                                                                                                                                             
//Version | Date       | Updated By            | Content                                                                                                                                                                           
//---------+------------+-----------------------+---------------------------------------------------                                                                                                                                                                            
//1.0.0   | 2021/08/16 | WS)E.Juan             | New Creation    


public class SurveyRate {
    
    private long id;
    private int mdQuestion1;
    private int mdQuestion2;
    private int mdQuestion3;
    private int mdQuestion4;
    
    private int matQuestion1;
    private int matQuestion2;
    private int matQuestion3;
    private int matQuestion4;
   
    private int insQuestion1;
    private int insQuestion2;
    private int insQuestion3;
    private int insQuestion4;
    private int insQuestion5;
    private int insQuestion6;
     
    private int eqFaQuestion1;
    private int eqFaQuestion2;
    private int eqFaQuestion3;
    private String commentsE;
    private String commentsF;
    private String commentsG;
   
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getMdQuestion1() {
        return mdQuestion1;
    }

    public void setMdQuestion1(int mdQuestion1) {
        this.mdQuestion1 = mdQuestion1;
    }

    public int getMdQuestion2() {
        return mdQuestion2;
    }

    public void setMdQuestion2(int mdQuestion2) {
        this.mdQuestion2 = mdQuestion2;
    }

    public int getMdQuestion3() {
        return mdQuestion3;
    }

    public void setMdQuestion3(int mdQuestion3) {
        this.mdQuestion3 = mdQuestion3;
    }

    public int getMdQuestion4() {
        return mdQuestion4;
    }

    public void setMdQuestion4(int mdQuestion4) {
        this.mdQuestion4 = mdQuestion4;
    }

    public int getMatQuestion1() {
        return matQuestion1;
    }

    public void setMatQuestion1(int matQuestion1) {
        this.matQuestion1 = matQuestion1;
    }

    public int getMatQuestion2() {
        return matQuestion2;
    }

    public void setMatQuestion2(int matQuestion2) {
        this.matQuestion2 = matQuestion2;
    }

    public int getMatQuestion3() {
        return matQuestion3;
    }

    public void setMatQuestion3(int matQuestion3) {
        this.matQuestion3 = matQuestion3;
    }

    public int getMatQuestion4() {
        return matQuestion4;
    }

    public void setMatQuestion4(int matQuestion4) {
        this.matQuestion4 = matQuestion4;
    }

    public int getInsQuestion1() {
        return insQuestion1;
    }

    public void setInsQuestion1(int insQuestion1) {
        this.insQuestion1 = insQuestion1;
    }

    public int getInsQuestion2() {
        return insQuestion2;
    }

    public void setInsQuestion2(int insQuestion2) {
        this.insQuestion2 = insQuestion2;
    }

    public int getInsQuestion3() {
        return insQuestion3;
    }

    public void setInsQuestion3(int insQuestion3) {
        this.insQuestion3 = insQuestion3;
    }

    public int getInsQuestion4() {
        return insQuestion4;
    }

    public void setInsQuestion4(int insQuestion4) {
        this.insQuestion4 = insQuestion4;
    }

    public int getInsQuestion5() {
        return insQuestion5;
    }

    public void setInsQuestion5(int insQuestion5) {
        this.insQuestion5 = insQuestion5;
    }

    public int getInsQuestion6() {
        return insQuestion6;
    }

    public void setInsQuestion6(int insQuestion6) {
        this.insQuestion6 = insQuestion6;
    }

    public int getEqFaQuestion1() {
        return eqFaQuestion1;
    }

    public void setEqFaQuestion1(int eqFaQuestion1) {
        this.eqFaQuestion1 = eqFaQuestion1;
    }

    public int getEqFaQuestion2() {
        return eqFaQuestion2;
    }

    public void setEqFaQuestion2(int eqFaQuestion2) {
        this.eqFaQuestion2 = eqFaQuestion2;
    }

    public int getEqFaQuestion3() {
        return eqFaQuestion3;
    }

    public void setEqFaQuestion3(int eqFaQuestion3) {
        this.eqFaQuestion3 = eqFaQuestion3;
    }

    public String getCommentsE() {
        return commentsE;
    }

    public void setCommentsE(String commentsE) {
        this.commentsE = commentsE;
    }

    public String getCommentsF() {
        return commentsF;
    }

    public void setCommentsF(String commentsF) {
        this.commentsF = commentsF;
    }

    public String getCommentsG() {
        return commentsG;
    }

    public void setCommentsG(String commentsG) {
        this.commentsG = commentsG;
    }
    

    
    @Override
    public String toString() {
        return "SurveyRateForm [id=" + id + "mdQuestion1="+ mdQuestion1 + ",mdQuestion2=" + mdQuestion2 + "mdQuestion3=" + mdQuestion3 
                + ",mdQuestion4=" + mdQuestion4 + ",matQuestion1=" + matQuestion1 
                + ",matQuestion2=" + matQuestion2 + ",matQuestion3=" + matQuestion3 + ",matQuestion4=" + matQuestion4 + ",insQuestion1=" + insQuestion1 + ",insQuestion2=" + insQuestion2
                + ",insQuestion3=" + insQuestion3 + ",insQuestion4=" + insQuestion4 + ",insQuestion5=" + insQuestion5 + ",insQuestion6=" + insQuestion6 + ",eqFaQuestion1=" + eqFaQuestion1
                + ",eqFaQuestion2=" + eqFaQuestion2 + ",eqFaQuestion3=" + eqFaQuestion3 + ",commentsE=" + commentsE + ",commentsF=" + commentsF + ",commentsG=" + commentsG + "]";
        
        
    }
    
    
     
}

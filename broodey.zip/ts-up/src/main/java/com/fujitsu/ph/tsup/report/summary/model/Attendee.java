//==================================================================================================
//Project Name : Training Sign Up
//System Name  : Attendee
//Class Name   : Attendee.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/07/02 | WS) L.Celoso          | Initial Version
// 0.02 | 2021/10/06 | WS) D.Dinglasan | Add last date attended
//==================================================================================================
package com.fujitsu.ph.tsup.report.summary.model;

public class Attendee {
	
	 /**
     * Course ID
     */
    private Long courseId;

    /**
     * Course name
     */
    private String courseName;
    
	 /**
     * Employee ID
     */
    private Long employeeId;
    
    /**
     * Employee Name
     */
    private String employeeName;
    
    /**
     * Date attended
     */
    private String dateAttended;

    public Long getId() {
        return courseId;
    }

    public void setId(Long courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }
    
    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
    
    /**
     * @return the dateAttended
     */
    public String getDateAttended() {
        return dateAttended;
    }

    /**
     * @param dateAttended the dateAttended to set
     */
    public void setDateAttended(String dateAttended) {
        this.dateAttended = dateAttended;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Attendee [courseId=" + courseId + ", courseName=" + courseName + ", employeeId=" + employeeId
                + ", employeeName=" + employeeName + ", dateAttended=" + dateAttended + "]";
    }

}

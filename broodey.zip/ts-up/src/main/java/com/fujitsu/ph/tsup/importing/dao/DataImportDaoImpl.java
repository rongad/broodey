/*
 * Copyright (C) 2020 FUJITSU LIMITED All rights reserved.
 */
package com.fujitsu.ph.tsup.importing.dao;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fujitsu.ph.tsup.importing.model.SabaDTO;
import com.fujitsu.ph.tsup.importing.model.TraineeInfo;
import com.fujitsu.ph.tsup.scheduling.domain.CourseScheduleDetail;

//==================================================================================================
//Project Name : Training Sign Up Project
//System Name  : Training Sign Up Project
//Class Name   : DataImportDaoImpl.java
//
//<<Modification History>>
//Version | Date       | Updated By            | Content
//--------+------------+-----------------------+---------------------------------------------------
//0.01    | 2021/10/13 | WS)j.lugtu            | Initial Version
//0.02    | 2021/10/13 | WS)j.lazo             | Added saveSabaImport
//0.03    | 2021/10/27 | WS)j.lazo             | Added from_saba flags
//0.04    | 2021/11/22 | WS)ju.cuevas          | Update
//==================================================================================================
@Repository
public class DataImportDaoImpl implements DataImportDao {
	
    private static Logger logger = LoggerFactory.getLogger(DataImportDaoImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * JDBC Template for Named Parameters
     */
    @Autowired
    private NamedParameterJdbcTemplate template;

	@Override
    public Set<String> loadAllUserEmail() {
    List<String> userEmail = jdbcTemplate.query("SELECT email_address FROM employee", new SingleColumnRowMapper<>(String.class));
    
    return userEmail.isEmpty() ? Collections.emptySet() : new LinkedHashSet<>(userEmail);
    }

    /**
     * Saves SABA Import data for the following tables:
     * course_attendance
     * course_participant
     * course_schedule
     * course_schedule_detail
     * 
     * @param dto SabaDTO to process
     */
    @Override
    public void saveSabaImport(SabaDTO dto) {

        //Get id (PK) value per insert in COURSE_SCHEDULE table.
        KeyHolder generatedKeyHolder = new GeneratedKeyHolder();
        String courseScheduleSql = 
                  " INSERT INTO COURSE_SCHEDULE(" 
                + "     COURSE_ID, " 
                + "     INSTRUCTOR_ID,"
                + "     VENUE_ID," 
                + "     MIN_REQUIRED," 
                + "     MAX_ALLOWED, "
                + "     STATUS, " 
                + "     FROM_SABA) " 
                + " SELECT"
                + "     (SELECT C.ID AS COURSE_ID from COURSE AS C WHERE C.COURSE_CODE = :course_code AND C.NAME = :name ),"
                + "      NULL," //set to null = no instructor since this is a SABA import)
                + "     :venue_id,"
                + "     :min_required," 
                + "     :max_allowed," 
                + "     :status,"
                + "     :from_saba"
                + " WHERE NOT EXISTS("
                + "     SELECT * FROM COURSE_SCHEDULE" 
                + "     WHERE" 
                + "         COURSE_ID = (SELECT C.ID AS COURSE_ID from COURSE AS C WHERE C.COURSE_CODE = :course_code AND C.NAME = :name )"
                + "         AND INSTRUCTOR_ID IS NULL" //set to null = no instructor since this is a SABA import)
                + "         AND VENUE_ID = :venue_id"
                + "         AND MIN_REQUIRED = :min_required"
                + "         AND MAX_ALLOWED = :max_allowed"
                + "         AND STATUS = :status"
                + "         AND FROM_SABA = :from_saba);";

        String courseScheduleIdSql = 
                  " SELECT ID FROM COURSE_SCHEDULE" 
                + " WHERE" 
                + "     COURSE_ID = (SELECT C.ID AS COURSE_ID from COURSE AS C WHERE C.COURSE_CODE=:course_code AND C.NAME = :name)"
                + "     AND INSTRUCTOR_ID IS NULL" //set to null = no instructor since this is a SABA import)
                + "     AND VENUE_ID = :venue_id"
                + "     AND MIN_REQUIRED = :min_required"
                + "     AND MAX_ALLOWED = :max_allowed"
                + "     AND STATUS = :status"
                + "     AND FROM_SABA = :from_saba";

        SqlParameterSource courseSchedParameters = new MapSqlParameterSource()
                .addValue("course_code", dto.getCourseId())
                .addValue("name", dto.getCourseTitle())
                .addValue("venue_id", 1) //static to 1 = online
                .addValue("min_required", 1) //static to 1 as default min
                .addValue("max_allowed", 99999) //static to 99999 as default max
                .addValue("status", "D") //static to D
                .addValue("from_saba", true); //static to true
        
        logger.debug("Generated Course Schedule SQL: {}", courseScheduleSql);
        template.update(courseScheduleSql, courseSchedParameters, generatedKeyHolder);
        logger.debug("Executed Course Schedule SQL: {}", courseScheduleSql);
        
        
        Long courseScheduleId = generatedKeyHolder.getKeyList().size() > 0 
                ? (Long) generatedKeyHolder.getKeys().get("id")
                : Long.parseLong(template.queryForList(courseScheduleIdSql, courseSchedParameters, String.class).get(0)) ;
        logger.debug("Generated Course Schedule ID: {}", courseScheduleId);

        //remove table header values
        dto.getTraineeInfos().remove(0);

        for (TraineeInfo traineeInfo : dto.getTraineeInfos()) {

            // Set as static 9:00AM for start time. Start date is the completion date from SABA file.
            String startDateTimeStr = traineeInfo.getCompletionDate().toString() + " 09:00:00";
            ZonedDateTime startDateTime = ZonedDateTime.parse(startDateTimeStr,
            DateTimeFormatter.ofPattern("d-MMM-yyyy HH:mm:ss").withZone(ZoneId.systemDefault()));
            
            //To get the end time, add the timeSpent from SABA file to start time (9:00AM)
            ZonedDateTime endDateTime = startDateTime.plusMinutes(Long.parseLong(traineeInfo.getTimeSpent()));

            //Set Duration to 0.0f to let the builder compute for the correct total duration.
            CourseScheduleDetail courseScheduleDetail = new CourseScheduleDetail.Builder(courseScheduleId, startDateTime, endDateTime, 0.0f).build();

            //Get id (PK) value per insert in COURSE_SCHEDULE_DETAIL table.
            KeyHolder courseSchedDetailGeneratedKeyHolder = new GeneratedKeyHolder();
            String courseScheduleDetailSql = 
            		" INSERT INTO COURSE_SCHEDULE_DETAIL(" 
                            + "     COURSE_SCHEDULE_ID,"
                            + "     SCHEDULED_START_DATETIME," 
                            + "     SCHEDULED_END_DATETIME," 
                            + "     DURATION,"
                            + "     FROM_SABA)"
                            + " SELECT "
                            + "     :course_schedule_id," 
                            + "     :scheduled_start_datetime,"
                            + "     :scheduled_end_datetime, " 
                            + "     :duration,"
                            + "     :from_saba"
                            + " WHERE NOT EXISTS( "
                            + "     SELECT * FROM COURSE_SCHEDULE_DETAIL"
                            + "     WHERE COURSE_SCHEDULE_ID = :course_schedule_id" 
                            + "         AND FROM_SABA = :from_saba);";
            
            String courseScheduleDetailIdSql =
                    " SELECT ID FROM COURSE_SCHEDULE_DETAIL"
                  + " WHERE COURSE_SCHEDULE_ID = :course_schedule_id" 
                  + "     AND FROM_SABA = :from_saba;";
            
            SqlParameterSource courseSchedDetailParameters = new MapSqlParameterSource()
                    .addValue("course_schedule_id", courseScheduleId)
                    .addValue("scheduled_start_datetime", courseScheduleDetail.getScheduledStartDateTime().toOffsetDateTime())
                    .addValue("scheduled_end_datetime", courseScheduleDetail.getScheduledEndDateTime().toOffsetDateTime())
                    .addValue("duration", courseScheduleDetail.getDuration())
                    .addValue("from_saba", true); //static to true

            logger.debug("Generated Course Schedule Detail ID: {}", courseScheduleDetailSql);

            template.update(courseScheduleDetailSql, courseSchedDetailParameters, courseSchedDetailGeneratedKeyHolder);

            logger.debug("Executed Course Schedule Detail SQL: {}", courseScheduleDetailSql);

            Long courseSchedDetailId = courseSchedDetailGeneratedKeyHolder.getKeyList().size() > 0 
                    ? (Long) courseSchedDetailGeneratedKeyHolder.getKeys().get("id")
                    : Long.parseLong(template.queryForList(courseScheduleDetailIdSql, courseSchedDetailParameters, String.class).get(0)) ;

            logger.debug("Generated Course Schedule Detail ID: {}", courseSchedDetailId);

            //Get id (PK) value per insert in COURSE_PARTICIPANT table.
            KeyHolder courseParticipantGeneratedKeyHolder = new GeneratedKeyHolder();
            String courseParticipantSql = 
                    " INSERT INTO COURSE_PARTICIPANT(" 
                  + "     COURSE_SCHEDULE_ID,"
                  + "     PARTICIPANT_ID," 
                  + "     REGISTRATION_DATE,"
                  + "     FROM_SABA)"
                  + " SELECT "
                  + "     :course_schedule_id," 
                  + "     (SELECT E.ID FROM EMPLOYEE AS E WHERE E.EMAIL_ADDRESS=:email_address LIMIT 1),"
                  + "     :registration_date,"
                  + "     :from_saba"
                  + " WHERE NOT EXISTS("
                  + "     SELECT * FROM COURSE_PARTICIPANT"
                  + "     WHERE"
                  + "         COURSE_SCHEDULE_ID = :course_schedule_id"
                  + "         AND PARTICIPANT_ID = (SELECT E.ID FROM EMPLOYEE AS E WHERE E.EMAIL_ADDRESS=:email_address LIMIT 1)" 
                  + "         AND REGISTRATION_DATE = :registration_date"
                  + "         AND FROM_SABA = :from_saba);";

            String courseParticipantIdSql = 
                    " SELECT ID FROM COURSE_PARTICIPANT"
                  + " WHERE"
                  + "     COURSE_SCHEDULE_ID = :course_schedule_id"
                  + "     AND PARTICIPANT_ID = (SELECT E.ID FROM EMPLOYEE AS E WHERE E.EMAIL_ADDRESS=:email_address LIMIT 1)" 
                  + "     AND REGISTRATION_DATE = :registration_date"
                  + "     AND FROM_SABA = :from_saba;";

            SqlParameterSource courseParticipantParameters = new MapSqlParameterSource()
                    .addValue("course_schedule_id", courseScheduleId)
                    .addValue("email_address", traineeInfo.getEmail())
                    .addValue("registration_date",
                            courseScheduleDetail.getScheduledStartDateTime().toOffsetDateTime())
                    .addValue("from_saba", true); //static to true

            logger.debug("Generated Course Participant SQL: {}", courseParticipantSql);

            template.update(courseParticipantSql, courseParticipantParameters,
                    courseParticipantGeneratedKeyHolder);

            logger.debug("Executed Course Participant SQL: {}", courseParticipantSql);

            Long courseParticipantId = courseParticipantGeneratedKeyHolder.getKeyList().size() > 0 
                    ? (Long) courseParticipantGeneratedKeyHolder.getKeys().get("id")
                    : Long.parseLong(template
                            .queryForList(courseParticipantIdSql, courseParticipantParameters, String.class).get(0)) ;

                    logger.debug("Generated Course Participant ID: {}", courseParticipantId);

          //Get id (PK) value per insert in COURSE_ATTENDANCE table.
            KeyHolder courseAttendanceGeneratedKeyHolder = new GeneratedKeyHolder();
            String courseAttendanceSql = 
                    " INSERT INTO COURSE_ATTENDANCE(" 
                  + "     COURSE_SCHEDULE_DETAIL_ID,"
                  + "     PARTICIPANT_ID," 
                  + "     STATUS," 
                  + "     LOG_IN_DATETIME," 
                  + "     LOG_OUT_DATETIME," 
                  + "     EMAIL,"
                  + "     FROM_SABA)"
                  + " SELECT "
                  + "     :course_schedule_detail_id," 
                  + "     (SELECT E.ID FROM EMPLOYEE AS E WHERE E.EMAIL_ADDRESS=:email_address LIMIT 1),"
                  + "     :status," 
                  + "     :log_in_datetime,"
                  + "     :log_out_datetime, " 
                  + "     :email_address,"
                  + "     :from_saba"
                  + " WHERE NOT EXISTS("
                  + "     SELECT * FROM COURSE_ATTENDANCE"
                  + "     WHERE"
                  + "         COURSE_SCHEDULE_DETAIL_ID = :course_schedule_detail_id"
                  + "         AND PARTICIPANT_ID = (SELECT E.ID FROM EMPLOYEE AS E WHERE E.EMAIL_ADDRESS=:email_address LIMIT 1)" 
                  + "         AND STATUS = :status" 
                  + "         AND LOG_IN_DATETIME = :log_in_datetime" 
                  + "         AND LOG_OUT_DATETIME = :log_out_datetime" 
                  + "         AND EMAIL = :email_address"
                  + "         AND FROM_SABA = :from_saba);";

            String courseAttendanceIdSql =  
                    " SELECT ID FROM COURSE_ATTENDANCE"
                  + " WHERE"
                  + "     COURSE_SCHEDULE_DETAIL_ID = :course_schedule_detail_id"
                  + "     AND PARTICIPANT_ID = (SELECT E.ID FROM EMPLOYEE AS E WHERE E.EMAIL_ADDRESS=:email_address LIMIT 1)" 
                  + "     AND STATUS = :status" 
                  + "     AND LOG_IN_DATETIME = :log_in_datetime" 
                  + "     AND LOG_OUT_DATETIME = :log_out_datetime" 
                  + "     AND EMAIL = :email_address"
                  + "     AND FROM_SABA = :from_saba";

            SqlParameterSource courseAttendanceParameters = new MapSqlParameterSource()
                    .addValue("course_schedule_detail_id", courseSchedDetailId)
                    .addValue("email_address",
                            traineeInfo.getEmail())
                    .addValue("status","P") //static to P for now
                    .addValue("log_in_datetime",
                            courseScheduleDetail.getScheduledStartDateTime().toOffsetDateTime())
                    .addValue("log_out_datetime",
                            courseScheduleDetail.getScheduledEndDateTime().toOffsetDateTime())
                    .addValue("from_saba", true); //static to true

            logger.debug("Generated Course Attendance SQL: {}", courseAttendanceSql);
            template.update(courseAttendanceSql, courseAttendanceParameters,
                    courseAttendanceGeneratedKeyHolder);
            logger.debug("Executed Course Attendance SQL: {}", courseAttendanceSql);

            Long courseAttendanceId = generatedKeyHolder.getKeyList().size() > 0 
                    ? (Long) generatedKeyHolder.getKeys().get("id")
                    : Long.parseLong(template.queryForList(courseAttendanceIdSql, courseAttendanceParameters, String.class).get(0)) ;
            logger.debug("Generated Course Attendance ID: {}", courseAttendanceId);
        }
    }
}

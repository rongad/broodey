package com.fujitsu.ph.tsup.tms.model;

import java.util.List;

public class OverallSummaryReport {
	
	private List<CourseStatus> listCourseStatus;
	private List<SummaryReport> summaryReportList;
	
	public OverallSummaryReport() {
	}

	public OverallSummaryReport(List<CourseStatus> listCourseStatus, List<SummaryReport> summaryReportList) {
		super();
		this.listCourseStatus = listCourseStatus;
		this.summaryReportList = summaryReportList;
	}	
	
	public List<SummaryReport> getSummaryReportList() {
		return summaryReportList;
	}

	public void setSummaryReportList(List<SummaryReport> summaryReportList) {
		this.summaryReportList = summaryReportList;
	}	

	public List<CourseStatus> getListCourseStatus() {
		return listCourseStatus;
	}

	public void setListCourseStatus(List<CourseStatus> listCourseStatus) {
		this.listCourseStatus = listCourseStatus;
	}
}

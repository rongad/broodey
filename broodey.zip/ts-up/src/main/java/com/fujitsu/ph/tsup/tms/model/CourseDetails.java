package com.fujitsu.ph.tsup.tms.model;

public class CourseDetails {
	private String manager;
	private String course;
	private String status;
	
	public CourseDetails() {
		super();
	}
	
	public CourseDetails(String manager, String course, String status) {
		super();
		this.manager = manager;
		this.course = course;
		this.status = status;
	}
	
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}

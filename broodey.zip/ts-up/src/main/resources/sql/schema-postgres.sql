﻿--DROP DATABASE tsup;

/*CREATE DATABASE tsup
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1; */
-- SEQUENCE: tsup."EMPLOYEE_AUTH_ID_seq"

-- DROP SCHEMA tsup;
    
CREATE SCHEMA tsup
    AUTHORIZATION postgres;

-- DROP SEQUENCE tsup."EMPLOYEE_AUTH_ID_seq";

CREATE SEQUENCE tsup."EMPLOYEE_AUTH_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."EMPLOYEE_AUTH_ID_seq"
    OWNER TO postgres;
    
-- SEQUENCE: tsup."EMPLOYEE_ID_seq"

-- DROP SEQUENCE tsup."EMPLOYEE_ID_seq";

CREATE SEQUENCE tsup."EMPLOYEE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."EMPLOYEE_ID_seq"
    OWNER TO postgres;
    
-- SEQUENCE: tsup."EMPLOYEE_ID_seq"

-- DROP SEQUENCE tsup."COURSE_ID_seq";

CREATE SEQUENCE tsup."COURSE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."COURSE_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."VENUE_ID_seq";

CREATE SEQUENCE tsup."VENUE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."VENUE_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."COURSE_SCHEDULE_ID_seq";

CREATE SEQUENCE tsup."COURSE_SCHEDULE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."COURSE_SCHEDULE_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."COURSE_SCHEDULE_DETAIL_ID_seq";

CREATE SEQUENCE tsup."COURSE_SCHEDULE_DETAIL_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."COURSE_SCHEDULE_DETAIL_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."COURSE_PARTICIPANT_ID_seq";

CREATE SEQUENCE tsup."COURSE_PARTICIPANT_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."COURSE_PARTICIPANT_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."COURSE_NON_PARTICIPANT_ID_seq";

CREATE SEQUENCE tsup."COURSE_NON_PARTICIPANT_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."COURSE_NON_PARTICIPANT_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."CERTIFICATE_ID_seq";

CREATE SEQUENCE tsup."CERTIFICATE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."CERTIFICATE_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."COURSE_ATTENDANCE_ID_seq";

CREATE SEQUENCE tsup."COURSE_ATTENDANCE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."COURSE_ATTENDANCE_ID_seq"
    OWNER TO postgres;
    
CREATE SEQUENCE tsup."DEPARTMENT_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup."DEPARTMENT_ID_seq"
    OWNER TO postgres;
    
-- DROP SEQUENCE tsup."COURSE_CATEGORY_ID_seq";

CREATE SEQUENCE tsup."COURSE_CATEGORY_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1; 

ALTER SEQUENCE tsup."COURSE_CATEGORY_ID_seq"
    OWNER TO postgres;
    
CREATE TABLE tsup.DEPARTMENT
(
    id bigint NOT NULL DEFAULT nextval('tsup."DEPARTMENT_ID_seq"'::regclass),
    department_name character varying(50) NOT NULL,
    CONSTRAINT "DEPARTMENT_pkey" PRIMARY KEY (id),
    CONSTRAINT "DEPARTMENT_NAME_unique" UNIQUE (department_name)
)

TABLESPACE pg_default;

ALTER TABLE tsup.DEPARTMENT
    OWNER to postgres;

-- Table: tsup.EMPLOYEE_AUTH

-- DROP TABLE tsup.EMPLOYEE_AUTH;

CREATE TABLE tsup.EMPLOYEE_AUTH
(
    ID bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_AUTH_ID_seq"'::regclass),
    AUTH_NAME character varying(50) COLLATE pg_catalog."default" NOT NULL,
    USERNAME character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT "EMPLOYEE_AUTH_pkey" PRIMARY KEY (ID)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.EMPLOYEE_AUTH
    OWNER to postgres;
    
-- Table: tsup.COURSE_CATEGORY

--DROP TABLE tsup.COURSE_CATEGORY;

CREATE TABLE tsup.COURSE_CATEGORY
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_CATEGORY_ID_seq"'::regclass),
    CATEGORY character varying(100) COLLATE pg_catalog."default",
    DETAIL character varying(200) COLLATE pg_catalog."default",
    CONSTRAINT "COURSE_CATEGORY_pkey" PRIMARY KEY (ID),
    CONSTRAINT "COURSE_CATEGORY_unique" UNIQUE (CATEGORY)
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_CATEGORY
    OWNER to postgres;

CREATE SEQUENCE tsup."MEMBER_ROLEID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

CREATE TABLE tsup.MEMBER_ROLE
(
    id bigint NOT NULL DEFAULT nextval('tsup."MEMBER_ROLEID_seq"'::regclass),
    role_type character varying(40),
    role_desc character varying(120),
    deleted_at timestamp,
    PRIMARY KEY (id)

)
WITH (
    OIDS = FALSE
)


TABLESPACE pg_default;

ALTER TABLE tsup.MEMBER_ROLE
    OWNER to postgres;    
    
        
-- Table: tsup.EMPLOYEE

--DROP TABLE tsup.EMPLOYEE;

CREATE TABLE tsup.EMPLOYEE
(
    id bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
    "number" character varying(10) COLLATE pg_catalog."default" NOT NULL,
    last_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    first_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    email_address character varying(50) COLLATE pg_catalog."default" NOT NULL,
    username character varying(50) COLLATE pg_catalog."default" NOT NULL,
    department_id bigint NOT NULL DEFAULT nextval('tsup."DEPARTMENT_ID_seq"'::regclass),
    member_role_id bigint NOT NULL DEFAULT nextval('tsup."MEMBER_ROLEID_seq"'::regclass),
    employment_date date NOT NULL,
    joining_date date NOT NULL,
    status character varying(20) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "EMPLOYEE_pkey" PRIMARY KEY (id),
    CONSTRAINT "EMAIL_ADDRESS_unique" UNIQUE (email_address),
    CONSTRAINT "NUMBER_unique" UNIQUE ("number"),
    CONSTRAINT "USER_NAME_unique" UNIQUE (username),
    CONSTRAINT "DEPARTMENT_ID_fkey" FOREIGN KEY (department_id) REFERENCES tsup.department (id) MATCH SIMPLE, 
    CONSTRAINT "MEMBER_ROLE_ID_fkey" FOREIGN KEY (member_role_id) REFERENCES tsup.member_role (id) MATCH SIMPLE 
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.EMPLOYEE
    OWNER to postgres;
    
-- Table: tsup.COURSE

--DROP TABLE tsup.COURSE;

CREATE TABLE tsup.COURSE
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_ID_seq"'::regclass),
    NAME character varying(150) COLLATE pg_catalog."default",
    DETAIL character varying(200) COLLATE pg_catalog."default",
    course_category_id bigint NOT NULL DEFAULT nextval('tsup."COURSE_CATEGORY_ID_seq"'::regclass),
    CONSTRAINT "COURSE_pkey" PRIMARY KEY (ID),
    CONSTRAINT "COURSE_NAME_unique" UNIQUE (NAME),
    CONSTRAINT "COURSE_CATEGORY_ID_fkey" FOREIGN KEY (course_category_id) REFERENCES tsup.COURSE_CATEGORY (id) MATCH SIMPLE
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.COURSE
    OWNER to postgres;
    
ALTER TABLE tsup.COURSE
	ADD COLUMN MANDATORY character varying(5) COLLATE pg_catalog."default",
	ADD COLUMN DEADLINE character varying(30) COLLATE pg_catalog."default";

-- Table: tsup.VENUE

--DROP TABLE tsup.VENUE;

CREATE TABLE tsup.VENUE
(
    ID bigint NOT NULL DEFAULT nextval('tsup."VENUE_ID_seq"'::regclass),
    NAME character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT "VENUE_pkey" PRIMARY KEY (ID),
    CONSTRAINT "VENUE_NAME_unique" UNIQUE (NAME)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.VENUE
    OWNER to postgres;

--DROP TABLE tsup.COURSE_SCHEDULE;
    
CREATE TABLE tsup.COURSE_SCHEDULE
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_ID_seq"'::regclass),
	COURSE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_ID_seq"'::regclass),
	INSTRUCTOR_ID bigint NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass), -- can be null for SABA import
	VENUE_ID bigint NOT NULL DEFAULT nextval('tsup."VENUE_ID_seq"'::regclass),
	MIN_REQUIRED integer NOT NULL,
	MAX_ALLOWED integer NOT NULL,
	STATUS character varying(1) NOT NULL COLLATE pg_catalog."default",
	FROM_SABA boolean NULL DEFAULT FALSE,
	CONSTRAINT "COURSE_SCHEDULE_pkey" PRIMARY KEY (ID),
	CONSTRAINT "COURSE_ID_fkey" FOREIGN KEY (COURSE_ID) REFERENCES tsup.COURSE(ID) MATCH SIMPLE ON DELETE CASCADE,
    CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (INSTRUCTOR_ID) REFERENCES tsup.EMPLOYEE(ID) MATCH SIMPLE ON DELETE CASCADE,
    CONSTRAINT "VENUE_ID_fkey" FOREIGN KEY (VENUE_ID) REFERENCES tsup.VENUE(ID) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_SCHEDULE
    OWNER to postgres;
    
--DROP TABLE tsup.COURSE_SCHEDULE_DETAIL
    
CREATE TABLE tsup.COURSE_SCHEDULE_DETAIL
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_DETAIL_ID_seq"'::regclass),
	COURSE_SCHEDULE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_ID_seq"'::regclass),
	SCHEDULED_START_DATETIME timestamp with time zone NOT NULL,
	SCHEDULED_END_DATETIME timestamp with time zone NOT NULL,
	DURATION numeric(5, 2) NOT NULL,
	rescheduled_start_datetime timestamp with time zone,
    rescheduled_end_datetime timestamp with time zone,
    FROM_SABA boolean NULL DEFAULT FALSE,
	CONSTRAINT "COURSE_SCHEDULE_DETAIL_pkey" PRIMARY KEY (ID),
	CONSTRAINT "COURSE_SCHEDULE_ID_fkey" FOREIGN KEY (COURSE_SCHEDULE_ID) REFERENCES tsup.COURSE_SCHEDULE(ID) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_SCHEDULE_DETAIL
    OWNER to postgres;
    
--DROP TABLE tsup.COURSE_PARTICIPANT;
    
CREATE TABLE tsup.COURSE_PARTICIPANT
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_PARTICIPANT_ID_seq"'::regclass),
	COURSE_SCHEDULE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_ID_seq"'::regclass),
	PARTICIPANT_ID bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
	REGISTRATION_DATE timestamp with time zone NOT NULL,
	FROM_SABA boolean NULL DEFAULT FALSE,
	CONSTRAINT "COURSE_PARTICIPANT_pkey" PRIMARY KEY (ID),
	CONSTRAINT "COURSE_SCHEDULE_ID_fkey" FOREIGN KEY (COURSE_SCHEDULE_ID) REFERENCES tsup.COURSE_SCHEDULE(ID) MATCH SIMPLE ON DELETE CASCADE,
    CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (PARTICIPANT_ID) REFERENCES tsup.EMPLOYEE(ID) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_PARTICIPANT
    OWNER to postgres;
   
--DROP TABLE tsup.COURSE_NON_PARTICIPANT;

CREATE TABLE tsup.COURSE_NON_PARTICIPANT
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_NON_PARTICIPANT_ID_seq"'::regclass),
	COURSE_SCHEDULE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_ID_seq"'::regclass),
	PARTICIPANT_ID bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
	REGISTRATION_DATE timestamp with time zone NOT NULL,
	REASON character varying(100) NOT NULL COLLATE pg_catalog."default",
	DECLINE_DATE timestamp with time zone NOT NULL,
	CONSTRAINT "COURSE_NON_PARTICIPANT_pkey" PRIMARY KEY (ID),
	CONSTRAINT "COURSE_SCHEDULE_ID_fkey" FOREIGN KEY (COURSE_SCHEDULE_ID) REFERENCES tsup.COURSE_SCHEDULE(ID) MATCH SIMPLE ON DELETE CASCADE,
    CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (PARTICIPANT_ID) REFERENCES tsup.EMPLOYEE(ID) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_NON_PARTICIPANT
    OWNER to postgres;
    
--DROP TABLE tsup.COURSE_ATTENDANCE;
    
CREATE TABLE tsup.COURSE_ATTENDANCE
(
    id bigint NOT NULL DEFAULT nextval('tsup."COURSE_ATTENDANCE_ID_seq"'::regclass),
    course_schedule_detail_id bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_DETAIL_ID_seq"'::regclass),
    participant_id bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
    status character varying(1) COLLATE pg_catalog."default" NOT NULL,
    log_in_datetime timestamp with time zone,
    log_out_datetime timestamp with time zone,
    email character varying COLLATE pg_catalog."default",
    FROM_SABA boolean NULL DEFAULT FALSE,
    CONSTRAINT "COURSE_ATTENDANCE_pkey" PRIMARY KEY (id),
    CONSTRAINT "COURSE_SCHEDULE_DETAIL_ID_fkey" FOREIGN KEY (course_schedule_detail_id)
        REFERENCES tsup.course_schedule_detail (id) MATCH SIMPLE ON DELETE CASCADE,
    CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (participant_id)
        REFERENCES tsup.employee (id) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_ATTENDANCE
    OWNER to postgres;

CREATE TABLE tsup.CERTIFICATE_UPLOAD
(
    ID bigint NOT NULL DEFAULT nextval('tsup."CERTIFICATE_ID_seq"'::regclass),
	EMPLOYEE_ID bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
	COURSE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_ID_seq"'::regclass),
	CERTIFICATE character varying(200) COLLATE pg_catalog."default",
	UPLOAD_DATE timestamp with time zone NOT NULL,
	fileDownloadUri character varying(200) COLLATE pg_catalog."default",
    CONSTRAINT "CERTIFICATE_pkey" PRIMARY KEY (ID),
	CONSTRAINT "COURSE_ID_fkey" FOREIGN KEY (COURSE_ID) REFERENCES tsup.COURSE(ID) MATCH SIMPLE ON DELETE CASCADE,
	CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (EMPLOYEE_ID) REFERENCES tsup.EMPLOYEE(ID) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.CERTIFICATE_UPLOAD
    OWNER to postgres;

--Added 2021/06/18
SET search_path = tsup;
ALTER TABLE venue
ADD COLUMN overlap boolean;

--NEW COLUMN MANDATORY TYPE and NEW TABLE FOR JDU TYPE 

CREATE SEQUENCE "JDU_TYPE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1; 
ALTER SEQUENCE "JDU_TYPE_ID_seq"  
    OWNER TO postgres;
    
CREATE TABLE JDU_TYPE
(
    ID bigint NOT NULL DEFAULT nextval('tsup."JDU_TYPE_ID_seq"'::regclass) ,
    JDU_NAME character varying(100) COLLATE pg_catalog."default",
    TIMEZONE character varying(10) COLLATE pg_catalog."default",
    CONSTRAINT "JDU_TYPE_pkey" PRIMARY KEY (id),
    CONSTRAINT "JDU_TYPE_unique" UNIQUE (jdu_name)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default; 
ALTER TABLE JDU_TYPE
    OWNER to postgres;
    
ALTER TABLE department
    ADD COLUMN JDU_ID bigint NOT NULL DEFAULT 1,
    ADD CONSTRAINT "JDU_TYPE_fkey" FOREIGN KEY (JDU_ID) REFERENCES jdu_type(ID) MATCH SIMPLE ON DELETE CASCADE;
ALTER TABLE course
    ADD COLUMN DEPARTMENT_ID bigint NOT NULL DEFAULT 1,
    ADD CONSTRAINT "DEPARTMENT_fkey" FOREIGN KEY (DEPARTMENT_ID) REFERENCES department(ID) MATCH SIMPLE ON DELETE CASCADE;

--FOR MANDATORY_TYPE
ALTER TABLE course
    ADD COLUMN mandatory_type character varying(30) DEFAULT '-';

ALTER TABLE course
	ADD CONSTRAINT MANDATORY_TYPE_check 
	CHECK (mandatory_type = '-' or mandatory_type = 'JDU' or mandatory_type = 'GDC');
	

--Added 2021/07/05
--Function for getting non-attendees
--DROP FUNCTION tsup.GET_NON_ATTENDEES(mandatoryType VARCHAR, jdutype BIGINT);
CREATE OR REPLACE FUNCTION tsup.GET_NON_ATTENDEES(mandatoryType VARCHAR, jdutype BIGINT)
RETURNS TABLE (COURSE_ID BIGINT, COURSE_NAME VARCHAR, EMPLOYEE_ID BIGINT, EMPLOYEE_NAME TEXT)
language plpgsql
as $$
begin
	return query 
	SELECT DISTINCT C.id  AS COURSE_ID,
		   C.NAME AS COURSE_NAME,
		   E.id  AS EMPLOYEE_ID,
		   CONCAT(E.last_name,', ', E.first_name) As EMPLOYEE_NAME
	FROM   tsup.employee E,
		   tsup.course C
		   INNER JOIN tsup.department D
		   ON C.department_id = D.id
	WHERE  C.mandatory = 'Yes'
		   AND C.mandatory_type = mandatoryType
		   AND D.jdu_id = jdutype
		   AND ( C.id, C.NAME, E.last_name ) NOT IN(
		   SELECT DISTINCT C.id   AS COURSE_ID,
				   C.NAME AS COURSE_NAME,
				   E.last_name
			FROM   tsup.employee E
			INNER JOIN tsup.course_attendance CA
				   ON E.id = CA.participant_id
			   INNER JOIN tsup.course_schedule_detail CSD
					   ON CSD.id = CA.course_schedule_detail_id
			   INNER JOIN tsup.course_schedule CS
					   ON CS.id = CSD.course_schedule_id
			   INNER JOIN tsup.course C
					   ON C.id = CS.course_id
			   INNER JOIN tsup.department D
					   ON C.department_id = D.id
				WHERE  C.mandatory = 'Yes'
					   AND C.mandatory_type = mandatoryType
					   AND D.jdu_id = jdutype) 
	ORDER BY COURSE_ID, EMPLOYEE_ID;
end;$$;


--ADDED 2021/07/09
CREATE SEQUENCE "TRAINING_REQUEST_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1; 
ALTER SEQUENCE "TRAINING_REQUEST_ID_seq"  
    OWNER TO postgres;
    
CREATE TABLE TRAINING_REQUEST
(
    ID bigint NOT NULL DEFAULT nextval('tsup."TRAINING_REQUEST_ID_seq"'::regclass) ,
    EMPLOYEE_ID bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
    COURSE_NAME character varying(150) COLLATE pg_catalog."default",
	MIN_REQUIRED integer NOT NULL,
	MAX_ALLOWED integer NOT NULL,
	SCHEDULED_START_DATETIME timestamp with time zone NOT NULL,
	SCHEDULED_END_DATETIME timestamp with time zone NOT NULL,
	DURATION numeric(5, 2) NOT NULL,
	STATUS character varying(10) NOT NULL COLLATE pg_catalog."default",
    REMARKS character varying(500) COLLATE pg_catalog."default",
    APPROVER_ID bigint,
    APPROVER_REMARKS character varying(500) COLLATE pg_catalog."default",
    CONSTRAINT "TRAINING_REQUEST_pkey" PRIMARY KEY (id),
    CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (EMPLOYEE_ID)
        REFERENCES tsup.employee (id) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
 
ALTER TABLE TRAINING_REQUEST
    OWNER to postgres;

--ADDED 2021/07/29
CREATE SEQUENCE "TRAINING_REQUEST_ARCHIVE_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1; 
ALTER SEQUENCE "TRAINING_REQUEST_ARCHIVE_ID_seq"  
    OWNER TO postgres;
    
CREATE TABLE TRAINING_REQUEST_ARCHIVE
(
    ID bigint NOT NULL DEFAULT nextval('tsup."TRAINING_REQUEST_ARCHIVE_ID_seq"'::regclass) ,
    TRAINING_REQUEST_ID bigint NOT NULL ,
    EMPLOYEE_ID bigint NOT NULL DEFAULT nextval('tsup."EMPLOYEE_ID_seq"'::regclass),
    COURSE_NAME character varying(150) COLLATE pg_catalog."default",
	MIN_REQUIRED integer NOT NULL,
	MAX_ALLOWED integer NOT NULL,
	SCHEDULED_START_DATETIME timestamp with time zone NOT NULL,
	SCHEDULED_END_DATETIME timestamp with time zone NOT NULL,
	DURATION numeric(5, 2) NOT NULL,
	STATUS character varying(10) NOT NULL COLLATE pg_catalog."default",
    REMARKS character varying(500) COLLATE pg_catalog."default",
    APPROVER_ID bigint,
    APPROVER_REMARKS character varying(500) COLLATE pg_catalog."default",
    CONSTRAINT "TRAINING_REQUEST_ARCHIVE_pkey" PRIMARY KEY (id),
    CONSTRAINT "EMPLOYEE_ID_fkey" FOREIGN KEY (EMPLOYEE_ID)
        REFERENCES tsup.employee (id) MATCH SIMPLE ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
 
ALTER TABLE TRAINING_REQUEST_ARCHIVE
    OWNER to postgres;
        
    
CREATE SEQUENCE tsup.batch_job_execution_seq
    INCREMENT 1
    START 10
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1; 

ALTER SEQUENCE tsup.batch_job_execution_seq
    OWNER TO postgres;
    

CREATE SEQUENCE tsup.batch_job_seq
    INCREMENT 1
    START 10
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup.batch_job_seq
    OWNER TO postgres;
    
    
CREATE SEQUENCE tsup.batch_step_execution_seq
    INCREMENT 1
    START 10
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE tsup.batch_step_execution_seq
    OWNER TO postgres;
    
CREATE TABLE tsup.batch_job_instance
(
    job_instance_id bigint NOT NULL,
    version bigint,
    job_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    job_key character varying(32) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT batch_job_instance_pkey PRIMARY KEY (job_instance_id),
    CONSTRAINT job_inst_un UNIQUE (job_name, job_key)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.batch_job_instance
    OWNER to postgres;
    

CREATE TABLE tsup.batch_job_execution
(
    job_execution_id bigint NOT NULL,
    version bigint,
    job_instance_id bigint NOT NULL,
    create_time timestamp without time zone NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    status character varying(10) COLLATE pg_catalog."default",
    exit_code character varying(2500) COLLATE pg_catalog."default",
    exit_message character varying(2500) COLLATE pg_catalog."default",
    last_updated timestamp without time zone,
    job_configuration_location character varying(2500) COLLATE pg_catalog."default",
    CONSTRAINT batch_job_execution_pkey PRIMARY KEY (job_execution_id),
    CONSTRAINT job_inst_exec_fk FOREIGN KEY (job_instance_id)
        REFERENCES tsup.batch_job_instance (job_instance_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.batch_job_execution
    OWNER to postgres;
    
    
CREATE TABLE tsup.batch_job_execution_context
(
    job_execution_id bigint NOT NULL,
    short_context character varying(2500) COLLATE pg_catalog."default" NOT NULL,
    serialized_context text COLLATE pg_catalog."default",
    CONSTRAINT batch_job_execution_context_pkey PRIMARY KEY (job_execution_id),
    CONSTRAINT job_exec_ctx_fk FOREIGN KEY (job_execution_id)
        REFERENCES tsup.batch_job_execution (job_execution_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.batch_job_execution_context
    OWNER to postgres;
    
    
CREATE TABLE tsup.batch_job_execution_params
(
    job_execution_id bigint NOT NULL,
    type_cd character varying(6) COLLATE pg_catalog."default" NOT NULL,
    key_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    string_val character varying(250) COLLATE pg_catalog."default",
    date_val timestamp without time zone,
    long_val bigint,
    double_val double precision,
    identifying character(1) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT job_exec_params_fk FOREIGN KEY (job_execution_id)
        REFERENCES tsup.batch_job_execution (job_execution_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.batch_job_execution_params
    OWNER to postgres;
    
    
CREATE TABLE tsup.batch_step_execution
(
    step_execution_id bigint NOT NULL,
    version bigint NOT NULL,
    step_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    job_execution_id bigint NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    status character varying(10) COLLATE pg_catalog."default",
    commit_count bigint,
    read_count bigint,
    filter_count bigint,
    write_count bigint,
    read_skip_count bigint,
    write_skip_count bigint,
    process_skip_count bigint,
    rollback_count bigint,
    exit_code character varying(2500) COLLATE pg_catalog."default",
    exit_message character varying(2500) COLLATE pg_catalog."default",
    last_updated timestamp without time zone,
    CONSTRAINT batch_step_execution_pkey PRIMARY KEY (step_execution_id),
    CONSTRAINT job_exec_step_fk FOREIGN KEY (job_execution_id)
        REFERENCES tsup.batch_job_execution (job_execution_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.batch_step_execution
    OWNER to postgres;
    
    
CREATE TABLE tsup.batch_step_execution_context
(
    step_execution_id bigint NOT NULL,
    short_context character varying(2500) COLLATE pg_catalog."default" NOT NULL,
    serialized_context text COLLATE pg_catalog."default",
    CONSTRAINT batch_step_execution_context_pkey PRIMARY KEY (step_execution_id),
    CONSTRAINT step_exec_ctx_fk FOREIGN KEY (step_execution_id)
        REFERENCES tsup.batch_step_execution (step_execution_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.batch_step_execution_context
    OWNER to postgres;


-- ADDED 2021/09/21
ALTER TABLE course
    ADD COLUMN course_code character varying(30) DEFAULT NULL;

-- ADDED 2021/09/21
 CREATE SEQUENCE "survey_form_id_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;
    
   -- Table: survey_form

-- DROP TABLE survey_form;

CREATE TABLE survey_form
(
    id bigint NOT NULL DEFAULT nextval('tsup.survey_form_id_seq'::regclass),
	COURSE_SCHEDULE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_SCHEDULE_ID_seq"'::regclass),
    coursetitle character varying COLLATE pg_catalog."default" NOT NULL,
    trainingvenue character varying COLLATE pg_catalog."default" NOT NULL,
    instructorname character varying COLLATE pg_catalog."default" NOT NULL,
    coursedatetime timestamp with time zone NOT NULL,
    mdquestion1 integer NOT NULL,
    mdquestion2 integer NOT NULL,
    mdquestion3 integer NOT NULL,
    mdquestion4 integer NOT NULL,
    matquestion1 integer NOT NULL,
    matquestion2 integer NOT NULL,
    matquestion3 integer NOT NULL,
    matquestion4 integer NOT NULL,
    insquestion1 integer NOT NULL,
    insquestion2 integer NOT NULL,
    insquestion3 integer NOT NULL,
    insquestion4 integer NOT NULL,
    insquestion5 integer NOT NULL,
    insquestion6 integer NOT NULL,
    eqfaquestion1 integer NOT NULL,
    eqfaquestion2 integer NOT NULL,
    eqfaquestion3 integer NOT NULL,
    commentse character varying COLLATE pg_catalog."default",
    commentsf character varying COLLATE pg_catalog."default",
    commentsg character varying COLLATE pg_catalog."default",
    CONSTRAINT "SURVEY_FORM_pkey" PRIMARY KEY (id),
	CONSTRAINT "COURSE_SCHEDULE_ID_fkey" FOREIGN KEY (COURSE_SCHEDULE_ID) REFERENCES tsup.COURSE_SCHEDULE(ID) MATCH SIMPLE ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE survey_form
    OWNER to postgres;    
    
-- ADDED 2021/10/15
-- COURSE TAG MAP
CREATE SEQUENCE tsup."COURSE_TAG_MAP_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

CREATE TABLE COURSE_TAG_MAP
(
    ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_TAG_MAP_ID_seq"'::regclass),
    COURSE_ID bigint NOT NULL DEFAULT nextval('tsup."COURSE_ID_seq"'::regclass),
	TAG_ID bigint NOT NULL DEFAULT nextval('tsup."MEMBER_ROLEID_seq"'::regclass),
	CONSTRAINT "COURSE_TAG_MAP_pkey" PRIMARY KEY (ID),
	CONSTRAINT "COURSE_ID_fkey" FOREIGN KEY (COURSE_ID) REFERENCES tsup.COURSE(ID) MATCH SIMPLE ON DELETE CASCADE,
	CONSTRAINT "TAG_ID_fkey" FOREIGN KEY (TAG_ID) REFERENCES tsup.MEMBER_ROLE(ID) MATCH SIMPLE ON DELETE CASCADE
	
)
WITH (
    OIDS = FALSE
)

TABLESPACE pg_default;

ALTER TABLE tsup.COURSE_TAG_MAP
    OWNER to postgres;



--Added 2021/11/10
-- Table: tsup.course_checklist
CREATE SEQUENCE tsup."COURSE_CHECKLIST_ID_seq"
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1; 
CREATE TABLE tsup.course_checklist
(
    id bigint NOT NULL DEFAULT nextval('tsup."COURSE_CHECKLIST_ID_seq"'::regclass),
    requirement character varying(255) COLLATE pg_catalog."default" NOT NULL,
    course_id bigint NOT NULL DEFAULT nextval('tsup."COURSE_ID_seq"'::regclass),
    CONSTRAINT "COURSE_CHECKLIST_pkey" PRIMARY KEY (id),
    CONSTRAINT "COURSE_ID_fkey" FOREIGN KEY (course_id)
        REFERENCES tsup.course (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.course_checklist
    OWNER to postgres;

-- Table: tsup.employee_checklist
CREATE TABLE tsup.employee_checklist
(
    id bigint NOT NULL GENERATED BY DEFAULT AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    is_Accomplished boolean NOT NULL,
    course_participant_id bigint NOT NULL,
    course_schedule_id bigint NOT NULL,
    course_checklist_id bigint NOT NULL,
    CONSTRAINT "EMPLOYEE_CHECKLIST_pkey" PRIMARY KEY (id),
    CONSTRAINT employee_checklist_course_checklist_id_fkey FOREIGN KEY (course_checklist_id)
        REFERENCES tsup.course_checklist (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT employee_checklist_course_participant_id_fkey FOREIGN KEY (course_participant_id)
        REFERENCES tsup.course_participant (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT employee_checklist_course_schedule_id_fkey FOREIGN KEY (course_schedule_id)
        REFERENCES tsup.course_schedule (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE tsup.employee_checklist
    OWNER to postgres;
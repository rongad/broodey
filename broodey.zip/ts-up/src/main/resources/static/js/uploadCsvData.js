var ajaxCall;

$(document).ready(function () {
	if (window.location.href.indexOf('#uploadSuccessModal') != -1) {
		showUploadSuccessModal();
	} else if (window.location.href.indexOf('#uploadFailModal') != -1){
		showUploadFailModal();
	}

});

$("#browseBtn").change(function() {
	var fileName = this.value;
	document.getElementById("uploadFile").value = fileName.substring(12);
	document.getElementById("fileName").innerHTML = " [File Name : "+ fileName.substring(12) + "]";
});



//Validation
$(document).ready((function() {
	'use strict';
	window.addEventListener('load', function() {
		// fetch all the forms we want to apply custom style
		var inputs = document.getElementsByClassName('needs-validation')
		// loop over each input and watch blue event
		var validation = Array.prototype.filter.call(inputs, function(input) {

			input.addEventListener('change', function(event) {
				// reset
				input.classList.remove('is-invalid')
				input.classList.remove('is-valid')
				var file = event.target.files[0];
				
				
				if (!isFileTypeValid(file)) {
					input.classList.add('is-invalid')
					document.getElementById("fileErrorMsg").innerHTML = "*CSV/Excel is required";
					$("#uploadButton").prop('disabled', true);
				}
				else {
					$("#uploadButton").prop('disabled', false);
					document.getElementById("fileErrorMsg").innerHTML = "";
				}
			}, false);
		});
	}, false);
}));


function courseCategoryValidation() {
		var format = /[^a-zA-Z0-9 ]/g;
		var inputs = document.getElementsByClassName('needs-validation')
		// loop over each input and watch blue event
		var validation = Array.prototype.filter.call(inputs, function(input) {

			input.addEventListener('blur', function(event) {
				// reset
				input.classList.remove('is-invalid');
				input.classList.remove('is-valid');
				var category = input.value;

				var trimCategory = myTrim(category);
				if (trimCategory.length == 0) {
					input.classList.add('is-invalid');
					$("#continueBtn").prop('disabled', true);
				}else if(trimCategory.length >= 100) {
					input.classList.add('is-invalid');
					$("#continueBtn").prop('disabled', true);
				} else if(trimCategory.match(format)) {
					$("#continueBtn").prop('disabled', true);
					input.classList.add('is-invalid');
				} else {
					input.classList.remove('is-invalid');
					input.classList.remove('is-valid');
					$("#continueBtn").prop('disabled', false);
					
					var categoryinputId = "categoryId" + input.id.substring(14, 15);
					
					var categoryId = $('option[value="' +category + '"]').data('value');
					if(categoryId) {
						document.getElementById(categoryinputId).value = categoryId;
					} else {
						document.getElementById(categoryinputId).value = null;
					}
	
				}
				
			
		
			}, false);
		});	
}

function myTrim(stringToTrim) {
	return stringToTrim.replace(/^\s+|\s+$/gm, '');
}

function isFileTypeValid(file) {
	
	if(!file){
		return false;
	}
	
	const allowedFileType = [
		"text/csv", 
		"application/vnd.ms-excel", 
		"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
		];

	return allowedFileType.includes(file.type);
	
}


function showSetCourseCategoryModal() {
	$('#setCategoryModal').modal('show');
}

function showNoImportedDataModalyModal() {
	$('#noImportedDataModal').modal('show');
}

function showProgressBar() {
	showProgressBarModal();
	hideConfirmationModal();
	startUploading();
}

function showUploadSuccessModal() {
	var successMessageContent = $('#successModalMessage').html();
	var successTitle = undefined;
	var successFooter = $('#successModalFooter').html();
	messageModalPrompt(successMessageContent,"success",successTitle,successFooter);
	//$('#uploadSuccessModal').modal('show');
}

function showUploadFailModal() {
	var errorMessageContent = $('#errorMessageContent').html();
	var errorTitle = 'Upload Error';
	var errorFooter = $('#errorMessageFooter').html();
	messageModalPrompt(errorMessageContent,"fail",errorTitle,errorFooter);
}

function showConfirmationModal() {
	
	var fileVal = document.getElementById("browseBtn").value;
	
	if (fileVal === "") {
		document.getElementById("fileErrorMsg").innerHTML = "*CSV/Excel is required";
		$("#uploadButton").prop('disabled', true);
	}
	else {
		$('#uploadConfirmationModal').modal('show');
	}

}

function showProgressBarModal() {
	$('#progressBarModal').modal('show');
}

function hideConfirmationModal() {
	$('#uploadConfirmationModal').modal('hide');
}

function hideUploadSuccessModal() {
	$('#uploadSuccessModal').modal('hide');
}

function hideProgressBarModal() {
	$('#progressBarModal').modal('hide');
}

/* Globle variables */
var totalFileCount, fileUploadCount, fileSize, successCount;

/* start uploading files */
function startUploading() {
	var files = document.getElementById('browseBtn').files;
	if (files.length == 0) {
		alert("Please choose at least one file and try.");
		return;
	}
	fileUploadCount = 0;
	successCount = 0;
	prepareProgressBarUI(files);

	// upload through ajax call     
	uploadFile();
}

/* This method will be called to prepare progress-bar UI */
function prepareProgressBarUI(files) {
	totalFileCount = files.length;
	var $tbody = $("#progress-bar-container").find("tbody");
	$tbody.empty();
	$("#upload-header-text").html("1 of " + totalFileCount + " file(s) is uploading");
	for (var i = 0; i < totalFileCount; i++) {
		var fsize = parseFileSize(files[i].size);
		var fname = files[i].name;
		var bar = '<tr id="progress-bar-' + i + '"><td style="width:75%"><div class="filename">' + fname + '</div>'
			+ '<div class="progress"><div class="progress-bar progress-bar-striped active" style="width:0%"></div></div><div class="error-msg text-danger"></div></td>'
			+ '<td  style="width:25%"><span class="size-loaded"></span> ' + fsize + ' <span class="percent-loaded"></span></td></tr>';
		$tbody.append(bar);
	}
	$("#upload-status-container").show();
}

/* parse the file size in kb/mb/gb */
function parseFileSize(size) {
	var precision = 1;
	var factor = Math.pow(10, precision);
	size = Math.round(size / 1024); //size in KB
	if (size < 1000) {
		return size + " KB";
	} else {
		size = Number.parseFloat(size / 1024); //size in MB
		if (size < 1000) {
			return (Math.round(size * factor) / factor) + " MB";
		} else {
			size = Number.parseFloat(size / 1024); //size in GB
			return (Math.round(size * factor) / factor) + " GB";
		}
	}
	return 0;
}

function cancelUpload() {
	ajaxCall.abort();
}

/* one by one file will be uploaded to the server by ajax call*/
function uploadFile() {

	var formData = new FormData();
	var file = document.getElementById('browseBtn').files[fileUploadCount];
	formData.append("multipartFile", file);
	
	 ajaxCall = $.ajax({
        type: "POST",
        url: "/tsup/dataUpload/upload",
        xhr: function () {
            var myXhr = $.ajaxSettings.xhr();
            if (myXhr.upload) {
                myXhr.upload.addEventListener('progress', onUploadProgress, false);
                myXhr.upload.addEventListener('load', onUploadComplete, false);
            }
            return myXhr;
        },
        success: function (data) {
			$('.modal').modal('hide');
			setTimeout(function() {
				$('#uploadFragment').replaceWith(data);
				
				var errorMsg = document.getElementById('errorMsg').innerHTML;
				if (errorMsg) {
					hideProgressBarModal();
					showUploadFailModal();
					clearUploadForm();
				} else {
					var setCourseCategoryTableRowsCount = $('#setCourseCategoryTable tr').length;
					if (setCourseCategoryTableRowsCount > 1) {
						showSetCourseCategoryModal();
					} else {
						showUploadSuccessModal();
					}
					clearUploadForm();
				}
			}, 500);	
        },
		 error: function(error) {
			if(error.statusText === "error"){
				document.getElementById('errorMsg').innerHTML = error.responseText;
			} else if (error.statusText === "abort") {
				document.getElementById('errorMsg').innerHTML = "Upload Has Been Cancel!";
			}
			 
			 setTimeout(function() {
				 hideProgressBarModal();
				 showUploadFailModal();
				 clearUploadForm();
			 }, 500);
		 },
        async: true,
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        timeout: 60000
    });

}

/* This function will continueously update the progress bar */
function onUploadProgress(e) {
	if (e.lengthComputable) {
		var loaded = e.loaded;
		var percentComplete = parseInt((loaded) * 100 / fileSize);
		if (percentComplete < 100) {
			var pbar = $('#progress-bar-' + fileUploadCount);
			var bar = pbar.find(".progress-bar");
			var sLoaded = pbar.find(".size-loaded");
			var pLoaded = pbar.find(".percent-loaded");
			bar.css("width", percentComplete + '%');
			sLoaded.html(parseFileSize(loaded) + " / ");
			pLoaded.html("(" + percentComplete + "%)");
		}
	} else {
		messageModalPrompt('Unable to compute', "fail");
	}
}

/* This function will call when upload is completed */
function onUploadComplete(e, error) {
	var pbar = $('#progress-bar-' + fileUploadCount);
	var bar = pbar.find(".progress-bar");
	if (error) {
		bar.removeClass("active").addClass("progress-bar-danger");
		pbar.find(".error-msg").html(e.currentTarget.responseText || "Something went wrong!");
	} else {
		bar.removeClass("active");
		bar.css("width", '100%');
		var sLoaded = pbar.find(".size-loaded");
		var pLoaded = pbar.find(".percent-loaded");
		sLoaded.html('<i class="fa fa-check text-success"></i> ');
		pLoaded.html("(100%)");
		successCount++;
	}
	fileUploadCount++;
	if (fileUploadCount < totalFileCount) {
		//ajax call if more files are there 
		uploadFile();
	}
}

/* This function will call when an error come while uploading */
function onUploadError(e) {
	onUploadComplete(e, true);
}

function clearUploadForm() {
	$("#uploadCSV").trigger("reset");
	$("#uploadButton").prop('disabled', false);
}